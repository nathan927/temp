import assert from 'node:assert/strict';
import {test} from 'node:test';
import {runFinalPhonetics} from '../acceptance/final-phonetics/run.mjs';
import {html} from './helpers.mjs';

test('5,000 additional near-sound orders resolve locally or stop safely',async()=>{
 const result=await runFinalPhonetics(html);
 assert.equal(result.unique,5000);
 assert.equal(result.failed,0,JSON.stringify(result.examples,null,2));
 assert.equal(result.passed,5000);
 assert.equal(result.unsafe,0);
 assert.equal(result.apiCalls,0);
});

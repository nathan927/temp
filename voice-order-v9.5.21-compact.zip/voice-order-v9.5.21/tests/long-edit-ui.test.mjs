import assert from 'node:assert/strict';
import {test} from 'node:test';
import {next,ui} from './ui-fixture.mjs';

const cart=[
 {id:'A',uid:'a',qty:1,drink:'凍奶茶'},
 {id:'B',uid:'b',qty:3,drink:'凍奶茶'},
 {id:'C',uid:'c',qty:1,drink:'凍奶茶'},
 {id:'D',uid:'d',qty:1,drink:'凍檸茶'},
 {id:'B',uid:'e',qty:1,drink:'凍咖啡'},
 {id:'F',uid:'f',qty:1,drink:'熱奶茶'},
];
async function say(f,text,alternatives=[]){
 await f.click('#home-mic');
 f.context.kamMicEvent(f.session,'result',{text,alternatives,peak:.1});
 for(let i=0;i<6;i++)await next();
}
const notice=f=>f.document.querySelector('#voice-error').textContent;

test('one portion splits, the next original line changes, and one undo restores both',async()=>{
 const f=ui(cart);
 await say(f,'第2行其中一份改少甜，同一份改走冰，第三行改飛邊');
 const lines=f.state().cart;
 assert.deepEqual(lines.map(({id,qty})=>[id,qty]),[['A',1],['B',2],['B',1],['C',1],['D',1],['B',1],['F',1]]);
 assert.equal(lines[1].sugar,'正常甜');
 assert.equal(lines[2].sugar,'少甜');assert.equal(lines[2].ice,'走冰');
 assert.equal(lines.find(line=>line.uid==='c').toast,'飛邊');
 await f.click('[data-action="undo"]');
 assert.deepEqual(f.state().cart.map(({id,qty})=>[id,qty]),cart.map(({id,qty})=>[id,qty]));
 assert.equal(f.state().cart.find(line=>line.uid==='c').toast,'正常多士');
});

test('duplicate set name shows numbered options and applies only the selected row',async()=>{
 const f=ui(cart);
 await say(f,'早餐B改走冰');
 assert.deepEqual(f.state().cart,cart);
 const button=f.document.querySelector('[data-target="e"]');
 assert.match(button.textContent,/5\./);assert.match(button.textContent,/凍咖啡/);
 await f.click('[data-target="e"]');
 assert.equal(f.state().cart.find(line=>line.uid==='e').ice,'走冰');
 assert.equal(f.state().cart.find(line=>line.uid==='b').ice,'正常冰');
});

test('unheard second edit says exactly which clause needs checking and changes nothing',async()=>{
 const f=ui(cart);
 await say(f,'第二行改少甜，第三行改做青玉雲朵');
 assert.deepEqual(f.state().cart,cart);
 assert.match(notice(f),/第三行改做青玉雲朵/);
 assert.match(notice(f),/成句改單未套用/);
});

test('different device candidates pause for confirmation rather than changing the primary row',async()=>{
 const f=ui(cart);
 await say(f,'第二行改走冰',['第三行改走冰']);
 assert.deepEqual(f.state().cart,cart);
 assert.ok(f.document.querySelector('[data-voice-candidate]'));
});

test('a sold-out dish in a partial addition is explained as sold out',async()=>{
 const f=ui([],{state:{version:2,cart:[],orders:[],lang:'tc',settings:{},availability:{T2:false},prices:{},mode:'dinein',table:2}});
 await say(f,'一份菠蘿油，一杯凍檸茶');
 assert.deepEqual(f.state().cart.map(line=>line.id),['P1']);
 assert.match(notice(f),/賣晒/);
 assert.match(notice(f),/凍檸茶/);
 assert.doesNotMatch(notice(f),/未聽實/);
});

test('unknown native errors show a recovery message without exposing the raw error',async()=>{
 const f=ui(cart);
 await f.click('#home-mic');
 f.context.kamMicEvent(f.session,'error',{code:'micInternalForTest',message:'raw backend diagnostic'});
 for(let i=0;i<6;i++)await next();
 assert.match(notice(f),/再試一次/);
 assert.doesNotMatch(notice(f),/micInternalForTest|raw backend diagnostic/);
 assert.deepEqual(f.state().cart,cart);
});

test('the nine context groups each rotate sixteen unique replies in Cantonese and English',()=>{
 const f=ui(cart),L=f.context.I18n;
 const codes=['missingTarget','notApplicable','invalidQty','soldOut','micDenied','network','allergyConfirm','partialUnresolved','unexpectedFailure'];
 for(const lang of ['tc','en']){
  const all=[];
  for(const code of codes){
   const messages=Array.from({length:16},()=>L.failureLead(code,lang));
   assert.equal(new Set(messages).size,16);
   assert.equal(L.failureLead(code,lang),messages[0]);
   all.push(...messages);
  }
  assert.equal(new Set(all).size,144);
 }
});

test('a conflicting whole-order note is explained before saving a row edit',async()=>{
 const f=ui(cart,{state:{version:2,cart,orders:[],lang:'tc',settings:{},availability:{},prices:{},orderNotes:['全部走冰'],mode:'dinein',table:2}});
 await say(f,'第三行改少冰');
 assert.deepEqual(f.state().cart,cart);
 assert.deepEqual(f.state().orderNotes,['全部走冰']);
 assert.match(notice(f),/整單備註/);
 assert.match(notice(f),/餐肉雙蛋早餐/);
});

test('an ambiguous same-line drink replacement pauses the entire edit',async()=>{
 const f=ui(cart);
 await say(f,'第二行其中一份改少甜，同一份改凍檸茶');
 assert.deepEqual(f.state().cart,cart);
 assert.match(notice(f),/同一份改凍檸茶/);
 assert.match(notice(f),/成句改單未套用/);
});

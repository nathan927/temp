import assert from 'node:assert/strict';
import fs from 'node:fs';
import {test} from 'node:test';
import vm from 'node:vm';
import {html,inlineScripts} from './helpers.mjs';
import {ui} from './ui-fixture.mjs';

const source=process.env.V959_TEST_HTML?fs.readFileSync(process.env.V959_TEST_HTML,'utf8'):html;
const compiledScripts=inlineScripts(source).map((script,index)=>new vm.Script(script,{filename:'app-'+index+'.js'}));
// Keep the real built HTML and scripts, omitting only embedded photo bytes from the test DOM.
const shell=source.replace(/<script\b[^>]*>[\s\S]*?<\/script>/g,'').replace(/data:image\/[^;"]+;base64,[\w+/=]+/g,'data:image/png;base64,');
const profiles=[
 {name:'Android Chrome',userAgent:'Mozilla/5.0 (Linux; Android 15; Pixel 8) Chrome/141.0 Mobile Safari/537.36',prefixed:true},
 {name:'Android Samsung Internet',userAgent:'Mozilla/5.0 (Linux; Android 14; SM-S921B) SamsungBrowser/28.0 Chrome/130.0 Mobile Safari/537.36',prefixed:true},
 {name:'Android reduced UA',userAgent:'Mobile browser',uaMobile:true},
 {name:'iOS Safari',userAgent:'Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) Version/18.7 Mobile Safari/604.1',prefixed:true,ios:true},
 {name:'iOS Home Screen',userAgent:'Mozilla/5.0 (iPhone; CPU iPhone OS 26_0 like Mac OS X) AppleWebKit/605.1.15 Mobile/15E148',prefixed:true,ios:true,standalone:true},
 {name:'iPad Safari desktop UA',userAgent:'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15) Version/26.0 Safari/605.1.15',platform:'MacIntel',touch:5,prefixed:true,ios:true},
];
const drafts=[[],[{id:'P1',qty:1}],[{id:'P3',qty:2}],[{id:'T3',qty:1,drink:'凍咖啡'}],[{id:'C',qty:2,drink:'熱奶茶'},{id:'P14',qty:1}]];
const promptDelays=[0,1,250,5000,59999],resultDelays=[0,1,250,3000,4499];

function clock(){
 const timers=new Map();let time=0,serial=0;
 return {now:()=>time,set(fn,ms=0){timers.set(++serial,{at:time+ms,fn});return serial;},
  clear:id=>timers.delete(id),advance(ms){
   const until=time+ms;
   while(true){
    const next=[...timers].filter(([,t])=>t.at<=until).sort(([,a],[,b])=>a.at-b.at)[0];
    if(!next)break;
    timers.delete(next[0]);time=next[1].at;next[1].fn();
   }
   time=until;
  }};
}
const result=(text,final=true,...alts)=>Object.assign([text,...alts].map(transcript=>({transcript})),{isFinal:final});
const flush=async()=>{for(let i=0;i<4;i++)await Promise.resolve();};

function fixture(profile,cart,overrides={}){
 const scheduler=clock(),recognizers=[],starts=[],downloads=[];
 let gesture=false,pcmCalls=0,apiCalls=0,stops=0,processor;
 const stream=()=>{const track={kind:'audio',readyState:'live',enabled:true,addEventListener(){},removeEventListener(){},
  stop(){this.readyState='ended';stops++;}};return {getTracks:()=>[track],getAudioTracks:()=>[track]};};
 const node=()=>({connect(){},disconnect(){}});
 class Audio {
  sampleRate=16000;destination={};
  async resume(){} async close(){}
  createMediaStreamSource(){return node();}
  createScriptProcessor(){return processor=node();}
  createGain(){return {...node(),gain:{value:0}};}
 }
 class Recognition {
  constructor(){recognizers.push(this);}
  start(...args){
   starts.push({gesture,args:args.length,lang:this.lang});
   if(!gesture||args.length)throw Object.assign(new Error('Mobile device mic requires a gesture and its own input'),{name:'NotAllowedError'});
  }
  stop(){this.stopCalls=(this.stopCalls||0)+1;}
  abort(){this.abortCalls=(this.abortCalls||0)+1;}
 }
 const permission={state:overrides.permission||'prompt'};
 const navigator={userAgent:profile.userAgent,platform:profile.platform,maxTouchPoints:profile.touch,
  userAgentData:profile.uaMobile?{mobile:true}:undefined,standalone:profile.standalone,
  get userActivation(){return {isActive:gesture};},
  permissions:overrides.query==='missing'?undefined:{query:async()=>{
   if(overrides.query==='reject')throw new TypeError('Browser lacks microphone permission query');
   return permission;
  }},mediaDevices:{getUserMedia:async()=>{pcmCalls++;return stream();}}};
 const protocol=overrides.protocol||'https:';
 class TestURL extends URL {
  static createObjectURL(blob){downloads.push(blob);return 'blob:https://example.test/fixture';}
  static revokeObjectURL(){}
 }
 const f=ui(cart,{html:shell,compiledScripts,fetch:async()=>{apiCalls++;throw Error('Unexpected API call');},
  environment:{KamNative:undefined,navigator,AudioContext:Audio,URL:TestURL,isSecureContext:!overrides.insecure,
   location:{protocol,origin:'https://example.test'},performance:{now:scheduler.now},
   setTimeout:scheduler.set,clearTimeout:scheduler.clear,
   [profile.prefixed?'webkitSpeechRecognition':'SpeechRecognition']:overrides.noSpeech?undefined:Recognition}});
 const createElement=f.document.createElement.bind(f.document);
 f.document.createElement=(name,...args)=>{
  const element=createElement(name,...args);
  if(name==='audio')element.play=async()=>{};
  return element;
 };
 if(overrides.policy)f.document.permissionsPolicy={allowsFeature:()=>false};
 let hidden=false;
 Object.defineProperty(f.document,'hidden',{get:()=>hidden});
 const click=async selector=>{
  gesture=true;const clicked=f.click(selector);gesture=false;await clicked;await flush();
 };
 const visibility=value=>{hidden=value;f.document.dispatchEvent(new f.window.Event('visibilitychange'));};
 const reset=next=>{
  f.context.kamStop();hidden=false;
  recognizers.length=starts.length=downloads.length=0;pcmCalls=apiCalls=stops=0;
  permission.state=next.permission||'prompt';
  f.context.location.protocol=next.protocol||'https:';f.context.isSecureContext=!next.insecure;
 };
 const mic=()=>recognizers.at(-1);
 const tap=()=>click('#home-mic');
 const say=(text,final=true,...alts)=>mic().onresult?.({results:[result(text,final,...alts)]});
 const grant=()=>{permission.state='granted';permission.onchange?.();mic().onstart?.();mic().onaudiostart?.();};
 const report=()=>JSON.parse(f.context.KamDebug.microphoneReport());
 return {...f,click,tap,visibility,reset,mic,say,grant,scheduler,starts,downloads,report,
  get processor(){return processor;},get pcmCalls(){return pcmCalls;},get stops(){return stops;},get apiCalls(){return apiCalls;}};
}
const cartOf=f=>(f.state().cart||[]).map(({id,qty,drink})=>({id,qty,drink}));
const micButton=f=>f.document.querySelector('#home-mic');
const errorBox=f=>f.document.querySelector('#voice-error');
const events=f=>f.report().attempts.at(-1)?.events||[];
function idle(f){assert.equal(micButton(f).disabled,false,'voice button must recover');assert.equal(micButton(f).getAttribute('aria-pressed'),'false');}
function unchanged(f,before){assert.deepEqual(cartOf(f),before);assert.equal((f.state().orders||[]).length,0);}
function errorIs(f,code,before){
 idle(f);unchanged(f,before);assert.equal(errorBox(f).hidden,false);assert.notEqual(errorBox(f).dataset.reply,'success');
 assert.ok(errorBox(f).querySelector('[data-action="voice-mic-help"]'));
 assert.ok(errorBox(f).querySelector('[data-action="mic-report"]'));
 assert.equal(events(f).findLast(e=>e.event==='attempt.failed')?.code,code);
}
function armed(f,number=1){
 assert.equal(f.starts.length,number);
 assert.deepEqual(f.starts.at(-1),{gesture:true,args:0,lang:'zh-HK'});
 assert.equal(f.pcmCalls,0,'a second audio owner would contend for the mobile mic');
 assert.equal(micButton(f).disabled,true,'pending prompt must suppress duplicate start');
}
async function finishOrder(f,before,text='一份炸雞翼',id='S1'){
 f.say(text);f.mic().onend?.();await flush();
 idle(f);
 const after=cartOf(f);
 assert.equal(after.length,before.length+1);assert.deepEqual(after.slice(0,-1),before);
 assert.equal(after.at(-1).id,id);assert.equal(after.at(-1).qty,1);
 assert.equal((f.state().orders||[]).length,0);
 assert.ok(events(f).some(e=>e.event==='attempt.result'&&e.textCharacters>0));
}
const cases=[
 {name:'first permission grant',run:async(f,b,i)=>{await f.tap();armed(f);f.scheduler.advance(promptDelays[i]);f.grant();await finishOrder(f,b);}},
 {name:'granted site retries',options:{permission:'granted'},run:async(f,b,i)=>{
  await f.tap();armed(f);f.grant();await finishOrder(f,b);
  const last=cartOf(f);await f.tap();armed(f,2);f.scheduler.advance(promptDelays[i]);f.grant();await finishOrder(f,last,'一份薯條','S3');
 }},
 {name:'Permissions API unsupported',options:{query:'missing'},run:async(f,b,i)=>{
  await f.tap();armed(f);assert.equal(events(f).find(e=>e.event==='permission.query')?.state,'unsupported');
  f.scheduler.advance(promptDelays[i]);f.grant();await finishOrder(f,b);
 }},
 {name:'Permissions query throws',options:{query:'reject'},run:async(f,b,i)=>{
  await f.tap();armed(f);assert.equal(events(f).find(e=>e.event==='permission.query')?.state,'unknown');
  f.scheduler.advance(promptDelays[i]);f.grant();await finishOrder(f,b);
 }},
 {name:'deny microphone',run:async(f,b,i)=>{await f.tap();armed(f);f.scheduler.advance(promptDelays[i]);f.mic().onerror({error:'not-allowed'});errorIs(f,'micSpeechDenied',b);}},
 {name:'allow after denial',run:async(f,b,i)=>{
  await f.tap();armed(f);f.mic().onerror({error:'not-allowed'});errorIs(f,'micSpeechDenied',b);
  f.scheduler.advance(promptDelays[i]);await f.click('#voice-error [data-action="record"]');armed(f,2);f.grant();await finishOrder(f,b);
 }},
 ...[
  ['speech service blocked','service-not-allowed','micSpeechUnavailable',false],
  ['speech network error','network','micSpeechNetwork',true],
  ['speech language unavailable','language-not-supported','micSpeechLanguage',true],
  ['audio capture unavailable','audio-capture','micBusy',false],
  ['speech service heard nothing','no-speech','micNoMatch',true],
 ].map(([name,browserCode,code,listening])=>({name,run:async(f,b,i)=>{
  await f.tap();armed(f);if(listening)f.grant();f.scheduler.advance(listening?resultDelays[i]:promptDelays[i]);
  f.mic().onerror({error:browserCode});errorIs(f,code,b);
  assert.ok(events(f).some(e=>e.event==='recognition.error'&&e.browserCode===browserCode));
 }})),
 {name:'permission prompt timeout and late callback',run:async(f,b,i)=>{
  await f.tap();armed(f);const stale=f.mic().onresult;f.scheduler.advance(60000);
  f.scheduler.advance(resultDelays[i]);stale({results:[result('一份炸雞翼')]});errorIs(f,'micPromptTimeout',b);
 }},
 {name:'manual stop waits for final words',run:async(f,b,i)=>{
  await f.tap();armed(f);f.grant();await f.tap();assert.equal(f.mic().stopCalls,1);
  f.scheduler.advance(resultDelays[i]);await finishOrder(f,b);
 }},
 {name:'manual stop times out without final words',run:async(f,b,i)=>{
  await f.tap();armed(f);f.grant();f.scheduler.advance(resultDelays[i]);await f.tap();
  assert.equal(f.mic().stopCalls,1);f.scheduler.advance(4500);errorIs(f,'micRecognitionTimeout',b);
 }},
 {name:'background aborts active audio and ignores stale words',run:async(f,b,i)=>{
  await f.tap();armed(f);f.grant();const stale=f.mic().onresult;f.visibility(true);
  f.scheduler.advance(resultDelays[i]);stale({results:[result('一份炸雞翼')]});assert.equal(f.mic().abortCalls,1);unchanged(f,b);
  f.visibility(false);await f.tap();armed(f,2);f.grant();await finishOrder(f,b);
 }},
 {name:'system sheet hides page while permission is pending',run:async(f,b,i)=>{
  await f.tap();armed(f);f.visibility(true);f.scheduler.advance(promptDelays[i]);assert.equal(f.mic().abortCalls,undefined);
  f.visibility(false);f.grant();await finishOrder(f,b);
 }},
 {name:'insecure page refuses capture',options:{protocol:'http:',insecure:true},code:'micInsecure'},
 {name:'embedding policy blocks microphone',options:{policy:true},code:'micPolicy'},
 {name:'download and chat previews',options:(profile,i)=>({protocol:(profile.ios?['file:','blob:','data:']:['content:','file:','blob:'])[i%3],insecure:i%2===0}),code:'micPreview'},
 {name:'unavailable SpeechRecognition API',options:{noSpeech:true},code:'micSpeechUnavailable'},
];

async function prepareDraft(f,draft){
 const existing=cartOf(f);
 if(existing.length===draft.length&&draft.every((row,i)=>row.id===existing[i].id&&row.qty===existing[i].qty&&
  (row.drink===undefined||row.drink===existing[i].drink)))return;
 if(cartOf(f).length){
  await f.click('#cart-panel [data-action="clear"]');
  await f.click('#modal [data-action="clear-confirm"]');
 }
 for(const item of draft){
  await f.click('[data-add="'+item.id+'"]');
  if(item.drink)await f.click('[data-option="drink"][data-value="'+item.drink+'"]');
  for(let i=1;i<item.qty;i++)await f.click('[data-draftqty="1"]');
  await f.click('#modal [data-action="save-item"]');
 }
 assert.deepEqual(cartOf(f).map(({id,qty})=>({id,qty})),draft.map(({id,qty})=>({id,qty})));
}
let fixtureKey,fixtureForScenario;
for(const [p,profile] of profiles.entries()){
 if(process.env.V959_SHARD!==undefined&&p!==Number(process.env.V959_SHARD))continue;
 for(const scenario of cases){
  const key=profile.name+'/'+scenario.name;
  for(const [d,draft] of drafts.entries())for(let i=0;i<5;i++){
   test(`${profile.name} / ${scenario.name} / draft ${d+1} / timing ${i+1}`,async()=>{
    const options=(typeof scenario.options==='function'?scenario.options(profile,i):scenario.options)||{};
    if(fixtureKey!==key){fixtureForScenario=fixture(profile,[],options);fixtureKey=key;}
    const f=fixtureForScenario;
    f.reset(options);
    await prepareDraft(f,draft);
    const before=cartOf(f);
    if(scenario.run)await scenario.run(f,before,i);
    else{f.scheduler.advance(promptDelays[i]);await f.tap();errorIs(f,scenario.code,before);assert.equal(f.starts.length,0);assert.equal(f.pcmCalls,0);}
    assert.equal(f.apiCalls,0);
   });
  }
 }
}

if(process.env.V959_SHARD===undefined||process.env.V959_SHARD==='0'){
 test('Android reported breakfast A path: interim without a final is logged and never orders; retry succeeds',async()=>{
  const f=fixture(profiles[0],[]);
  await f.tap();armed(f);f.grant();f.say('早餐A',false);f.mic().onend();
  errorIs(f,'micNoMatch',[]);
  assert.ok(events(f).some(e=>e.event==='recognition.result'&&e.rows===1&&e.finalRows===0));
  assert.ok(events(f).some(e=>e.event==='recognition.ended'&&e.finalCharacters===0));
  await f.click('#voice-error [data-action="mic-report"]');
  const json=await f.downloads[0].text();
  assert.doesNotMatch(json,/早餐A|password|API.?key|base64/i);
  assert.equal(JSON.parse(json).attempts.length,1);
  await f.click('#voice-error [data-action="record"]');armed(f,2);f.grant();await finishOrder(f,[],'早餐A','A');
  assert.equal(f.apiCalls,0);
 });
 test('public iOS microphone test releases its audio track before the next voice order',async()=>{
  const f=fixture(profiles[3],[]);
  await f.tap();armed(f);f.mic().onerror({error:'not-allowed'});
  await f.click('#voice-error [data-action="voice-mic-help"]');
  assert.ok(f.document.querySelector('#mic-test-status'));assert.equal(f.document.querySelector('#settings-password'),null);
  await f.click('#modal [data-action="test-mic"]');
  f.processor.onaudioprocess({inputBuffer:{getChannelData:()=>new Float32Array(4096).fill(.1)}});
  await f.click('#modal [data-action="finish-mic-test"]');
  assert.ok(f.document.querySelector('#mic-test-playback audio'));
  assert.equal(f.stops,1);assert.equal(f.pcmCalls,1);
  await f.click('#modal [data-action="close"]');
  await f.tap();f.grant();await finishOrder(f,[],'早餐A','A');
  assert.equal(f.pcmCalls,1);assert.equal(f.apiCalls,0);
 });
}

if(process.env.V959_SHARD===undefined||process.env.V959_SHARD==='0'){
 for(const profile of [profiles[0],profiles[3]]){
  test(profile.name+' replays 凍檸茶 then 專業飲 on the same draft line',async()=>{
   const f=fixture(profile,[]);
   await f.tap();armed(f);f.grant();await finishOrder(f,[],'凍檸茶','T2');
   const [before]=f.state().cart;
   assert.equal(before.drink,'凍檸茶');
   await f.tap();armed(f,2);f.grant();f.say('專業飲');f.mic().onend();await flush();
   assert.deepEqual(f.state().cart.map(i=>[i.uid,i.qty,i.drink]),[[before.uid,1,'熱檸茶']]);
   assert.equal(errorBox(f).dataset.reply,'success');
   assert.equal(f.apiCalls,0);
  });
 }
 test('Android 專業飲 offers a choice between two drinks and changes only the one selected',async()=>{
  const f=fixture(profiles[0],[]);
  await f.tap();armed(f);f.grant();await finishOrder(f,[],'凍檸茶','T2');
  await f.tap();armed(f,2);f.grant();await finishOrder(f,cartOf(f),'凍奶茶','T1');
  const before=cartOf(f),[lemon,milk]=f.state().cart;
  await f.tap();armed(f,3);f.grant();f.say('專業飲');f.mic().onend();await flush();
  unchanged(f,before);
  const buttons=f.document.querySelectorAll('#modal [data-target]');
  assert.equal(buttons.length,2);
  await f.click('[data-target="'+lemon.uid+'"]');
  assert.deepEqual(f.state().cart.map(i=>[i.uid,i.drink]),[[lemon.uid,'熱檸茶'],[milk.uid,'凍奶茶']]);
  assert.equal(f.apiCalls,0);
 });
}

if(process.env.V959_SHARD===undefined||process.env.V959_SHARD==='0'){
 test('Android assigns each near-sound quantity to its own order clause',async()=>{
  const f=fixture(profiles[0],[]);
  await f.tap();armed(f);f.grant();f.say('豬拍包兩芬，凍西洋菜密三碑');f.mic().onend();await flush();
  assert.deepEqual(f.state().cart.map(({id,qty,drink})=>[id,qty,drink]),[['P17',2,''],['T7',3,'凍西洋菜蜜']]);
  assert.equal(errorBox(f).dataset.reply,'success');
  assert.equal(f.apiCalls,0);
 });
}

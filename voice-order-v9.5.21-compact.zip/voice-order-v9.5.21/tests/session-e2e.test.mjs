import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {ui,next,waitFor} from './ui-fixture.mjs';

const original=process.env.V958_TEST_HTML?fs.readFileSync(process.env.V958_TEST_HTML,'utf8'):undefined;
const sets='ABCDE',quantity='零一兩三四五';
const dishes=[['P3','腿蛋治',28],['S1','炸雞翼',32],['P1','菠蘿油',24],['P2','西多士',32],['T3','熱咖啡',22]];
const names=['沙嗲牛肉早餐','火腿通粉早餐','餐肉雙蛋早餐','叉燒湯麵早餐','腸仔煎蛋早餐'];
const setPrices=[42,39,40,45,41];
const months=['2026-11-04','2026-12-31','2027-01-01','2027-02-28','2028-02-29'];
const storage=map=>({getItem:k=>map.get(k)??null,setItem:(k,v)=>map.set(k,v),removeItem:k=>map.delete(k)});
const pause=async()=>{for(let i=0;i<6;i++)await next();};
const act=(f,key)=>f.click('[data-action="'+key+'"]');
const modalAct=(f,key)=>f.click('#modal [data-action="'+key+'"]');
const row=(f,id)=>f.document.querySelector('[data-submitted-order="'+id+'"]');
async function say(f,text,alternatives=[]){
 await f.click('#home-mic');f.context.kamMicEvent(f.session,'result',{text,alternatives,peak:.1});await pause();
}
async function send(f,count,close=true){
 await act(f,'confirm');await waitFor(()=>f.state().orders?.length===count&&f.document.querySelector('.receipt'));
 const order=f.state().orders[0];if(close)await modalAct(f,'close');return order;
}
function expectSession(f,order){
 const displayed=row(f,order.id);assert.ok(displayed,'submitted order is visible on home');
 assert.match(displayed.textContent,new RegExp('\\$'+order.total));
 assert.equal(displayed.querySelectorAll('li').length,order.items.length);
}
function boot({store=new Map(),session=new Map(),navigation='navigate',date}={}){
 const clock=date?class extends Date{
  constructor(...args){super(...(args.length?args:[date]));}
  static now(){return Date.parse(date);}
 }:Date;
 return ui([],{store,html:original,environment:{
  Date:clock,sessionStorage:storage(session),performance:{now:()=>performance.now(),getEntriesByType:()=>[{type:navigation}]},
 }});
}
async function draftSet(f,n,set){await say(f,quantity[n]+'份早餐'+set);}
async function defer(f,n,set){await draftSet(f,n,set);await act(f,'defer-drink');}
const families=[
 'receipt-to-home','defer-then-submit','defer-then-choose','fill-submitted-drink','refresh-keeps-history','navigation-keeps-session',
 'new-draft-is-separate','discard-amendment','reload-during-amendment','order-number-and-history','choose-between-deferred-orders','ready-partial-drink',
];
for(const [familyIndex,family] of families.entries())for(let variant=0;variant<5;variant++)for(let n=1;n<=5;n++){
 if(process.env.V958_E2E_SHARD!==undefined&&familyIndex%4!==Number(process.env.V958_E2E_SHARD))continue;
 test('E2E '+family+' '+(variant+1)+'/'+n,async()=>{
  const set=sets[variant],food=dishes[variant],store=new Map(),session=new Map();
  const date=months[variant]+'T'+(n%2?'16':'15')+':0'+n+':00.000Z';
  const f=boot({store,session,date});
  switch(family){
   case 'receipt-to-home':{
    await say(f,quantity[n]+'份'+food[1]);const o=await send(f,1);
    expectSession(f,o);assert.equal(f.state().cart.length,0);
    await act(f,'home');expectSession(f,o);
    await act(f,'orders');await modalAct(f,'close');expectSession(f,o);
    assert.equal(f.document.querySelector('[data-cart-status]').textContent,'已下單');
    break;
   }
   case 'defer-then-submit':{
    await defer(f,n,set);assert.deepEqual(f.state().cart.map(i=>[i.id,i.qty,i.drinkStatus]),[[set,n,'deferred']]);
    assert.equal(f.state().orders.length,0);assert.match(f.document.querySelector('#cart-items').textContent,new RegExp(names[variant]));
    const o=await send(f,1);expectSession(f,o);
    assert.equal(o.total,setPrices[variant]*n);assert.equal(o.items[0].drink,'待選飲品');
    assert.ok(row(f,o.id).querySelector('[data-amend]'));break;
   }
   case 'defer-then-choose':{
    await defer(f,n,set);await act(f,'choose-drink');await f.click('[data-option="drink"][data-value="凍檸茶"]');await modalAct(f,'save-item');
    assert.equal(f.state().cart[0].drink,'凍檸茶');assert.equal(f.state().cart[0].qty,n);
    const o=await send(f,1);assert.equal(o.total,(setPrices[variant]+3)*n);expectSession(f,o);break;
   }
   case 'fill-submitted-drink':{
    await defer(f,n,set);const o=await send(f,1);
    await say(f,quantity[n]+'杯凍檸茶');assert.ok(f.document.querySelector('.amend-banner'));
    await send(f,1);
    const updated=f.state().orders[0];assert.equal(updated.id,o.id);assert.equal(updated.revision,2);
    assert.deepEqual(updated.items.map(i=>[i.id,i.qty,i.drink]),[[set,n,'凍檸茶']]);expectSession(f,updated);break;
   }
   case 'refresh-keeps-history':{
    await say(f,quantity[n]+'份'+food[1]);const o=await send(f,1);
    const g=boot({store,session,navigation:'reload'});
    assert.equal(row(g,o.id),null);assert.equal(g.state().orders.length,1);
    await act(g,'orders');await g.click('#modal [data-receipt="'+o.id+'"]');
    assert.ok(g.document.querySelector('.ticket').textContent.includes(o.id));break;
   }
   case 'navigation-keeps-session':{
    await say(f,quantity[n]+'份'+food[1]);const o=await send(f,1);
    const g=boot({store,session,navigation:n%2?'back_forward':'navigate'});
    expectSession(g,o);assert.equal(g.state().cart.length,0);break;
   }
   case 'new-draft-is-separate':{
    await say(f,quantity[n]+'份'+food[1]);const o=await send(f,1);
    await say(f,'一份果占多士');expectSession(f,o);assert.deepEqual(f.state().cart.map(i=>i.id),['P14']);
    await act(f,'clear');await modalAct(f,'clear-confirm');
    assert.equal(f.state().cart.length,0);expectSession(f,o);break;
   }
   case 'discard-amendment':{
    await defer(f,n,set);const o=await send(f,1);
    await say(f,'一份果占多士');const draft=f.state().cart;
    await f.click('[data-submitted-order="'+o.id+'"] [data-amend]');
    await say(f,quantity[n]+'杯凍檸茶');await act(f,'discard-amend');
    assert.deepEqual(f.state().cart,draft);assert.equal(f.state().orders[0].revision,1);expectSession(f,o);break;
   }
   case 'reload-during-amendment':{
    await defer(f,n,set);const o=await send(f,1,false);
    await f.click('#modal [data-amend]');await say(f,quantity[n]+'杯凍檸茶');
    const g=boot({store,session,navigation:'reload'});
    assert.equal(g.state().cart.length,0);assert.equal(g.state().orders[0].items[0].drink,'待選飲品');
    assert.equal(g.document.querySelector('.amend-banner'),null);assert.equal(row(g,o.id),null);break;
   }
   case 'order-number-and-history':{
    await say(f,quantity[n]+'份'+food[1]);const o=await send(f,1);
    await say(f,'一份果占多士');const other=await send(f,2);
    assert.match(o.id,/^KK-\d{6}-[A-Z0-9]{8}$/);assert.notEqual(o.id,other.id);
    const hk=new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Hong_Kong',dateStyle:'short'}).format(new Date(date)).replace(/-/g,'').slice(2);
    assert.ok(o.id.startsWith('KK-'+hk+'-'));
    expectSession(f,o);expectSession(f,other);
    const saved=f.state();saved.orders[1].id='KK-26-11-04T16:-CB3E6';f.store.set('kamkee.v2',JSON.stringify(saved));
    const g=boot({store,session,navigation:'reload'});await act(g,'orders');assert.ok(g.document.querySelector('#modal [data-receipt="KK-26-11-04T16:-CB3E6"]'));break;
   }
   case 'choose-between-deferred-orders':{
    await defer(f,n,set);const a=await send(f,1);
    await defer(f,n,sets[(variant+1)%5]);const b=await send(f,2);
    await say(f,quantity[n]+'杯凍檸茶');assert.equal(f.document.querySelectorAll('[data-followup-order]').length,2);
    await f.click('[data-followup-order="'+a.id+'"]');await send(f,2);
    const first=f.state().orders.find(o=>o.id===a.id),second=f.state().orders.find(o=>o.id===b.id);
    assert.equal(first.revision,2);assert.equal(first.items[0].drink,'凍檸茶');
    assert.equal(second.revision,1);assert.equal(second.items[0].drink,'待選飲品');break;
   }
   case 'ready-partial-drink':{
    await defer(f,n,set);const o=await send(f,1);
    const saved=f.state();saved.orders[0].status='ready';f.store.set('kamkee.v2',JSON.stringify(saved));
    const g=boot({store,session,navigation:'back_forward'});
    await g.click('[data-submitted-order="'+o.id+'"] [data-amend]');await say(g,'一杯凍檸茶');await send(g,1);
    const updated=g.state().orders[0],drinks=updated.items.filter(i=>updated.drinkUids.includes(i.uid));
    assert.equal(updated.id,o.id);assert.equal(updated.fulfillment,'drinks');assert.equal(updated.status,'received');
    assert.deepEqual(drinks.map(i=>[i.id,i.qty,i.drink]),[[set,1,'凍檸茶']]);
    assert.equal(updated.items.reduce((total,i)=>total+i.qty,0),n);assert.equal(updated.total,setPrices[variant]*n+3);
    expectSession(g,updated);break;
   }
  }
 });
}

import {test} from 'node:test';
import assert from 'node:assert/strict';
import {ui,next} from './ui-fixture.mjs';

async function say(f,text){await f.click('#home-mic');f.context.kamMicEvent(f.session,'result',{text,alternatives:[],peak:.1});for(let i=0;i<8;i++)await next();}

test('one long order retains all seven independently customized meals',async()=>{
 const f=ui();await say(f,'一份早餐A凍檸茶少冰，兩份早餐B熱奶茶少甜，一份早餐C熱檸茶，一份早餐D熱咖啡丁麵，一份早餐E凍鴛鴦，一份早餐F熱檸茶，一份腿蛋治飛邊');
 const cart=f.state().cart;
 assert.equal(cart.length,7);
 assert.deepEqual(cart.map(i=>[i.id,i.qty]),[['A',1],['B',2],['C',1],['D',1],['E',1],['F',1],['P3',1]]);
 assert.equal(cart[0].ice,'少冰');assert.equal(cart[1].sugar,'少甜');assert.equal(cart[3].noodle,'出前一丁');assert.equal(cart[6].toast,'飛邊');
});

test('the other portion and the remaining portions still identify their dishes',async()=>{
 const f=ui();await say(f,'一份早餐A，另一份早餐B，其餘兩份早餐C');
 assert.deepEqual(f.state().cart.map(i=>[i.id,i.qty]),[['A',1],['B',1],['C',2]]);
 assert.equal(f.document.querySelector('#voice-error').dataset.reply,'success');
 assert.match(f.document.querySelector('#voice-error').textContent,/加咗 2 份/);
});

test('missed fragments leave the clear dishes visible and ask only for the missed part',async()=>{
 const f=ui();await say(f,'一份早餐A凍檸茶，一份烏龍飛，一份腿蛋治飛邊');
 assert.deepEqual(f.state().cart.map(i=>i.id),['A','P3']);
 const message=f.document.querySelector('#voice-error').textContent;
 assert.match(message,/2 份/);assert.match(message,/一份烏龍飛/);assert.match(message,/淨係再講呢截/);
 await say(f,'一份菠蘿油');assert.deepEqual(f.state().cart.map(i=>i.id),['A','P3','P1']);
});

test('ambiguous edit mixed into long order does not add any dish',async()=>{
 const f=ui();await say(f,'一份早餐A，改叫早餐B，唔知乜');
 assert.equal((f.state().cart||[]).length,0);assert.equal((f.state().orders||[]).length,0);
});

test('allergy or whole-order service clause does not become a silent partial add',async()=>{
 const f=ui(),K=f.context.Kam;
 const allergy=K.analyzeLocal('一份早餐A，花生敏感但係唔知點做',[],{});
 assert.equal(allergy.plan?.partialUnresolved,undefined);
 const service=K.analyzeLocal('一份早餐A，轉外賣',[],{});
 assert.equal(service.plan?.partialUnresolved,undefined);
 assert.equal(service.plan?.mode,'takeaway');
});

test('132 friendly voice variants are distinct and recognition guidance stays visible',async()=>{
 const f=ui(),copy=f.context.I18n.voiceFailCopy;
 const variants=Array.from({length:132},()=>copy('tc'));
 assert.equal(new Set(variants).size,132);
 assert.ok(variants.every(x=>/講|再試|重|一次|一轉|多轉|再嚟|再話/.test(x)));
 await f.click('#home-mic');f.context.kamMicEvent(f.session,'error',{code:'micNoMatch'});for(let i=0;i<5;i++)await next();
 const message=f.document.querySelector('#voice-error').textContent;
 assert.match(message,/講|再試|重/);assert.match(message,/測試收音|測試麥克風|咪高峰/);
});

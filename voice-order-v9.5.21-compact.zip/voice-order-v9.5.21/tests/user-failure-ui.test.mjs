import assert from 'node:assert/strict';
import {test}from 'node:test';
import {load,html,plain}from './helpers.mjs';
import {ui,next,waitFor}from './ui-fixture.mjs';
import {runUserFailures}from '../acceptance/user-failures/run.mjs';
import {originalCases}from '../acceptance/user-failures/originals.mjs';
async function say(f,text,alternatives=[]){await f.click('#home-mic');f.context.kamMicEvent(f.session,'result',{text,alternatives,peak:.1});for(let i=0;i<8;i++)await next();}
const box=f=>f.document.querySelector('#voice-error');
const stats=f=>JSON.parse(f.store.get('kamkee.voice-statistics.v1'));
const signature=items=>items.map(({id,qty,drink,sugar})=>({id,qty,drink,sugar}));

test('42 original recordings replay in declared contexts; three must ask or refuse',async()=>{
 const r=await runUserFailures(html,originalCases(),{historical:true});
 assert.equal(r.total,42);assert.equal(r.passed,42,JSON.stringify(r.examples));assert.equal(r.guarded,3);assert.equal(r.apiCalls,0);
});
test('10,000 new field-derived scenarios validate every item, price and portion order',async()=>{
 const r=await runUserFailures(html);assert.equal(r.total,10000);assert.equal(r.passed,10000,JSON.stringify(r.examples));assert.equal(r.unique,10000);assert.equal(r.guarded,2000);assert.equal(r.fulfilled,8000);assert.equal(r.apiCalls,0);
});
test('observed breakfast C drink, follow-on repeat and changed repeat update receipts',async()=>{
 const f=ui();await say(f,'一份早餐試飲熱奶茶');assert.deepEqual(signature(f.state().cart),[{id:'C',qty:1,drink:'熱奶茶',sugar:'正常甜'}]);
 await say(f,'嚟多份');assert.equal(f.state().cart[0].qty,2);assert.match(box(f).textContent,/加咗 1 份/);
 await say(f,'我要多一份但要凍檸茶少甜');assert.equal(f.state().cart.length,2);assert.equal(f.state().cart[1].drink,'凍檸茶');assert.equal(f.state().cart[1].sugar,'少甜');assert.match(box(f).textContent,/凍檸茶/);
});
test('波餐 add then 改要個bo餐 edits only the open meal and preserves beverage',async()=>{
 const f=ui();await say(f,'一份早餐A凍檸茶');await say(f,'改要個bo餐');assert.equal(f.state().cart.length,1);assert.equal(f.state().cart[0].id,'B');assert.equal(f.state().cart[0].drink,'凍檸茶');
 await say(f,'我要個波餐');assert.equal(f.state().cart.reduce((n,i)=>n+i.qty,0),2);assert.equal(f.state().cart[1].drink,'待選飲品');
});
test('CDE aliases add 2-7 person orders and a middle-row customization stays scoped',async()=>{
 const f=ui();await say(f,'一份早餐先熱奶茶兩份早餐啲凍檸茶三份早餐衣熱咖啡');
 assert.deepEqual(f.state().cart.map(i=>[i.id,i.qty]),[['C',1],['D',2],['E',3]]);
 await say(f,'第二行飲品轉熱奶茶少甜');assert.equal(f.state().cart[0].drink,'熱奶茶');assert.equal(f.state().cart[1].drink,'熱奶茶');assert.equal(f.state().cart[1].sugar,'少甜');assert.equal(f.state().cart[2].drink,'熱咖啡');
});
test('unknown clause adds known items and asks only about the unheard food',async()=>{
 const f=ui();await say(f,'一份早餐先熱奶茶，兩份bo餐凍檸茶，青玉雲朵');assert.deepEqual(f.state().cart.map(i=>[i.id,i.qty]),[['C',1],['B',2]]);
 assert.match(box(f).textContent,/青玉雲朵/);assert.match(box(f).textContent,/加咗/);
});
test('only one selected drink can change temperature while other sets are pending',async()=>{
 const f=ui();await say(f,'一份早餐A，一份早餐B凍檸茶，一份早餐C');await say(f,'專業飲');
 assert.deepEqual(f.state().cart.map(i=>i.drink),['待選飲品','熱檸茶','待選飲品']);await say(f,'凍');assert.equal(f.state().cart[1].drink,'凍檸茶');
});
test('recommendation next is contextual and retains the draft and dietary preferences',async()=>{
 const f=ui();await say(f,'一份早餐A凍檸茶');const before=JSON.stringify(f.state().cart);
 await say(f,'餵有咩介紹');assert.match(f.document.querySelector('#recommendation-slot').textContent,/推介|介紹/);
 await say(f,'換一套呀');assert.equal(JSON.stringify(f.state().cart),before);assert.equal(stats(f).messages.at(-1).intent,'recommend');
 const K=f.context.Kam,r=K.analyzeLocal('換一些',f.state().cart,{recommendationActive:true,recoFilter:{noPork:true}});assert.deepEqual(plain(r.plan.filter),{});
});
test('cancel draft keeps submitted orders and the question 要唔要喇 never removes items',async()=>{
 const f=ui();await say(f,'一份早餐A凍檸茶');await f.click('[data-action="confirm"]');await waitFor(()=>f.state().orders?.length===1&&f.document.querySelector('.receipt'));await f.click('#modal [data-action="close"]');
 const submitted=JSON.stringify(f.state().orders);assert.ok(f.state().orders.length);
 await say(f,'一杯凍奶茶');const before=JSON.stringify(f.state().cart);await say(f,'要唔要喇');assert.equal(JSON.stringify(f.state().cart),before);assert.match(box(f).textContent,/想取消邊份/);
 await say(f,'取消訂單');assert.equal(f.state().cart.length,0);assert.equal(JSON.stringify(f.state().orders),submitted);
 await say(f,'取消訂單');assert.equal(JSON.stringify(f.state().orders),submitted);assert.match(box(f).textContent,/我的訂單/);
});
test('mode near-sound command and its negation preserve all food and notes',async()=>{
 const f=ui();await say(f,'一份早餐A凍檸茶');await say(f,'轉外賣');const cart=JSON.stringify(f.state().cart);await say(f,'煮飯堂食');assert.equal(f.state().mode,'dinein');assert.equal(JSON.stringify(f.state().cart),cart);
 await say(f,'轉外賣');await say(f,'唔好煮飯堂食');assert.equal(f.state().mode,'takeaway');
});
test('new B/C homophones with conflicting candidates require confirmation',()=>{
 const K=load().Kam;
 for(const text of ['波餐','bo餐','早餐波','早餐先','早餐啲'])assert.throws(()=>K.resolveDeviceVoice({localText:text,localAlternatives:['早餐A']}),e=>e.code==='confirmTranscript',text);
});
test('repeat generalizations preserve explicit new items and other quantities',()=>{
 const K=load().Kam,cart=[K.normalize({id:'C',uid:'c',qty:2,drink:'熱奶茶'})];
 for(const text of ['我要多一份','加返份','添多份','唔該幫我要多份']){
  const p=K.resolveDeviceVoice({localText:text,cart}).plan;const result=K.applyPlan(cart,p);assert.equal(result.items.length,2);assert.equal(result.items[1].qty,1);assert.equal(result.items[1].id,'C');
 }
 const p=K.resolveDeviceVoice({localText:'加返兩份早餐B凍檸茶',cart}).plan;const result=K.applyPlan(cart,p);assert.equal(result.items[1].id,'B');assert.equal(result.items[1].qty,2);
});
test('voice statistics retain before/after draft, final candidates and version with no credentials',async()=>{
 const f=ui();await say(f,'一份早餐A凍檸茶');await say(f,'嚟多份',['嚟多一份']);
 const m=stats(f).messages.at(-1);assert.equal(m.appVersion,'9.5.21');assert.equal(m.context.cart[0].qty,1);assert.equal(m.after.cart[0].qty,2);assert.deepEqual(m.alternatives,['嚟多一份']);assert.equal(m.capture.origin,'home');
 const Store=f.context.KamVoiceStatistics.Store,s=new Store({storage:f.context.KamLocale.storage});const exp=JSON.parse(s.export());assert.equal(exp.appVersion,'9.5.21');assert.equal(exp.data.messages.at(-1).context.cart[0].qty,1);assert.equal(exp.data.messages.at(-1).after.cart[0].qty,2);
 assert.equal(exp.summary.counts.localFirstPass,2);
});
test('snapshot is captured at recording start and contains no settings or API keys',async()=>{
 const f=ui();await say(f,'一份早餐A凍檸茶');await f.click('#home-mic');
 const snap=f.micOptions.draftContext;assert.equal(snap.cart[0].qty,1);assert.equal(snap.settings,undefined);assert.equal(snap.orders,undefined);assert.equal(snap.submittedOrderCount,0);
 f.context.kamMicEvent(f.session,'result',{text:'加多份',peak:.1});for(let i=0;i<8;i++)await next();assert.equal(stats(f).messages.at(-1).context.cart[0].qty,1);
});
test('no final device text records a capture failure and never invents a food order',async()=>{
 const f=ui();await say(f,'一份早餐A');const before=JSON.stringify(f.state().cart);await say(f,'');assert.equal(JSON.stringify(f.state().cart),before);
 const m=stats(f).messages.at(-1);assert.equal(m.status,'failed');assert.equal(m.text,'');assert.equal(m.initial.reason,'noDeviceTranscript');assert.equal(m.context.cart[0].id,'A');assert.ok(m.error);
});
test('statistics preserve long accepted transcripts and sanitize bounded export context',()=>{
 const c=load(),s=new c.KamVoiceStatistics.Store(),text='一份早餐A熱奶茶，'.repeat(80);assert.ok(text.length>240);
 s.begin({id:'long',deviceText:true,text,alternatives:Array(10).fill('短句'),context:{cart:[{id:'A',uid:'a',qty:1}],mode:'takeaway',settings:{apiKey:'secret'},apiKey:'secret',orderNotes:['API_KEY=sk-private-value']}});
 const raw=JSON.parse(s.export()),m=raw.data.messages[0];assert.equal(m.text,text);assert.equal(m.alternatives.length,1);assert.equal(m.context.apiKey,undefined);assert.equal(m.context.settings,undefined);assert.equal(m.context.mode,'takeaway');assert.doesNotMatch(JSON.stringify(m.context),/sk-private-value/);
});
test('historical statistics have unknown context instead of a fabricated current snapshot',()=>{
 const c=load(),memory=new Map(),storage={getItem:k=>memory.get(k)||null,setItem:(k,v)=>memory.set(k,v)},s=new c.KamVoiceStatistics.Store({storage});s.begin({id:'old',text:'早餐A',deviceText:true});s.finish('old');const saved=JSON.parse(memory.get('kamkee.voice-statistics.v1'));delete saved.messages[0].context;delete saved.messages[0].appVersion;memory.set('kamkee.voice-statistics.v1',JSON.stringify(saved));
 const r=JSON.parse(new c.KamVoiceStatistics.Store({storage}).export());assert.equal(r.data.messages[0].context,undefined);assert.equal(r.data.messages[0].appVersion,undefined);assert.equal(r.summary.counts.received,1);
});

test('context-rich logs archive settled history before the size budget is exceeded',()=>{
 const c=load(),s=new c.KamVoiceStatistics.Store({limit:500,maxChars:12000}),cart=['A','B','C','D'].map((id,i)=>({id,uid:'row-'+i,qty:1,drink:'凍檸茶'}));
 for(let n=0;n<40;n++){s.begin({id:'budget-'+n,deviceText:true,text:'早餐A',context:{cart}});s.finish('budget-'+n,{after:{cart}});}
 const r=s.report();assert.equal(r.counts.received,40);assert.equal(r.counts.resolved,40);assert.ok(r.messages.length<40);assert.ok(r.messages.length>0);assert.equal(r.messages.at(0).id,'budget-39');assert.ok(JSON.stringify(s.data).length<=12000);assert.equal(r.storageAvailable,true);
});

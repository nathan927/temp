import {test} from 'node:test';
import assert from 'node:assert/strict';
import {load} from './helpers.mjs';
function fixture(extra={}){
 let stopped=0,requests=0;
 const track={kind:'audio',enabled:true,muted:false,readyState:'live',stop(){stopped++;this.readyState='ended';},addEventListener(){},removeEventListener(){},getSettings(){return {sampleRate:48000,channelCount:1,deviceId:'private-device'};}};
 const stream={getTracks:()=>[track],getAudioTracks:()=>[track]};
 const node=()=>({connect(){},disconnect(){}});
 class Audio {constructor(){this.state='suspended';this.sampleRate=48000;this.destination={};}resume(){this.state='running';return Promise.resolve();}close(){this.state='closed';return Promise.resolve();}createMediaStreamSource(){return node();}createScriptProcessor(){return node();}createGain(){return {...node(),gain:{value:0}};}}
 const env={isSecureContext:true,location:{protocol:'https:',origin:'https://example.test'},document:{visibilityState:'visible',addEventListener(){},permissionsPolicy:{allowsFeature:()=>true}},navigator:{permissions:{query:async()=>({state:'prompt'})},mediaDevices:{getUserMedia:async()=>{requests++;return stream;}}},AudioContext:Audio,...extra};
 const context=load(env),states=[],errors=[],results=[];
 const mic=new context.KamMicrophone.Microphone({onState:s=>states.push(s),onError:e=>errors.push(e),onResult:r=>results.push(r)});
 return {context,mic,states,errors,results,stream,track,get stopped(){return stopped;},get requests(){return requests;}};
}
test('denied permission preserves raw error and recovery',async()=>{
 const raw=Object.assign(new Error('User denied microphone permission'),{name:'NotAllowedError'});
 const f=fixture({navigator:{mediaDevices:{getUserMedia:async()=>{throw raw;}}}});
 await f.mic.start({test:true});assert.equal(f.errors[0].code,'micDenied');assert.equal(f.mic.active,false);
 const log=f.context.KamDebug.export();assert.match(log,/NotAllowedError/);assert.match(log,/User denied/);assert.match(log,/getUserMedia.rejected/);assert.match(log,/handling/);
});
test('insecure and policy failures stop before requesting media',async()=>{
 for(const [env,code] of [[{isSecureContext:false},'micInsecure'],[{document:{addEventListener(){},permissionsPolicy:{allowsFeature:()=>false}}},'micPolicy']]){
  const f=fixture(env);await f.mic.start();assert.equal(f.errors[0].code,code);assert.equal(f.requests,0);
 }
});
test('overconstrained request retries and records both outcomes',async()=>{
 let calls=0;const f=fixture();f.context.navigator.mediaDevices.getUserMedia=async constraints=>{calls++;if(calls===1)throw Object.assign(new Error('bad channels'),{name:'OverconstrainedError',constraint:'channelCount'});assert.equal(constraints.audio,true);return f.stream;};
 await f.mic.start();assert.equal(calls,2);assert.equal(f.mic.session.state,'listening');assert.match(f.context.KamDebug.export(),/constraints.retry/);f.mic.cancel();f.mic.release();
});
test('grant after cancellation closes the late stream',async()=>{
 let grant;const f=fixture();f.context.navigator.mediaDevices.getUserMedia=()=>new Promise(resolve=>grant=resolve);
 const started=f.mic.start();f.mic.cancel();grant(f.stream);await started;assert.equal(f.mic.active,false);assert.equal(f.stopped,1);assert.match(f.context.KamDebug.export(),/lateGrant.released/);
});
test('Android callbacks preserve diagnostic cause and ignore stale sessions',async()=>{
 const calls=[];const f=fixture({KamNative:{startMic:(...args)=>calls.push(args),cancelMic(){}}});
 await f.mic.start({test:true});const id=f.mic.session.id;
 f.mic.nativeEvent('older-session','error',{code:'micDenied'});assert.equal(f.errors.length,0);
 f.mic.nativeEvent(id,'error',{code:'micDeniedPermanent',message:'Android denied RECORD_AUDIO',sdk:35,shouldShowRationale:false});
 assert.equal(f.errors[0].code,'micDeniedPermanent');assert.equal(f.errors[0].diagnostic.sdk,35);
 const log=f.context.KamDebug.export();assert.match(log,/Android denied RECORD_AUDIO/);assert.match(log,/shouldShowRationale/);assert.match(log,/"accepted": false/);
});
test('Android result and debug callback never export recording bytes or credentials',async()=>{
 const f=fixture({KamNative:{startMic(){},cancelMic(){}}});await f.mic.start({test:true});const id=f.mic.session.id;
 f.context.KamDebug.addSecret('example-private-key-123');
 f.context.kamNativeDebug('permission.result',{granted:false,apiKey:'private-key',message:'example-private-key-123',password:'nathanyuen.org'});
 f.mic.nativeEvent(id,'result',{audio:'UklGRg==',text:'早餐A',peak:.1,durationMs:4000});
 const log=f.context.KamDebug.export();assert.doesNotMatch(log,/UklGRg==|example-private-key-123|nathanyuen\.org|private-device/);assert.match(log,/REDACTED/);assert.equal(f.results.length,1);
});
test('native timeout logs absence of acknowledgement and releases ownership',async()=>{
 const timers=new Map();let serial=0;
 const f=fixture({KamNative:{startMic(){},cancelMic(){}},setTimeout:(fn,ms)=>{const id=++serial;timers.set(id,{fn,ms});return id;},clearTimeout:id=>timers.delete(id)});
 await f.mic.start();const timeout=[...timers.values()].find(t=>t.ms===60000);timeout.fn();assert.equal(f.errors[0].code,'micPromptTimeout');assert.equal(f.mic.active,false);assert.match(f.context.KamDebug.export(),/micPromptTimeout/);
});
test('speech service failure is distinguished from recording permission failure',async()=>{
 class Speech{start(){this.onerror({error:'network',message:'Speech server disconnected'});}abort(){}}
 const f=fixture({SpeechRecognition:Speech});await f.mic.start({deviceSpeech:true});assert.equal(f.mic.session.speechError,'network');assert.equal(f.mic.session.state,'listening');assert.equal(f.errors.length,0);assert.match(f.context.KamDebug.export(),/Speech server disconnected/);f.mic.cancel();f.mic.release();
});
test('silent recording still returns measurable duration for diagnosis',async()=>{
 const f=fixture();await f.mic.start({test:true});f.mic.session.chunks=[new Float32Array(24000)];f.mic.finish();assert.equal(f.results.length,1);assert.equal(f.results[0].durationMs,500);assert.equal(f.results[0].peak,0);f.mic.release();
});
test('journal remains bounded and survives storage denial',()=>{
 const f=fixture({localStorage:{getItem(){throw Error('denied');},setItem(){throw Error('full');}}});for(let i=0;i<2600;i++)f.context.KamDebug.log('test','event',{i});assert.equal(f.context.KamDebug.entries().length,2500);assert.doesNotThrow(()=>f.context.KamDebug.flush());
});

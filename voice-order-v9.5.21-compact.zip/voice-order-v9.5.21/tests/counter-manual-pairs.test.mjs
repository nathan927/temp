import assert from 'node:assert/strict';
import {test} from 'node:test';
import {ui,next} from './ui-fixture.mjs';
import {load,plain} from './helpers.mjs';

async function say(f,text,alternatives=[]){
 await f.click('#home-mic');
 f.context.kamMicEvent(f.session,'result',{text,alternatives,peak:.1});
 for(let i=0;i<6;i++)await next();
}
const box=f=>f.document.querySelector('#voice-error');
const order=f=>f.state().cart.map(({id,qty,drink,ice})=>[id,qty,drink,ice]);
function setInput(f,id,value){
 const input=f.document.querySelector('#'+id);
 input.value=value;
 input.dispatchEvent(new f.window.Event('input',{bubbles:true}));
}
async function openPairs(f){
 await f.click('[data-action="settings"]');
 await f.unlock();
 await f.click('[data-action="manual-pairs"]');
}
async function submitPair(f,source,target){
 if(source!==undefined)setInput(f,'manual-pair-source',source);
 if(target!==undefined)setInput(f,'manual-pair-target',target);
 f.document.querySelector('#manual-pair-form').dispatchEvent(new f.window.Event('submit',{bubbles:true,cancelable:true}));
 await next();
}

test('the yellow panel reports exact adds, a split edit, a removal and undo',async()=>{
 const f=ui();
 assert.equal(f.document.querySelector('[data-voice-state]').className,'sr-only');
 await say(f,'兩份早餐A凍檸茶，一份菠蘿油');
 assert.equal(box(f).dataset.reply,'success');
 assert.match(box(f).textContent,/加咗 2 份 沙嗲牛肉早餐.*凍檸茶/);
 assert.match(box(f).textContent,/加咗 1 份 .*菠蘿油/);
 await say(f,'第一行其中一份改走冰');
 assert.match(box(f).textContent,/改咗 1 份 沙嗲牛肉早餐.*走冰/);
 assert.doesNotMatch(box(f).textContent,/加咗 1 份/);
 await say(f,'剛才一個唔要');
 assert.match(box(f).textContent,/刪咗 1 份 .*菠蘿油/);
 await say(f,'撤銷');
 assert.match(box(f).textContent,/還原上一步/);
 assert.match(box(f).textContent,/菠蘿油/);
 assert.equal(f.document.querySelector('[data-voice-state]').textContent,'');
});

test('success says what changed and an identical edit acknowledges the original draft',async()=>{
 const f=ui();
 await say(f,'一杯凍奶茶');
 await say(f,'第一行改走冰');
 assert.match(box(f).textContent,/走冰/);
 await say(f,'第一行改走冰');
 assert.equal(box(f).dataset.reply,'success');
 assert.match(box(f).textContent,/照舊|原樣|冇改|保留|原先/);
 assert.doesNotMatch(box(f).textContent,/改咗 1 份/);
 await say(f,'全單取消');
 assert.equal(box(f).dataset.reply,'success');
 assert.match(box(f).textContent,/刪咗 1 份 .*奶茶/);
 assert.deepEqual(f.state().cart,[]);
});

test('the yellow panel keeps the accepted items and the clarification for a partial order',async()=>{
 const f=ui();
 await say(f,'一份菠蘿油，一份青玉雲朵');
 assert.equal(box(f).dataset.reply,'partial');
 assert.match(box(f).textContent,/加咗 1 份 .*菠蘿油/);
 assert.match(box(f).textContent,/青玉雲朵/);
 await say(f,'青玉雲朵');
 assert.equal(box(f).dataset.reply,'error');
 assert.equal(f.document.querySelector('[data-voice-state]').textContent,'');
 assert.doesNotMatch(box(f).textContent,/加咗 1 份/);
});

test('one character shows every matching choice, then the selected pair works after reopen',async()=>{
 const store=new Map(),f=ui([],{store});
 await openPairs(f);
 setInput(f,'manual-pair-source','小太陽');
 setInput(f,'manual-pair-target','早');
 const matches=f.context.Kam.manualPairs.search('早');
 const results=f.document.querySelector('#manual-pair-results');
 assert.ok(matches.length>10);
 assert.equal(results.querySelectorAll('button').length,matches.length);
 assert.equal(results.hidden,false);
 assert.match(f.document.querySelector('#manual-pair-match-count').textContent,new RegExp(String(matches.length)));
 setInput(f,'manual-pair-target','早餐A');
 const candidate=[...results.querySelectorAll('button')].find(button=>button.querySelector('strong').textContent.toLowerCase()==='早餐a');
 assert.ok(candidate);
 await f.click('[data-manual-pair-choice="'+candidate.dataset.manualPairChoice+'"]');
 assert.match(f.document.querySelector('#manual-pair-preview').textContent,/小太陽.*早餐a/i);
 await submitPair(f);
 assert.deepEqual(f.state().manualPairs,[{source:'小太陽',target:'早餐a'}]);
 assert.deepEqual(f.state().cart,[]);
 const g=ui([],{store});
 await say(g,'兩份小太陽凍檸茶');
 assert.deepEqual(order(g),[['A',2,'凍檸茶','正常冰']]);
 assert.match(box(g).textContent,/加咗 2 份 沙嗲牛肉早餐/);
});

test('settings reject one character, duplicates, built-in conflicts and unknown targets',async()=>{
 const f=ui();await openPairs(f);
 await submitPair(f,'星','早餐A');
 assert.match(f.document.querySelector('#manual-pair-message').textContent,/最少兩個字/);
 await submitPair(f,'早餐A','早餐B');
 assert.match(f.document.querySelector('#manual-pair-message').textContent,/本身已識/);
 await submitPair(f,'銀河代號','夢境青玉雲朵');
 assert.match(f.document.querySelector('#manual-pair-message').textContent,/完整指令/);
 await submitPair(f,'銀河代號','早餐A');
 await submitPair(f,'銀河代號','早餐B');
 assert.match(f.document.querySelector('#manual-pair-message').textContent,/已經有配對/);
 assert.deepEqual(f.state().manualPairs,[{source:'銀河代號',target:'早餐A'}]);
 await f.click('[data-manual-pair-edit="0"]');
 await submitPair(f,undefined,'早餐B');
 assert.deepEqual(f.state().manualPairs,[{source:'銀河代號',target:'早餐B'}]);
 await f.click('[data-manual-pair-remove="0"]');
 assert.deepEqual(f.state().manualPairs,[]);
});

test('aliases for options and whole commands obey context and confirm conflicting recognition',()=>{
 const {Kam:K}=load();
 const cart=[K.normalize({id:'A',uid:'a',qty:2,drink:'凍檸茶'})];
 let manualPairs=K.manualPairs.save([],'微霜','少冰');
 manualPairs=K.manualPairs.save(manualPairs,'重新整理一下','清空餐單');
 const context={cart,manualPairs,orderNotes:[],mode:'dinein'};
 const edit=K.resolveDeviceVoice({localText:'第一行改微霜',cart,context});
 const edited=K.transitionDraft(context,edit.plan);
 assert.equal(edited.cart[0].ice,'少冰');
 assert.equal(cart[0].ice,'正常冰');
 assert.equal(K.resolveDeviceVoice({localText:'重新整理一下',cart,context}).plan.intent,'clear');
 const embedded=K.analyzeLocal('一份菠蘿油重新整理一下',cart,context);
 assert.ok(!embedded.plan?.ops?.some(op=>op.type==='clear'));
 assert.notEqual(embedded.plan?.intent,'clear');
 assert.throws(()=>K.resolveDeviceVoice({localText:'第一行改微霜',localAlternatives:['第一行改走冰'],cart,context}),
  error=>error.code==='confirmTranscript');
 const hot=plain(cart.map(item=>({...item,drink:'熱奶茶'})));
 assert.throws(()=>K.resolveDeviceVoice({localText:'第一行改微霜',cart:hot,context:{...context,cart:hot}}),
  error=>error.code==='notApplicable');
});

test('336 success variations are distinct in each language and complete a cycle',()=>{
 const {KamCounterReply:reply}=load();
 for(const lang of ['tc','sc','en']){
  const all=[];
  for(const kind of reply.kinds){
   const messages=Array.from({length:reply.variantsPerKind},()=>reply.next(kind,lang));
   assert.equal(new Set(messages).size,48);
   assert.equal(reply.next(kind,lang),messages[0]);
   all.push(...messages);
  }
  assert.equal(new Set(all).size,336);
 }
});

test('typed existing commands can be saved and are interpreted against the live draft',async()=>{
 const f=ui();
 await openPairs(f);
 await submitPair(f,'換個環境','轉外賣');
 assert.equal(f.state().mode,'dinein');
 await submitPair(f,'冰山三號','第三行改少冰');
 assert.equal(f.state().manualPairs.length,2);
 await f.click('#modal [data-action="close"]');
 await say(f,'換個環境');
 assert.equal(f.state().mode,'takeaway');
 assert.match(box(f).textContent,/外賣/);
 await say(f,'一份早餐A熱奶茶，一份早餐B熱咖啡，一份早餐C凍檸茶');
 await say(f,'冰山三號');
 assert.deepEqual(order(f).map(([id,,,ice])=>[id,ice]),[['A','正常冰'],['B','正常冰'],['C','少冰']]);
 assert.match(box(f).textContent,/改咗 1 份 餐肉雙蛋早餐.*少冰/);
});

test('an existing context-dependent command cannot be overwritten on an empty draft',()=>{
 const {Kam:K}=load();
 assert.throws(()=>K.manualPairs.save([],'第一行改少冰','早餐A'),error=>error.code==='manualPairSourceKnown');
});

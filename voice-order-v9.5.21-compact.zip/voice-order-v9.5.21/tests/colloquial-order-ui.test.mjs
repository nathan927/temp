import assert from 'node:assert/strict';
import {test} from 'node:test';
import {ui,next,waitFor} from './ui-fixture.mjs';

async function say(f,text,alternatives=[]){
 await f.click('#home-mic');
 f.context.kamMicEvent(f.session,'result',{text,alternatives,peak:.1});
 for(let i=0;i<6;i++)await next();
}
const portions=f=>f.state().cart.map(({id,qty})=>[id,qty]);
const notice=f=>f.document.querySelector('#voice-error').textContent;

test('repeat and cancellation follow the latest portion after merging and reload',async()=>{
 const store=new Map(),f=ui([],{store});
 await say(f,'一份早餐A凍檸茶，一份早餐B熱咖啡，一份早餐A凍檸茶');
 assert.deepEqual(portions(f),[['A',2],['B',1]]);
 const g=ui([],{store});
 await say(g,'我要一樣');
 assert.deepEqual(portions(g),[['A',3],['B',1]]);
 await say(g,'講錯咗');
 await say(g,'，剛才一個唔要');
 assert.deepEqual(portions(g),[['A',1],['B',1]]);
 await say(g,'跟多份');
 assert.deepEqual(portions(g),[['A',1],['B',2]]);
});

test('repeat with a hot drink changes the new portion only',async()=>{
 const f=ui();
 await say(f,'兩份早餐B凍檸茶少冰半糖飛邊');
 await say(f,'跟多份，但要熱奶茶');
 const [source,added]=f.state().cart;
 assert.deepEqual([source.qty,source.drink,source.ice,source.sugar,source.toast],[2,'凍檸茶','少冰','半糖','飛邊']);
 assert.deepEqual([added.qty,added.drink,added.ice,added.sugar,added.toast],[1,'熱奶茶','正常冰','半糖','飛邊']);
});

test('a split edit preserves which portion came last and undo restores recency',async()=>{
 const f=ui();
 await say(f,'一份早餐A凍奶茶，一份早餐B凍檸茶，一份早餐A凍奶茶');
 await say(f,'第一行其中一份改走冰');
 await say(f,'跟多份');
 assert.deepEqual(f.state().cart.map(({id,qty,ice})=>[id,qty,ice]),[['A',1,'正常冰'],['A',2,'走冰'],['B',1,'正常冰']]);
 await say(f,'唔好跟多份');
 await f.click('[data-action="undo"]');
 assert.deepEqual(f.state().cart.map(({id,qty,ice})=>[id,qty,ice]),[['A',1,'正常冰'],['A',1,'走冰'],['B',1,'正常冰']]);
 await f.click('[data-action="undo"]');
 await say(f,'講錯咗');
 assert.deepEqual(portions(f),[['A',1],['B',1]]);
});

test('group overflow keeps the newest portions across the twenty-per-line boundary',async()=>{
 const f=ui();
 await say(f,'十九份早餐A熱奶茶，一份早餐B熱咖啡，三份早餐A熱奶茶');
 assert.deepEqual(portions(f),[['A',20],['B',1],['A',2]]);
 for(let i=0;i<3;i++)await say(f,'講錯咗');
 assert.deepEqual(portions(f),[['A',19],['B',1]]);
 await say(f,'同上');
 assert.deepEqual(portions(f),[['A',19],['B',2]]);
});

test('a submitted order is outside the scope of casual repeat or cancellation',async()=>{
 const f=ui();
 await say(f,'一份菠蘿油');
 await f.click('[data-action="confirm"]');
 await waitFor(()=>f.state().orders?.length===1&&f.document.querySelector('.receipt'));
 await f.click('#modal [data-action="close"]');
 const [placed]=f.state().orders;
 await say(f,'講錯咗');
 assert.match(notice(f),/草稿未有上一份/);
 await say(f,'跟多份');
 assert.deepEqual(f.state().orders,[placed]);
 assert.deepEqual(f.state().cart,[]);
});

test('alternatives that disagree between adding and removing ask for confirmation',async()=>{
 const f=ui();
 await say(f,'兩份早餐A熱奶茶');
 await say(f,'跟多份',['講錯咗']);
 assert.ok(f.document.querySelector('[data-voice-candidate]'));
 assert.deepEqual(portions(f),[['A',2]]);
});

test('a compound request with an unknown override saves no partial addition',async()=>{
 const f=ui();
 await say(f,'一份早餐A熱奶茶');
 await say(f,'一份早餐B凍檸茶，跟多份但要青玉雲朵');
 assert.match(notice(f),/青玉雲朵/);
 assert.deepEqual(portions(f),[['A',1]]);
});

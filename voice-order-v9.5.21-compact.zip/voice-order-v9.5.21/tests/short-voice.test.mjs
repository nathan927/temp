import assert from 'node:assert/strict';
import {test} from 'node:test';
import {runShortVoice} from '../acceptance/short-voice/run.mjs';
import {html} from './helpers.mjs';

test('10,000 Cantonese short-command transcription cases apply the expected edit or stop safely',async()=>{
 const result=await runShortVoice(html);
 assert.equal(result.unique,10000);
 assert.equal(result.failed,0,JSON.stringify(result.examples,null,2));
 assert.equal(result.passed,10000);
 assert.equal(result.unsafe,0);
 assert.equal(result.apiCalls,0);
});

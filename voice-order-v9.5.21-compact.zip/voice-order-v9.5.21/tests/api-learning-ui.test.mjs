import assert from'node:assert/strict';import{test}from'node:test';import fs from'node:fs';import path from'node:path';
import{ui,next,waitFor}from'./ui-fixture.mjs';import{load,plain}from'./helpers.mjs';
const say=async(f,text,extra={})=>{await f.click('#home-mic');f.context.kamMicEvent(f.session,'result',{text,alternatives:[],peak:.1,...extra});for(let i=0;i<15;i++)await next();};
async function settings(f){await f.click('[data-action="settings"]');if(f.document.querySelector('#settings-password'))await f.unlock();}
async function configure(f,{provider='mimo',both=false,proxy=false,off=false}={}){await settings(f);f.document.querySelector('#key-'+provider).value='authorized-private-key-123';if(both)f.document.querySelector('#key-'+(provider==='mimo'?'minimax':'mimo')).value='second-private-key-456';if(proxy){f.document.querySelector('#api-base').value='https://orders.test';f.document.querySelector('#store-token').value='store-private-token-123';}if(off)f.document.querySelector('#parser').value='off';await f.click('[data-action="save-settings"]');}
const wrap=(plan,status=200,more={})=>({ok:status>=200&&status<300,status,text:async()=>status>=400?'HTML error body':JSON.stringify({choices:[{finish_reason:'stop',message:{content:JSON.stringify(plan)}}],...more})});
const p1={intent:'add',ops:[{type:'add',item:{id:'P1',qty:1}}]},word='伙記呢邊想歎一份菠蘿油';
function memoryAdapter(){const events=new Map(),latest=new Map();return{events,latest,async write(rows){await next();for(const row of rows){events.set(row.id,structuredClone(row));if(row.key)latest.set(row.key,structuredClone(row.data));}},async read(){return{events:[...events.values()],latest:[...latest].map(([key,value])=>({key,value}))};},async get(key){return latest.get(key);}};}

test('saved key automatically recovers an unknown phrase, adds both dictionary views and repeats locally',async()=>{
 const requests=[],f=ui([],{fetch:async(url,init)=>{requests.push({url,init});return wrap(p1);}});await configure(f);await say(f,word);assert.equal(requests.length,1);assert.equal(f.state().cart[0].id,'P1');assert.equal(f.state().cart[0].qty,1);
 assert.match(requests[0].url,/api.xiaomimimo.com/);assert.equal(requests[0].init.headers['api-key'],'authorized-private-key-123');
 await say(f,word);assert.equal(requests.length,1);assert.equal(f.state().cart[0].qty,2);
 await settings(f);await f.click('[data-action="manual-pairs"]');assert.match(f.document.querySelector('#automatic-pair-list').textContent,/菠蘿油/);
 await f.click('[data-action="settings"]');await f.click('[data-action="glossary"]');assert.match(f.document.querySelector('.automatic-dictionary-row').textContent,/菠蘿油/);
 await f.click('[data-action="settings"]');await f.click('[data-action="all-logs"]');await waitFor(()=>f.files.length===1);const out=JSON.parse(f.files[0].data);
 assert.ok(out.audit.events.some(e=>e.source==='api'&&e.event==='response'));assert.ok(Object.values(out.audit.latest).some(v=>v.active?.rules?.length));assert.doesNotMatch(f.files[0].data,/authorized-private-key-123/);
});
test('partial local order asks API to complete it once without duplicating known items',async()=>{
 const c=load(),K=c.Kam,plan={intent:'add',ops:[{type:'add',item:{id:'A',qty:1,drink:'熱奶茶'}},{type:'add',item:{id:'B',qty:2,drink:'凍檸茶'}}]};let calls=0;
 const f=ui([],{fetch:async()=>{calls++;return wrap(plan);}});await configure(f);await say(f,'伙記呢邊想嘆一份早餐A熱奶茶，兩份早餐B凍檸茶');assert.equal(calls,1);assert.deepEqual(f.state().cart.map(i=>[i.id,i.qty]),[['A',1],['B',2]]);assert.equal(JSON.parse(f.store.get('kamkee.voice-statistics.v1')).messages.at(-1).finalSource,'model');
});
test('partial rescue cannot drop clear items; failure keeps only the known portions',async()=>{
 const f=ui([],{fetch:async()=>wrap(p1)});await configure(f);await say(f,'伙記呢邊想嘆一份早餐A熱奶茶，兩份早餐B凍檸茶');assert.deepEqual(f.state().cart.map(i=>[i.id,i.qty]),[['B',2]]);assert.ok(JSON.parse(f.store.get('kamkee.evolution.v1')).active.rules.length===0);
});
test('first provider failure moves to the second configured key',async()=>{
 const calls=[],f=ui([],{fetch:async(url)=>{calls.push(url);return url.includes('minimaxi')?wrap(null,401):wrap(p1);}});await configure(f,{provider:'minimax',both:true});await say(f,word);assert.equal(calls.length,2);assert.equal(f.state().cart[0].id,'P1');
});
test('proxy uses the store token and a typed result, then learns locally',async()=>{
 let request,calls=0;const f=ui([],{fetch:async(url,init)=>{calls++;request={url,init};return{ok:true,status:200,text:async()=>JSON.stringify(p1)};}});await configure(f,{proxy:true});await say(f,word);assert.equal(request.url,'https://orders.test/api/parse');assert.equal(request.init.headers['X-Store-Token'],'store-private-token-123');await say(f,word);assert.equal(calls,1);
});
test('an explicit local-only setting makes no API request for unknown text',async()=>{
 let calls=0;const f=ui([],{fetch:async()=>{calls++;return wrap(p1);}});await configure(f,{off:true});await say(f,word);assert.equal(calls,0);assert.equal(f.state().cart?.length||0,0);
});
test('missing device text with available audio automatically uses ASR, then the local parser',async()=>{
 let calls=0;const f=ui([],{fetch:async(_url,init)=>{calls++;const body=JSON.parse(init.body);assert.equal(body.model,'mimo-v2.5-asr');return{ok:true,status:200,text:async()=>JSON.stringify({choices:[{message:{content:'一份早餐A熱奶茶'}}]})};}});await configure(f);await say(f,'',{audio:'UklGRg==',peak:.1});await waitFor(()=>f.state().cart?.length===1);assert.equal(calls,1);assert.equal(f.state().cart[0].id,'A');assert.equal(f.state().cart[0].drink,'熱奶茶');
});
test('blank text without audio stays unresolved and does not invent a dictionary entry',async()=>{
 let calls=0;const f=ui([],{fetch:async()=>{calls++;return wrap(p1);}});await configure(f);await say(f,'');assert.equal(calls,0);assert.equal(f.state().cart?.length||0,0);assert.equal(JSON.parse(f.store.get('kamkee.evolution.v1')||'{"active":{"rules":[]}}').active.rules.length,0);
});
for(const [status,code,cue]of[[401,'apiInvalidKey',/key|金鑰/],[403,'apiForbidden',/模型|key/],[429,'apiRateLimit',/等|忙/],[503,'apiUnavailable',/服務|再試/]])test('HTTP '+status+' has actionable human copy and does not learn',async()=>{
 const f=ui([{id:'A',uid:'a',qty:1,drink:'熱奶茶'}],{fetch:async()=>wrap(null,status)});await configure(f);const before=JSON.stringify(f.state().cart);await say(f,word);assert.equal(JSON.stringify(f.state().cart),before);assert.match(f.document.querySelector('#voice-error').textContent,cue);assert.doesNotMatch(f.document.querySelector('#voice-error').textContent,new RegExp(code));assert.equal(JSON.parse(f.store.get('kamkee.evolution.v1')).active.rules.length,0);
});
test('busy draft controls stay locked while the API answer is applied once',async()=>{
 let release,started=false;const f=ui([{id:'A',uid:'a',qty:1,drink:'熱奶茶'}],{fetch:async()=>{started=true;await new Promise(r=>release=r);return wrap(p1);}});await configure(f);await f.click('#home-mic');f.context.kamMicEvent(f.session,'result',{text:word,peak:.1});await waitFor(()=>started);await f.click('[data-mode="takeaway"]');release();for(let i=0;i<20;i++)await next();assert.equal(f.state().cart.length,2);assert.equal(f.state().mode,'dinein');assert.equal(f.state().cart[1].id,'P1');assert.ok(JSON.parse(f.store.get('kamkee.evolution.v1')).active.rules.length);
});
test('API connectivity test uses an isolated draft and verifies local replay',async()=>{
 const f=ui([{id:'A',uid:'a',qty:1,drink:'凍檸茶'}],{fetch:async()=>wrap(p1)});await configure(f);const before=JSON.stringify(f.state().cart);await settings(f);await f.click('[data-action="api-probe"]');await waitFor(()=>/已實際回覆/.test(f.document.querySelector('#api-probe-result').textContent));assert.equal(JSON.stringify(f.state().cart),before);assert.equal(JSON.parse(f.store.get('kamkee.evolution.v1')).active.rules.length,0);
});
test('API-learned pairs can be removed without altering user-authored pairs',async()=>{
 const f=ui([],{fetch:async()=>wrap(p1)});await configure(f);await say(f,word);await settings(f);await f.click('[data-action="manual-pairs"]');assert.ok(f.document.querySelector('[data-auto-pair-remove]'));await f.click('[data-auto-pair-remove]');assert.equal(JSON.parse(f.store.get('kamkee.evolution.v1')).active.rules.length,0);assert.equal(f.state().manualPairs.length,0);
});
test('settings displays 100 recent voice records while downloads contain all 160',async()=>{
 const c=load(),memory=new Map(),storage={getItem:k=>memory.get(k)||null,setItem:(k,v)=>memory.set(k,v)},s=new c.KamVoiceStatistics.Store({storage});for(let i=0;i<160;i++){s.begin({id:'history-'+i,text:'早餐A',deviceText:true});s.finish('history-'+i);}
 const f=ui([],{store:memory});await settings(f);assert.equal(f.document.querySelectorAll('.statistics-message').length,100);await f.click('[data-action="statistics-export"]');await waitFor(()=>f.files.length===1);const exp=JSON.parse(f.files[0].data);assert.equal(exp.data.messages.length,160);assert.equal(exp.summary.counts.received,160);
});
test('full history persists across audit restarts and includes entries beyond UI cache limits',async()=>{
 const c=load(),adapter=memoryAdapter(),a=new c.KamAudit.Store({adapter});a.addSecret('a-private-credential');for(let i=0;i<3000;i++)a.record('voice','voice-'+i,{id:'voice-'+i,values:Array.from({length:150},(_,n)=>n),credential:'a-private-credential'});
 const full=await a.read();assert.equal(full.events.length,3000);assert.equal(full.events[0].data.values.length,150);assert.doesNotMatch(JSON.stringify(full),/a-private-credential/);
 const reopened=new c.KamAudit.Store({adapter});const restored=await reopened.read();assert.equal(restored.events.length,3000);assert.ok(restored.latest['voice:voice-0']);assert.ok(restored.latest['voice:voice-2999']);
});
test('disk-backed audit adapter reopens complete data and flushes pending writes before export',async()=>{
 const folder=fs.mkdtempSync(path.resolve('.audit-test-')),file=path.join(folder,'audit.json');const adapter={async write(rows){await next();fs.writeFileSync(file,JSON.stringify({events:rows,latest:rows.filter(x=>x.key).map(x=>({key:x.key,value:x.data}))}));},async read(){return fs.existsSync(file)?JSON.parse(fs.readFileSync(file,'utf8')):{events:[],latest:[]};}};
 try{const c=load(),a=new c.KamAudit.Store({adapter});for(let i=0;i<800;i++)a.record('execution',String(i),{id:i,text:'原始文字'+i});const full=await a.read();assert.equal(full.events.length,800);const reopened=new c.KamAudit.Store({adapter});assert.equal((await reopened.read()).events.length,800);}finally{fs.rmSync(folder,{recursive:true,force:true});}
});
test('persistent write failure retains all pending log rows and discloses memory-only coverage',async()=>{
 const c=load(),a=new c.KamAudit.Store({adapter:{async write(){throw Error('quota');},async read(){return{events:[],latest:[]};}}});a.record('voice','a',{id:'a',text:'早餐A'});const r=await a.read();assert.equal(r.events.length,1);assert.equal(r.coverage.persistent,false);assert.equal(r.coverage.pending,1);
});
test('a complete export read error does not produce a partial download',async()=>{
 const f=ui();f.context.KamAudit.adapter={async write(){},async read(){throw Error('read failed');}};await settings(f);await f.click('[data-action="all-logs"]');for(let i=0;i<10;i++)await next();assert.equal(f.files.length,0);assert.match(f.document.querySelector('#settings-error').textContent,/完整紀錄|讀唔齊/);
});
test('success replies never append the removed sentence',()=>{
 const c=load();for(const lang of ['tc','sc','en'])for(let i=0;i<400;i++)assert.doesNotMatch(c.KamCounterReply.next('update',lang),/你睇吓啱唔啱|你睇吓啱唔啱/);
});

test('100 records are shown from cold history after pruning and all 130 export without double counting',async()=>{
 const c=load(),memory=new Map(),storage={getItem:k=>memory.get(k)||null,setItem:(k,v)=>memory.set(k,v)},s=new c.KamVoiceStatistics.Store({storage,limit:3});
 for(let i=0;i<130;i++){s.begin({id:'cold-'+i,text:'早餐A',deviceText:true});s.finish('cold-'+i);}
 const old=await c.KamAudit.read(),adapter=memoryAdapter();for(const row of old.events){adapter.events.set(row.id,plain(row));if(row.key)adapter.latest.set(row.key,plain(row.data));}
 const f=ui([],{store:memory});f.context.KamAudit.adapter=adapter;await settings(f);await waitFor(()=>f.document.querySelectorAll('.statistics-message').length===100);await f.click('[data-action="statistics-export"]');await waitFor(()=>f.files.length===1);
 const exp=JSON.parse(f.files[0].data);assert.equal(exp.data.messages.length,130);assert.equal(exp.coverage.legacyVoiceDetailsMissing,0);
 const restoredStorage={getItem:()=>JSON.stringify(exp.data),setItem(){}};const reopened=new c.KamVoiceStatistics.Store({storage:restoredStorage});assert.equal(reopened.report().counts.received,130);
});

test('API profile and model selection control the actual request',async()=>{
 let last;const f=ui([],{fetch:async(url,init)=>{last={url,body:JSON.parse(init.body)};return wrap(p1);}});await settings(f);f.document.querySelector('#key-mimo').value='authorized-private-key-123';f.document.querySelector('#mimo-profile').value='token-sgp';f.document.querySelector('#mimo-model').value='mimo-v2.6-pro';await f.click('[data-action="save-settings"]');await say(f,word);assert.match(last.url,/token-plan-sgp/);assert.equal(last.body.model,'mimo-v2.6-pro');
});

test('provider thinking blocks stay outside the order JSON and unfinished thinking is rejected',()=>{
 const K=load().Kam,body={choices:[{message:{content:'<think>request analysis</think>\n'+JSON.stringify(p1)}}]};assert.equal(K.readAI('parse',body).ops[0].item.id,'P1');
 assert.throws(()=>K.readAI('parse',{choices:[{message:{content:'<think>unfinished '+JSON.stringify(p1)}}]}),e=>e.code==='invalidJSON');
 assert.throws(()=>K.readAI('parse',{choices:[{message:{content:'unrelated text '+JSON.stringify(p1)}}]}),e=>e.code==='invalidJSON');
});

test('an explicit manual pair can override an API-learned phrase while built-in meanings stay protected',async()=>{
 const f=ui([],{fetch:async()=>wrap(p1)});await configure(f);await say(f,word);await settings(f);await f.click('[data-action="manual-pairs"]');
 f.document.querySelector('#manual-pair-source').value=word;f.document.querySelector('#manual-pair-target').value='腿蛋治';f.document.querySelector('#manual-pair-form').dispatchEvent(new f.window.Event('submit',{bubbles:true,cancelable:true}));for(let i=0;i<5;i++)await next();assert.equal(f.state().manualPairs.length,1);
 await f.click('#modal [data-action="close"]');await say(f,word);assert.deepEqual(f.state().cart.map(i=>i.id),['P1','P3']);
});

test('learning history initializes before UI helpers without a temporal-dead-zone failure',async()=>{const f=ui();await next();assert.doesNotMatch(JSON.stringify(f.context.KamDebug.entries()),/ReferenceError|before initialization/);});

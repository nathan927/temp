import assert from 'node:assert/strict';
import vm from 'node:vm';
import {webcrypto} from 'node:crypto';
import {parseHTML} from 'linkedom';
import {html,scripts,inlineScripts} from './helpers.mjs';

export const next=()=>new Promise(resolve=>setImmediate(resolve));
export const waitFor=async fn=>{for(let n=0;n<200;n++){if(fn())return;await new Promise(resolve=>setTimeout(resolve,5));}assert.ok(fn(),'UI condition did not become ready');};
export function scopedStore(root,lang){const prefix='voice-order.v20.'+lang+'.';return {rootStore:root,language:lang,get:k=>root.get(prefix+k),set(k,v){root.set(prefix+k,v);return this;},has:k=>root.has(prefix+k),delete:k=>root.delete(prefix+k),entries:()=>[...root].filter(([k])=>k.startsWith(prefix)).map(([k,v])=>[k.slice(prefix.length),v])[Symbol.iterator](),[Symbol.iterator](){return this.entries();}};}
export function ui(cart=[],options={}){
 const {document,window}=parseHTML(options.html||html),rawStore=options.store?.rootStore||options.store||new Map(),lang=options.lang||options.state?.lang||options.store?.language||'tc',store=scopedStore(rawStore,lang),files=[],navigations=[];
 if(!options.legacy&&!options.store?.rootStore)for(const [key,value]of [...rawStore])if(key.startsWith('kamkee.')){store.set(key,value);rawStore.delete(key);}
 if(options.state)store.set('kamkee.v2',JSON.stringify({...options.state,lang}));
 // Historical single-utterance suites explicitly opt out; production/default
 // behavior is tested by the continuous-session acceptance suite.
 if(!options.productionDefaults){let state;try{state=JSON.parse(store.get('kamkee.v2')||'null');}catch{}state=state||{version:2,cart:[],orders:[],lang,settings:{}};state.settings={...state.settings,handsFree:state.settings?.handsFree??false};store.set('kamkee.v2',JSON.stringify(state));}

 window.HTMLInputElement.prototype.select=function(){};
 Object.defineProperty(window.HTMLInputElement.prototype,'checked',{configurable:true,get(){return this.hasAttribute('checked');},set(value){this.toggleAttribute('checked',!!value);}});
 Object.defineProperty(window.HTMLSelectElement.prototype,'value',{configurable:true,get(){return this.querySelector('option[selected]')?.getAttribute('value')??this.querySelector('option')?.getAttribute('value')??'';},set(value){for(const option of this.querySelectorAll('option'))option.toggleAttribute('selected',option.getAttribute('value')===String(value));}});
 if(cart.length&&!options.state)store.set('kamkee.v2',JSON.stringify({version:2,cart,orders:[],lang,settings:options.productionDefaults?{}:{handsFree:false},availability:{},prices:{},mode:'dinein',table:2}));
 let nativeSession,nativeOptions;
 const context=vm.createContext({console,document,navigator:{userAgent:'DOM test',permissions:{query:async()=>({state:'prompt'})}},KAM_LANG:lang,location:{protocol:'https:',origin:'https://example.test',href:'https://example.test/app?lang='+lang,assign:url=>navigations.push(url)},isSecureContext:true,
  Blob,TextEncoder,crypto:webcrypto,URL,performance,setTimeout,clearTimeout,structuredClone,atob,btoa,AbortSignal,FormData,fetch:options.fetch,FileReader:class{readAsDataURL(){this.result='data:audio/wav;base64,UklGRg==';queueMicrotask(()=>this.onload());}},requestAnimationFrame:fn=>setTimeout(fn,0),
  localStorage:{getItem:k=>rawStore.get(k)??null,setItem:(k,v)=>rawStore.set(k,v),removeItem:k=>rawStore.delete(k)},
  KamNative:{saveFile:(filename,type,data)=>files.push({filename,type,data:Buffer.from(data,'base64').toString('utf8')}),startMic:(id,options)=>{nativeSession=id;nativeOptions=JSON.parse(options);},cancelMic(){},cancelRecognition(){}},
  addEventListener:window.addEventListener.bind(window),dispatchEvent:window.dispatchEvent.bind(window),scrollTo(){},...options.environment});
 context.window=context;context.top=context;context.self=context;
 if(options.compiledScripts){
  for(const script of options.compiledScripts)script.runInContext(context);
 }else for(const source of (options.html?inlineScripts(options.html):scripts))vm.runInContext(source,context);
 const click=async selector=>{const button=document.querySelector(selector);assert.ok(button,selector);button.dispatchEvent(new window.Event('click',{bubbles:true}));await next();await next();};
 const unlock=async(value='nathanyuen.org')=>{document.querySelector('#settings-password').value=value;document.querySelector('#settings-auth-form').dispatchEvent(new window.Event('submit',{bubbles:true,cancelable:true}));await next();};
 return {context,document,window,click,unlock,files,store,rawStore,navigations,state:()=>JSON.parse(store.get('kamkee.v2')||'{}'),get session(){return nativeSession;},get micOptions(){return nativeOptions;}};
}

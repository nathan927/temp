import fs from 'node:fs';
import vm from 'node:vm';
import {webcrypto} from 'node:crypto';
const {version}=JSON.parse(fs.readFileSync(new URL('../package.json',import.meta.url),'utf8'));
export const html=fs.readFileSync(new URL('../智能茶餐廳-v'+version+'.html',import.meta.url),'utf8');
export const inlineScripts=source=>[...source.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/g)].filter(m=>m[2].trim()).map(m=>m[2]);
export const scripts=inlineScripts(html);
export function load(overrides={}){
 const memory=new Map();
 const context=vm.createContext({console,Blob,TextEncoder,crypto:webcrypto,URL,atob,btoa,structuredClone,performance,setTimeout,clearTimeout,localStorage:{getItem:k=>memory.get(k)||null,setItem:(k,v)=>memory.set(k,v)},...overrides});
 for(const [i,source] of scripts.entries()){
  new vm.Script(source,{filename:'inline-'+i+'.js'});
  if(source.includes("(()=>{'use strict';"))continue;
  vm.runInContext(source,context);
 }
 return context;
}
export const plain=x=>JSON.parse(JSON.stringify(x));
export function order(K,text,cart=[]){return K.applyPlan(cart,K.parseCommand(text,cart)).items;}

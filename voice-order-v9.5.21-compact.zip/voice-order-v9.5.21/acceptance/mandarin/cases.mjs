export const foods=[['P1','菠萝包夹黄油'],['P2','法式吐司'],['P3','火腿鸡蛋三明治'],['P6','鸡蛋三明治'],['P7','午餐肉鸡蛋三明治'],['P9','金枪鱼三明治'],['P10','奶酪三明治'],['P11','火腿三明治'],['P14','果酱吐司'],['P15','黄油吐司'],['S1','香脆炸鸡翅'],['S2','瑞士汁鸡翅'],['S3','炸薯条'],['R1','干炒牛河'],['R3','扬州炒饭'],['R4','焗猪排饭'],['R7','叉烧饭'],['R8','番茄炒蛋饭'],['R9','牛腩面'],['R10','鲜虾云吞面']];
const drinks=[['T1','奶茶'],['T2','柠檬茶'],['T3','咖啡'],['T4','鸳鸯']];const prefixes=['我要','请来','给我来','来','麻烦来'];
const aliases=[['T1','热奶查',{drink:'熱奶茶'}],['T1','冰乃茶',{drink:'凍奶茶'}],['T2','冰宁檬茶',{drink:'凍檸茶'}],['T2','热柠檬查',{drink:'熱檸茶'}],['T3','冰咖飞',{drink:'凍咖啡'}],['T3','热咖非',{drink:'熱咖啡'}],['T4','冰鸳央',{drink:'凍鴛鴦'}],['S1','炸机翅',{}],['P1','黄油菠萝包',{}],['P3','火腿炒蛋三明治',{}]];
export const families=['普通话早餐','普通话单点','普通话近音','饮料自定义','多人同餐','多人不同餐','多人不同配搭','部分没听清','单项直接改','中间餐点改','跟一份相同','跟一份另配','取消最近一份','否定不取消','所有饮料冷热','一杯冰一杯热','对象不明确','售罄保护','复合改错保护','堂食外带'];
const base=n=>[{uid:'a',id:'A',qty:1+n%19,drink:'凍奶茶',sugar:n<361?'正常甜':'走甜'},{uid:'b',id:'B',qty:1+Math.floor(n/19)%19,drink:'凍檸茶'},{uid:'c',id:'C',qty:1,drink:'熱咖啡'}];
export function* mandarinCases(){let count=0;for(const [f,family]of families.entries())for(let n=0;n<500;n++){
 const q=1+Math.floor(n/25),code='ABCDEF'[n%6],drink=n%2?'凍檸茶':'熱奶茶',spoken=n%2?'冰柠檬茶':'热奶茶',prefix=prefixes[n%5];let cart=[],text,expected=[],error=false,partial=false,mode='dinein',availability={};
 switch(f){
 case 0:text=prefix+q+'份早餐'+code+'，饮料要'+spoken;expected=[{id:code,qty:q,drink}];break;
 case 1:{const food=foods[n%20];text=prefixes[Math.floor(n/20)%5]+(1+Math.floor(n/100))+'份'+food[1];expected=[{id:food[0],qty:1+Math.floor(n/100)}];break;}
 case 2:{const [id,word,opts]=aliases[n%10];text=prefixes[Math.floor(n/10)%5]+(1+Math.floor(n/50))+(id.startsWith('T')?'杯':'份')+word;expected=[{id,qty:1+Math.floor(n/50),...opts}];break;}
 case 3:{const [id,word]=drinks[n%4],sugar=['少甜','走甜','半糖'][Math.floor(n/4)%3],ice=['少冰','走冰'][Math.floor(n/12)%2],s=['少放糖','不加糖','一半糖'][Math.floor(n/4)%3],i=['少放冰','不要冰'][Math.floor(n/12)%2];text=prefix+q+'杯冰'+word+s+i;expected=[{id,qty:q,drink:'凍'+(id==='T2'?'檸茶':id==='T4'?'鴛鴦':id==='T3'?'咖啡':'奶茶'),sugar,ice}];break;}
 case 4:{const people=2+n%6,each=1+Math.floor(n/6)%7,id='ABCDEF'[Math.floor(n/42)%6],d=n<252?'熱奶茶':'凍檸茶',texts=[];for(let i=0;i<people;i++){texts.push(each+'份早餐'+id+(n<252?'热奶茶':'冰柠檬茶'));expected.push({id,qty:each,drink:d});}text=texts.join('，');break;}
 case 5:{const people=2+Math.floor(n/20)%6,texts=[];for(let i=0;i<people;i++){const [id,word]=foods[(n+i)%20];texts.push((i===0?prefix:'')+(1+Math.floor(n/120))+'份'+word);expected.push({id,qty:1+Math.floor(n/120)});}text=texts.join('，');break;}
 case 6:{const people=2+n%6,id='ABCDEF'[Math.floor(n/6)%6],each=1+Math.floor(n/36)%5,ice=['正常冰','少冰','走冰'][Math.floor(n/180)%3],texts=[];for(let i=0;i<people;i++){const sugar=i%2?'走甜':'少甜';texts.push(each+'份早餐'+id+(i%2?'热奶茶不加糖':'冰柠檬茶少放糖'+(ice==='少冰'?'少放冰':ice==='走冰'?'不要冰':'')));expected.push({id,qty:each,drink:i%2?'熱奶茶':'凍檸茶',sugar,...(i%2?{}:{ice})});}text=texts.join('，');break;}
 case 7:{const [id,word]=foods[n%20];text=prefixes[Math.floor(n/20)%5]+(1+Math.floor(n/100))+'份'+word+'，一份青玉云朵';expected=[{id,qty:1+Math.floor(n/100)}];partial=true;break;}
 case 8:{const [id,word]=drinks[n%4];cart=[{id,qty:q,uid:'solo',drink:'凍'+(id==='T2'?'檸茶':id==='T4'?'鴛鴦':id==='T3'?'咖啡':'奶茶'),sugar:['正常甜','少甜','半糖','走甜'][Math.floor(n/4)%4]}];text=['换成热的','饮料换成热的','改热的','换成热饮','请换热的'][n%5];expected=cart.map(i=>({...i,drink:'熱'+(id==='T2'?'檸茶':id==='T4'?'鴛鴦':id==='T3'?'咖啡':'奶茶')}));break;}
 case 9:cart=base(n);text=['第二份的饮料改成热奶茶','第二个套餐的饮料换成热奶茶','把第二份的鸡蛋改成煎蛋','第二行改少糖','第二行的饮料改成热奶茶'][n%5];expected=cart.map((i,j)=>j!==1?i:{...i,...(n%5===2?{egg:'太陽蛋'}:n%5===3?{sugar:'少甜'}:{drink:'熱奶茶'})});break;
 case 10:cart=base(n);text=['再来一份一样的','我也要同样的','再要一份相同的','再上一份一样的','我要一样的'][n%5];expected=[...cart,{...cart.at(-1),qty:1}];break;
 case 11:cart=base(n);text=['再来一份但是要热奶茶','再上一份但要热奶茶','跟多份但要热奶茶','再来一份不过换成热奶茶','再来一份但改成热奶茶'][n%5];expected=[...cart,{...cart.at(-1),qty:1,drink:'熱奶茶'}];break;
 case 12:cart=base(n);text=['刚才那个不要了','刚刚那份不要了','上一份不要了','取消上一份','说错了'][n%5];expected=cart.slice(0,-1);break;
 case 13:cart=base(n);text=['不要取消订单','不要清空订单','别取消订单','不用取消全部','不要重新开始'][n%5];expected=cart;break;
 case 14:cart=base(n);text=['所有饮料都换成热的','全部饮料换成热的','每杯饮料都换成热的','所有饮料都换成热饮','全部饮料改热的'][n%5];expected=cart.map(i=>({...i,drink:i.drink.replace(/^凍/,'熱')}));break;
 case 15:{const [id,word]=drinks[n%4],a=1+Math.floor(n/4)%9,b=1+Math.floor(n/36);text=(a+b)+'杯'+word+'，'+a+'杯冰的'+b+'杯热的';expected=[{id,qty:a,drink:'凍'+(id==='T2'?'檸茶':id==='T4'?'鴛鴦':id==='T3'?'咖啡':'奶茶')},{id,qty:b,drink:'熱'+(id==='T2'?'檸茶':id==='T4'?'鴛鴦':id==='T3'?'咖啡':'奶茶')}];break;}
 case 16:cart=base(n);text=['改少糖','饮料换成热的','多士换成白面包','其中一份改少糖','鸡蛋改煎蛋'][n%5];error=true;break;
 case 17:{const[id,word]=foods[n%20];cart=base(n);text=prefix+q+'份'+word;availability[id]=false;error=true;break;}
 case 18:cart=base(n);text=['第一份改少糖，第二份改成青玉云朵','第二行换成热奶茶，第三行改成青玉云朵','取消第一份，然后改成青玉云朵','重新点餐，一份青玉云朵','第一份改成热奶茶，但是不要青玉云朵'][n%5];error=true;break;
 case 19:cart=base(n);text=['打包外带','改成外带','打包带走','外带','改成堂食'][n%5];mode=n%5===4?'dinein':'takeaway';expected=cart;break;
 }
 yield{id:'SC-'+String(++count).padStart(5,'0'),family,n,text,cart,expected,error,partial,mode,availability};
}}

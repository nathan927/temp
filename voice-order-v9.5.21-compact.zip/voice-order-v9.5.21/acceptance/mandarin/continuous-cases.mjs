import fs from'node:fs';const words=JSON.parse(fs.readFileSync(new URL('./closing-words.json',import.meta.url)));
export function* mandarinContinuousCases(){let serial=0;const row=(family,n,extra={})=>({id:'SC-HF-'+String(++serial).padStart(4,'0'),family,n,cart:Array.from({length:1+n%6},(_,i)=>({uid:'r'+i,id:'ABCDEF'[(n+i)%6],qty:i===0?Math.min(19,1+Math.floor(n/6)):1+(n+i)%3,drink:(n+i)%2?'熱奶茶':'凍檸茶',sugar:(n+i)%2?'少甜':'正常甜'})),...extra});
for(const[n,closing]of words.entries())yield row('收尾語獨立退出',n,{text:closing,closing});
for(const[n,closing]of words.entries()){const id='ABCDEF'[n%6],qty=1+n%3,drink=n%2?'凍檸茶':'熱奶茶';yield row('落餐連收尾語',n,{text:qty+'份早餐'+id+(n%2?'冰柠檬茶':'热奶茶')+'，'+closing,closing,add:{id,qty,drink},ambiguous:false});}
for(let n=0;n<30;n++)yield row('七秒靜音邊界',n);
for(let n=0;n<30;n++)yield row('暫定文字及長講話',n,{browser:n%2?'ios':'android'});
for(let n=0;n<40;n++)yield row('API排隊及退出保留已聽內容',n,{cart:[],set:'ABCDEF'[n%6],qty:1+Math.floor(n/6)});
for(let n=0;n<40;n++)yield row('辨識重啟及重複回呼',n,{cart:[],set:'ABCDEF'[n%6],qty:1+Math.floor(n/6),browser:n%2?'ios':undefined});
for(let n=0;n<30;n++)yield row('預設開關及設定保留',n);
for(let n=0;n<20;n++)yield row('權限提示背景及離頁',n,{cart:[],set:'ABCDEF'[n%6],qty:1+Math.floor(n/6)});
const negative=['不要停止收音','别停','还没说完','我还要点','继续听','无糖奶茶','冰柠檬茶','OK套餐','可乐','全部不要'];for(let n=0;n<30;n++)yield row('否定及非收尾字眼',n,{text:negative[n%10],expectKeep:n%10<5});
for(let n=0;n<40;n++)yield row('雲端轉錄收尾及截斷後續',n,{cart:[],set:'ABCDEF'[n%6],qty:1+Math.floor(n/6),cloudText:n%2?(1+Math.floor(n/6))+'份早餐'+'ABCDEF'[n%6]+'热奶茶，就这些':words[n]});
}

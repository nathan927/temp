import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import {createHash,webcrypto} from 'node:crypto';
import {pathToFileURL} from 'node:url';
import {userFailureCases} from './cases.mjs';
const plain=value=>JSON.parse(JSON.stringify(value));
function engine(html,api){
 const context=vm.createContext({URL,console,crypto:webcrypto,structuredClone,performance,setTimeout,clearTimeout,fetch:()=>{api.count++;throw Error('Unexpected network request');}});
 for(const [,source]of html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/g))if(!source.includes("(()=>{'use strict';"))vm.runInContext(source,context);
 return context.Kam;
}
function expected(K,cart,order,steps){
 let items=structuredClone(cart),portionOrder=order.slice();
 for(const step of steps){
  if(step.clear){items=[];portionOrder=[];continue;}
  if(step.update!==undefined){items[step.update]=plain(K.normalize({...items[step.update],...step.patch}));continue;}
  if(step.replace!==undefined){const source=items[step.replace];items[step.replace]=plain(K.normalize({...K.defaults(K.menu.find(m=>m.id===step.id)),uid:source.uid,qty:source.qty,drink:source.drink,sugar:source.sugar,milk:source.milk,ice:source.ice,size:source.size}));continue;}
  const item=plain(K.normalize(step.add||{...cart[step.copy],qty:step.qty,...step.patch}));
  item.uid='expected-'+items.length;items.push(item);portionOrder.push(...Array(item.qty).fill(item.uid));
 }
 return {cart:items,portionOrder};
}
const stable=cart=>cart.map(({uid,pendingPair,drinkPrompted,...item})=>item);
export async function runUserFailures(html,rows=userFailureCases(),{historical=false}={}){
 const api={count:0},K=engine(html,api),hash=createHash('sha256'),seen=new Set(),phrases=new Set();
 const report={total:0,passed:0,failed:0,unsafe:0,fulfilled:0,guarded:0,families:{},examples:[]};
 for(const row of rows){
  const key=JSON.stringify([row.text,row.cart,row.portionOrder,row.mode,row.orderNotes,row.recommendationActive,row.alternatives]);if(!historical)assert.ok(!seen.has(key));seen.add(key);phrases.add(row.text);hash.update(JSON.stringify(row)+'\n');report.total++;
  const family=report.families[row.family]??={passed:0,failed:0};
  const cart=plain(row.cart.map(K.normalize)),state={...row,cart,orders:[{id:'submitted-existing',status:'received',items:[{id:'P1',qty:1}]}]},before=JSON.stringify(state);
  let error,resolved,result;
  try{resolved=K.resolveDeviceVoice({localText:row.text,localAlternatives:row.alternatives||[],cart,context:state});if(resolved.plan)result=K.transitionDraft(state,resolved.plan,state.availability);}catch(caught){error=caught;}
  try{
   assert.equal(JSON.stringify(state),before,'input state and submitted orders must not mutate');
   if(row.error){
    assert.equal(resolved?.plan,undefined,'unsafe executable plan for a guard');
    assert.ok([row.error].flat().includes(error?.code),'expected '+row.error+'; got '+error?.code);report.guarded++;
   }else{
    assert.equal(error?.code,undefined,'local command failed: '+error?.code);
    assert.equal(resolved.provider,'device');
    if(row.intent)assert.equal(resolved.plan.intent,row.intent);
    if(row.next)assert.equal(resolved.plan.next,true);
    if(row.partial)assert.ok(resolved.plan.partialUnresolved?.length,'ask about only the unknown clauses');
    const want=expected(K,cart,row.portionOrder,row.steps);
    assert.deepEqual(stable(plain(result.cart)),stable(want.cart),'every item, quantity and option');
    const ids=new Map(result.cart.map((item,index)=>[item.uid,'row-'+index])),wantedIds=new Map(want.cart.map((item,index)=>[item.uid,'row-'+index]));
    assert.deepEqual(Array.from(result.portionOrder,id=>ids.get(id)),want.portionOrder.map(id=>wantedIds.get(id)),'portion chronology');
    assert.equal(result.mode,row.expectedMode||row.mode);assert.deepEqual(plain(result.orderNotes),row.orderNotes);assert.equal(K.total(result.cart),K.total(want.cart),'price');
    report.fulfilled++;
   }
   family.passed++;report.passed++;
  }catch(assertion){
   if(result){
    const wanted=row.error?{cart,portionOrder:row.portionOrder}:expected(K,cart,row.portionOrder,row.steps);
    if(JSON.stringify(stable(plain(result.cart)))!==JSON.stringify(stable(wanted.cart))||result.mode!==(row.expectedMode||row.mode)||JSON.stringify(plain(result.orderNotes))!==JSON.stringify(row.orderNotes))report.unsafe++;
   }
   family.failed++;report.failed++;
   if(report.examples.filter(item=>item.family===row.family).length<3)report.examples.push({id:row.id,family:row.family,text:row.text,expectedError:row.error,error:error?.code,data:error?.data,assertion:assertion.message.split('\n')[0],result:result?.cart.map(({id,qty,drink,sugar,ice})=>({id,qty,drink,sugar,ice}))});
  }
 }
 return {...report,unique:seen.size,uniqueTranscripts:phrases.size,apiCalls:api.count,sha256:hash.digest('hex')};
}
if(import.meta.url===pathToFileURL(process.argv[1]||'').href){
 const {version}=JSON.parse(fs.readFileSync(new URL('../../package.json',import.meta.url),'utf8'));
 const report=await runUserFailures(fs.readFileSync(process.argv[2]||'智能茶餐廳-v'+version+'.html','utf8'));
 console.log(JSON.stringify(report,null,2));if(report.failed||report.apiCalls)process.exitCode=1;
}

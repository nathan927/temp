/* Verify that even configured cloud providers are not called for these
 * locally fulfilled or safely clarified scenarios. No remote requests. */
import fs from 'node:fs';
import vm from 'node:vm';
import {webcrypto}from 'node:crypto';
import {userFailureCases}from './cases.mjs';
const {version}=JSON.parse(fs.readFileSync(new URL('../../package.json',import.meta.url),'utf8'));
const html=fs.readFileSync(process.argv[2]||'智能茶餐廳-v'+version+'.html','utf8');
const report={total:0,passed:0,failed:0,asrAttempts:0,parserAttempts:0,networkAttempts:0,examples:[]};
const c=vm.createContext({console,crypto:webcrypto,performance,setTimeout,clearTimeout,structuredClone,fetch:()=>{report.networkAttempts++;throw Error('Unexpected network request');}});
for(const [,source]of html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/g))if(!source.includes("(()=>{'use strict';"))vm.runInContext(source,c);
const K=c.Kam;
for(const row of userFailureCases()){
 report.total++;let error,resolved;
 try{resolved=await K.resolveVoice({audio:'test-fixture',localText:row.text,localAlternatives:row.alternatives||[],cart:row.cart.map(K.normalize),context:row,
  available:()=>true,canParse:()=>true,asr:async()=>{report.asrAttempts++;throw Error('Unexpected ASR call');},parse:async()=>{report.parserAttempts++;throw Error('Unexpected parser call');}});}catch(e){error=e;}
 const valid=row.error?[row.error].flat().includes(error?.code)&&!resolved?.plan:resolved?.provider==='device'&&!!resolved.plan&&!error;
 if(valid)report.passed++;else{report.failed++;if(report.examples.length<5)report.examples.push({id:row.id,text:row.text,code:error?.code,message:error?.message});}
}
console.log(JSON.stringify(report,null,2));if(report.failed||report.asrAttempts||report.parserAttempts||report.networkAttempts)process.exitCode=1;

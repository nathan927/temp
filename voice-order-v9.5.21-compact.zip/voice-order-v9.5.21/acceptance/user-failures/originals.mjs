/* These are declared replay contexts, not reconstructed historical carts:
 * the supplied export does not contain historical draft snapshots. */
import fs from 'node:fs';
const log=JSON.parse(fs.readFileSync(new URL('./field-log-fixture.json',import.meta.url),'utf8'));
export function originalCases(){
 const a={uid:'original-a',id:'A',qty:1,drink:'凍檸茶'},t={uid:'original-t',id:'T2',qty:1,drink:'凍檸茶'};
 const add=(id,qty=1,drink='待選飲品')=>({add:{id,qty,drink}});
 return log.messages.map((message,index)=>{
  const row={id:'original-'+index,family:'原句重播（'+message.status+'）',text:message.text,observedStatus:message.status,observedError:message.error,
   cart:[a],portionOrder:[a.uid],mode:'dinein',orderNotes:[],steps:[]};
  const empty=()=>{row.cart=[];row.portionOrder=[];};
  switch(message.text){
   case '凍':row.cart=[{...t,drink:'熱檸茶'}];row.portionOrder=[t.uid];row.steps=[{update:0,patch:{drink:'凍檸茶'}}];break;
   case '凍檸茶':case '要檸檬茶':empty();row.steps=[add('T2',1,'凍檸茶')];break;
   case '熱檸茶':empty();row.steps=[add('T2',1,'熱檸茶')];break;
   case '專業飲':case '專業音':row.cart=[t];row.portionOrder=[t.uid];row.steps=[{update:0,patch:{drink:'熱檸茶'}}];break;
   case '唔要喇':case '全部唔要':case '取消':case '取消訂單':row.steps=[{clear:true}];break;
   case '有咩好介紹':case '有咩介紹':case '餵有咩介紹':row.intent='recommend';break;
   case '換一些':case '換一套呀':row.recommendationActive=true;row.intent='recommend';row.next=true;break;
   case '跟多一杯':row.cart=[t];row.portionOrder=[t.uid];row.steps=[{copy:0,qty:1}];break;
   case '轉外賣':row.expectedMode='takeaway';break;
   case '煮飯堂食':case '轉返堂食':row.mode='takeaway';row.expectedMode='dinein';break;
   case '早餐a':case '一份早餐a':empty();row.steps=[add('A')];break;
   case '唔要檸檬茶':row.cart=[t];row.portionOrder=[t.uid];row.steps=[{clear:true}];break;
   case '早餐師':empty();row.steps=[add('C')];break;
   case '要唔要喇':row.error='cancelQuestion';break;
   case '有咩飲品揀':row.intent='navigate';break;
   case '早餐司檸檬茶轉意粉':row.cart=[{...a,id:'C'}];row.error=['notApplicable','missingTarget'];break;
   case '早餐a轉意粉':row.steps=[{update:0,patch:{noodle:'意粉'}}];break;
   case '落錯咗':row.steps=[{clear:true}];break;
   case '早餐師兩份':empty();row.steps=[add('C',2)];break;
   case '飲品要熱菜蜜':row.steps=[{update:0,patch:{drink:'熱西洋菜蜜'}}];break;
   case '一份早餐先兩份早餐啲三份早餐衣':empty();row.steps=[add('C'),add('D',2),add('E',3)];break;
   case '一份早餐試兩份早餐衣三份早餐f':empty();row.steps=[add('C'),add('E',2),add('F',3)];break;
   case '一份早餐試飲熱奶茶':empty();row.steps=[add('C',1,'熱奶茶')];break;
   case '嚟多份':case '加多份':case '要多一份':row.steps=[{copy:0,qty:1}];break;
   case '有冇兒童餐':row.error='unavailable';break;
   case '我要個波餐':empty();row.steps=[add('B')];break;
   case '改要個bo餐':row.steps=[{replace:0,id:'B'}];break;
   default:throw Error('Undeclared replay context: '+message.text);
  }
  return row;
 });
}

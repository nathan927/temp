/* 10,000 new scenarios derived from the supplied 55-message field log.
 * Expected effects are declared here, independently of the interpreter. */
const families=['嚟多份照跟','加多份的份數','照跟轉飲品','明確加新餐不照跟','波餐與bo餐','改要bo餐','早餐C連飲品','多人CDE近音長單','長單中間改飲品','凍熱短句','餵有咩介紹','推介後換一些或換一套','煮飯堂食','取消草稿與否定取消','加餐再照跟及反口','取消問句不得刪餐','無上下文不得猜測','不供應或不可行的配搭','ASR候選意思衝突','部分聽清先記低'];
const copy=['嚟多','來多','加多','再加多','再加','要多','叫多','整多','加返','添多'];
const prefix=['','唔該','麻煩你','幫我','老細，','師傅，'];
const suffix=['','呀','吖','啦','唔該','多謝'];
const drinks=['熱奶茶','凍奶茶','熱檸茶','凍檸茶','熱咖啡','凍咖啡','熱西洋菜蜜','凍西洋菜蜜'];
const aliases={A:['A','apple','alpha'],B:['B','波餐','bo餐','早餐波','早餐bo','早餐Boy'],C:['C','早餐先','早餐試','早餐司','早餐師','早餐see'],D:['D','早餐啲','早餐dog'],E:['E','早餐衣','早餐egg'],F:['F','早餐fox']};
const named=(id,n)=>{const a=aliases[id][n%aliases[id].length];return /^[A-F]$/.test(a)||/^[a-z]+$/i.test(a)?'早餐'+a:a;};
const count=n=>['一','兩','三','四','五','六','七'][n-1];
const rnd=seed=>()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
const choose=(a,r)=>a[Math.floor(r()*a.length)];
function make(f,n,attempt){
 const r=rnd(516916+f*112849+n*11719+attempt*932743),length=2+Math.floor(r()*6);
 const cart=Array.from({length},(_,i)=>({uid:'line-'+i,id:choose(['A','B','C','D','E','F'],r),qty:1+Math.floor(r()*3),
  drink:choose(drinks,r),sugar:choose(['正常甜','少甜','半糖','走甜'],r),ice:choose(['正常冰','少冰','走冰'],r),toast:choose(['正常多士','烘底','飛邊'],r)}));
 for(const item of cart)if(item.drink[0]==='熱')item.ice='正常冰';
 const target=Math.floor(r()*length),source=cart[target],portionOrder=cart.flatMap((item,i)=>Array(item.qty-(i===target?1:0)).fill(item.uid)).concat(source.uid);
 const state={cart,portionOrder,mode:n%2?'takeaway':'dinein',orderNotes:n%3===0?['餐具另外放']:[]};
 const d=choose(drinks,r),q=1+n%5;
 const decorate=text=>choose(prefix,r)+text+choose(suffix,r);
 const row=(text,steps=[],extra={})=>({family:families[f],...state,text,steps,...extra});
 const guard=(text,error,extra={})=>row(text,[],{error,...extra});
 const item=(id,qty=1,drink='待選飲品',more={})=>({id,qty,drink,...more});
 switch(f){
  case 0:return row(decorate(choose(copy,r)+'份'),[{copy:target,qty:1}]);
  case 1:return row(decorate(choose(copy,r)+(n%2?q:count(q))+'份'+(n%3===0?'一樣':'')),[{copy:target,qty:q}]);
  case 2:return row(decorate(choose(copy,r)+'份'+choose(['但要','不過要','但係想飲','改做'],r)+d+'少甜'),[{copy:target,qty:1,patch:{drink:d,sugar:'少甜',...(d[0]==='熱'?{ice:'正常冰'}:{})}}]);
  case 3:{const id=choose(['A','B','C','D','E','F'],r);return row(decorate(choose(['加多','要多','再嚟','再加'],r)+count(q)+'份早餐'+id+d),[{add:item(id,q,d)}]);}
  case 4:return row(decorate(count(q)+'份'+choose(['波餐','bo餐','BO餐','早餐波','早餐bo','早餐Boy'],r)+d),[{add:item('B',q,d)}]);
  case 5:{
   state.cart=[{uid:'line-0',id:choose(['A','C','D','E'],r),qty:q,drink:d,sugar:choose(['少甜','半糖','正常甜'],r)}];state.portionOrder=Array(q).fill('line-0');
   return row(decorate(choose(['改要個','改叫','轉叫','改要'],r)+choose(['波餐','bo餐','早餐Boy','早餐bo'],r)),[{replace:0,id:'B'}]);
  }
  case 6:return row(decorate(count(q)+'份'+choose(['早餐試','早餐師','早餐司','早餐先','早餐C'],r)+'飲'+d+(n%2?'少甜':'')),[{add:item('C',q,d,n%2?{sugar:'少甜'}:{})}]);
  case 7:{
   const people=2+n%6,parts=[],steps=[];
   for(let i=0;i<people;i++){const id=choose(['B','C','D','E'],r),qty=1+Math.floor(r()*2),drink=choose(drinks,r);parts.push(count(qty)+'份'+named(id,n+i)+drink);steps.push({add:item(id,qty,drink)});}
   return row(decorate(parts.join(n%2?'，':'')),steps);
  }
  case 8:{const index=Math.floor(length/2),drink=cart[index].drink[0]==='熱'?'凍奶茶':'熱奶茶';return row(decorate('第'+count(index+1)+'行飲品轉'+drink),[{update:index,patch:{drink,...(drink[0]==='熱'?{ice:'正常冰'}:{})}}]);}
  case 9:{
   const index=target,temp=n%2?'熱':'凍',command=n%4===0?temp:n%4===1?temp+'啲':temp==='熱'?choose(['專業飲','專業音','轉業飲','轉熱飲'],r):choose(['傳動飲','轉凍音','轉動飲','轉凍飲'],r);
   for(let i=0;i<length;i++)if(i!==index)cart[i].drink='待選飲品';
   return row(decorate(command),[{update:index,patch:{drink:temp+source.drink.slice(1),...(temp==='熱'?{ice:'正常冰'}:{})}}]);
  }
  case 10:return row(choose(['餵','喂'],r)+choose(['有咩介紹','有冇好介紹','有咩好介紹'],r)+choose(suffix,r),[],{intent:'recommend'});
  case 11:return row(decorate(choose(['換一些','換一啲','換一套','換另一套','換第二款','轉另一套','再換款'],r)),[],{recommendationActive:true,intent:'recommend',next:true});
  case 12:{const negative=n%4===0;return row(decorate((negative?'唔好':'')+choose(['煮飯堂食','煮返堂食','轉飯堂食'],r)),[],{intent:negative?'edit':'service',expectedMode:negative?state.mode:'dinein'});}
  case 13:{const negative=n%3===0;return row(decorate((negative?choose(['唔好','咪','唔使'],r):'')+choose(['取消訂單','取消呢張訂單','清空草稿','刪走訂單'],r)),negative?[]:[{clear:true}],{intent:negative?'edit':'clear'});}
  case 14:{
   const id=choose(['A','B','C','D','E','F'],r);return row(decorate('一份早餐'+id+d+'，'+choose(copy,r)+'份但要熱奶茶'+(n%2?'，講錯咗':'')),n%2?[{add:item(id,1,d)}]:[{add:item(id,1,d)},{add:item(id,1,'熱奶茶')}]);
  }
  case 15:return guard(decorate(choose(['要唔要喇','係咪唔要嗰份','係咪取消訂單','要唔要張單'],r)),'cancelQuestion');
  case 16:{
   const which=n%3;
   if(which===0){state.cart=[];state.portionOrder=[];return guard(decorate(choose(copy,r)+'份'),'noRecentPortion');}
   if(which===1)return guard(decorate(choose(['換一些','換一套','轉另一套','換第二款'],r)),'recommendNeedsContext');
   return guard(decorate(choose(['凍','熱','凍啲','熱啲'],r)),'temperatureNeedsTarget');
  }
  case 17:{
   const which=n%3;
   if(which===0)return guard(decorate(choose(['有冇兒童餐','有冇小童餐','要份兒童套餐','要小童套餐'],r)),'unavailable');
   if(which===1){state.cart=[item('C',q,d,{uid:'line-0'})];state.portionOrder=Array(q).fill('line-0');return guard(decorate('早餐司檸檬茶轉意粉'),['notApplicable','missingTarget']);}
   return guard(decorate(choose(copy,r)+'份但要走冰少冰'),'conflictingOptions');
  }
  case 18:return guard(decorate(n%2?choose(copy,r)+'份':choose(['波餐','bo餐','早餐波','早餐啲','早餐先'],r)),'confirmTranscript',{alternatives:[n%2?'講錯咗':'早餐A']});
  case 19:{const a=choose(['A','B','C','D','E','F'],r),b=choose(['B','C','D','E'],r);return row(decorate(count(q)+'份早餐'+a+d+'，'+count(q)+'份'+named(b,n)+'熱奶茶，'+choose(['青玉雲朵','星河雪糕','紫霞晚餐'],r)),[{add:item(a,q,d)},{add:item(b,q,'熱奶茶')}],{partial:true});}
 }
}
export function* userFailureCases(){
 const seen=new Set();
 for(let f=0;f<families.length;f++)for(let n=0;n<500;n++){
  let row,key,attempt=0;
  do{row=make(f,n,attempt++);key=JSON.stringify([row.text,row.cart,row.portionOrder,row.mode,row.orderNotes,row.recommendationActive,row.alternatives]);}while(seen.has(key));
  seen.add(key);yield {id:'UF-'+String(f*500+n+1).padStart(5,'0'),...row};
 }
}

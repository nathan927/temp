import fs from 'node:fs';
import {runUserFailures}from './run.mjs';
import {originalCases}from './originals.mjs';
const {version}=JSON.parse(fs.readFileSync(new URL('../../package.json',import.meta.url),'utf8'));
const r=await runUserFailures(fs.readFileSync(process.argv[2]||'智能茶餐廳-v'+version+'.html','utf8'),originalCases(),{historical:true});
console.log(JSON.stringify(r,null,2));if(r.failed)process.exitCode=1;

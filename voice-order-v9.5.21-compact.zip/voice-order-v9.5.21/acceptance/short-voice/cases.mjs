// Expected dish IDs, quantities and options are specified independently of the parser.
const drinks=[
 ['T1','奶茶','凍瀨茶'],['T2','檸茶','凍凝茶'],['T3','咖啡','東啡'],['T4','鴛鴦','東冤央'],
 ['T5','檸水','凍凝水'],['T6','檸蜜','凍寧密'],['T7','西洋菜蜜','凍菜勿'],
 ['T8','阿華田','凍阿華填'],['T9','好立克','凍好粒克'],['T10','美祿','凍米祿'],
];
const food=[
 ['S1','炸雞疫'],['P1','菠蘿佑'],['P2','西多仕'],['P3','腿旦寺'],['P6','蛋池'],
 ['P13','瀨醬多士'],['P15','牛油多仕'],['S3','炸薯跳'],['R1','乾抄牛荷'],['R3','揚州抄繁'],
];
const hot=['轉業飲','轉葉飲','轉熱音','轉熱陰','傳熱音','專熱飲','轉熱任','轉熱隱','傳熱飲','專業音'];
const cold=['傳動飲','轉動飲','專凍飲','轉凍音','轉凍陰','轉冬飲','轉凍隱','轉凍任','傳凍飲','轉洞飲'];
const sugar=[
 ['少廷','sugar','少甜'],['走廷','sugar','走甜'],['半堂','sugar','半糖'],['少賓','ice','少冰'],
 ['小賓','ice','少冰'],['走賓','ice','走冰'],['少瀨','milk','少奶'],['走瀨','milk','走奶'],
 ['大卑','size','大杯'],['少填','sugar','少甜'],
];
const kitchen=[
 ['返但','A','egg','反蛋'],['淑旦','B','egg','熟蛋'],['煎但','C','egg','太陽蛋'],['湯令尚','Q1','broth','湯另上'],
 ['少塘','Q2','broth','少湯'],['芳包','P13','toast','方包'],['飛鞭','P14','toast','飛邊'],
 ['返但','D','egg','反蛋'],['煎但','E','egg','太陽蛋'],['淑旦','A','egg','熟蛋'],
];
const families=[
 'observed-hot-transcript','hot-command-variants','cold-command-variants','named-noisy-target','ordinal-target',
 'one-of-several-portions','set-included-drink','casual-explicit-change','same-effect-candidates','negated-command',
 'missing-or-ineligible-drink','multi-drink-clarification','conflicting-temperature','conflicting-scope','unrelated-phrase-or-note',
 'drink-name-variants','food-name-variants','spoken-quantities','drink-modifier-variants','kitchen-modifier-variants',
];
const zh=['零','一','兩','三','四','五','六','七','八','九','十'];
const prefixes=['','唔該','麻煩你','幫我','請'],suffixes=['','呀','啦','唔該','喎'];
const row=(id,qty,fields={})=>({id,qty,...fields});
const saved=(id,qty,fields={})=>row(id,qty,{uid:'line-'+id,...fields});
const foodSide=(qty=1)=>saved('P21',qty,{note:'餐具分開'});
const beverage=(d,n,temperature,fields={})=>saved(d[0],n,{drink:temperature+d[1],...fields});
const hotUpdate=(line,d)=>({...line,drink:'熱'+d[1],ice:'正常冰'});
const coldUpdate=(line,d)=>({...line,drink:'凍'+d[1],ice:'正常冰'});
const sets='ABCDE';

export function* shortVoiceCases(){
 for(const family of families)for(let i=0;i<500;i++){
  const k=i%10,n=1+Math.floor(i/10)%10,style=Math.floor(i/100),num=zh[n];
  const say=s=>prefixes[style]+s+suffixes[style];
  const d=drinks[k],other=drinks[(k+3)%10];
  const iced=beverage(d,n,'凍',{sugar:'少甜',ice:'少冰'}),warm=beverage(d,n,'熱',{sugar:'少甜'});
  const second=beverage(other,1,'凍');
  let text,alternatives=[],cart=[],expected=[],error,notes=[];
  switch(family){
   case 'observed-hot-transcript':
    text=say('專業飲');cart=[iced];expected=[hotUpdate(iced,d)];break;
   case 'hot-command-variants':
    text=say(hot[k]);cart=[foodSide(2),iced];expected=[cart[0],hotUpdate(iced,d)];break;
   case 'cold-command-variants':
    text=say(cold[k]);cart=[warm,foodSide(3)];expected=[coldUpdate(warm,d),cart[1]];break;
   case 'named-noisy-target':
    text=say(d[2]+'專業飲');cart=[second,iced];expected=[second,hotUpdate(iced,d)];break;
   case 'ordinal-target':
    text=say(['第三杯','弟三杯','第三碑','地三卑','第三背'][style]+hot[k]);
    cart=[foodSide(),second,iced];expected=[cart[0],second,hotUpdate(iced,d)];break;
   case 'one-of-several-portions':{
    const count=n+1,line={...iced,qty:count};
    text=say(['其中一杯','期中一杯','其鐘一碑','其中一背','其鐘一卑'][style]+hot[k]);
    cart=[line];const {uid,...portion}=hotUpdate(line,d);
    expected=[{...line,qty:n},{...portion,qty:1}];break;
   }
   case 'set-included-drink':{
    const set=saved(sets[k%5],n,{drink:iced.drink,egg:'炒蛋',sugar:'少甜',ice:'走冰'});
    text=say((k<5?'轉熱音':'專業飲'));cart=[set];
    expected=[hotUpdate(set,d)];break;
   }
   case 'casual-explicit-change':{
    const colder=k%2===1;
    const terms=['轉返熱嘅','轉返凍嘅','改返熱嘅','改返凍嘅','換返熱嘅','換返凍嘅','改做熱啲','改做凍啲','杯嘢整熱少少','杯嘢整凍少少'];
    text=say(terms[k]);cart=[colder?warm:iced,foodSide(4)];
    expected=[colder?coldUpdate(warm,d):hotUpdate(iced,d),cart[1]];break;
   }
   case 'same-effect-candidates':
    text=say(hot[k]);alternatives=['轉熱飲'];cart=[iced];expected=[hotUpdate(iced,d)];break;
   case 'negated-command':
    text=say((k%2?'唔好':'咪')+hot[k]);cart=[iced,second];expected=cart;break;
   case 'missing-or-ineligible-drink':
    text=say(hot[k]);
    if(k<4){cart=[foodSide(n)];error='notApplicable';}
    else if(k<7){cart=[saved(sets[k%5],n,{drink:'待選飲品'})];error='needChange';}
    else{cart=[saved('T20',n,{drink:'凍可樂'}),saved(food[k][0],1)];error='invalidOption';}
    break;
   case 'multi-drink-clarification':
    text=say('專業飲');cart=[iced,second];error='ambiguousTarget';break;
   case 'conflicting-temperature':
    text=say(hot[k]);alternatives=['轉凍飲'];cart=[iced];error='confirmTranscript';break;
   case 'conflicting-scope':
    text=say('第二杯'+hot[k]);alternatives=[k%2?'全部轉熱飲':'第一杯轉熱飲'];cart=[second,iced];error='confirmTranscript';break;
   case 'unrelated-phrase-or-note':
    cart=[iced,foodSide(5)];
    if(k<5){text=say('專業飲食');error='unrecognizedTokens';}
    else{text=say('備註：專業飲食標貼');expected=cart;notes=['專業飲食標貼'];}
    break;
   case 'drink-name-variants':
    text=say('要'+num+'杯'+d[2]);expected=[row(d[0],n,{drink:iced.drink})];break;
   case 'food-name-variants':
    text=say('要'+num+'份'+food[k][1]);expected=[row(food[k][0],n)];break;
   case 'spoken-quantities':{
    const foodOrder=k%2===1,name=foodOrder?food[k][1]:d[2];
    const measure=foodOrder?(k<5?'芬':'吩'):(k<5?'碑':'卑');
    text=say(style%2?name+num+measure:'要'+num+measure+name);
    expected=foodOrder?[row(food[k][0],n)]:[row(d[0],n,{drink:iced.drink})];
    break;
   }
   case 'drink-modifier-variants':{
    const [term,field,value]=sugar[k],line=beverage(drinks[field==='milk'?0:k%3],n,'凍');
    text=say('改'+term);cart=[line];expected=[{...line,[field]:value}];break;
   }
   case 'kitchen-modifier-variants':{
    const [term,id,field,value]=kitchen[k];cart=[saved(id,n)];text=say('改做'+term);expected=[{...cart[0],[field]:value}];break;
   }
  }
  yield {family,text,alternatives,cart,expected,error,notes,audio:i%2===0};
 }
}

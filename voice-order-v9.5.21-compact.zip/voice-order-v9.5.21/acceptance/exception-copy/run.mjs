import fs from'node:fs';import vm from'node:vm';import assert from'node:assert/strict';import{webcrypto,createHash}from'node:crypto';import{pathToFileURL}from'node:url';import{exceptionCases}from'./cases.mjs';
export function runExceptions(html,{traceFile}={}){
 const contexts=Object.fromEntries(['tc','sc','en'].map(lang=>{const c=vm.createContext({URL,KAM_LANG:lang,console,crypto:webcrypto,structuredClone,performance,setTimeout,clearTimeout});for(const [,s]of html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/g))if(!s.includes("(()=>{'use strict';"))vm.runInContext(s,c);return[lang,c];}));
 const seen=new Set(),wording=new Set(),hash=createHash('sha256'),report={total:0,passed:0,failed:0,codes:{},examples:[]};const trace=[];
 for(const row of exceptionCases()){
  const L=contexts[row.lang].I18n;report.total++;seen.add(JSON.stringify([row.code,row.lang,row.cart,row.error.data,row.source]));hash.update(JSON.stringify(row)+'\n');const group=report.codes[row.code]??={passed:0,failed:0};const before=JSON.stringify(row.cart);
  const lead=L.exceptionLead(row.code,row.lang),key=Object.hasOwn(L.dict,row.code)||Object.hasOwn(L.errors,row.code)?row.code:'unexpectedFailure';
  let detail=L.text(key,row.lang,row.error.data);if(/\{\w+\}/.test(detail))detail=L.text('unexpectedFailure',row.lang);const text=lead+'\n'+detail;wording.add(text);
  try{
   assert.equal(JSON.stringify(row.cart),before);assert.ok(lead.length>=5);assert.ok(detail.length>=5);assert.doesNotMatch(text,/你睇吓啱唔啱|\{\w+\}|undefined|\[object Object\]|unknownInternalMarker|TypeError|Error Code/i);
   assert.doesNotMatch(lead,/已送單|已確認落單|已經落好單/);if(row.lang==='en')assert.doesNotMatch(lead,/\p{Script=Han}/u);if(row.lang==='sc')assert.doesNotMatch(text,/[唔咗喺嘅啱揀哋喎冇]/);
   if(row.code==='apiInvalidKey')assert.match(detail,/key|金鑰|金钥/i);
   if(row.code==='apiRateLimit')assert.match(detail,/等|wait/i);
   if(row.code==='apiQuota')assert.match(detail,/用量|quota/i);
   if(row.code==='staleVoiceOrder')assert.match(detail,/改|changed/i);
   if(row.code==='auditReadFailed')assert.match(detail,/未下載|未下载|没有下载|No partial download/i);
   report.passed++;group.passed++;trace.push({...row,lead,detail,status:'passed'});
  }catch(e){report.failed++;group.failed++;trace.push({...row,lead,detail,status:'failed',error:e.message});if(report.examples.length<10)report.examples.push({id:row.id,code:row.code,lang:row.lang,lead,detail,error:e.message.split('\n')[0]});}
 }
 if(traceFile){fs.writeFileSync(traceFile+'.partial',trace.map(r=>JSON.stringify(r)).join('\n')+'\n');fs.renameSync(traceFile+'.partial',traceFile);}
 return {...report,unique:seen.size,distinctResponses:wording.size,sha256:hash.digest('hex')};
}
if(import.meta.url===pathToFileURL(process.argv[1]||'').href){const{version}=JSON.parse(fs.readFileSync(new URL('../../package.json',import.meta.url),'utf8'));const r=runExceptions(fs.readFileSync(process.argv[2]||'智能茶餐廳-v'+version+'.html','utf8'),{traceFile:'acceptance/exception-copy/execution.jsonl'});console.log(JSON.stringify(r,null,2));if(r.failed)process.exitCode=1;}

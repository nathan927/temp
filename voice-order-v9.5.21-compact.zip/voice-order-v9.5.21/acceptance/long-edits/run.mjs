import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import {createHash,webcrypto} from 'node:crypto';
import {pathToFileURL} from 'node:url';
import {longEditCases} from './cases.mjs';

function engine(html){
 const context=vm.createContext({URL,console,crypto:webcrypto,structuredClone,performance,setTimeout,clearTimeout});
 for(const [,source] of html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/g)){
  if(!source.includes("(()=>{'use strict';"))vm.runInContext(source,context);
 }
 return context.Kam;
}
const plain=value=>JSON.parse(JSON.stringify(value));
function expectedCart(cart,changes){
 const byIndex=new Map(changes.map(change=>[change.i,change]));
 return cart.flatMap((line,index)=>{
  const change=byIndex.get(index);
  if(!change)return [line];
  if(change.remove)return [];
  if(change.split)return [{...line,qty:line.qty-change.split},{...line,...change.patch,uid:null,qty:change.split}];
  return [{...line,...change.patch}];
 });
}
export async function runLongEdits(html){
 const K=engine(html),seen=new Set(),hash=createHash('sha256');
 const report={total:0,passed:0,failed:0,unsafe:0,apiCalls:0,families:{},examples:[]};
 for(const row of longEditCases()){
  const {text,cart:fixture,mode,orderNotes,availability,alternatives}=row;
  const key=JSON.stringify({text,fixture,mode,orderNotes,availability,alternatives});
  assert.ok(!seen.has(key),'Duplicate transcript and cart');
  seen.add(key);hash.update(JSON.stringify(row)+'\n');report.total++;
  const family=report.families[row.family]??={passed:0,failed:0};
  const cart=plain(row.cart.map(K.normalize)),before=JSON.stringify(cart);
  const state={cart,mode:row.mode,orderNotes:row.orderNotes||[],availability:row.availability||{}};
  const args={localText:row.text,localAlternatives:row.alternatives||[],cart,context:state};
  let resolved,error,result;
  try{
   if(row.clause){
    const unexpected=()=>{report.apiCalls++;throw new Error('Unexpected remote call');};
    resolved=await K.resolveVoice({...args,audio:'fixture',available:()=>true,asr:unexpected,parse:unexpected});
   }else resolved=K.resolveDeviceVoice(args);
   error=resolved.error;
   if(resolved.plan)result=K.transitionDraft(state,resolved.plan,state.availability);
  }catch(caught){error=caught;}
  try{
   assert.equal(JSON.stringify(cart),before,'input draft mutation');
   if(row.error){
    assert.equal(resolved?.plan,undefined,'a failed request must have no executable plan');
    assert.equal(error?.code,row.error,'typed failure');
    if(row.clause)assert.ok(error.data?.editClause,'identify the failed clause');
    if(row.choices){
     const choices=Array.from(error.data?.choices||[]);
     for(const index of row.choices)assert.ok(choices.some(choice=>choice.uid===cart[index].uid),'choice must identify the real row');
     for(const choice of choices){
      assert.equal(choice.plan.ops.length,1,'only the chosen line can change');
      assert.equal(choice.plan.ops[0].target.uid,choice.uid);
     }
    }
   }else{
    assert.equal(error,undefined,'local edit should resolve');
    assert.equal(resolved.provider,'device');
    assert.equal(result.mode,row.mode);assert.equal(result.orderNotes.length,0);
    const expected=expectedCart(cart,row.changes),actual=plain(result.cart);
    const oldIds=new Set(cart.map(line=>line.uid));
    assert.equal(new Set(actual.map(line=>line.uid)).size,actual.length,'stable unique IDs');
    for(const line of actual)if(!oldIds.has(line.uid))line.uid=null;
    assert.deepEqual(actual,expected,'all rows and customizations must match');
   }
   family.passed++;report.passed++;
  }catch(assertion){
   if(result)report.unsafe++;
   family.failed++;report.failed++;
   if(report.examples.filter(x=>x.family===row.family).length<3)report.examples.push({
    family:row.family,text:row.text,error:error?.code,detail:error?.data,expectedError:row.error,
    actualOps:resolved?.plan?.ops,expectedChanges:row.changes,assertion:assertion.message.split('\n')[0],
   });
  }
 }
 return {...report,unique:seen.size,sha256:hash.digest('hex')};
}
if(import.meta.url===pathToFileURL(process.argv[1]||'').href){
 const {version}=JSON.parse(fs.readFileSync(new URL('../../package.json',import.meta.url),'utf8'));
 const report=await runLongEdits(fs.readFileSync(process.argv[2]||'智能茶餐廳-v'+version+'.html','utf8'));
 console.log(JSON.stringify(report,null,2));
 if(report.failed||report.apiCalls)process.exitCode=1;
}

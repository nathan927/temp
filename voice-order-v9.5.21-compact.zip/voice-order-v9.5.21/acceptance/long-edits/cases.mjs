const families=[
 '指定中間行改飲品','無改字嘅指定行選項','同一行補充配搭','重複餐名按舊配搭定位',
 '拆份後改原行號','取消後改原行號','按行改份數','兩個目標或同款歧義',
 '行號超出或餐名對唔上','批次有售罄或漏聽','選項不適用或衝突','裝置候選行號不一致','整單備註同單行衝突','份數同選項範圍未明',
];
const han=['零','一','二','三','四','五','六','七','八','九','十','十一','十二','十三','十四','十五','十六'];
const ids=['A','B','C','D','E','F'];
const drinks=['凍奶茶','凍檸茶','凍咖啡'];
const choose=(values,r)=>values[Math.floor(r()*values.length)];
function random(seed){
 let value=seed;
 return ()=>{value=(Math.imul(value,1664525)+1013904223)>>>0;return value/4294967296;};
}
function row(i,style){return '第'+(style%2?han[i+1]??String(i+1):i+1)+['行','列','份','項'][style%4];}
function make(f,n){
 const r=random(4261+f*1000003+n*11719),length=5+n%8;
 const cart=Array.from({length},(_,i)=>({
  uid:'line-'+i,id:choose(ids,r),qty:1+Math.floor(r()*3),
  drink:choose(drinks,r),sugar:choose(['正常甜','少甜','半糖'],r),
  ice:choose(['正常冰','少冰'],r),toast:choose(['正常多士','飛邊','烘底'],r),
 }));
 cart[0]={uid:'line-0',id:'P1',qty:1};
 cart[length-1]={uid:'line-'+(length-1),id:'T1',qty:1,drink:'凍奶茶'};
 const i=1+Math.floor(r()*(length-3)),j=i+1;
 const a=row(i,n),b=row(j,n+1),name='早餐'+cart[i].id;
 const record={family:families[f],cart,mode:n%3===0?'takeaway':'dinein'};
 const ok=(text,changes)=>({...record,text,changes});
 const fail=(text,error,extra={})=>({...record,text,error,...extra});
 switch(f){
  case 0:
   cart[i].drink='凍奶茶';
   return ok(a+name+choose(['嘅飲品','跟餐嗰杯','跟餐嗰杯飲品','嗰杯嘢飲'],r)+choose(['轉','改做','換成'],r)+'凍檸茶走冰',[
    {i,patch:{drink:'凍檸茶',ice:'走冰'}},
   ]);
  case 1:
   return ok(a+name+choose(['嘅飲品','嗰杯',''],r)+'走冰',[{i,patch:{ice:'走冰'}}]);
  case 2:
   return ok(a+'嘅飲品改半糖，'+choose(['走冰','嗰杯改走冰','同一份改走冰','同一行再改走冰'],r),[
    {i,patch:{sugar:'半糖',ice:'走冰'}},
   ]);
  case 3:
   for(const line of cart)if(line.id===cart[i].id)line.drink='熱奶茶';
   cart[j].id=cart[i].id;cart[j].drink='熱奶茶';
   cart[i].drink='凍奶茶';cart[i].sugar='少甜';
   return ok(name+'凍奶茶少甜改做走甜',[{i,patch:{sugar:'走甜'}}]);
  case 4:
   cart[i].qty=2+n%3;
   return ok(a+'其中一份改少甜，'+choose(['同一份改走冰','嗰份改走冰','走冰'],r)+'，'+b+'改飛邊',[
    {i,split:1,patch:{sugar:'少甜',ice:'走冰'}},{i:j,patch:{toast:'飛邊'}},
   ]);
  case 5:
   return ok(choose(['取消'+a,a+'取消','刪走'+a],r)+'，'+b+'飲品改走冰',[
    {i,remove:true},{i:j,patch:{ice:'走冰'}},
   ]);
  case 6:
   return ok(a+choose(['改','改做','轉做'],r)+['兩','三','四','五'][n%4]+'份',[
    {i,patch:{qty:2+n%4}},
   ]);
  case 7:
   if(n%2===0)return fail(a+'同'+b+'改走冰','needClarification');
   cart[j].id=cart[i].id;
   return fail(name+'改走冰','ambiguousTarget',{choices:[i,j]});
  case 8:
   return n%2===0?fail(row(length+1,n)+'改走冰','missingTarget'):
    fail(a+'早餐'+ids[(ids.indexOf(cart[i].id)+1)%6]+'改走冰','missingTarget');
  case 9:
   if(n%2===0){
    cart[i].drink='凍奶茶';cart[j].drink='凍奶茶';
    return fail(a+'改走冰，'+b+'飲品轉凍檸茶','soldOut',{availability:{T2:false},clause:true});
   }
   return fail(a+'改走冰，'+b+'改做青玉雲朵','unrecognizedTokens',{clause:true});
  case 10:
   if(n%2===0){cart[i].drink='熱奶茶';return fail(a+'改走冰','notApplicable');}
   return fail(n%4===1?a+'改少甜轉鮮奶走甜':
    a+'改少甜，'+choose(['走甜','同一份改走甜','嗰杯改走甜'],r),'conflictingOptions');
  case 11:
   return fail(a+'改走冰','confirmTranscript',{alternatives:[b+'改走冰']});
  case 12:
   return fail(n%2===0?a+'改少冰':a+'改少甜，'+b+'改少冰','orderNoteConflict',{orderNotes:['全部走冰']});
  case 13:
   return fail(a+'改'+choose(['少甜五份','走冰兩杯','凍檸茶一杯','飛邊3份'],r),'editQuantityScope');
 }
}
export function* longEditCases(){
 for(let family=0;family<families.length;family++)for(let n=0;n<500;n++)yield make(family,n);
}

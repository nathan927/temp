const hot=[
 ['T1','熱奶茶','熱懶茶'],['T2','熱檸茶','業凝茶'],['T3','熱咖啡','業加啡'],['T4','熱鴛鴦','熱冤陽'],
 ['T5','熱檸水','熱凝水'],['T6','熱檸蜜','熱凝密'],['T8','熱阿華田','熱阿樺填'],
 ['T9','熱好立克','熱好粒刻'],['T12','熱杏仁霜','熱杏仁箱'],['T13','熱鮮奶','熱鮮瀨'],
];
const cold=[
 ['T1','凍奶茶','東乃茶'],['T2','凍檸茶','冬寧茶'],['T3','凍咖啡','東咖飛'],['T4','凍鴛鴦','東鴛央'],
 ['T5','凍檸水','冬零水'],['T6','凍檸蜜','東檸密'],['T7','凍西洋菜蜜','凍西洋菜密'],
 ['T14','凍檸樂','寧落'],['T15','凍檸七','寧柒'],['T18','凍檸賓','東寧賓'],
];
const snacks=[
 ['P7','餐育蛋三文治'],['P8','咸牛育蛋治'],['P9','吞拿魚三文至'],['P10','芝士三文智'],['P11','火腿三文至'],
 ['P12','公司三文智'],['P17','豬拍包'],['P18','雞拍包'],['P19','魚柳飽'],['S7','薯併'],
];
const mains=[
 ['R1','乾炒牛何'],['R2','星洲抄米'],['R3','楊洲抄飯'],['R4','焗豬拍繁'],['R5','咖喱牛林飯'],
 ['R6','咖喱雞繁'],['R7','差燒飯'],['R8','番茄抄旦飯'],['R10','雲吞綿'],['R11','餐肉旦公仔麵'],
];
const changes=[
 ['少亭','T1','sugar','少甜'],['走亭','T2','sugar','走甜'],['半棠','T3','sugar','半糖'],
 ['少浜','T1','ice','少冰'],['走浜','T2','ice','走冰'],['少懶','T3','milk','少奶'],
 ['走懶','T1','milk','走奶'],['大悲','T2','size','大杯'],['湯寧上','Q1','broth','湯另上'],['方胞','P13','toast','方包'],
];
const families=['hot-drink','cold-drink','counter-food','rice-and-noodles','two-postfix-quantities','included-drink',
 'short-edit','conflicting-quantity','wrong-classifier','cold-temperature-with-ordinal'];
const numbers=['零','一','兩','三','四','五','六','七','八','九','十'];
const heads=['','唔該','麻煩你','幫我','請'],tails=['','呀','啦','唔該','喎'];
const row=(id,qty,fields={})=>({id,qty,...fields});
const saved=(id,qty,fields={})=>row(id,qty,{uid:'prior-'+id,...fields});
const drink=(item,n)=>row(item[0],n,{drink:item[1]});
const safeSide=n=>saved('P6',n,{note:'獨立包裝'});

export function* finalPhoneticCases(){
 for(const family of families)for(let i=0;i<500;i++){
  const k=i%10,n=1+Math.floor(i/10)%10,style=Math.floor(i/100),num=numbers[n];
  const say=s=>heads[style]+s+tails[style];
  const c=cold[k],h=hot[k],f=snacks[k],m=mains[k];
  let text,cart=[],alternatives=[],expected=[],error,notes=[];
  switch(family){
   case 'hot-drink':
    text=say('要'+num+'杯'+h[2]);expected=[drink(h,n)];break;
   case 'cold-drink':
    text=say('再加'+num+'杯'+c[2]);cart=[safeSide(1)];expected=[cart[0],drink(c,n)];break;
   case 'counter-food':
    text=say('叫'+num+'份'+f[1]);expected=[row(f[0],n)];break;
   case 'rice-and-noodles':
    text=say(num+'份'+m[1]);expected=[row(m[0],n)];break;
   case 'two-postfix-quantities':{
    const cups=11-n;
    text=say(f[1]+num+'芬，'+c[2]+numbers[cups]+'碑');expected=[row(f[0],n),drink(c,cups)];break;
   }
   case 'included-drink':{
    const set='ABCDE'[k%5];
    text=say(num+'杯'+h[2]);cart=[saved(set,n,{drink:'待選飲品',drinkStatus:'deferred'})];
    expected=[{...cart[0],drink:h[1],drinkStatus:'selected'}];break;
   }
   case 'short-edit':{
    const [phrase,id,field,value]=changes[k];
    cart=[saved(id,n,field==='sugar'||field==='ice'||field==='milk'||field==='size'?{drink:cold[Number(id[1])-1][1]}:{})];
    text=say('改做'+phrase);expected=[{...cart[0],[field]:value}];break;
   }
   case 'conflicting-quantity':
    text=say(num+'杯'+h[2]);alternatives=[String(n+1)+'杯'+h[1]];error='confirmTranscript';break;
   case 'wrong-classifier':
    cart=[safeSide(k+1)];
    text=say(num+(k%2?'碑'+f[1]:'芬'+c[2]));error=k===0?'ambiguousTerm':'unrecognizedTokens';break;
   case 'cold-temperature-with-ordinal':{
    const [id,value]=h;
    cart=[safeSide(2),saved('T4',1,{uid:'untouched',drink:'凍鴛鴦',sugar:'少甜'}),saved(id,n,{drink:value,sugar:'半糖'})];
    text=say('弟三碑'+['專冬飲','轉凍任','傳凍音','轉東飲','專凍音'][k%5]);
    expected=[...cart.slice(0,2),{...cart[2],drink:value.replace(/^熱/,'凍')}];break;
   }
  }
  yield {family,text,alternatives,cart,expected,error,notes,audio:i%2===0};
 }
}

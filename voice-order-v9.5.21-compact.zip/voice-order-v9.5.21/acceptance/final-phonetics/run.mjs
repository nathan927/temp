import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createHash,webcrypto} from 'node:crypto';
import {pathToFileURL} from 'node:url';
import vm from 'node:vm';
import {finalPhoneticCases} from './cases.mjs';

export async function runFinalPhonetics(html){
 const context=vm.createContext({URL,console,crypto:webcrypto,structuredClone,performance,setTimeout,clearTimeout});
 for(const [,source] of html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/g)){
  if(!source.includes("(()=>{'use strict';"))vm.runInContext(source,context);
 }
 const K=context.Kam,seen=new Set(),hash=createHash('sha256');
 const r={total:0,passed:0,failed:0,unsafe:0,apiCalls:0,expectedLocal:0,localPassed:0,guardPassed:0,families:{},examples:[]};
 for(const row of finalPhoneticCases()){
  const {family,text,alternatives,audio,cart,expected,error,notes}=row;
  const key=JSON.stringify({text,alternatives,cart});
  assert.ok(!seen.has(key),'Duplicate input '+family+' '+key);
  seen.add(key);hash.update(JSON.stringify(row)+'\n');r.total++;
  if(!error)r.expectedLocal++;
  const stats=r.families[family]??={passed:0,failed:0};
  const before=cart.map(x=>K.normalize(x)),snapshot=JSON.stringify(before);
  const state={cart:before,orderNotes:[],mode:'dinein'};
  let result,after,thrown;
  try{
   const args={localText:text,localAlternatives:alternatives,cart:before,context:state};
   const unexpected=()=>{r.apiCalls++;throw Error('Unexpected API call');};
   result=audio?await K.resolveVoice({...args,audio:'fixture',available:()=>!error,asr:unexpected,parse:unexpected}):K.resolveDeviceVoice(args);
   if(!result.plan)throw result.error||new K.OrderError('notUnderstood');
   after=K.transitionDraft(state,result.plan);
   after.cart=K.groupDraftLines(after.cart);
  }catch(e){thrown=e;}
  try{
   assert.equal(JSON.stringify(before),snapshot,'original draft mutated');
   if(error){
    if(after&&JSON.stringify(after.cart)!==snapshot)r.unsafe++;
    assert.equal(thrown?.code,error,'clarification code');
    assert.equal(after,undefined,'unexpected draft mutation');
    r.guardPassed++;
   }else{
    assert.equal(thrown?.code||thrown?.message,undefined,'local interpretation failed');
    assert.equal(result.provider,'device');
    assert.equal(after.mode,'dinein','service mode');
    assert.deepEqual(Array.from(after.orderNotes),notes,'order notes');
    assert.equal(after.cart.length,expected.length,'number of lines');
    for(const [i,x] of expected.entries())for(const [key,value] of Object.entries(x))
     assert.equal(after.cart[i][key],value,'line '+(i+1)+' '+key);
    r.localPassed++;
   }
   stats.passed++;r.passed++;
  }catch(e){
   stats.failed++;r.failed++;
   if(r.examples.filter(x=>x.family===family).length<5)r.examples.push({
    family,text,alternatives,cart,error,expected,actual:after?.cart,notes:after?.orderNotes,
    thrown:thrown?.code||thrown?.message,detail:thrown?.data,assertion:e.message.split('\n')[0],
   });
  }
 }
 return {...r,unique:seen.size,sha256:hash.digest('hex')};
}
if(import.meta.url===pathToFileURL(process.argv[1]||'').href){
 const version=JSON.parse(fs.readFileSync(new URL('../../package.json',import.meta.url),'utf8')).version;
 const result=await runFinalPhonetics(fs.readFileSync(process.argv[2]||'智能茶餐廳-v'+version+'.html','utf8'));
 console.log(JSON.stringify(result,null,2));
 if(result.failed||result.apiCalls)process.exitCode=1;
}

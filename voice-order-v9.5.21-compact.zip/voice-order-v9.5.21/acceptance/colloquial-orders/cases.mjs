const families=[
 '口頭照跟','數量變種','跟單轉熱奶茶','換飲品兼保留配搭','單點飲品照跟換款',
 '跟單改食物選項','停頓後補配搭','取消最後加入一份','講錯咗取消一份','連續刪同跟',
 '同一句加餐再跟','同一句最後反口','否定及撤回取消','取消意圖未明','空草稿',
 '份數或量詞無效','配搭衝突或聽唔清','售罄及容量限制','裝置候選矛盾','原有指令分流',
];
const sets=['A','B','C','D','E','F'];
const drinks=['凍奶茶','凍檸茶','凍咖啡','凍鴛鴦'];
const copy=['我要一樣','跟多份','同上','我都要一樣','一份同款','一模一樣','跟頭先一樣','同頭先一樣','照頭先','照樣','同款','照舊','再嚟一份一樣','再要同一款','重複頭先嗰份','再嚟個一樣'];
const correction=['講錯咗','講錯左','講錯了','我講錯咗','啱啱講錯咗','剛才說錯了','頭先叫錯咗','我落錯咗','叫錯咗','剛剛講錯咗'];
const remove=['，剛才一個唔要','頭先嗰份唔要','取消頭先嗰份','唔要啱啱嗰個','刪走上一個','最後一份唔要','攞走頭先一份','剛剛一件不要','上一份取消','取消最後嗰份','頭先嘅嗰份唔要','剛才嗰個刪走'];
const prefix=['','唔該','麻煩你','幫我','請','老細，','師傅，','可唔可以'];
const suffix=['','呀','吖','啦','喎','唔該','多謝','。','！'];
const choose=(values,r)=>values[Math.floor(r()*values.length)];
function random(seed){
 let value=seed>>>0;
 return ()=>{value=(Math.imul(value,1664525)+1013904223)>>>0;return value/4294967296;};
}
function make(f,n,attempt){
 const r=random(46921+f*1000003+n*11719+attempt*923747);
 const length=f===17?5+Math.floor(r()*4):3+Math.floor(r()*6);
 const cart=Array.from({length},(_,i)=>({
  uid:'line-'+i,id:choose(sets,r),qty:1+Math.floor(r()*4),
  drink:choose(drinks,r),ice:choose(['正常冰','少冰','走冰'],r),
  sugar:choose(['正常甜','少甜','半糖','走甜'],r),
  toast:choose(['正常多士','飛邊','烘底'],r),
 }));
 const i=Math.floor(r()*(length-1)),source=cart[i],amount=1+n%5;
 const decorate=text=>choose(prefix,r)+text+choose(suffix,r);
 const recent=()=>[...cart.flatMap(item=>Array(item.qty-(item===source?1:0)).fill(item.uid)),source.uid];
 const state={cart,portionOrder:recent(),mode:n%3===0?'takeaway':'dinein'};
 const outcome=(text,expected,extra={})=>({family:families[f],...state,text,expected,...extra});
 const add=(text,patch={},qty=1)=>outcome(text,[{copy:i,patch,qty}]);
 const cancel=text=>outcome(text,[{remove:i}]);
 const fail=(text,error,extra={})=>outcome(text,null,{error,...extra});
 switch(f){
  case 0:return add(decorate(choose(copy,r)));
  case 1:return add(decorate(choose(['跟多','再跟多','照舊再加','同款再加','再嚟','再叫','再整'],r)+
   (n%2?['一','兩','三','四','五'][amount-1]:amount)+'份'+(n%3===0?'一樣':'')),{},amount);
  case 2:{
   const extra=n%2?'少甜':'',join=choose(['但要','但係要','但係想飲','不過要','但是要','但想要','但要 ','，但要'],r);
   return add(decorate(choose(['跟多份','跟多一份','我要一樣','同上','照頭先'],r)+join+'熱奶茶'+extra),
    {drink:'熱奶茶',ice:'正常冰',...(extra?{sugar:'少甜'}:{})});
  }
  case 3:{
   const drink=choose(['熱咖啡','凍檸茶','凍鴛鴦','凍奶茶'],r);
   return add(decorate(choose(['跟多份轉','跟多份改做','照舊但要','同款但要'],r)+drink+'半糖'),
    {drink,sugar:'半糖',...(drink.startsWith('熱')?{ice:'正常冰'}:{})});
  }
  case 4:{
   cart[i]={uid:source.uid,id:'T1',qty:source.qty,drink:'凍奶茶',sugar:source.sugar,ice:source.ice,size:n%2?'標準杯':'大杯'};
   return add(decorate(choose(['跟多杯但要','跟多一杯不過要','我要一樣但轉做'],r)+'熱咖啡'),
    {id:'T3',drink:'熱咖啡',ice:'正常冰'});
  }
  case 5:{
   const toast=choose(['飛邊','烘底','正常多士'],r);
   return add(decorate(choose(['跟多份但要','照舊但要','同頭先一樣不過要'],r)+toast),{toast});
  }
  case 6:return add(decorate(choose(['跟多份但要熱奶茶，少甜','同上，但要熱奶茶，少甜','照頭先，熱奶茶少甜'],r).replace('照頭先，熱奶茶','照頭先，但要熱奶茶')),
   {drink:'熱奶茶',ice:'正常冰',sugar:'少甜'});
  case 7:return cancel(decorate(choose(remove,r)));
  case 8:return cancel(decorate(choose(correction,r)+(n%4===0?'，'+choose(remove,r).replace(/^，/,''):'')));
  case 9:{
   source.qty=1;state.portionOrder=recent();
   return outcome(decorate(choose(correction,r)),[{remove:i}],{followup:decorate(choose(copy,r)),followupCopy:length-1});
  }
  case 10:{
   if(n%2===0){state.cart=[];state.portionOrder=[];}
   const id=choose(sets,r);
   return outcome(decorate('一份早餐'+id+'凍檸茶，'+choose(['跟多份但要熱奶茶','跟多份，但要熱奶茶','跟多一份不過要熱奶茶'],r)),
    [{item:{id,qty:1,drink:'凍檸茶'}},{item:{id,qty:1,drink:'熱奶茶'}}]);
  }
  case 11:{
   const id=choose(sets,r),other=choose(sets,r);
   return outcome(decorate('一份早餐'+id+'熱奶茶，一份早餐'+other+'凍咖啡，'+choose(correction,r)),
    [{item:{id,qty:1,drink:'熱奶茶'}}]);
  }
  case 12:return outcome(decorate(choose(['唔好跟多份','咪照頭先','我唔要跟多份','唔好刪走上一個','講錯咗，唔好取消','唔使再嚟一份一樣','咪取消頭先嗰份'],r)),[]);
  case 13:return fail(decorate(choose(['講錯咗，轉熱奶茶','叫錯咗，跟多份','講錯咗，重新落單','成張單一樣','全單照舊','全部同款','整張單都一樣','講錯咗熱奶茶','頭先叫錯咗，改第三份'],r)),'repeatNeedsTarget');
  case 14:{
   state.cart=[];state.portionOrder=[];
   return fail(decorate(choose([...copy,...correction,...remove],r)),'noRecentPortion');
  }
  case 15:{
   const [text,code]=choose([['跟多零份','invalidQty'],['跟多21份','invalidQty'],['跟多1.5份','invalidQty'],['跟多一杯','repeatPortionUnit']],r);
   return fail(decorate(text),code);
  }
  case 16:{
   const [text,code]=choose([['跟多份但要走冰少冰','conflictingOptions'],['跟多份但要青玉雲朵','unrecognizedTokens'],
    ['跟多份但係','repeatNeedsOption'],['跟多份但要早餐A','repeatNeedsOption'],
    ['一份早餐B，跟多份但要青玉雲朵','unrecognizedTokens']],r);
   return fail(decorate(text),code);
  }
  case 17:
   if(n%2===0)return fail(decorate(choose(copy,r)),'soldOut',{availability:{[source.id]:false}});
   cart.forEach((item,index)=>{item.qty=Math.floor(100/length)+(index<100%length?1:0);});
   state.portionOrder=recent();
   return fail(decorate('跟多份'),'orderLimit');
  case 18:return fail(decorate(choose(copy,r)),'confirmTranscript',{alternatives:[choose(correction,r)]});
  case 19:{
   const id=choose(sets,r);
   return outcome(decorate('再嚟兩份早餐'+id+'熱奶茶'),[{item:{id,qty:2,drink:'熱奶茶'}}]);
  }
 }
}
export function* colloquialCases(){
 const seen=new Set();
 for(let family=0;family<families.length;family++)for(let n=0;n<500;n++){
  for(let attempt=0;;attempt++){
   const row=make(family,n,attempt);
   const key=JSON.stringify([row.text,row.cart,row.portionOrder,row.mode,row.availability,row.alternatives,row.followup]);
   if(seen.has(key)){if(attempt===1000)throw Error('Duplicate input limit');continue;}
   seen.add(key);yield row;break;
  }
 }
}

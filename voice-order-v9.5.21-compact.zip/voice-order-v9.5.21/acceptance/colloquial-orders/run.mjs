import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import {createHash,webcrypto} from 'node:crypto';
import {pathToFileURL} from 'node:url';
import {colloquialCases} from './cases.mjs';

function engine(html){
 const context=vm.createContext({URL,console,crypto:webcrypto,structuredClone,performance,setTimeout,clearTimeout});
 for(const [,source] of html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/g)){
  if(!source.includes("(()=>{'use strict';"))vm.runInContext(source,context);
 }
 return context.Kam;
}
const plain=value=>JSON.parse(JSON.stringify(value));
function expected(K,cart,portionOrder,steps){
 let items=structuredClone(cart),order=portionOrder.slice(),index=0;
 for(const step of steps){
  if(step.remove!==undefined){
   const id=cart[step.remove].uid,line=items.find(item=>item.uid===id);
   line.qty--;
   if(!line.qty)items=items.filter(item=>item.uid!==id);
   order.splice(order.lastIndexOf(id),1);
  }else{
   const uid='new-'+index++;
   const data=step.item||{...cart[step.copy],...step.patch,qty:step.qty};
   const item=plain(K.normalize({...data,uid}));
   items.push(item);order.push(...Array(item.qty).fill(uid));
  }
 }
 return {cart:items,portionOrder:order};
}
const signature=({uid,qty,pendingPair,drinkPrompted,...options})=>JSON.stringify({...options,extras:[...options.extras].sort()});
function validateResult(K,result,want,before){
 const actual=plain(result.cart),oldIds=new Set(before.map(item=>item.uid)),uids=new Map();
 let index=0;
 for(const item of actual){
  if(!oldIds.has(item.uid)){const alias='new-'+index++;uids.set(item.uid,alias);item.uid=alias;}
 }
 assert.deepEqual(actual,want.cart,'all rows, portions and customization fields');
 if(K.groupDraft){
  assert.deepEqual(Array.from(result.portionOrder,id=>uids.get(id)||id),want.portionOrder,'order of each portion');
  const grouped=K.groupDraft(result.cart,result.portionOrder);
  const raw=new Map(result.cart.map(item=>[item.uid,signature(item)]));
  const byUid=new Map(grouped.cart.map(item=>[item.uid,signature(item)]));
  assert.deepEqual(Array.from(grouped.portionOrder,id=>byUid.get(id)),
   Array.from(result.portionOrder,id=>raw.get(id)),'grouping must preserve the chronological portions');
  for(const item of grouped.cart)assert.equal(grouped.portionOrder.filter(id=>id===item.uid).length,item.qty);
 }
}
export async function runColloquial(html){
 const K=engine(html),hash=createHash('sha256'),seen=new Set();
 const report={total:0,passed:0,failed:0,unsafe:0,apiCalls:0,families:{},examples:[]};
 for(const row of colloquialCases()){
  const key=JSON.stringify([row.text,row.cart,row.portionOrder,row.mode,row.availability,row.alternatives,row.followup]);
  assert.ok(!seen.has(key));seen.add(key);hash.update(JSON.stringify(row)+'\n');report.total++;
  const family=report.families[row.family]??={passed:0,failed:0};
  const cart=plain(row.cart.map(K.normalize)),before=JSON.stringify(cart);
  const state={cart,portionOrder:row.portionOrder,mode:row.mode,orderNotes:[],availability:row.availability||{}};
  let result,resolved,error;
  const attempt={localText:row.text,localAlternatives:row.alternatives||[],cart,context:state};
  try{
   if(row.error==='unrecognizedTokens'||row.error==='repeatNeedsTarget'){
    const unexpected=()=>{report.apiCalls++;throw Error('Unexpected remote call');};
    resolved=await K.resolveVoice({...attempt,audio:'fixture',available:()=>true,asr:unexpected,parse:unexpected});
   }else resolved=K.resolveDeviceVoice(attempt);
   error=resolved.error;
   if(resolved.plan)result=K.transitionDraft(state,resolved.plan,state.availability);
  }catch(caught){error=caught;}
  try{
   assert.equal(JSON.stringify(cart),before,'input cart mutation');
   if(row.error){
    assert.equal(resolved?.plan,undefined,'a clarification must not return an executable plan');
    assert.equal(error?.code,row.error,'typed failure');
   }else{
    assert.equal(error?.code,undefined,'local command must resolve');
    assert.equal(resolved.provider,'device');
    const want=expected(K,cart,row.portionOrder,row.expected);
    validateResult(K,result,want,cart);
    assert.equal(result.mode,row.mode);assert.equal(result.orderNotes.length,0);
    if(row.followup){
     const next=K.resolveDeviceVoice({localText:row.followup,cart:result.cart,context:{...state,...result}});
     const after=K.transitionDraft({...state,...result},next.plan);
     const source=want.cart.find(item=>item.uid===cart[row.followupCopy].uid);
     const wanted=expected(K,want.cart,want.portionOrder,[{copy:want.cart.indexOf(source),patch:{},qty:1}]);
     validateResult(K,after,wanted,want.cart);
    }
   }
   family.passed++;report.passed++;
  }catch(assertion){
   if(result)report.unsafe++;
   family.failed++;report.failed++;
   if(report.examples.filter(example=>example.family===row.family).length<3)report.examples.push({
    family:row.family,text:row.text,expectedError:row.error,error:error?.code,detail:error?.data,
    result:result?.cart.map(({id,qty,drink,sugar,ice})=>({id,qty,drink,sugar,ice})),
    actualOps:resolved?.plan?.ops?.map(op=>op.type),assertion:assertion.message.split('\n')[0],
   });
  }
 }
 return {...report,unique:seen.size,sha256:hash.digest('hex')};
}
if(import.meta.url===pathToFileURL(process.argv[1]||'').href){
 const {version}=JSON.parse(fs.readFileSync(new URL('../../package.json',import.meta.url),'utf8'));
 const report=await runColloquial(fs.readFileSync(process.argv[2]||'智能茶餐廳-v'+version+'.html','utf8'));
 console.log(JSON.stringify(report,null,2));
 if(report.failed||report.apiCalls)process.exitCode=1;
}

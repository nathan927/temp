import fs from'node:fs';import assert from'node:assert/strict';import{createHash}from'node:crypto';import{pathToFileURL}from'node:url';import{continuousCases}from'./cases.mjs';import{fastUI as baseFastUI,plain}from'./fixture.mjs';
import{mandarinContinuousCases}from'../mandarin/continuous-cases.mjs';
const language=process.env.CAPTURE_LANG||'tc';
function fastUI(cart=[],options={}){const f=baseFastUI(cart,{...options,...(language==='sc'?{lang:'sc'}:{})});if(language==='sc'){const say=f.say;f.say=(text,extra)=>{const spoken=f.context.I18n.toSC(text.replace(/伙記呢邊想歎/g,'服务员这边想整点儿').replace(/跟多份/g,'再来一份一样的').replace(/其中一份改凍檸茶/g,'其中一份的饮料改成冰柠檬茶').replace(/係咁多|系咁多/g,'就这些'));assert.doesNotMatch(spoken,/[唔咗喺嘅啱哋]|系咁多/);return say(spoken,extra);};}return f;}
const response=text=>({ok:true,status:200,text:async()=>JSON.stringify({choices:[{message:{content:text}}]})});
const modelPlan={intent:'add',ops:[{type:'add',item:{id:'A',qty:1,drink:'熱奶茶'}}]};
async function configure(f){await f.click('[data-action="settings"]');await f.unlock();f.document.querySelector('#key-mimo').value='fixture-continuous-key';await f.click('[data-action="save-settings"]');}
const basket=(K,items)=>{const grouped=new Map();for(const raw of items){const {uid,qty,pendingPair,drinkPrompted,...rest}=plain(K.normalize(raw)),key=JSON.stringify(Object.fromEntries(Object.entries(rest).sort(([a],[b])=>a.localeCompare(b))));grouped.set(key,(grouped.get(key)||0)+qty);}return [...grouped].sort(([a],[b])=>a.localeCompare(b));};
export async function runContinuous({traceFile}={}){
 const report={total:0,passed:0,failed:0,families:{},examples:[]},records=[],seen=new Set(),hash=createHash('sha256');
 for(const row of (language==='sc'?mandarinContinuousCases():continuousCases())){
  if(process.env.CASE_ID&&row.id!==process.env.CASE_ID)continue;
  if(process.env.PROGRESS)console.error(row.id,row.family);
  report.total++;hash.update(JSON.stringify(row)+'\n');assert.ok(!seen.has(JSON.stringify([row.family,row.n,row.text,row.cart])));seen.add(JSON.stringify([row.family,row.n,row.text,row.cart]));const family=report.families[row.family]??={passed:0,failed:0};let f,release,requests=0,record={...row};
  try{
   if(row.family==='API排隊及退出保留已聽內容'){
    f=fastUI([],{productionDefaults:true,fetch:async()=>{requests++;await new Promise(r=>release=r);return response(JSON.stringify({intent:'add',ops:[{type:'add',item:{id:row.set,qty:row.qty,drink:'熱奶茶'}}]}));}});await configure(f);await f.start();await f.say('伙記呢邊想歎'+row.qty+'份早餐'+row.set+'熱奶茶');assert.equal(requests,1);assert.equal(f.active(),true);await f.say('跟多份');await f.say('其中一份改凍檸茶');
    if(row.n%2)await f.say('係咁多');else await f.advance(7000);assert.equal(f.active(),false);assert.equal(f.document.querySelector('[data-action="confirm"]').disabled,true);
    release();await f.flush();assert.deepEqual(f.state().cart.map(i=>[i.id,i.qty,i.drink]).sort(),[[row.set,1,'凍檸茶'],[row.set,row.qty,'熱奶茶']].sort());assert.equal(requests,1);assert.equal(f.state().orders.length,0);
   }else if(row.family==='雲端轉錄收尾及截斷後續'){
    f=fastUI([],{productionDefaults:true,fetch:async(_url,init)=>{requests++;assert.equal(JSON.parse(init.body).model,'mimo-v2.5-asr');await new Promise(r=>release=r);return response(row.cloudText);}});await configure(f);await f.start();await f.say('',{audio:'UklGRg=='});await f.say('早餐C熱奶茶');release();await f.flush();assert.equal(requests,1);assert.equal(f.active(),false);assert.deepEqual(f.state().cart.map(i=>[i.id,i.qty]),row.n%2?[[row.set,row.qty]]:[]);const stats=JSON.parse(f.store.get('kamkee.voice-statistics.v1'));assert.ok(stats.messages.some(m=>m.status==='cancelled'));
   }else if(row.family==='暫定文字及長講話'){
    f=fastUI(row.cart,{productionDefaults:true,browser:row.browser});await f.start();const sr=f.recognizers.at(-1);assert.equal(sr.continuous,true);assert.equal(sr.interimResults,true);const initial=JSON.stringify(f.state().cart);
    await f.advance(6500);sr.onresult({results:[Object.assign([{transcript:'一份早餐A'}],{isFinal:false})]});await f.advance(6500);assert.equal(f.active(),true);assert.equal(JSON.stringify(f.state().cart),initial);
    sr.onspeechstart();await f.advance(15000);assert.equal(f.active(),true);sr.rows=[Object.assign([{transcript:'一份早餐A熱奶茶'}],{isFinal:true})];sr.onresult({results:sr.rows,resultIndex:0});sr.onspeechend();await f.flush();await f.advance(6999);assert.equal(f.active(),true);await f.advance(1);assert.equal(f.active(),false);assert.deepEqual(basket(f.context.Kam,f.state().cart),basket(f.context.Kam,[...row.cart,{id:'A',qty:1,drink:'熱奶茶'}]));
   }else if(row.family==='辨識重啟及重複回呼'){
    f=fastUI([],{productionDefaults:true,browser:row.browser});await f.start();const firstId=f.session,firstSR=f.recognizers.at(-1),handler=firstSR?.onresult;await f.say(row.qty+'份早餐'+row.set+'熱奶茶');
    if(row.browser){firstSR.onresult({results:firstSR.rows,resultIndex:0});firstSR.onend();await f.advance(150);handler({results:[Object.assign([{transcript:'早餐C'}],{isFinal:true})]});}else f.context.kamMicEvent(firstId,'result',{text:'早餐C',peak:.1});
    await f.say(row.qty+'份早餐'+row.set+'熱奶茶');assert.equal(f.state().cart[0].qty,row.qty*2);assert.equal(f.state().cart[0].id,row.set);assert.equal(f.state().cart.length,1);await f.say('OK');assert.equal(f.active(),false);
   }else if(row.family==='預設開關及設定保留'){
    f=fastUI(row.cart,{productionDefaults:true});await f.click('[data-action="settings"]');await f.unlock();assert.equal(f.document.querySelector('#hands-free-mode').checked,true);const input=f.document.querySelector('#hands-free-mode');input.checked=false;input.dispatchEvent(new f.window.Event('change',{bubbles:true}));await f.click('[data-action="save-settings"]');assert.equal(f.state().settings.handsFree,false);await f.start();assert.notEqual(f.micOptions.continuous,true);await f.say('早餐A熱奶茶');assert.equal(f.active(),false);
    const g=fastUI([],{productionDefaults:true,store:f.store});await g.click('[data-action="settings"]');await g.unlock();assert.equal(g.document.querySelector('#hands-free-mode').checked,false);await g.close();
   }else if(row.family==='權限提示背景及離頁'){
    f=fastUI([],{productionDefaults:true});await f.start();await f.say(row.qty+'份早餐'+row.set+'熱奶茶');const before=JSON.stringify(f.state().cart),old=f.session;
    if(row.n%3===0)f.context.kamStop();else if(row.n%3===1){Object.defineProperty(f.document,'hidden',{configurable:true,value:true});f.document.dispatchEvent(new f.window.Event('visibilitychange'));}else f.context.dispatchEvent(new f.window.Event('pagehide'));
    await f.flush();f.context.kamMicEvent(old,'result',{text:'早餐B',peak:.1});await f.advance(1000);assert.equal(f.active(),false);assert.equal(JSON.stringify(f.state().cart),before);
   }else{
    f=fastUI(row.cart,{productionDefaults:true});await f.start();const initial=JSON.stringify(f.state().cart);
    if(row.family==='收尾語獨立退出'){await f.say(row.text);assert.equal(f.active(),false);assert.equal(JSON.stringify(f.state().cart),initial);assert.equal(f.state().orders.length,0);}
    if(row.family==='落餐連收尾語'){await f.say(row.text);assert.equal(f.active(),false);if(row.ambiguous)assert.match(f.document.querySelector('#voice-error').textContent,/取消上一份/);assert.deepEqual(basket(f.context.Kam,f.state().cart),basket(f.context.Kam,row.ambiguous?row.cart:[...row.cart,row.add]));assert.equal(f.state().orders.length,0);}
    if(row.family==='七秒靜音邊界'){await f.advance(6999);assert.equal(f.active(),true);await f.advance(1);assert.equal(f.active(),false);assert.equal(JSON.stringify(f.state().cart),initial);}
    if(row.family==='否定及非收尾字眼'){await f.say(row.text);assert.equal(f.active(),true);if(row.expectKeep??/唔好|don't|不要|繼續|未講完|别停|没说完|继续听|还要点/.test(row.text))assert.equal(JSON.stringify(f.state().cart),initial);await f.say('係咁多');assert.equal(f.active(),false);}
   }
   record.inputs=[...f.utterances];record.actual={cart:plain(f.state().cart||[]),orders:(f.state().orders||[]).length,active:f.active(),requests};record.status='passed';family.passed++;report.passed++;
  }catch(error){record.status='failed';record.error=error.message;family.failed++;report.failed++;if(report.examples.filter(x=>x.family===row.family).length<3)report.examples.push({id:row.id,family:row.family,text:row.text,error:error.message.split('\n')[0],detail:f?.document.querySelector('#voice-error')?.textContent});}
  finally{if(release)release();if(f)await f.close();}
  records.push(record);
 }
 if(traceFile){const tmp=traceFile+'.partial';fs.writeFileSync(tmp,records.map(row=>JSON.stringify(row)).join('\n')+'\n');fs.renameSync(tmp,traceFile);}
 return {...report,unique:seen.size,sha256:hash.digest('hex')};
}
if(import.meta.url===pathToFileURL(process.argv[1]||'').href){const result=await runContinuous({traceFile:process.env.TRACE_FILE||'acceptance/continuous-voice/execution.jsonl'});console.log(JSON.stringify(result,null,2));if(result.failed)process.exitCode=1;}

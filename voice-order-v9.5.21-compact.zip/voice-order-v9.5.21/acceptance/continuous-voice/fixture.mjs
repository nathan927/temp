import vm from'node:vm';
import {html,inlineScripts}from'../../tests/helpers.mjs';
import {ui,next,scopedStore}from'../../tests/ui-fixture.mjs';
export const compiledScripts=inlineScripts(html).map((s,i)=>new vm.Script(s,{filename:'release-'+i+'.js'}));
export const shell=html.replace(/<script\b[^>]*>[\s\S]*?<\/script>/g,'').replace(/data:image\/[^;"]+;base64,[\w+/=]+/g,'data:image/png;base64,');
export const plain=x=>JSON.parse(JSON.stringify(x));
export function clock(){let at=0,serial=0;const timers=new Map();return{now:()=>at,set(fn,ms=0){timers.set(++serial,{fn,at:at+ms});return serial;},clear:id=>timers.delete(id),advance(ms){const until=at+ms;let loops=0;while(true){const pair=[...timers].filter(([,v])=>v.at<=until).sort((a,b)=>a[1].at-b[1].at||a[0]-b[0])[0];if(!pair)break;if(++loops>20000)throw Error('Timer loop');timers.delete(pair[0]);at=pair[1].at;pair[1].fn();}at=until;},timers};}
export function fastUI(cart=[],options={}){
 const time=clock(),utterances=[],native={start:0,cancel:0},recognizers=[];
 class Speech{
  constructor(){recognizers.push(this);}start(){this.started=true;this.onstart?.();this.onaudiostart?.();}stop(){this.onend?.();}abort(){this.aborted=true;}
 }
 const browser=options.browser;
 const env={setTimeout:time.set.bind(time),clearTimeout:time.clear,performance:{now:time.now,getEntriesByType:()=>[{type:'navigate'}]},...options.environment};
 if(browser)Object.assign(env,{KamNative:undefined,SpeechRecognition:Speech,navigator:{userAgent:browser==='ios'?'Mozilla/5.0 iPhone':'Mozilla/5.0 Android',permissions:{query:async()=>({state:'granted'})}}});
 let languageState=options.state;if(options.lang){let saved;try{saved=JSON.parse((options.store?scopedStore(options.store.rootStore||options.store,options.lang):null)?.get('kamkee.v2')||'null');}catch{}languageState={version:2,cart,orders:[],mode:'dinein',table:12,availability:{},prices:{},settings:{handsFree:options.productionDefaults?true:false},...(saved||options.state||{}),lang:options.lang};}
 const f=ui(cart,{...options,...(languageState?{state:languageState}:{}),html:shell,compiledScripts,environment:env});let acknowledged='';
 const flush=async()=>{for(let n=0;n<12;n++)await next();};
 const ack=()=>{if(!browser&&f.session&&f.session!==acknowledged){acknowledged=f.session;f.context.kamMicEvent(f.session,'started');}};
 const advance=async ms=>{time.advance(ms);await flush();ack();await flush();};
 const start=async()=>{await f.click('#home-mic');ack();await flush();};
 const result=(text,extra={})=>{utterances.push(text);if(browser){const sr=recognizers.at(-1);sr.rows??=[];const row=Object.assign([{transcript:text}],{isFinal:true});sr.rows.push(row);sr.onresult?.({results:sr.rows,resultIndex:sr.rows.length-1});}else f.context.kamMicEvent(f.session,'result',{text,peak:.1,alternatives:[],...extra});};
 const say=async(text,extra={})=>{if(!active()){await start();}ack();result(text,extra);await flush();if(!browser)await advance(150);};
 const active=()=>f.document.querySelector('#home-mic')?.getAttribute('aria-pressed')==='true';
 const close=async()=>{f.context.kamStop();await flush();};
 return Object.assign(f,{time,recognizers,utterances,flush,advance,start,say,result,active,ack,close,browser});
}

import fs from'node:fs';
const closings=JSON.parse(fs.readFileSync(new URL('./closings.json',import.meta.url),'utf8'));
export function* continuousCases(){let serial=0;const row=(family,n,extra={})=>({id:'HF-'+String(++serial).padStart(4,'0'),family,n,cart:Array.from({length:1+n%6},(_,i)=>({uid:'row-'+i,id:'ABCDEF'[(n+i)%6],qty:i===0?Math.min(19,1+Math.floor(n/6)):1+(n+i)%3,drink:(n+i)%2?'熱奶茶':'凍檸茶',sugar:(n+i)%2?'少甜':'正常甜'})),...extra});
 for(const [n,closing]of closings.entries())yield row('收尾語獨立退出',n,{closing,text:n%3===0?closing.toUpperCase()+'！':closing});
 for(const [n,closing]of closings.entries()){const id='ABCDEF'[n%6],qty=1+n%3,drink=n%2?'凍檸茶':'熱奶茶';yield row('落餐連收尾語',n,{closing,text:qty+'份早餐'+id+drink+(n%2?'，':'')+closing,ambiguous:/^(?:(?:暫時)?唔(?:加|叫|使)(?:喇|啦)?|唔使再叫|不用了)$/.test(closing),add:{id,qty,drink}});}
 for(let n=0;n<30;n++)yield row('七秒靜音邊界',n);
 for(let n=0;n<30;n++)yield row('暫定文字及長講話',n,{browser:n%2?'ios':'android'});
 for(let n=0;n<40;n++)yield row('API排隊及退出保留已聽內容',n,{cart:[],set:'ABCDEF'[n%6],qty:1+Math.floor(n/6)});
 for(let n=0;n<40;n++)yield row('辨識重啟及重複回呼',n,{cart:[],set:'ABCDEF'[n%6],qty:1+Math.floor(n/6),browser:n%2?'ios':undefined});
 for(let n=0;n<30;n++)yield row('預設開關及設定保留',n);
 for(let n=0;n<20;n++)yield row('權限提示背景及離頁',n,{cart:[],set:'ABCDEF'[n%6],qty:1+Math.floor(n/6)});
 const negative=['唔好停止收音',"don't stop listening",'不要停止收音','繼續聽','仲未講完','無糖奶茶','凍檸茶','OK餐','可樂','全部唔要'];
 for(let n=0;n<20;n++)yield row('否定及非收尾字眼',n,{text:negative[n%negative.length]});
 for(let n=0;n<20;n++)yield row('雲端轉錄收尾及截斷後續',n,{cart:[],set:'ABCDEF'[n%6],qty:1+Math.floor(n/6),cloudText:n%2?(1+Math.floor(n/6))+'份早餐'+'ABCDEF'[n%6]+'熱奶茶，係咁多':closings[n]});
}

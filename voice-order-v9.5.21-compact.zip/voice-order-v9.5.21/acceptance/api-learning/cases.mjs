const families=['新口語單點','早餐新叫法','新叫法單點飲品','二至七人長單','套餐自訂化','修改長單中間飲品','刪最後一份','照跟加一份','照跟另配熱奶茶','餐牌導航','轉堂食或外賣','整單廚房備註','填跟餐飲品','第一服務失敗轉第二服務','儲存後重開字庫','代理服務及金鑰類型','HTTP及連線例外','壞回覆與未完整回覆','錯餐或不可用操作','過期回覆及危險改單'];
const openings=['伙記呢邊想嘆','呢邊幫我記實','我呢枱想歎返','勞煩記低畀我','夥記我想歎','幫我記住呢個要求','呢邊落呢個選擇','麻煩跟我呢個版本','我呢份就揀','呢邊預埋我嗰份','今鋪我想食','夥記幫我寫實','呢邊就咁安排','今次我就嗌呢個','照我呢個配搭記','幫我跟實呢個講法','呢邊先定咗呢款','留住我呢個選擇','我呢度想落嘅係','勞煩跟呢張清單'];
const ds=['熱奶茶','凍奶茶','熱檸茶','凍檸茶','熱咖啡','凍咖啡','熱鴛鴦','凍鴛鴦'];
const sets=['A','B','C','D','E','F'];
const random=seed=>()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
const choose=(a,r)=>a[Math.floor(r()*a.length)];
function make(f,n,attempt=0){
 const r=random(517000+f*100003+n*11119+attempt*1937),len=2+n%6,q=1+n%4,drink=choose(ds,r),id=choose(sets,r),i=Math.floor(len/2);
 const cart=Array.from({length:len},(_,k)=>({uid:'row-'+k,id:choose(sets,r),qty:1+Math.floor(r()*3),drink:choose(ds,r),sugar:choose(['少甜','半糖','正常甜'],r)}));
 const row={family:families[f],cart,mode:n%2?'dinein':'takeaway',orderNotes:[],provider:n%2?'mimo':'minimax',profile:n%3===0?'token-cn':'standard',qty:q};
 const text=command=>choose(openings,r)+command+choose(['吖','呀','唔該','喇','先','。'],r);
 const add=(id,qty=1,drink='待選飲品',extra={})=>({type:'add',item:{id,qty,drink,...extra}});
 const outcome=(phrase,plan,steps,more={})=>({...row,text:phrase,plan,steps,...more});
 const order=(phrase,id,qty=1,drink='待選飲品',extra={},rewrite)=>outcome(phrase,{intent:'add',ops:[add(id,qty,drink,extra)],localRewrite:rewrite},[{add:{id,qty,drink,...extra}}]);
 switch(f){
  case 0:{const [sku,name]=choose([['P1','菠蘿油'],['P3','腿蛋治'],['S1','炸雞翼'],['Q1','沙嗲牛肉麵'],['R1','乾炒牛河']],r);return order(text(q+'份'+name),sku,q);}
  case 1:return order(text(q+'份早餐'+id+drink),id,q,drink);
  case 2:{row.cart=[];const [sku,d]=choose([['T1','凍奶茶'],['T2','熱檸茶'],['T3','凍咖啡'],['T4','熱鴛鴦']],r);return order(text(q+'杯'+d),sku,q,d);}
  case 3:{const ops=[],steps=[],parts=[];for(let k=0;k<len;k++){const sku=choose(sets,r),d=choose(ds,r),qty=1+k%2;ops.push(add(sku,qty,d));steps.push({add:{id:sku,qty,drink:d}});parts.push(qty+'份早餐'+sku+d);}return outcome(text(parts.join('，')),{intent:'add',ops},steps);}
  case 4:return order(text(q+'份早餐A'+drink+'煎蛋方包少甜'),'A',q,drink,{egg:'太陽蛋',toast:'方包',sugar:'少甜'},q+'份早餐A'+drink+'煎蛋方包少甜');
  case 5:return outcome(text('中間第'+(i+1)+'份飲品幫我改熱奶茶少甜'),{intent:'edit',ops:[{type:'update',target:{uid:cart[i].uid},patch:{drink:'熱奶茶',sugar:'少甜',ice:'正常冰'}}],localRewrite:'第'+(i+1)+'行飲品轉熱奶茶少甜'},[{update:i,patch:{drink:'熱奶茶',sugar:'少甜',ice:'正常冰'}}]);
  case 6:return outcome(text('最尾嗰份抽起佢'),{intent:'edit',ops:[{type:'remove',target:{uid:cart.at(-1).uid,count:1}}],localRewrite:'最後一份唔要'},[{remove:len-1}]);
  case 7:return outcome(text('照住最尾嗰份再抄一份'),{intent:'add',ops:[{type:'add',item:{...cart.at(-1),qty:1}}],localRewrite:'跟多份'},[{copy:len-1,qty:1}]);
  case 8:return outcome(text('最尾嗰款多份但杯嘢換熱奶茶'),{intent:'add',ops:[{type:'add',item:{...cart.at(-1),qty:1,drink:'熱奶茶',ice:'正常冰'}}],localRewrite:'跟多份但要熱奶茶'},[{copy:len-1,qty:1,patch:{drink:'熱奶茶',ice:'正常冰'}}]);
  case 9:return outcome(text('帶我去飲品嗰頁睇選擇').replace(/^我呢份就揀/,'伙記呢邊想嘆'),{intent:'navigate',ops:[],categories:['港式飲品'],localRewrite:'有咩飲品揀'},[],{expectedIntent:'navigate'});
  case 10:return outcome(text(n%2?'呢張改喺度坐低食':'呢張幫我拎走食'),{intent:'service',ops:[],mode:n%2?'dinein':'takeaway',localRewrite:n%2?'轉堂食':'轉外賣'},[],{expectedMode:n%2?'dinein':'takeaway'});
  case 11:{const note=choose(['全部少辣','全部走青','全部汁另上'],r);return outcome(text('廚房備低'+note),{intent:'customize',ops:[],orderNotesAdd:[note],localRewrite:note},[],{expectedNotes:[note]});}
  case 12:{row.cart=[{uid:'waiting',id:'A',qty:q,drink:'待選飲品'}];return outcome(text('餐飲落實揀熱奶茶少甜'),{intent:'edit',ops:[{type:'update',target:{uid:'waiting'},patch:{drink:'熱奶茶',sugar:'少甜'}}],localRewrite:'飲品要熱奶茶少甜'},[{update:0,patch:{drink:'熱奶茶',sugar:'少甜',drinkStatus:'selected'}}]);}
  case 13:return {...order(text(q+'份早餐'+id+drink),id,q,drink),failover:true,provider:'minimax'};
  case 14:return {...order(text(q+'份早餐'+id+drink),id,q,drink),reload:true};
  case 15:return {...order(text(q+'份早餐'+id+drink),id,q,drink),proxy:n%2===0};
  case 16:{const [status,error]=choose([[401,'apiInvalidKey'],[402,'apiQuota'],[403,'apiForbidden'],[429,'apiRateLimit'],[503,'apiUnavailable'],[408,'timeout']],r);return outcome(text(q+'份早餐'+id),{intent:'add',ops:[add(id,q)]},[],{status,error});}
  case 17:{const [fault,error]=choose([['json','invalidJSON'],['empty','emptyResponse'],['incomplete','apiIncomplete']],r);return outcome(text(q+'份早餐'+id),{intent:'add',ops:[add(id,q)]},[],{fault,error});}
  case 18:{const [kind,error]=choose([['qty','invalidQty'],['uid','missingTarget'],['option','notApplicable'],['soldOut','soldOut']],r);let plan;
   if(kind==='qty')plan={intent:'add',ops:[add('A',0)]};
   if(kind==='uid')plan={intent:'edit',ops:[{type:'update',target:{uid:'absent'},patch:{sugar:'少甜'}}]};
   if(kind==='option')plan={intent:'edit',ops:[{type:'update',target:{uid:cart[0].uid},patch:{id:'C',noodle:'意粉'}}]};
   if(kind==='soldOut'){plan={intent:'add',ops:[add('A')]};row.availability={A:false};}
   return outcome(text(q+'份早餐'+id),plan,[],{error});
  }
  case 19:if(n%2)return outcome(text('改一改呢張'),{intent:'clear',ops:[]},[],{error:'unsafeAIAction'});else return outcome(text(q+'份早餐'+id),{intent:'add',ops:[add(id,q)]},[],{stale:true,error:'staleVoiceOrder'});
 }
}
export function* apiCases(){const seen=new Set();for(let f=0;f<20;f++)for(let n=0;n<250;n++){let row,key,attempt=0;do{row=make(f,n,attempt++);key=JSON.stringify([row.text,row.cart,row.mode,row.plan,row.error,row.profile,row.status]);}while(seen.has(key));seen.add(key);yield{id:'API-'+String(f*250+n+1).padStart(5,'0'),...row};}}

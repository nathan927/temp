import fs from 'node:fs';
import vm from 'node:vm';
import http from 'node:http';
import assert from 'node:assert/strict';
import {webcrypto,createHash}from 'node:crypto';
import {pathToFileURL}from 'node:url';
import {apiCases}from './cases.mjs';
const plain=x=>JSON.parse(JSON.stringify(x));
const sig=items=>plain(items).map(({uid,pendingPair,drinkPrompted,...item})=>item);
function engine(html){const c=vm.createContext({URL,console,crypto:webcrypto,structuredClone,performance,setTimeout,clearTimeout,AbortSignal});for(const [,s]of html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/g))if(!s.includes("(()=>{'use strict';"))vm.runInContext(s,c);return c;}
function expected(K,row,cart){let items=cart.map(plain);for(const s of row.steps){if(s.add)items.push(plain(K.normalize(s.add)));if(s.copy!==undefined)items.push(plain(K.normalize({...cart[s.copy],qty:s.qty,...s.patch})));if(s.update!==undefined)items[s.update]=plain(K.normalize({...items[s.update],...s.patch}));if(s.remove!==undefined){items[s.remove].qty--;if(!items[s.remove].qty)items.splice(s.remove,1);}}return items;}
export async function runAPI(html,{traceFile}={}){
 const c=engine(html),K=c.Kam,E=c.KamEvolution,fixtures=new Map(),templates={},traceRows=[],allRules=[],samples=[],phrases=new Set(),hash=createHash('sha256');let calls=0;
 const server=http.createServer(async(req,res)=>{let raw='';for await(const chunk of req)raw+=chunk;const body=JSON.parse(raw),row=fixtures.get(req.headers['x-fixture']);
  try{assert.equal(req.headers['x-provider']==='mimo'?req.headers['api-key']:req.headers.authorization,req.headers['x-provider']==='mimo'?'authorized-fixture-key':'Bearer authorized-fixture-key');assert.ok(row);assert.ok(body.model);if(req.headers['x-provider']==='minimax')assert.equal(body.reasoning_split,true);res.setHeader('content-type','application/json');
   const status=row.failover&&req.headers['x-provider']==='minimax'?401:row.status||200;res.statusCode=status;
   const output=status!==200?'<html>service error</html>':row.fault==='json'?'not JSON':row.fault==='empty'?'{}':JSON.stringify({status:row.fault==='incomplete'?'incomplete':'completed',choices:[{finish_reason:'stop',message:{content:(req.headers['x-provider']==='minimax'?'<think>fixture reasoning</think>\n':'')+JSON.stringify(row.plan)}}]});res.end(output);
  }catch(e){res.statusCode=500;res.end(JSON.stringify({fixtureFailure:e.message}));}
 });
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));const endpoint='http://127.0.0.1:'+server.address().port;
 const report={total:0,passed:0,failed:0,fulfilled:0,guarded:0,learned:0,replayedWithoutAPI:0,httpRequests:0,families:{},examples:[]};if(traceFile)fs.writeFileSync(traceFile,'');
 try{for(const row of apiCases()){
  report.total++;hash.update(JSON.stringify(row)+'\n');phrases.add(row.text);const family=report.families[row.family]??={passed:0,failed:0};E.install(E.empty());fixtures.set(row.id,row);
  const cart=plain(row.cart.map(K.normalize)),state=E.snapshot({...row,cart}),before=JSON.stringify(cart);let data;
  const journal=new c.KamEvolutionCycle.Journal({read:()=>null,write:value=>{data=value;}});const local=K.analyzeLocal(row.text,cart,state);journal.sample(row.id,row.text,local,state,'device');
  const record={id:row.id,family:row.family,text:row.text,state,expectedError:row.error,localDecision:local.decision,requests:[]};let result,error,after;
  try{result=await K.fallbackFlow.resolve({text:row.text,cart,context:{...state,availability:row.availability},settings:{parser:'auto'},configured:row.failover?['minimax','mimo']:[row.provider],current:()=>!row.stale,
   parse:async(provider,text,cart)=>{
    const spec=K.spec('parse',{provider,key:'authorized-fixture-key',text,cart,apiProfile:row.profile});const requestId=row.id+'-'+(++calls);report.httpRequests++;
    const body=spec.body,request={id:requestId,provider,endpoint:spec.url,model:body.model,promptSHA256:createHash('sha256').update(body.instructions||body.messages[0].content).digest('hex'),input:body.input||body.messages.at(-1).content};const template={...body,messages:body.messages?.map((message,index)=>index===body.messages.length-1?{...message,content:'$INPUT'}:message)};const templateID=createHash('sha256').update(JSON.stringify(template)).digest('hex');templates[templateID]=template;request.templateSHA256=templateID;request.authentication={header:provider==='mimo'?'api-key':'Authorization',value:'[REDACTED]'};record.requests.push(request);journal.call(row.id,requestId,{phase:'request',...request});
    const response=await fetch(endpoint,{method:'POST',headers:{...spec.headers,'x-fixture':row.id,'x-provider':provider},body:JSON.stringify(body)}),raw=await response.text();request.status=response.status;request.response=raw;journal.call(row.id,requestId,{phase:'response',status:response.status,response:raw});
    if(!response.ok)throw K.fallbackFlow.failure(null,response.status);let value;try{value=JSON.parse(raw);}catch{throw new K.OrderError('invalidJSON');}if(value.status==='incomplete')throw new K.OrderError('apiIncomplete');const plan=K.readAI('parse',value);journal.call(row.id,requestId,{phase:'accepted',result:plan});return plan;
   }});
   after=K.transitionDraft({...state,availability:row.availability},result.plan,row.availability);
   journal.resolved(row.id,row.text,result.plan,state,'model');
  }catch(e){error=e;journal.finish(row.id,{status:'failed',error:e.code});}
  try{
   assert.ok(K.fallbackFlow.eligible(local),'case must reach the API from a genuine local gap');assert.equal(JSON.stringify(cart),before,'original cart mutation');
   if(row.error){assert.equal(error?.code,row.error);assert.equal(after,undefined);assert.equal(data?.active.rules.length||0,0);report.guarded++;}
   else{
    assert.equal(error?.code,undefined,'unexpected failure '+error?.code);assert.equal(result.source,'model');
    const want=expected(K,row,cart);assert.deepEqual(sig(after.cart),sig(want),'all ordered items and customizations');assert.equal(after.mode,row.expectedMode||row.mode);
    if(row.expectedNotes)assert.deepEqual(plain(after.orderNotes),row.expectedNotes);else assert.deepEqual(plain(after.orderNotes),row.orderNotes);
    assert.equal(K.total(after.cart),K.total(want));assert.ok(data?.active.rules.length,'successful recovery must learn');
    const restored=row.reload?new c.KamEvolutionCycle.Journal({read:()=>JSON.parse(JSON.stringify(data)),write:()=>{}}).data:data;
    E.install(restored.active);const replayCart=cart.map((item,i)=>({...item,uid:'reopened-'+i})),replayState=E.snapshot({...state,cart:replayCart,portionOrder:undefined});const beforeCalls=calls;
    const replay=await K.fallbackFlow.resolve({text:row.text,cart:replayCart,context:replayState,settings:{parser:'auto'},configured:[row.provider],parse:()=>{throw Error('Repeat must not call API');}});
    assert.equal(replay.source,'dictionary');assert.equal(calls,beforeCalls);const replayAfter=K.transitionDraft(replayState,replay.plan);assert.deepEqual(sig(replayAfter.cart),sig(want));
    if(['新叫法單點飲品','修改長單中間飲品','照跟加一份','照跟另配熱奶茶','填跟餐飲品','整單廚房備註'].includes(row.family)){const afterState=E.snapshot({...state,...after});const again=await K.fallbackFlow.resolve({text:row.text,cart:afterState.cart,context:afterState,settings:{parser:'auto'},configured:[row.provider],parse:()=>{throw Error('Post-operation repeat must stay local');}});assert.equal(again.source,'dictionary');record.postOperationReplay='dictionary';}
    record.learned=plain(data.active.rules);record.replay={source:replay.source,cart:plain(replayAfter.cart)};allRules.push(...plain(data.active.rules));samples.push({text:row.text,state,expected:E.effect(result.plan,state)});report.learned++;report.replayedWithoutAPI++;report.fulfilled++;
   }
   family.passed++;report.passed++;record.status='passed';
  }catch(e){family.failed++;report.failed++;record.status='failed';record.assertion=e.message.split('\n')[0];if(report.examples.filter(x=>x.family===row.family).length<3)report.examples.push({id:row.id,family:row.family,text:row.text,local:local.decision,error:error?.code,data:error?.data,assertion:record.assertion,validation:data?.cases[0]?.validation?.slice(-3)});}
  record.error=error&&{code:error.code,data:plain(error.data||{})};record.after=after&&plain(after);record.learningChecks=data?.cases[0]?.validation;
  if(traceFile)traceRows.push(JSON.stringify(record));fixtures.delete(row.id);
 }}finally{await new Promise(resolve=>server.close(resolve));}
 try{const pack=E.append(E.empty(),allRules,'acceptance-5000');E.validatePack(pack);E.install(pack);for(const sample of samples.filter((_,i)=>i%41===0)){const replay=K.analyzeLocal(sample.text,sample.state.cart,sample.state);assert.ok(replay.learned);assert.equal(E.effect(replay.plan,sample.state),sample.expected);}report.combinedDictionaryRules=pack.rules.length;report.combinedDictionaryVerified=true;}catch(e){report.combinedDictionaryVerified=false;report.failed++;report.examples.push({assertion:e.message});}
 if(traceFile){const data=traceRows.join('\n')+'\n',temporary=traceFile+'.partial-'+process.pid,fd=fs.openSync(temporary,'w');try{fs.writeFileSync(fd,data);fs.fsyncSync(fd);}finally{fs.closeSync(fd);}fs.renameSync(temporary,traceFile);const bytes=fs.readFileSync(traceFile);assert.equal(bytes.toString('utf8').trimEnd().split('\n').length,report.total,'complete execution trace');report.traceRows=traceRows.length;report.traceBytes=bytes.length;report.traceSHA256=createHash('sha256').update(bytes).digest('hex');fs.writeFileSync(traceFile.replace(/execution\.jsonl$/,'request-templates.json'),JSON.stringify(templates,null,2));}
 return{...report,uniqueTranscripts:phrases.size,sha256:hash.digest('hex'),liveVendorCalls:0,transport:'Real HTTP to local fixture server; provider responses controlled; no live vendor key supplied.'};
}
if(import.meta.url===pathToFileURL(process.argv[1]||'').href){const{version}=JSON.parse(fs.readFileSync(new URL('../../package.json',import.meta.url),'utf8'));const r=await runAPI(fs.readFileSync(process.argv[2]||'智能茶餐廳-v'+version+'.html','utf8'),{traceFile:'acceptance/api-learning/execution.jsonl'});console.log(JSON.stringify(r,null,2));if(r.failed)process.exitCode=1;}

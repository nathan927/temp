/* Deterministic spoken-transcript corpus. Expected item fields come from
 * independently declared menu scenarios rather than the parser output. */
const breakfast=[
 ['早餐A','A',{}],['早餐B','B',{}],['早餐C','C',{}],['早餐D','D',{}],['早餐E','E',{}],['早餐F','F',{}],
 ['早餐A熱咖啡','A',{drink:'熱咖啡'}],['早餐A凍檸茶少冰','A',{drink:'凍檸茶',ice:'少冰'}],
 ['早餐B熱奶茶少甜','B',{drink:'熱奶茶',sugar:'少甜'}],['早餐B凍奶茶少冰','B',{drink:'凍奶茶',ice:'少冰'}],
 ['早餐C熱檸茶','C',{drink:'熱檸茶'}],['早餐C凍檸茶','C',{drink:'凍檸茶'}],
 ['早餐D熱咖啡丁麵','D',{drink:'熱咖啡',noodle:'出前一丁'}],['早餐D凍奶茶少甜','D',{drink:'凍奶茶',sugar:'少甜'}],
 ['早餐E熱奶茶','E',{drink:'熱奶茶'}],['早餐E凍鴛鴦','E',{drink:'凍鴛鴦'}],
 ['早餐F熱檸茶','F',{drink:'熱檸茶'}],['早餐F凍檸茶','F',{drink:'凍檸茶'}],
 ['早餐A加蛋','A',{extras:['X1']}],['早餐A轉丁麵','A',{noodle:'出前一丁'}],
];
const standalone=[
 ['菠蘿油','P1',{}],['腿蛋治','P3',{}],['腿蛋治飛邊','P3',{toast:'飛邊'}],
 ['火腿通粉','Q2',{}],['乾炒牛河','R1',{}],['炸雞翼','S1',{}],
 ['熱奶茶','T1',{drink:'熱奶茶'}],['凍奶茶少甜','T1',{drink:'凍奶茶',sugar:'少甜'}],
 ['凍檸茶少冰','T2',{drink:'凍檸茶',ice:'少冰'}],['熱咖啡','T3',{drink:'熱咖啡'}],
 ['凍咖啡少甜','T3',{drink:'凍咖啡',sugar:'少甜'}],
 ['蛋撻','P5',{}],['星洲炒米','R2',{}],['咖喱魚蛋','S4',{}],
];
const phonetic=[
 ['早餐Boy','B',{}],['早餐Dog','D',{}],['早餐See','C',{}],
 ['波羅遊','P1',{}],['腿旦字','P3',{}],['東咖飛','T3',{drink:'凍咖啡'}],
 ['熱懶茶','T1',{drink:'熱奶茶'}],['凍寧茶','T2',{drink:'凍檸茶'}],
 ['豬拍包','P17',{}],['星洲抄米','R2',{}],
];
const broken=['一份烏龍飛','兩份早餐咩','一份餐鬼','一杯神秘嘢','三份唔知乜餐','一份咩包','一份早餐未講完','兩杯茶定啡'];
const unsafe=['改叫早餐B，唔知乜','取消第一份，唔知乜','轉早餐C，但未講清','重新落單，唔知乜'];
const punctuation=['，',', ','；','。'];
const numerals=['一','兩','三'];
const families=['全員相同','大部分相同','全員不同','同餐不同配搭','套餐單點混合','多人數量混合','地道近音混合','其中一截漏聽','多截漏聽','改單交錯防誤落'];
function random(seed){let x=seed>>>0;return()=>{x=(x+0x6d2b79f5)|0;let t=Math.imul(x^(x>>>15),1|x);t^=t+Math.imul(t^(t>>>7),61|t);return((t^(t>>>14))>>>0)/4294967296;};}
function choose(r,list){return list[Math.floor(r()*list.length)];}
function make(family,index,attempt){
 const r=random(0x96331+family*99991+index*149+attempt*7727),people=2+(index%6),base=choose(r,breakfast);
 const pool=family===6?phonetic:family===4||family>=7?[...breakfast,...standalone]:family===2?[...breakfast.slice(0,6),...standalone]:family===5?[...breakfast,...standalone]:family===3?breakfast.slice(6):breakfast;
 let descriptions=[];
 for(let n=0;n<people;n++){
  let row=family===0?base:family===1&&n!==people-1?base:choose(r,pool);
  if(family===2){const used=new Set(descriptions.map(d=>d.id));const candidates=pool.filter(x=>!used.has(x[1]));row=choose(r,candidates);}
  if(family===3){const used=new Set(descriptions.map(d=>d.text));const candidates=pool.filter(x=>!used.has(x[0]));row=choose(r,candidates.length?candidates:pool);}
  if(family===4&&n===people-1)row=choose(r,standalone);
  if(family===6&&n===people-1)row=choose(r,phonetic);
  const quantity=family===0?1+Math.floor(r()*2):family===5?1+Math.floor(r()*3):1;
  const unit=row[1].startsWith('T')?'杯':'份';
  const text=family===1&&n===people-1&&r()<.5?'另一'+unit+row[0]:numerals[quantity-1]+unit+row[0];
  descriptions.push({text,id:row[1],qty:quantity,...row[2]});
 }
 let missed=[];
 if(family===7){const at=Math.floor(r()*people);missed=[{at,text:choose(r,broken)}];}
 if(family===8){const a=Math.floor(r()*people),b=(a+1+Math.floor(r()*(people-1)))%people;missed=[{at:a,text:choose(r,broken)},{at:b,text:choose(r,broken)}];}
 let parts=descriptions.map((d,n)=>missed.find(x=>x.at===n)?.text||d.text);
 if(family===9){const at=Math.floor(r()*people);parts.splice(at,0,choose(r,unsafe));}
 const join=choose(r,punctuation),text=parts.join(join);
 const expected=descriptions.filter((_,n)=>!missed.some(x=>x.at===n));
 return {family:families[family],people,text,expected,
  unresolved:missed.sort((a,b)=>a.at-b.at).map(x=>x.text),atomic:family===9||!expected.length};
}
export function* groupCases(){
 const seen=new Set();
 for(let family=0;family<families.length;family++)for(let index=0;index<1000;index++){
  let row,attempt=0;
  do{row=make(family,index,attempt++);}while(seen.has(row.text)&&attempt<500);
  if(seen.has(row.text))throw Error('Cannot generate unique group utterance '+family+'/'+index);
  seen.add(row.text);yield row;
 }
}
export {families};

import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import {createHash,webcrypto} from 'node:crypto';
import {pathToFileURL} from 'node:url';
import {groupCases} from './cases.mjs';

function engine(html){const context=vm.createContext({URL,console,crypto:webcrypto,structuredClone,performance,setTimeout,clearTimeout});for(const[,source]of html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/g))if(!source.includes("(()=>{'use strict';"))vm.runInContext(source,context);return context.Kam;}
function grouped(rows){
 const out=[],seen=new Map();
 for(const row of rows){const {text,qty,...fields}=row,key=JSON.stringify(fields),found=seen.get(key);if(found)found.qty+=qty;else{const item={...fields,qty};out.push(item);seen.set(key,item);}}
 return out;
}
export function runGroupOrders(html,{limit=10000}={}){
 const K=engine(html),seen=new Set(),hash=createHash('sha256');
 const report={total:0,passed:0,failed:0,partial:0,unsafe:0,apiCalls:0,people:{},families:{},examples:[]};
 for(const row of groupCases()){
  if(report.total>=limit)break;
  assert.ok(!seen.has(row.text),'Duplicate utterance');seen.add(row.text);hash.update(JSON.stringify(row)+'\n');report.total++;
  report.people[row.people]=(report.people[row.people]||0)+1;
  const stats=report.families[row.family]??={total:0,passed:0,failed:0,partial:0};stats.total++;
  let result,after,error;
  try{
   result=K.resolveDeviceVoice({localText:row.text,cart:[],context:{cart:[],mode:'dinein',orderNotes:[]}});
   if(result.plan){after=K.transitionDraft({cart:[],mode:'dinein',orderNotes:[]},result.plan);after.cart=K.groupDraftLines(after.cart);}
   else error=result.error;
  }catch(e){error=e;}
  try{
   if(row.atomic){if(after?.cart?.length)report.unsafe++;assert.equal(after,undefined,'unsafe partial edit applied');assert.equal(result?.plan,undefined);assert.ok(error,'atomic request should ask for clarification');}
   else{
    assert.equal(error?.code,undefined,'device voice did not resolve');
    assert.equal(result.provider,'device');assert.equal(result.plan.intent,'add');
    const unresolved=Array.from(result.plan.partialUnresolved||[],x=>x.text);
    assert.deepEqual(unresolved,row.unresolved,'missed fragments');
    const want=grouped(row.expected),got=after.cart;
    assert.equal(got.length,want.length,'number of distinct lines');
    for(const [i,item] of want.entries())for(const[key,value]of Object.entries(item))
     assert.equal(JSON.stringify(got[i][key]),JSON.stringify(value),'line '+i+' '+key);
    assert.equal(after.mode,'dinein');assert.equal(after.orderNotes.length,0);
    if(row.unresolved.length){report.partial++;stats.partial++;}
   }
   stats.passed++;report.passed++;
  }catch(e){stats.failed++;report.failed++;if(report.examples.filter(x=>x.family===row.family).length<8)report.examples.push({family:row.family,text:row.text,people:row.people,unresolved:row.unresolved,expected:row.expected,actual:after?.cart?.map(x=>({id:x.id,qty:x.qty,drink:x.drink,sugar:x.sugar,ice:x.ice,noodle:x.noodle,extras:x.extras,toast:x.toast})),error:error?.code,gotUnresolved:result?.plan?.partialUnresolved,assertion:e.message.split('\n')[0]});}
 }
 return {...report,unique:seen.size,sha256:hash.digest('hex')};
}
if(import.meta.url===pathToFileURL(process.argv[1]||'').href){const version=JSON.parse(fs.readFileSync(new URL('../../package.json',import.meta.url),'utf8')).version;const result=runGroupOrders(fs.readFileSync(process.argv[2]||'智能茶餐廳-v'+version+'.html','utf8'),{limit:Number(process.env.GROUP_TEST_LIMIT)||10000});console.log(JSON.stringify(result,null,2));if(result.failed||result.apiCalls)process.exitCode=1;}

# 三語隔離契約 — v9.5.21

## 邊界

語言於啟動時綁定為 `tc`、`sc` 或 `en`，解析期間不可改變。`src/locale-bootstrap.js` 在所有資料模組前執行。選單改動使用完整文件導覽，終止舊收音工作，下一頁建立全新 JavaScript realm；原生收音 session ID 含語言及隨機識別，舊回傳不能命中新頁 session。

`src/locales/<language>/` 包含獨立餐牌快照、短句及長單語法、近音字、手工配對處理、自動學習引擎、連續模式收尾字、回應字典。TC 規則以已交付 v9.5.18 的廣東話版本為基準；SC 的普通話改寫器只在 SC 載入；English 有獨立指令適配器。共享網絡層會把輸入語言固定為當頁語言，不會選擇另一套語法。

| 資料 | 命名空間 |
|---|---|
| localStorage / sessionStorage | `voice-order.v20.<language>.kamkee.*` |
| IndexedDB | `smart-cafe-audit-v20-<language>` |
| 規則包、學習 journal、完整 log | 必帶所屬 `language` |
| 備份餐單 | `lang` 必須等於當頁語言 |
| 舊版未分類原文 | `voice-order.legacy-shared.v1`，只供明確選取或匯出 |
| 舊資料分類索引 | `voice-order.legacy-claims.v1`，防止重複匯入 |

不自動沿用舊版共用學習包。內部項目仍使用固定餐牌 ID 及標準選項值（例如 `T1`、`熱奶茶`）；標準值不是共享可變字典。

## 後備解析與學習

文字解析代理的 body 包含 `language` 和 `speechLanguage`；原供應商請求的 user context 也包含這兩個欄位。MiniMax ASR 使用 language header，MiMo ASR 使用語言提示。這些設定只能指定供應商輸入，不代表真機辨識成功率保證。

每個本地學習包及 journal 都帶不可混用的 language。安裝、還原完整學習紀錄、回滾版本都檢查語言；未知語言的包不得安裝。API 回應先驗證草稿效果，通過後才建立本頁規則。同一句陌生文字可以在三個語言學成三種獨立意思。

## 本地學習服務

```sh
LEARNING_LANGUAGE=tc LEARNING_PORT=8789 LEARNING_DATA_DIR=./learning-data node server/learning-server.mjs
LEARNING_LANGUAGE=sc LEARNING_PORT=8790 LEARNING_DATA_DIR=./learning-data node server/learning-server.mjs
LEARNING_LANGUAGE=en LEARNING_PORT=8791 LEARNING_DATA_DIR=./learning-data node server/learning-server.mjs
```

另從環境變數設定 `LEARNING_ADMIN_TOKEN`（最少 24 字）、`TEACHER_API_KEY` 及適當的 `LEARNING_ORIGIN`。憑證不要放進命令參數、ZIP 或 Git。

每個程序只讀寫 `LEARNING_DATA_DIR/<language>/journal.json`。除 `/healthz` 和 OPTIONS 外，請求必須有：

```http
Authorization: Bearer <admin token>
X-Voice-Language: sc
```

所有 JSON 回應都有 envelope：

```json
{"language":"sc","data":{"version":"...","rules":[]}}
```

`/v1/rules` 的 data 本身也有 `language`。上傳 cases 的每個 record 必須有相同 `language`，每個 sample.state.lang 亦必須相同；不一致回應 409，整批不儲存。舊版原始 journal 不會從根目錄自動移入。

## 訂單後端

每次請求都有 `X-Voice-Language`。寫入 body 帶 `language`，後端必須按此值分區儲存、查詢及修改；餐牌設定也要分區。每次寫入前，前端先 GET `/api/store` 檢查：

```json
{"language":"sc","capabilities":{"languageIsolation":1},"prices":{},"availability":{}}
```

訂單、訂單列表及店舖資料回應必須帶相符的 language；列表中每張訂單亦須相符。不相符或能力不足時，前端停止操作並保留本頁草稿。此契約需由現有外部訂單後端實作，ZIP 不包含該外部服務；附帶學習後端已實作分區及驗證。

## 驗證方式

- `tests/locale-isolation.test.mjs`：三套引擎、同名不同義配對、API 學習重播、跨語言備份/規則拒絕、清除隔離、舊資料分類、舊收音回傳、訂單後端能力、三個真正 HTTP 學習服務及只改 SC 源碼的重建檢查。
- `acceptance/locale-isolation/golden.mjs`：以交付 v9.5.18 產生的 5,000 個凍結廣東話語義結果，驗證本版 TC 行為一致。測試 oracle 附原版 HTML SHA-256，不把參考版本程式一起打包。
- 原有普通話、廣東話、權限及 UI 測試各載入所屬頁面；語言切換測試檢查新頁導覽及資料保留，不再容許直接改變同一 engine 的語言。

UI 及裝置事件測試使用模擬 DOM/語音事件；本地 HTTP 測試使用假供應商回應，不消耗實際 API 額度。未以實機音訊或真實 API key 證實的項目，不能宣稱為已通過真機或供應商測試。

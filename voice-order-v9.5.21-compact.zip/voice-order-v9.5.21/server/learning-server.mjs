import {createServer} from 'node:http';
import {timingSafeEqual, webcrypto} from 'node:crypto';
import {mkdirSync, readFileSync, renameSync, writeFileSync} from 'node:fs';
import {resolve, join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {createContext, runInContext} from 'node:vm';

function loadEngine(language){
 const {version}=JSON.parse(readFileSync(new URL('../package.json',import.meta.url),'utf8'));
 const html=readFileSync(new URL('../智能茶餐廳-v'+version+'.html',import.meta.url),'utf8');
 const context=createContext({KAM_LANG:language,URL,AbortSignal,crypto:webcrypto,structuredClone,setTimeout,clearTimeout,performance,console,Blob,TextEncoder});
 for(const match of html.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/g)){
  if(match[2].trim()&&!match[2].includes("(()=>{'use strict';"))runInContext(match[2],context);
 }
 return context;
}
const idPattern=/^[a-zA-Z0-9_.:-]{1,100}$/;
const matches=(actual,wanted)=>{
 const a=Buffer.from(actual), b=Buffer.from(wanted);
 return a.length===b.length&&timingSafeEqual(a,b);
};
async function body(request,limit=8000000){
 const chunks=[];let length=0;
 for await(const part of request){
  length+=part.length;
  if(length>limit)throw Object.assign(Error('request-too-large'),{status:413});
  chunks.push(part);
 }
 try{return JSON.parse(Buffer.concat(chunks).toString('utf8'));}catch{throw Object.assign(Error('invalid-json'),{status:400});}
}
function json(response,status,value){
 response.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});
 response.end(JSON.stringify(value));
}
export async function startLearningServer({
 host='127.0.0.1',port=8789,dir='./learning-data',adminToken,teacherKey,origin='',settings={},transport=globalThis.fetch,tickMs=15000,language='tc'
}={}){
 if(typeof adminToken!=='string'||adminToken.length<24)throw Error('LEARNING_ADMIN_TOKEN must be at least 24 characters');
 if(!['tc','sc','en'].includes(language))throw Error('invalid-language');
 const {Kam:K,KamDebug,KamEvolution:E,KamEvolutionCycle:C}=loadEngine(language);
 KamDebug.addSecret(adminToken);KamDebug.addSecret(teacherKey);
 const root=resolve(dir,language),path=join(root,'journal.json');
 mkdirSync(root,{recursive:true,mode:0o700});
 const store=new C.Journal({
  read:()=>{try{return JSON.parse(readFileSync(path,'utf8'));}catch(error){if(error.code==='ENOENT')return null;throw error;}},
  write:data=>{
   const temporary=path+'.tmp';
   writeFileSync(temporary,JSON.stringify(data),{mode:0o600});renameSync(temporary,path);
  }
 });
 // An explicit environment override applies at launch. Otherwise keep the saved schedule.
 if(Object.entries(settings).some(([key,value])=>store.data.config[key]!==value))store.configure(settings);
 if(!store.data.next)store.configure({});
 const run=force=>C.teach(store,{credential:teacherKey,force,transport,validate:E.validateRelease});
 function status(){
  const data=store.data;
  return {version:data.active.version,rules:data.active.rules.length,queued:C.pending(data).length,next:data.next,last:data.last,running:!!store.running,configured:!!teacherKey,config:data.config,rollback:!!data.previous.length};
 }
 function receive(records){
  if(!Array.isArray(records)||records.length>8)throw Object.assign(Error('invalid-cases'),{status:400});
  const cases=records.map(record=>{
   if(record?.language!==language)throw Object.assign(Error('case-language-mismatch'),{status:409});
   if(!record||!idPattern.test(record.id)||!Number.isInteger(record.revision)||record.revision<1||!Array.isArray(record.samples)||record.samples.length>8||!Array.isArray(record.calls)||record.calls.length>24||!['resolved','failed','clarification','cancelled'].includes(record.final?.status))throw Object.assign(Error('invalid-case'),{status:400});
   const c={language,id:record.id,revision:record.revision,at:record.at,updated:record.updated,final:KamDebug.sanitize(record.final),calls:KamDebug.sanitize(record.calls),validation:KamDebug.sanitize(record.validation),samples:[]};
   for(const s of record.samples){
    if(s.state?.lang!==language)throw Object.assign(Error('sample-language-mismatch'),{status:409});
    if(s.decision!=='fallback'||typeof s.text!=='string'||!s.state||!Array.isArray(s.state.cart)||s.state.cart.length>50)continue;
    try{
     const state=KamDebug.sanitize(E.snapshot(s.state));
     if(!E.gap(E.base(s.text,state.cart)))continue;
     c.samples.push({text:KamDebug.sanitize(s.text),decision:'fallback',phase:KamDebug.sanitize(s.phase),reason:KamDebug.sanitize(s.reason),state,expected:typeof s.expected==='string'?KamDebug.sanitize(s.expected):undefined});
    }catch{}
   }
   return c;
  });
  store.change(data=>{
   for(const record of cases){
    const index=data.cases.findIndex(c=>c.id===record.id);
    if(index>=0){
     const prior=data.cases[index];if(prior.revision>=record.revision)continue;
     if(JSON.stringify(prior.samples)===JSON.stringify(record.samples))record.taught=prior.taught;
     data.cases[index]=record;
    }else data.cases.push(record);
   }
   while(data.cases.length>C.retention){const index=data.cases.findIndex(c=>c.taught||!c.samples.length);data.cases.splice(Math.max(0,index),1);}
  });
 }
 const reply=(response,status,data)=>json(response,status,{language,data});
 const server=createServer(async(request,response)=>{
  try{
   const supplied=request.headers.origin;
   if(supplied){
    if(supplied!==origin){reply(response,403,{error:'origin-denied'});return;}
    response.setHeader('Access-Control-Allow-Origin',origin);
    response.setHeader('Vary','Origin');
    response.setHeader('Access-Control-Allow-Headers','Authorization, Content-Type, X-Voice-Language');
    response.setHeader('Access-Control-Allow-Methods','GET, POST, PUT, OPTIONS');
   }
   if(request.method==='OPTIONS'){response.writeHead(204);response.end();return;}
   const path=new URL(request.url,'http://localhost').pathname,route=request.method+' '+path;
   if(route==='GET /healthz'){reply(response,200,{ok:true});return;}
   if(!matches(request.headers.authorization||'','Bearer '+adminToken)){reply(response,401,{error:'unauthorized'});return;}
   if(request.headers['x-voice-language']!==language){reply(response,409,{error:'language-mismatch'});return;}
   switch(route){
    case 'GET /v1/status': reply(response,200,status());break;
    case 'GET /v1/rules': reply(response,200,store.data.active);break;
    case 'GET /v1/export': reply(response,200,store.data);break;
    case 'POST /v1/cases': receive((await body(request)).cases);reply(response,200,status());break;
    case 'POST /v1/run': reply(response,200,await run(true));break;
    case 'POST /v1/rollback': store.rollback();reply(response,200,status());break;
    case 'PUT /v1/config': {
     const values=await body(request,2000),{enabled,interval,batch}=values;
     if(typeof enabled!=='boolean')throw Object.assign(Error('invalid-enabled'),{status:400});
     try{store.configure({enabled,interval,batch});}catch{throw Object.assign(Error('invalid-schedule'),{status:400});}
     reply(response,200,status());break;
    }
    default: reply(response,404,{error:'not-found'});
   }
  }catch(error){
   reply(response,error.status||(error.message==='no-previous-release'?409:500),{error:KamDebug.sanitize(error.message)});
  }
 });
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(port,host,resolve);});
 const timer=setInterval(()=>run(false).catch(error=>console.error('Learning journal write failed:',error.code||error.name)),tickMs);
 server.on('close',()=>clearInterval(timer));
 return {server,url:'http://'+host+':'+server.address().port,close:()=>new Promise((resolve,reject)=>server.close(error=>error?reject(error):resolve()))};
}

if(process.argv[1]&&import.meta.url===pathToFileURL(resolve(process.argv[1])).href){
 const env=process.env,settings={};
 if(env.TEACHER_MODEL)settings.model=env.TEACHER_MODEL;
 if(env.TEACHER_API_URL)settings.endpoint=env.TEACHER_API_URL;
 if(env.TEACHER_AUTH)settings.auth=env.TEACHER_AUTH;
 if(env.LEARNING_INTERVAL_MINUTES)settings.interval=Number(env.LEARNING_INTERVAL_MINUTES);
 if(env.LEARNING_BATCH_SIZE)settings.batch=Number(env.LEARNING_BATCH_SIZE);
 const app=await startLearningServer({host:env.LEARNING_HOST,port:env.LEARNING_PORT?Number(env.LEARNING_PORT):undefined,dir:env.LEARNING_DATA_DIR,adminToken:env.LEARNING_ADMIN_TOKEN,teacherKey:env.TEACHER_API_KEY,origin:env.LEARNING_ORIGIN,language:env.LEARNING_LANGUAGE||'tc',settings});
 console.log('Smart Café learning scheduler listening at '+app.url);
}

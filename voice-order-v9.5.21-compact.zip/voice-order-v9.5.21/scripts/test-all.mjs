/* Isolate mobile profiles so long diagnostic histories cannot accumulate
 * across six different browser simulations. Every case still runs. */
import fs from'node:fs';import path from'node:path';import{spawn}from'node:child_process';
const directory='verification/test-runs';fs.mkdirSync(directory,{recursive:true});
const normal=fs.readdirSync('tests').filter(name=>name.endsWith('.test.mjs')&&name!=='mobile-mic-e2e.test.mjs').map(name=>'tests/'+name);
const jobs=Array.from({length:6},(_,n)=>({name:'mobile-'+n,args:['--test','--test-reporter=tap','--test-timeout=30000','tests/mobile-mic-e2e.test.mjs'],env:{V959_SHARD:String(n)},format:'tap'}));
jobs.push({name:'app-regressions',args:['--test','--test-reporter=tap','--test-concurrency=1','--test-timeout=60000',...normal],format:'tap'},
 {name:'api-learning-5000',args:['acceptance/api-learning/run.mjs'],format:'json'},
 {name:'exception-copy-5000',args:['acceptance/exception-copy/run.mjs'],format:'json'});
jobs.unshift({name:'continuous-500',args:['acceptance/continuous-voice/run.mjs'],format:'json',expected:500},...Array.from({length:2},(_,n)=>({name:'ui-operations-'+n,args:['acceptance/ui-operations/run.mjs'],env:{UI_SHARD:String(n),UI_SHARDS:'2'},format:'json',expected:500})));
jobs.unshift({name:'tc-golden-5000',args:['acceptance/locale-isolation/golden.mjs'],format:'json',expected:5000},{name:'mandarin-natural-500',args:['acceptance/mandarin/natural.mjs'],format:'json',expected:500},{name:'mandarin-critical-1000',args:['acceptance/mandarin/critical.mjs'],format:'json',expected:1000},{name:'mandarin-10000',args:['acceptance/mandarin/run.mjs'],format:'json',expected:10000},{name:'mandarin-continuous-500',args:['acceptance/continuous-voice/run.mjs'],env:{CAPTURE_LANG:'sc',TRACE_FILE:'acceptance/mandarin/continuous-execution.jsonl'},format:'json',expected:500},...Array.from({length:2},(_,n)=>({name:'mandarin-ui-'+n,args:['acceptance/ui-operations/run.mjs'],env:{UI_LANG:'sc',UI_SHARD:String(n),UI_SHARDS:'2',TRACE_FILE:'acceptance/mandarin/ui-execution-'+n+'.jsonl'},format:'json',expected:500})));
const results=[];let next=0;
async function worker(){while(next<jobs.length){const job=jobs[next++],started=Date.now(),file=directory+'/'+job.name+'.txt';
 const result=await new Promise(resolve=>{
  const child=spawn(process.execPath,job.args,{env:{...process.env,...job.env},stdio:['ignore','pipe','pipe'],detached:process.platform!=='win32'});let out='',errors='',timedOut=false;
  const timeout=setTimeout(()=>{timedOut=true;try{process.kill(process.platform==='win32'?child.pid:-child.pid,'SIGTERM');}catch{}},600000);
  child.stdout.on('data',data=>out+=data);child.stderr.on('data',data=>errors+=data);
  child.on('error',error=>{clearTimeout(timeout);resolve({name:job.name,failed:true,error:error.message});});
  child.on('close',(code,signal)=>{clearTimeout(timeout);fs.writeFileSync(file,out+(errors?'\nSTDERR\n'+errors:''));let parsed;
   try{if(job.format==='json'){const data=JSON.parse(out);parsed={tests:data.total,passed:data.passed,failed:data.failed};if(job.expected&&data.total!==job.expected)throw Error('Expected '+job.expected+' cases; got '+data.total);}
    else{const value=key=>Number(out.match(new RegExp('^# '+key+' (\\d+)','m'))?.[1]);parsed={tests:value('tests'),passed:value('pass'),failed:value('fail')};if(!Number.isFinite(parsed.tests)||!Number.isFinite(parsed.passed)||!Number.isFinite(parsed.failed))throw Error('Test summary missing');}
    resolve({name:job.name,...parsed,code,signal,timedOut,elapsedMs:Date.now()-started,output:file,ok:code===0&&!timedOut&&parsed.failed===0&&parsed.tests===parsed.passed});
   }catch(error){resolve({name:job.name,ok:false,code,signal,timedOut,error:error.message,output:file});}
  });
 });results.push(result);console.log(JSON.stringify(result));
}}
await Promise.all([worker(),worker()]);
if(results.filter(r=>r.name.startsWith('ui-operations-')).every(r=>r.ok)){const rows=[0,1].flatMap(n=>fs.readFileSync('acceptance/ui-operations/execution-'+n+'.jsonl','utf8').trim().split('\n').map(line=>JSON.parse(line))).sort((a,b)=>a.id.localeCompare(b.id));if(rows.length!==1000||new Set(rows.map(r=>r.id)).size!==1000||new Set(rows.map(r=>JSON.stringify(r.operations))).size!==1000)throw Error('Incomplete UI trace');fs.writeFileSync('acceptance/ui-operations/execution.jsonl.partial',rows.map(row=>JSON.stringify(row)).join('\n')+'\n');fs.renameSync('acceptance/ui-operations/execution.jsonl.partial','acceptance/ui-operations/execution.jsonl');}
if(results.filter(r=>r.name.startsWith('mandarin-ui-')).every(r=>r.ok)){const rows=[0,1].flatMap(n=>fs.readFileSync('acceptance/mandarin/ui-execution-'+n+'.jsonl','utf8').trim().split('\n').map(s=>JSON.parse(s))).sort((a,b)=>a.id.localeCompare(b.id));if(rows.length!==1000||new Set(rows.map(r=>JSON.stringify(r.operations))).size!==1000)throw Error('Mandarin UI trace incomplete');fs.writeFileSync('acceptance/mandarin/ui-execution.jsonl',rows.map(r=>JSON.stringify(r)).join('\n')+'\n');}
const summary={jobs:results,passed:results.every(r=>r.ok),tests:results.reduce((n,r)=>n+(r.tests||0),0),successful:results.reduce((n,r)=>n+(r.passed||0),0)};fs.writeFileSync('verification/test-summary.json',JSON.stringify(summary,null,2)+'\n');console.log(JSON.stringify({allJobsPassed:summary.passed,tests:summary.tests,successful:summary.successful}));if(!summary.passed)process.exitCode=1;

import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash}from 'node:crypto';
const root=process.cwd(),manifest=JSON.parse(fs.readFileSync('release-manifest.json','utf8'));
const {version}=JSON.parse(fs.readFileSync('package.json','utf8'));assert.equal(version,manifest.version);
let bytes=0;
for(const [name,expected]of Object.entries(manifest.files)){
 const file=path.resolve(root,name);assert.ok(file.startsWith(root+path.sep));
 const data=fs.readFileSync(file);assert.equal(data.length,expected.bytes,name+' size');assert.equal(createHash('sha256').update(data).digest('hex'),expected.sha256,name+' SHA-256');bytes+=data.length;
}
console.log(JSON.stringify({version,checkedFiles:Object.keys(manifest.files).length,checkedBytes:bytes,status:'verified'},null,2));

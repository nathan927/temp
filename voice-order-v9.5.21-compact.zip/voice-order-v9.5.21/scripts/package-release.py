"""Package only current source and validated evidence for the three-language suite."""
from pathlib import Path
import hashlib,json,shutil,zipfile
root=Path.cwd();version=json.loads((root/'package.json').read_text())['version'];result=json.loads((root/'verification/three-languages-final.json').read_text());assert result['passed']==30000 and result['failed']==0
assert hashlib.sha256((root/('智能茶餐廳-v'+version+'.html')).read_bytes()).hexdigest()==result['htmlSHA256']
destination=root.parent.parent/'deliverables';destination.mkdir(exist_ok=True);stage=destination/('voice-order-v'+version)
if stage.exists():shutil.rmtree(stage)
stage.mkdir()
allowed_traces={row['file'] for language in result['languages'].values() for row in language['files']}
allowed_traces.update('acceptance/three-languages/'+lang+'-semantic-'+phase+'.jsonl' for lang in ['tc','sc','en'] for phase in ['baseline','final'])
allowed_traces.add('acceptance/locale-isolation/execution.jsonl');allowed_traces.add('acceptance/api-learning/execution.jsonl')
fixture_names={'field-log-fixture.json','closings.json','closing-words.json','tc-v18-golden.json','case-manifest.json','request-templates.json'}
for directory in ['src','assets','scripts','tests','server','docs','acceptance']:
 for source in (root/directory).rglob('*'):
  if not source.is_file() or '__pycache__' in source.parts or source.suffix=='.pyc' or source.name in {'finalize-evidence.py','reconcile-validation.mjs'}:continue
  relative=source.relative_to(root);name=relative.as_posix()
  if directory=='acceptance':
   if source.suffix=='.jsonl' and name not in allowed_traces:continue
   if source.suffix=='.json' and source.name not in fixture_names:continue
  if source.name.endswith('.partial') or '.partial-' in source.name:continue
  target=stage/relative;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
for name in ['README.md','package.json','package-lock.json','智能茶餐廳-v'+version+'.html','voice-order-v'+version+'-report.md','locale-engine-manifest.json']:
 shutil.copyfile(root/name,stage/name)
verification=['sc-closing-change.json','sc-closing-final-summary.json','closing-and-isolation-current.txt','api-learning-5000-current.json','three-languages-final.json','dietary-api-change.json','feedback-name-change.json','en-safety-change.json','affected-current.txt','safety-isolation-release.txt','audit-and-safety-release.txt','allergy-api-before.txt','allergy-scope-final.txt','allergy-scope-execution.jsonl','tc-golden-current.json','sc-regression-current.json']
verification+= [lang+'-'+kind+'.json' for lang in ['tc','sc','en'] for kind in ['final-summary','semantic-baseline','semantic-final']]
for name in verification:
 source=root/'verification'/name;assert source.is_file(),name;target=stage/'verification'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
# Preserve the actual initial OOM diagnostics and counters without packing duplicate
# successful traces from the abandoned execution as another set of cases.
for lang in ['tc','sc','en']:
 for name in [lang+'-ui-run.txt',lang+'-ui-checkpoint.json']:
  source=root/'verification'/name;target=stage/'verification/initial-ui'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
source=root/'acceptance/three-languages/en-ui-rejection-guards.jsonl'
if source.exists():shutil.copyfile(source,stage/'verification/initial-ui/en-menu-name-failures.jsonl')
source=root/'acceptance/three-languages/sc-final-closing-silence.jsonl';shutil.copyfile(source,stage/'verification/initial-ui/sc-closing-before-fix.jsonl')
for lang in ['tc','sc','en']:
 rows=[]
 for data in result['languages'][lang]['files']:
  source=stage/data['file'];assert hashlib.sha256(source.read_bytes()).hexdigest()==data['sha256'];part=[json.loads(s) for s in source.read_text().splitlines()];assert len(part)==500 and all(row['status']=='passed' for row in part);rows+=part
 assert len(rows)==10000 and len({row['id'] for row in rows})==10000
safety=[json.loads(s) for s in (stage/'verification/allergy-scope-execution.jsonl').read_text().splitlines()];assert len(safety)==63 and all(row['status']=='passed' for row in safety)
manifest={'version':version,'files':{}}
for source in sorted(stage.rglob('*')):
 if source.is_file():
  raw=source.read_bytes();manifest['files'][str(source.relative_to(stage))]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
(stage/'release-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
archive=destination/('voice-order-v'+version+'-compact.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for source in sorted(stage.rglob('*')):
  if source.is_file():
   info=zipfile.ZipInfo(str(source.relative_to(destination)),(2026,11,5,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o644<<16;z.writestr(info,source.read_bytes(),compresslevel=9)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None;assert len(z.namelist())==len(manifest['files'])+1;assert len([name for name in z.namelist() if name.endswith('.html')])==1;assert not any('/node_modules/' in name for name in z.namelist())
meta={'path':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':len(manifest['files'])+1,'htmlSHA256':result['htmlSHA256'],'cases':30000}
(destination/'release-artifact-v21.json').write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps(meta,indent=2))

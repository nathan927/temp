/* One real provider request and an isolated learning/replay check.
 * Supply credentials via environment variables, never in command arguments. */
import fs from'node:fs';import vm from'node:vm';import{webcrypto}from'node:crypto';
const provider=process.argv[2]||'mimo',profile=process.argv[3]||(provider==='mimo'?'standard':'cn'),output='live-api-check-result.json';
if(!['mimo','minimax'].includes(provider))throw Error('Use mimo or minimax');
const credential=process.env[provider==='mimo'?'MIMO_API_KEY':'MINIMAX_API_KEY'];
const report={provider,profile,liveVendor:true,at:new Date().toISOString(),status:'not-run',requests:[],draftChanged:false};
if(!credential){report.reason='No credential supplied in '+(provider==='mimo'?'MIMO_API_KEY':'MINIMAX_API_KEY');fs.writeFileSync(output,JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report));process.exitCode=2;}
else{
 const{version}=JSON.parse(fs.readFileSync('package.json','utf8')),html=fs.readFileSync('智能茶餐廳-v'+version+'.html','utf8'),c=vm.createContext({console,crypto:webcrypto,performance,structuredClone,setTimeout,clearTimeout,URL,AbortSignal});
 for(const [,source]of html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/g))if(!source.includes("(()=>{'use strict';"))vm.runInContext(source,c);
 c.KamDebug.addSecret(credential);c.KamAudit.addSecret(credential);
 const K=c.Kam,E=c.KamEvolution,state=E.snapshot({cart:[]}),text='連線驗證：一份菠蘿油';let data;const journal=new c.KamEvolutionCycle.Journal({read:()=>null,write:value=>data=value});
 journal.sample('live',text,K.analyzeLocal(text,[]),state,'device');
 try{
  const result=await K.fallbackFlow.resolve({text,cart:[],context:state,settings:{parser:provider},configured:[provider],parse:async(provider,text,cart)=>{
   const spec=K.spec('parse',{provider,key:credential,text,cart,apiProfile:profile,model:process.env[provider==='mimo'?'MIMO_MODEL':'MINIMAX_MODEL']}),record={endpoint:spec.url,body:spec.body};report.requests.push(record);
   const response=await fetch(spec.url,{method:'POST',headers:spec.headers,body:JSON.stringify(spec.body),signal:AbortSignal.timeout(45000)}),raw=await response.text();record.status=response.status;record.response=raw;
   if(!response.ok)throw K.fallbackFlow.failure(null,response.status);let value;try{value=JSON.parse(raw);}catch{throw new K.OrderError('invalidJSON');}if(value.status==='incomplete'||value.choices?.some(c=>c.finish_reason==='length'))throw new K.OrderError('apiIncomplete');return K.readAI('parse',value);
  }});
  if(E.effect(result.plan,state)!==E.effect(K.analyzeLocal('一份菠蘿油',[]).plan,state))throw new K.OrderError('apiProbeUnexpected');
  journal.resolved('live',text,result.plan,state,'model');E.install(data.active);const replay=K.analyzeLocal(text,[],state);if(!replay.learned)throw new K.OrderError('apiProbeLearningFailed');
  report.status='passed';report.learnedRules=data.active.rules;report.secondPass='dictionary';report.secondPassRequests=0;
 }catch(error){report.status='failed';report.error={code:error.code||error.name,message:error.message};process.exitCode=1;}
 fs.writeFileSync(output,JSON.stringify(c.KamAudit.sanitize(report),null,2)+'\n');console.log(JSON.stringify({status:report.status,provider,profile,requests:report.requests.length,output}));
}

let handsFreeRearm=null,handsFreeStopReason='',handsFreeTurn=null;
const handsFree=new KamHandsFree.Session({
 consume:consumeHandsFreeTurn,
 enqueue(turn){
  voiceMetrics.begin({id:turn.id,cloudConfigured:!!(keys.minimax||keys.mimo||S.settings.apiBase),deviceText:!!turn.result.text,text:turn.result.text,
   context:voiceContext(),alternatives:turn.result.alternatives,capture:{origin:turn.origin||'home',language:locale(),deviceSpeech:S.settings.asr==='browser',sessionId:turn.sessionId,turn:turn.sequence,receivedAt:turn.receivedAt}});
 },
 discard(turn,reason){voiceMetrics.finish(turn.id,{status:'cancelled',error:'continuous-'+reason});},
 stop(reason){
  handsFreeStopReason=reason;clearTimeout(handsFreeRearm);handsFreeRearm=null;
  microphone.cancel();microphone.release();micStarting=false;recording=null;
 },
 change:refreshHandsFreeUI,error(error,turn){if(turn&&['processing','pending'].includes(voiceMetrics.find(turn.id)?.status))voiceMetrics.finish(turn.id,{status:'failed',error});voiceError(error);},
 log:(event,data)=>{KamDebug.log('hands-free',event,data);KamAudit.append('hands-free',event,data);},
});
function refreshHandsFreeUI(){
 const active=handsFree.active,waiting=handsFree.processing||handsFree.pending>0,mic=$('#home-mic');
 if(mic){mic.classList.toggle('recording',active||!!recording);mic.setAttribute('aria-pressed',String(active||!!recording));mic.setAttribute('aria-label',t(active?'stopMic':'startMic'));mic.disabled=active?false:busy||waiting||micStarting||!!microphone.session?.options.test;}
 for(const button of document.querySelectorAll('[data-action="confirm"]'))button.disabled=busy||waiting||active||!!recording||micStarting||!S.cart.length;
 const state=$('#hands-free-state');if(state){
  state.hidden=S.settings.handsFree===false&&!active&&!waiting;
  state.textContent=active?t(waiting?'handsFreeQueued':'handsFreeListening',{n:handsFree.pending+(handsFree.processing?1:0)}):waiting?t('handsFreeFinishing',{n:handsFree.pending+(handsFree.processing?1:0)}):t(handsFreeStopReason?'handsFreeStopped':'handsFreeReady');
 }
 const hint=$('.home-mic-hint');if(hint)hint.textContent=t(S.settings.handsFree!==false?'handsFreeHint':'homeMicHint');
}
function stopHandsFree(reason='manual',discard=false){handsFree.stop(reason,'',{discard});}
function queueHandsFreeResult(result,s){
 if(!handsFree.active)return;
 handsFree.feed(result,{origin:s.options.origin||'home',physicalId:s.id});
}
async function openHandsFreeCapture(){
 if(!handsFree.active||microphone.active||micStarting)return;
 await microphone.start({origin:handsFree.options.origin||'home',language:locale(),test:false,continuous:true,
  deviceSpeech:S.settings.asr==='browser'&&!handsFree.options.forceAudio,draftContext:voiceMetrics.snapshot(voiceContext()),continuousSession:handsFree.id});
}
function rearmHandsFree(){
 if(!handsFree.active)return;const id=handsFree.id;clearTimeout(handsFreeRearm);
 handsFreeRearm=setTimeout(()=>{handsFreeRearm=null;if(handsFree.active&&handsFree.id===id)openHandsFreeCapture().catch(voiceError);},150);
}
async function consumeHandsFreeTurn(turn){
 handsFreeTurn=turn;activeVoiceId=turn.id;
 const message=voiceMetrics.find(turn.id);if(message){message.parseContext=voiceMetrics.snapshot(voiceContext());voiceMetrics.save();}
 try{
  const ordinal=/^(?:第)?([一二兩三四五六七八九十\d]+)(?:個|份|杯|行|款|項)?$/.exec(K.language.clean(turn.result.text));
  const choiceIndex=ordinal?K.number(ordinal[1])-1:-1,old=pending;
  if(old?.state===S&&ordinal&&(old.targetChoices||old.transcript)){
   const choice=old.targetChoices?.find(choice=>choice.index===choiceIndex),candidate=old.candidates?.[choiceIndex];
   if(choice||candidate){
    pending=null;if(!$('#modal-layer').hidden)close();
    await processCommand(candidate||old.text,{voiceId:turn.id,origin:old.origin,plan:choice?.plan,source:old.source,localOnly:true});
    if(voiceMetrics.find(turn.id)?.status==='resolved')voiceMetrics.finish(old.voiceId,{status:'resolved',source:old.source||'dictionary',intent:voiceMetrics.find(turn.id).intent});
    return;
   }
  }
  if(['voice-clarify','clarify','term-clarify','pair-clarify','upgrade-clarify'].includes(modalType)&&!$('#modal-layer').hidden)close();
  if(turn.result.blob){
   if(turn.result.peak<.0001&&!turn.result.text){voiceMetrics.finish(turn.id,{status:'failed',error:'micSilent'});voiceError(new K.OrderError('micSilent'));return;}
   await recoverClip(turn.result.blob,turn.result.text,turn.origin,turn.result.alternatives||[],turn.id);
  }else await handleDeviceVoice(turn.result,turn.origin,turn.id);
 }finally{handsFreeTurn=null;if(activeVoiceId===turn.id)activeVoiceId=null;refreshHandsFreeUI();}
}
Object.assign(L.dict,{
 voiceClosingAmbiguous:['尾嗰句係想唔要嗰份，定係講完收音？我先留住原單；想刪餐可以講「取消上一份」，講完就講「係咁多」吖。','Did you mean to cancel that item or finish speaking? I kept the draft. Say “cancel the last item” to remove it, or “that’s all” to stop listening.'],
 handsFreeMode:['連續落單（7 秒冇聲自動停止）','Continuous orders (stop after 7 seconds of silence)'],
 handsFreeSettingHint:['預設開啟。講完一段就落草稿，再繼續聽；「係咁多」、「OK」、「就咁」、「無喇」等會停止收音，唔會自動送單。','On by default. Each completed utterance updates the draft while listening continues. Closing words stop recording; they never submit the order.'],
 handsFreeHint:['可以一路講；7 秒冇聲會停，講「係咁多」都得。','Keep speaking. Seven seconds of silence or a closing phrase stops listening.'],
 handsFreeReady:['連續落單已開，撳咪就可以開始。','Continuous ordering is on. Tap the mic to start.'],
 handsFreeListening:['繼續聽緊你講～講「係咁多」或者再撳咪就停。','Still listening. Say “that’s all” or tap the mic to stop.'],
 handsFreeQueued:['繼續聽緊；正按次序處理 {n} 段說話。','Still listening; processing {n} utterances in order.'],
 handsFreeFinishing:['已停收音，仲有 {n} 段已聽到嘅內容處理緊。','Listening stopped; finishing {n} already captured utterances.'],
 handsFreeStopped:['已停收音，張單幫你留住。','Listening stopped. Your draft is kept.'],
 voiceQueueFull:['頭先收到好多段喇，先幫你處理已聽到嗰啲。等一等，再撳咪補講其餘內容吖。','Many utterances are queued. Let me finish those captured, then tap the mic for the rest.'],
});

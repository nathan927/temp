var auditCaseVersions,auditEventIds;
function gThisAudit(data){
 auditCaseVersions??=new Map();auditEventIds??=new Set();
 for(const c of data.cases){const signature=JSON.stringify([c.revision,c.updated,c.synced,c.taught,c.samples?.length,c.calls?.length,c.validation?.length,c.final]);if(auditCaseVersions.get(c.id)!==signature){KamAudit.record('learning-case',c.id,c);auditCaseVersions.set(c.id,signature);}}
 for(const e of data.events){const id=e.id||e.at+'-'+e.type;if(!auditEventIds.has(id)){KamAudit.record('learning-event',id,{...e,id});auditEventIds.add(id);}}
 KamAudit.state('evolution',data);
}
let evolutionCaseHistory=[],evolutionEventHistory=[];
async function loadEvolutionHistory(){try{[evolutionCaseHistory,evolutionEventHistory]=await Promise.all([KamAudit.recent('learning-case',100),KamAudit.recent('learning-event',100)]);renderEvolutionStatus();}catch(error){KamDebug.error('audit','recent-learning.failed',error);}}
let teacherKey='',learningAccessToken='',evolutionTimer,evolutionSyncing=false,evolutionSession=0,remoteStatus=null,evolutionStorageError='';
function createEvolution(){
 const storage='kamkee.evolution.v1',Cycle=KamEvolutionCycle;
 const write=data=>{
  gThisAudit(data);

  let raw=JSON.stringify(data);
  while(raw.length>2200000&&(data.events.length>8||data.cases.length>1||data.previous.length)){
   if(data.events.length>8)data.events.shift();
   else if(data.previous.length)data.previous.shift();
   else{
    const index=data.cases.findIndex(c=>c.taught);
    data.cases.splice(Math.max(index,0),1);
   }
   raw=JSON.stringify(data);
  }
  try{localStorage.setItem(storage,raw);}catch(error){KamAudit.append('storage','learning-cache-write-failed',{error,handling:'Full state queued in audit history; learned rules remain active in memory.'});}
 };
 try{
  const journal=new Cycle.Journal({read:()=>JSON.parse(localStorage.getItem(storage)||'null'),write});
  try{journal.importHistory(unlearned.data.cases);}catch(error){KamDebug.error('evolution','history.import.failed',error);}
  KamEvolution.install(journal.data.active,journal.data.remote);return journal;
 }catch(error){
  KamDebug.error('evolution','storage.read.failed',error);
  return new Cycle.Journal({read:()=>null,write});
 }
}
function evolutionWrite(action){
 try{
  const result=action();
  const [active,remote]=KamEvolution.active();
  if(active!==evolution.data.active.version||remote!==evolution.data.remote.version)KamEvolution.install(evolution.data.active,evolution.data.remote);
  evolutionStorageError='';return result;
 }catch(error){
  evolutionStorageError=error.message;
  KamDebug.error('evolution','journal.failed',error);
 }
}
function stopEvolution(){evolutionSession++;teacherKey='';learningAccessToken='';clearTimeout(evolutionTimer);}
function queueEvolutionSync(delay=250){
 clearTimeout(evolutionTimer);
 if(!teacherKey&&!learningAccessToken)return;
 evolutionTimer=setTimeout(()=>evolutionTick().catch(error=>KamDebug.error('evolution','tick.failed',error)),delay);
}
async function learningServer(path,method='GET',body){
 const endpoint=evolution.data.config.backend;
 if(!endpoint||!learningAccessToken)throw Error('learning-server-credential-required');
 const response=await fetch(endpoint+path,{method,headers:{'X-Voice-Language':KamLocale.id,Authorization:'Bearer '+learningAccessToken,...(body?{'Content-Type':'application/json'}:{})},body:body?JSON.stringify(body):undefined,signal:AbortSignal.timeout(95000),redirect:'error'});
 if(!response.ok)throw Error('learning-server-http-'+response.status);
 const envelope=await response.json();if(envelope.language!==KamLocale.id)throw new K.OrderError('localeMismatch');if(path==='/v1/rules'&&envelope.data?.language!==KamLocale.id)throw new K.OrderError('localeMismatch');return envelope.data;
}
async function syncLearning(){
 const session=evolutionSession, url=evolution.data.config.backend;
 const cases=evolution.data.cases.filter(c=>c.final&&c.synced!==c.revision).slice(0,8);
 if(cases.length)await learningServer('/v1/cases','POST',{cases});
 const remote=await learningServer('/v1/status');
 if(session!==evolutionSession||url!==evolution.data.config.backend)return;
 remoteStatus=remote;
 let pack;
 if(remote.version!==evolution.data.remote.version){
  pack=KamEvolution.validatePack(await learningServer('/v1/rules'));
  if(session!==evolutionSession||url!==evolution.data.config.backend)return;
 }
 if(pack||cases.length)evolutionWrite(()=>evolution.change(data=>{
  if(pack)data.remote=pack;
  for(const c of cases){const saved=data.cases.find(x=>x.id===c.id);if(saved)saved.synced=c.revision;}
 }));
}
async function evolutionTick(force=false){
 if(evolutionSyncing)return;
 if(document.hidden&&!force){queueEvolutionSync(15000);return;}
 evolutionSyncing=true;
 try{
  if(evolution.data.config.backend&&learningAccessToken){
   await syncLearning();
   if(force){const result=await learningServer('/v1/run','POST',{});await syncLearning();return result;}
  }else if(teacherKey&&!evolution.data.config.backend){
   const transport=globalThis.KamNative?.request?(url,request)=>nativeFetch({url,headers:request.headers,body:JSON.parse(request.body)}):globalThis.fetch;
   const result=await KamEvolutionCycle.teach(evolution,{credential:teacherKey,transport,force});
   KamEvolution.install(evolution.data.active,evolution.data.remote);return result;
  }
 }catch(error){
  evolutionStorageError=error.message;KamDebug.error('evolution','sync-or-teach.failed',error);
  if(force)throw error;
 }finally{
  evolutionSyncing=false;queueEvolutionSync(15000);renderEvolutionStatus();
 }
}
document.addEventListener('visibilitychange',()=>{if(!document.hidden)queueEvolutionSync();});
const evolveLabel=(tc,en)=>S.lang==='en'?en:label(tc);
function evolutionStatus(status){
 const words={
  released:['已發佈','Released'],reviewed:['已覆核','Reviewed'],requested:['教學請求已送出','Teaching requested'],
  failed:['失敗','Failed'],empty:['沒有到期案例','No due cases'],waiting:['等待排程','Waiting for schedule'],
  busy:['處理中','Running'],resolved:['已處理','Resolved'],clarification:['待澄清','Needs clarification'],
  cancelled:['已取消','Cancelled'],'disabled-or-missing-key':['已停用或欠金鑰','Disabled or missing key']
 };
 return words[status]?evolveLabel(...words[status]):status||'—';
}
function renderEvolutionStatus(){
 if(modalType!=='evolution'||!settingsAccess)return;
 const data=evolution.data, r=remoteStatus;
 const status=$('#evolution-status');if(!status)return;
 const date=value=>value?new Date(value).toLocaleString():'—';
 const lines=[
  [evolveLabel('待批次覆核','Queued for teaching'),data.config.backend&&r?r.queued:KamEvolutionCycle.pending(data).length],
  [evolveLabel('本機規則版本','Local rule release'),data.active.version+' · '+data.active.rules.length],
  [evolveLabel('後端規則版本','Server rule release'),data.remote.version+' · '+data.remote.rules.length],
  [evolveLabel('下次批次時間','Next batch'),date(data.config.backend?r?.next:data.next)],
  [evolveLabel('上次批次結果','Last batch'),evolutionStatus(data.config.backend?r?.last?.status:data.last?.status)]
 ];
 status.innerHTML=lines.map(([k,v])=>'<div><strong>'+esc(k)+'</strong> '+esc(v)+'</div>').join('');
 const rollback=$('[data-action="evolution-rollback"]');if(rollback)rollback.disabled=!data.previous.length;
 const history=$('#evolution-history');
 const recentEvents=new Map(evolutionEventHistory.map(e=>[e.id,e]));for(const e of data.events)recentEvents.set(e.id||e.at+'-'+e.type,e);
 if(history)history.innerHTML=[...recentEvents.values()].sort((a,b)=>b.at.localeCompare(a.at)).slice(0,100).map(e=>'<details class="debug-entry"><summary>'+esc(e.at)+' · '+esc(e.type)+'</summary><pre>'+esc(JSON.stringify(e.detail,null,2))+'</pre></details>').join('');
 const cases=$('#evolution-cases');
 const recentCases=new Map(evolutionCaseHistory.map(c=>[c.id,c]));for(const c of data.cases)recentCases.set(c.id,c);
 if(cases)cases.innerHTML=[...recentCases.values()].sort((a,b)=>b.at.localeCompare(a.at)).slice(0,100).map(c=>{
  const text=c.samples[0]?.text||c.final?.text||c.id;
  return '<details class="debug-entry"><summary>'+esc(text)+' · '+esc(evolutionStatus(c.final?.status))+' · API '+c.calls.length+'</summary><pre>'+esc(JSON.stringify(c,null,2))+'</pre></details>';
 }).join('');
 const error=$('#settings-error');
 if(error){error.textContent=evolutionStorageError;error.hidden=!evolutionStorageError;}
}
function evolutionPage(){
 if(!requireSettings('evolution'))return;
 stopAudio();
 const c=evolution.data.config, l=evolveLabel;
 const field=(id,title,value,type='text',extra='')=>'<label class="form-field">'+title+'<input id="evo-'+id+'" type="'+type+'" value="'+esc(value)+'" '+extra+'></label>';
 modal(t('evolutionTitle'),t('appVersion'),`
  <p class="micro-hint">${l('後備 API 成功後會即時驗證可重用的規則。批次會覆核其餘案例。關頁後的排程由後端服務執行。','Successful fallbacks are checked for immediate reuse. The batch reviews remaining cases. Use the server to run while this page is closed.')}</p>
  <label class="voice-setting-toggle"><input id="evo-enabled" type="checkbox" ${c.enabled?'checked':''}>${l('啟用本機學習及批次','Enable local learning and batches')}</label>
  ${field('interval',l('批次間隔（分鐘）','Batch interval (minutes)'),c.interval,'number','min="1" max="1440"')}
  ${field('batch',l('每批案例上限','Cases per batch'),c.batch,'number','min="1" max="24"')}
  ${field('model',l('教學模型','Teacher model'),c.model)}
  ${field('endpoint',l('教學 API 網址','Teacher API URL'),c.endpoint,'url')}
  <label class="form-field">${l('教學 API 驗證','Teacher API authentication')}<select id="evo-auth"><option value="api-key" ${c.auth==='api-key'?'selected':''}>api-key</option><option value="bearer" ${c.auth==='bearer'?'selected':''}>Bearer</option></select></label>
  ${field('key',l('教學 API 金鑰（本次開頁）','Teacher API key (this page session)'),'', 'password','autocomplete="off"')}
  ${field('backend',l('排程後端網址（可選）','Scheduling server URL (optional)'),c.backend,'url')}
  ${field('token',l('排程後端管理 Token（本次開頁）','Server admin token (this page session)'),'', 'password','autocomplete="off"')}
  <p class="micro-hint">${l('連接後端後，教學模型及金鑰由伺服器環境設定。失敗句子、餐單上下文及補救結果會用於教學；記錄會遮蔽已知金鑰，不含錄音。','With a server, its environment supplies the teacher model and key. Failed phrases, draft context and recovery outcomes are used for teaching. Known keys and audio are excluded from logs.')}</p>
  <div id="settings-error" class="notice error-notice" hidden></div>
  <div class="settings-tools"><button class="primary" data-action="evolution-save">${l('儲存設定','Save settings')}</button><button class="secondary" data-action="evolution-run">${l('立即執行','Run now')}</button><button class="secondary" data-action="evolution-sync">${l('更新狀態','Refresh status')}</button></div>
  <div id="evolution-status" class="notice" role="status"></div>
  <div class="settings-tools">
   <button class="secondary" data-action="evolution-export">${l('匯出本機記錄 JSON','Export local journal JSON')}</button>
   <button class="secondary" data-action="evolution-server-export" ${c.backend?'':'disabled'}>${l('匯出後端記錄 JSON','Export server journal JSON')}</button>
   <button class="secondary" data-action="evolution-rules">${l('匯出規則版本 .mjs','Export rule release .mjs')}</button>
   <button class="text-button" data-action="evolution-rollback" ${evolution.data.previous.length?'':'disabled'}>${l('回退本機版本','Roll back local release')}</button>
   <button class="text-button" data-action="evolution-server-rollback" ${c.backend?'':'disabled'}>${l('回退後端版本','Roll back server release')}</button>
  </div><details class="desk-details"><summary>${l('最近語音補救案例','Recent voice fallback cases')}</summary><div id="evolution-cases"></div></details>
  <details class="desk-details"><summary>${l('最近版本及教學記錄','Recent releases and teaching log')}</summary><div id="evolution-history"></div></details>
 `,`<button class="primary full" data-action="settings">${t('backSettings')}</button>`,'evolution');
 renderEvolutionStatus();loadEvolutionHistory();
}
async function saveEvolution(){
 const value=id=>$('#evo-'+id).value.trim(), key=value('key'), token=value('token'), old=evolution.data.config;
 const config=KamEvolutionCycle.configuration({enabled:$('#evo-enabled').checked,interval:value('interval'),batch:value('batch'),model:value('model'),endpoint:value('endpoint'),auth:value('auth'),backend:value('backend')});
 KamDebug.addSecret(key);KamDebug.addSecret(token);
 evolutionSession++;
 evolution.configure(config);
 if(config.backend!==old.backend){
  remoteStatus=null;learningAccessToken='';
  KamEvolution.install(evolution.data.active,evolution.data.remote);
 }
 if(config.endpoint!==old.endpoint)teacherKey='';
 teacherKey=key||teacherKey;learningAccessToken=token||learningAccessToken;
 try{
  if(config.backend&&learningAccessToken)await learningServer('/v1/config','PUT',{enabled:config.enabled,interval:config.interval,batch:config.batch});
  evolutionStorageError='';evolutionPage();
 }finally{queueEvolutionSync();}
}
const evolutionActions={
 evolution:evolutionPage,
 'evolution-save':()=>settingsAccess&&saveEvolution(),
 'evolution-run':async()=>{
  if(!settingsAccess)return;
  if(evolution.data.config.backend?!learningAccessToken:!teacherKey)throw Error(evolveLabel('請先儲存教學 API 金鑰或後端 Token。','Save the teacher key or server token first.'));
  const result=await evolutionTick(true);if(modalType==='evolution')evolutionPage();if(result)toast(evolutionStatus(result.status));
 },
 'evolution-sync':()=>settingsAccess&&evolutionTick(),
 'evolution-export':exportAllLogs,
 'evolution-server-export':async()=>{if(settingsAccess)download(JSON.stringify(await learningServer('/v1/export'),null,2),'SmartCafe-Server-Evolution.json','application/json');},
 'evolution-rules':()=>{
  if(!settingsAccess)return;
  for(const pack of [evolution.data.active,evolution.data.remote].filter(p=>p.version!=='base'))download(KamEvolution.moduleSource(pack),'SmartCafe-Rules-'+pack.version+'.mjs','text/javascript');
 },
 'evolution-rollback':()=>{if(settingsAccess){evolution.rollback();KamEvolution.install(evolution.data.active,evolution.data.remote);evolutionPage();}},
 'evolution-server-rollback':async()=>{if(settingsAccess){await learningServer('/v1/rollback','POST',{});await syncLearning();evolutionPage();}}
};
Object.assign(L.dict,{evolutionTitle:['自進化學習','Self-improving voice rules']});

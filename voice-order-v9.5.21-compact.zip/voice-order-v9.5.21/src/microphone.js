/* One microphone owner at a time. Native callbacks and delayed browser grants
 * carry a session id so they cannot complete a newer recording. */
(function (g) {
  'use strict';
  const failure = (code, cause) => Object.assign(new Error(code), {code, cause});
  function mobileBrowser() {
    const nav = g.navigator;
    return /Android|iPhone|iPad|iPod/i.test(nav?.userAgent || '') ||
      nav?.userAgentData?.mobile === true || nav?.platform === 'MacIntel' && nav.maxTouchPoints > 1;
  }
  const speechFailures = {
    'not-allowed': 'micSpeechDenied', 'service-not-allowed': 'micSpeechUnavailable',
    'audio-capture': 'micBusy', network: 'micSpeechNetwork',
    'language-not-supported': 'micSpeechLanguage', 'no-speech': 'micNoMatch', aborted: 'micSpeechInterrupted'
  };
  function classify(error, env = g) {
    if (error?.code && typeof error.code === 'string') return error;
    const name = error?.name || 'UnknownError';
    const policy = env.document?.permissionsPolicy || env.document?.featurePolicy;
    let blocked = false;
    try { blocked = policy?.allowsFeature('microphone') === false; } catch {}
    const protocol = env.location?.protocol;
    const code = blocked ? 'micPolicy' : env.isSecureContext === false ? 'micInsecure' :
      protocol === 'content:' || /WhatsApp/i.test(env.navigator?.userAgent || '') ? 'micPreview' :
      ['NotAllowedError', 'PermissionDeniedError'].includes(name) ? 'micDenied' :
      ['NotFoundError', 'DevicesNotFoundError'].includes(name) ? 'micMissing' :
      ['NotReadableError', 'TrackStartError', 'AbortError'].includes(name) ? 'micBusy' :
      name === 'OverconstrainedError' ? 'micConstraints' :
      name === 'SecurityError' ? 'micPolicy' :
      name === 'InvalidStateError' ? 'micInactive' : 'micFailed';
    return Object.assign(failure(code, error), {diagnostic: name});
  }
  function encodeWav(chunks, inputRate) {
    const count = chunks.reduce((n, a) => n + a.length, 0);
    if (count < inputRate * .2) throw failure('recordShort');
    const source = new Float32Array(count);
    let offset = 0;
    for (const c of chunks) { source.set(c, offset); offset += c.length; }
    const rate = 16000, length = Math.floor(count * rate / inputRate);
    const buffer = new ArrayBuffer(44 + length * 2), view = new DataView(buffer);
    const word = (at, value) => { for (let i = 0; i < value.length; i++) view.setUint8(at + i, value.charCodeAt(i)); };
    word(0, 'RIFF'); view.setUint32(4, 36 + length * 2, true); word(8, 'WAVE'); word(12, 'fmt ');
    view.setUint32(16, 16, true); view.setUint16(20, 1, true); view.setUint16(22, 1, true);
    view.setUint32(24, rate, true); view.setUint32(28, rate * 2, true);
    view.setUint16(32, 2, true); view.setUint16(34, 16, true); word(36, 'data'); view.setUint32(40, length * 2, true);
    for (let i = 0; i < length; i++) {
      const a = Math.floor(i * inputRate / rate), b = Math.min(count, Math.max(a + 1, Math.floor((i + 1) * inputRate / rate)));
      let value = 0; for (let j = a; j < b; j++) value += source[j];
      view.setInt16(44 + i * 2, Math.max(-1, Math.min(1, value / (b - a))) * 32767, true);
    }
    return new Blob([buffer], {type: 'audio/wav'});
  }
  class Microphone {
    constructor(options = {}) { this.options = options; this.session = null; this.stream = null; this.serial = 0; }
    get starting() { return this.session?.state === 'starting'; }
    get active() { return !!this.session; }
    get native() { return typeof g.KamNative?.startMic === 'function'; }
    current(s) { return this.session === s; }
    trace(s, event, detail = {}) {
      g.KamDebug?.log('mic-trace', event, {sessionId:s.id, route:s.route,
        elapsedMs:Math.round(performance.now()-s.at), state:s.state, ...detail});
    }
    state(s, value) { if (!this.current(s)) return; g.KamDebug?.log('microphone','state',{sessionId:s.id,native:s.native,from:s.state,to:value}); s.state = value; this.options.onState?.(value, s); }
    async start(options = {}) {
      if (this.active) return;
      const native = this.native, phone = mobileBrowser();
      const route = native ? 'native-bridge' : options.test ? 'audio-test' :
        options.deviceSpeech ? phone ? 'mobile-device' : 'browser-audio-and-speech' : 'audio-asr';
      const s = {id: (g.KamLocale?.id||'tc')+'-'+Date.now().toString(36)+'-'+(++this.serial)+'-'+(g.crypto?.randomUUID?.()||''), options, native, route, at:performance.now(),
        state: 'starting', chunks: [], transcript: '', alternatives: [], peak: 0, timers: []};
      this.session = s;
      this.trace(s,'attempt.start',{language:options.language,userActivation:g.navigator?.userActivation?.isActive,
        hidden:!!g.document?.hidden,focused:g.document?.hasFocus?.()});
      g.KamDebug?.log('microphone','start',{sessionId:s.id,native:s.native,options,environment:g.KamDebug.environment()});
      g.KamDebug?.inspect('microphone.start',s.id); this.state(s, 'starting');
      this.timer(s, () => this.fail(s, failure('micPromptTimeout')), 60000);
      try {
        if (s.native) {this.trace(s,'native.request');g.KamDebug?.log('android','startMic.request',{sessionId:s.id,options,permissionState:'Awaiting native callback; browser permission is separate'});g.KamNative.startMic(s.id, JSON.stringify(options)); return; }
        if (phone && ['content:', 'data:', 'blob:', 'file:'].includes(location.protocol)) throw failure('micPreview');
        if (g.isSecureContext === false) throw failure('micInsecure');
        if (document.hidden) throw failure('micInactive');
        const policy = document.permissionsPolicy || document.featurePolicy;
        if (policy?.allowsFeature('microphone') === false) throw failure('micPolicy');
        if (options.deviceSpeech && !options.test && phone) {
          this.mobileSpeech(s);
          return;
        }
        if (!navigator.mediaDevices?.getUserMedia) throw failure(location.protocol === 'content:' ? 'micPreview' : 'micUnsupported');
        const Audio = g.AudioContext || g.webkitAudioContext;
        if (!Audio) throw failure('micAudioUnsupported');
        // Create/resume while still in the tap's user activation.
        s.ctx = new Audio();
        // Attach a rejection handler immediately: a permission prompt can stay
        // open longer than the AudioContext takes to reject its resume.
        g.KamDebug?.log('audio','context.created',{sessionId:s.id,state:s.ctx.state,sampleRate:s.ctx.sampleRate});const resume = s.ctx.resume().then(() => {g.KamDebug?.log('audio','context.resumed',{sessionId:s.id,state:s.ctx.state});return null;}, error => {g.KamDebug?.error('audio','resume.failed',error,{sessionId:s.id});return error;});
        let stream = this.stream;
        if (!stream?.getAudioTracks().some(t => t.readyState === 'live')) {
          try {this.trace(s,'capture.request');g.KamDebug?.log('permission','getUserMedia.request',{sessionId:s.id,constraints:{audio:{channelCount:1,echoCancellation:true,noiseSuppression:true}}}); stream = await navigator.mediaDevices.getUserMedia({audio: {channelCount: 1, echoCancellation: true, noiseSuppression: true}}); }
          catch (e) {g.KamDebug?.error('permission','getUserMedia.rejected',e,{sessionId:s.id,constraint:e.constraint}); if (e.name !== 'OverconstrainedError') throw e;g.KamDebug?.log('permission','constraints.retry',{sessionId:s.id,constraints:{audio:true}},'warn'); stream = await navigator.mediaDevices.getUserMedia({audio: true}); }
        }
        if (!this.current(s)) {this.trace(s,'capture.lateGrantReleased');g.KamDebug?.log('microphone','lateGrant.released',{sessionId:s.id},'warn'); stream.getTracks().forEach(t => t.stop()); return; }
        this.stream = s.stream = stream;g.KamDebug?.log('permission','getUserMedia.granted',{sessionId:s.id,tracks:stream.getAudioTracks().map(t=>({kind:t.kind,enabled:t.enabled,muted:t.muted,readyState:t.readyState,settings:t.getSettings?.()}))});
        this.trace(s,'capture.granted',{audioTracks:stream.getAudioTracks().length});
        stream.getAudioTracks().forEach(t => t.enabled = true);
        const resumeError = await Promise.race([resume, new Promise((_, reject) => this.timer(s, () => reject(failure('micAudioUnsupported')), 5000))]);
        if (resumeError) throw failure('micAudioUnsupported', resumeError);
        if (!this.current(s)) return;
        s.source = s.ctx.createMediaStreamSource(stream);
        s.processor = s.ctx.createScriptProcessor(4096, 1, 1);
        s.gain = s.ctx.createGain(); s.gain.gain.value = 0;
        s.rate = s.ctx.sampleRate; s.start = performance.now(); s.lastVoice = s.start;
        s.processor.onaudioprocess = e => {
          if (!this.current(s) || s.state !== 'listening') return;
          const c = new Float32Array(e.inputBuffer.getChannelData(0)); s.chunks.push(c);
          let sum = 0; for (const v of c) sum += v * v;
          const rms = Math.sqrt(sum / c.length); s.peak = Math.max(s.peak, rms);
          this.options.onLevel?.(rms, s);if(!s.lastLevelLog||performance.now()-s.lastLevelLog>1000){s.lastLevelLog=performance.now();g.KamDebug?.log('audio','input.level',{sessionId:s.id,rms,peak:s.peak});}
          if (rms > .012) { s.heard = true; s.lastVoice = performance.now();if(options.continuous)this.options.onActivity?.(s,'audio'); }
          if (!options.test && s.heard && (performance.now()-s.lastVoice>1600&&performance.now()-s.start>1800||options.continuous&&performance.now()-s.start>30000)){if(options.continuous)this.continuousChunk(s);else this.finish();}
        };
        s.trackEnded = () => this.fail(s, failure('micDisconnected'));
        for (const track of stream.getAudioTracks()) track.addEventListener('ended', s.trackEnded);
        s.source.connect(s.processor); s.processor.connect(s.gain); s.gain.connect(s.ctx.destination);
        this.trace(s,'capture.listening',{sampleRate:s.rate});
        this.clearTimers(s); this.state(s, 'listening');
        if(!options.continuous)this.timer(s, () => this.finish(), options.test ? 4000 : 45000);
        if (options.deviceSpeech && !options.test) this.browserSpeech(s);
      } catch (error) { this.fail(s, classify(error)); }
    }
    timer(s, callback, delay) { const id = setTimeout(()=>{g.KamDebug?.log('microphone','timer.fired',{sessionId:s.id,state:s.state,delayMs:delay});callback();}, delay); s.timers.push(id); return id; }
    clearTimers(s) { for (const id of s.timers) clearTimeout(id); s.timers = []; }
    createRecognizer(s) {
      const Speech = g.SpeechRecognition || g.webkitSpeechRecognition;
      if (!Speech) throw failure('micSpeechUnavailable');
      const sr = s.recognizer = new Speech();
      sr.lang = s.options.language || 'zh-HK';
      sr.continuous = !!s.options.continuous;
      sr.maxAlternatives = 5;
      return sr;
    }
    saveSpeechResult(s, rows) {
      s.transcript = rows.map(row => row[0].transcript).join('');
      s.alternatives = rows.flatMap((row, n) => Array.from(row).slice(1, 5).map(alt =>
        rows.map((r, i) => i === n ? alt.transcript : r[0].transcript).join(''))).slice(0, 5);
    }
    continuousSpeech(s,sr,track=false){
      s.speechOnly=!track;sr.interimResults=true;const sent=new Set();
      const current=()=>this.current(s)&&s.recognizer===sr;
      sr.onstart=()=>{if(!current())return;this.trace(s,'recognition.started',{continuous:true});this.clearTimers(s);this.state(s,'listening');};
      sr.onaudiostart=()=>{if(!current())return;s.didListen=true;this.trace(s,'recognition.audioStarted');sr.onstart();};
      sr.onspeechstart=()=>{if(current()){s.isSpeaking=true;this.options.onActivity?.(s,'speech-start');}};
      sr.onspeechend=()=>{if(current()){s.isSpeaking=false;this.options.onActivity?.(s,'speech-end');}};
      sr.onresult=event=>{
        if(!current())return;const rows=Array.from(event.results);
        this.trace(s,'recognition.result',{rows:rows.length,finalRows:rows.filter(row=>row.isFinal).length,continuous:true});
        if(rows.some((row,i)=>row[0]?.transcript?.trim()&&(row.isFinal!==true||!sent.has(i))))this.options.onActivity?.(s,'speech');
        for(let i=0;i<rows.length&&current();i++){
          const row=rows[i];if(row.isFinal!==true||!row[0]?.transcript?.trim()||sent.has(i))continue;
          sent.add(i);s.didListen=true;s.chunkHadFinal=true;
          const text=row[0].transcript,alternatives=Array.from(row).slice(1,5).map(value=>value.transcript);
          this.trace(s,'recognition.turn',{index:i,textCharacters:text.length});
          this.options.onUtterance?.({text,alternatives,peak:s.peak},s);
        }
      };
      const restart=()=>{
        if(!current())return;if(s.isSpeaking){s.isSpeaking=false;this.options.onActivity?.(s,'speech-end');}s.recognizer=null;sr.onresult=sr.onend=sr.onerror=sr.onnomatch=sr.onspeechstart=sr.onspeechend=null;try{sr.abort();}catch{};
        this.trace(s,'recognition.restarting',{continuous:true});
        this.timer(s,()=>{if(!this.current(s))return;try{const next=this.createRecognizer(s);this.continuousSpeech(s,next,track);}catch(error){this.fail(s,classify(error));}},150);
      };
      sr.onnomatch=()=>{if(current())restart();};
      sr.onerror=event=>{
        if(!current())return;this.trace(s,'recognition.error',{browserCode:event.error});
        if(event.error==='no-speech'){restart();return;}
        this.fail(s,failure(speechFailures[event.error]||'micSpeechUnavailable',{name:'SpeechRecognitionError',code:event.error,message:event.message}));
      };
      sr.onend=restart;
      sr.onnomatch=()=>{if(current()){this.trace(s,'recognition.noMatch',{continuous:true});restart();}};
      sr.onerror=event=>{if(!current())return;this.trace(s,'recognition.error',{browserCode:event.error,continuous:true});if(event.error==='no-speech'){restart();return;}this.fail(s,failure(speechFailures[event.error]||'micSpeechUnavailable',{name:'SpeechRecognitionError',code:event.error,message:event.message}));};
      this.trace(s,'recognition.request',{continuous:true,input:track?'track':'microphone',language:sr.lang});
      try{if(track){try{sr.start(s.stream.getAudioTracks()[0]);}catch{sr.start();}}else sr.start();}
      catch(error){this.fail(s,failure(error.name==='NotAllowedError'?'micSpeechDenied':'micSpeechUnavailable',error));}
    }
    continuousChunk(s){
      if(!this.current(s)||!s.chunks.length)return;
      const chunks=s.chunks,hadFinal=s.chunkHadFinal;s.chunks=[];s.chunkHadFinal=false;s.heard=false;s.start=performance.now();
      if(hadFinal)return;
      try{const blob=encodeWav(chunks,s.rate);this.options.onUtterance?.({blob,text:'',alternatives:[],peak:s.peak,durationMs:chunks.reduce((n,c)=>n+c.length,0)/s.rate*1000},s);}
      catch(error){this.trace(s,'capture.shortChunk',{code:error.code});}
    }
    mobileSpeech(s) {
      const sr = this.createRecognizer(s);
      s.speechOnly = true;
      if(s.options.continuous){this.continuousSpeech(s,sr);return;}
      sr.interimResults = false;
      sr.onstart = () => {
        if (!this.current(s) || s.state !== 'starting') return;
        this.trace(s,'recognition.started');
        this.clearTimers(s);
        this.state(s, 'listening');
        this.timer(s, () => this.finish(), 45000);
      };
      sr.onaudiostart = () => {
        if (!this.current(s)) return;
        s.didListen = true;
        this.trace(s,'recognition.audioStarted');
        g.KamDebug?.log('speech', 'audio.started', {sessionId:s.id, route:'mobile-device'});
        sr.onstart();
      };
      sr.onresult = event => {
        if (!this.current(s)) return;
        const results = Array.from(event.results);
        const rows = results.filter(row => row.isFinal === true && row[0]?.transcript);
        this.trace(s,'recognition.result',{rows:results.length,finalRows:rows.length,
          finalCharacters:rows.reduce((n,row)=>n+row[0].transcript.length,0)});
        if (!rows.length) return;
        s.didListen = true;
        this.saveSpeechResult(s, rows);
      };
      sr.onnomatch = () => {s.didListen = true; this.trace(s,'recognition.noMatch');this.fail(s, failure('micNoMatch'));};
      sr.onerror = event => {
        this.trace(s,'recognition.error',{browserCode:event.error});
        this.fail(s, failure(speechFailures[event.error] || 'micSpeechUnavailable',
          {name:'SpeechRecognitionError', code:event.error, message:event.message}));
      };
      sr.onend = () => this.endMobileSpeech(s);
      g.KamDebug?.log('speech', 'start.microphone', {sessionId:s.id, language:sr.lang, route:'mobile-device'});
      this.trace(s,'recognition.request',{input:'microphone',language:sr.lang});
      try { sr.start(); }
      catch (error) {
        throw failure(error.name === 'NotAllowedError' ? 'micSpeechDenied' : 'micSpeechUnavailable', error);
      }
    }
    endMobileSpeech(s, timeout = false) {
      if (!this.current(s)) return;
      this.trace(s,'recognition.ended',{timeout,finalCharacters:s.transcript.trim().length});
      if (s.transcript.trim()) this.complete(s, {text:s.transcript, alternatives:s.alternatives});
      else this.fail(s, failure(timeout ? 'micRecognitionTimeout' : s.state === 'starting' ? 'micSpeechUnavailable' : 'micNoMatch'));
    }
    browserSpeech(s) {
      const SR = g.SpeechRecognition || g.webkitSpeechRecognition;
      if (!SR) {g.KamDebug?.log('speech','unavailable',{sessionId:s.id},'warn'); s.speechError = 'unavailable'; return; }
      try {
        const sr = this.createRecognizer(s);
        if(s.options.continuous){this.continuousSpeech(s,sr,true);return;}
        sr.interimResults = true;
        sr.onstart = () => {if(this.current(s))this.trace(s,'recognition.started');};
        sr.onaudiostart = () => {if(this.current(s))this.trace(s,'recognition.audioStarted');};
        sr.onresult = e => {
          if (!this.current(s)) return;
          const rows = Array.from(e.results);
          this.trace(s,'recognition.result',{rows:rows.length,finalRows:rows.filter(row=>row.isFinal).length});
          this.saveSpeechResult(s, rows.filter(row=>row.isFinal===true));
        };
        sr.onerror = e => {this.trace(s,'recognition.error',{browserCode:e.error});g.KamDebug?.log('speech','error',{sessionId:s.id,error:e.error,message:e.message,handling:'Recording may still be usable for cloud ASR; do not infer microphone denial from speech service errors.'},'error');s.speechError = e.error; };
        sr.onend = () => {this.trace(s,'recognition.ended',{characters:s.transcript.length});g.KamDebug?.log('speech','ended',{sessionId:s.id,transcript:s.transcript,alternatives:s.alternatives}); s.speechEnded = true; if (this.current(s) && s.state === 'stopping') this.completeBrowser(s); };
        try {this.trace(s,'recognition.request',{input:'track',language:sr.lang});g.KamDebug?.log('speech','start.track',{sessionId:s.id,language:sr.lang}); sr.start(s.stream.getAudioTracks()[0]); } catch(error) {this.trace(s,'recognition.request',{input:'microphone',errorName:error.name});g.KamDebug?.error('speech','start.track.failed',error,{sessionId:s.id,handling:'Retry SpeechRecognition.start() without track argument.'});sr.start(); }
      } catch(error) {this.trace(s,'recognition.startFailed',{errorName:error.name});g.KamDebug?.error('speech','start.failed',error,{sessionId:s.id}); s.speechError = 'unavailable'; }
    }
    detach(s, discard = false) {g.KamDebug?.log('microphone','detach',{sessionId:s.id,discard,native:s.native});
      this.clearTimers(s);
      if (s.processor) { s.processor.onaudioprocess = null; try { s.processor.disconnect(); } catch {} }
      try { s.source?.disconnect(); s.gain?.disconnect(); } catch {}
      for (const track of s.stream?.getAudioTracks() || []) {
        track.removeEventListener('ended', s.trackEnded); track.enabled = false;
      }
      if (s.ctx) { try { const closing = s.ctx.close(); closing?.catch?.(() => {}); } catch {} }
      if (discard && s.recognizer) {
        s.recognizer.onresult = s.recognizer.onend = s.recognizer.onerror = null;
        s.recognizer.onstart = s.recognizer.onaudiostart = s.recognizer.onspeechstart = s.recognizer.onspeechend = s.recognizer.onnomatch = null;
        try { s.recognizer.abort(); } catch {}
      }
    }
    finish() {
      const s = this.session;g.KamDebug?.log('microphone','finish.request',{sessionId:s?.id,state:s?.state}); if (!s || s.state !== 'listening') return;
      this.trace(s,'attempt.finishRequested');
      this.state(s, 'stopping');
      if (s.native) {
        this.clearTimers(s); this.timer(s, () => this.fail(s, failure('micRecognitionTimeout')), 12000);
        try { g.KamNative.finishMic(s.id); } catch (e) { this.fail(s, classify(e)); }
        return;
      }
      if (s.speechOnly) {
        this.clearTimers(s);
        this.timer(s, () => this.endMobileSpeech(s, true), 4500);
        try { s.recognizer.stop(); }
        catch (error) { this.fail(s, failure('micSpeechInterrupted', error)); }
        return;
      }
      this.detach(s);
      if (s.recognizer && !s.speechEnded) {
        try { s.recognizer.stop(); } catch {}
        this.timer(s, () => this.completeBrowser(s), 900);
      } else this.completeBrowser(s);
    }
    completeBrowser(s) {
      if (!this.current(s)) return;
      try {
        const blob = encodeWav(s.chunks, s.rate);
        this.complete(s, {blob, text: s.transcript, alternatives: s.alternatives, peak: s.peak,
          durationMs: s.chunks.reduce((n,c) => n+c.length,0) / s.rate * 1000, speechError: s.speechError});
      } catch (e) { this.fail(s, e); }
    }
    nativeEvent(id, type, payload = {}) {
      const s = this.session;if(type!=='level'||!s?.lastNativeLevel||Date.now()-s.lastNativeLevel>1000){g.KamDebug?.log('android','callback.'+type,{sessionId:id,accepted:!!s&&s.native&&s.id===id,payload},type==='error'?'error':'info');if(s&&type==='level')s.lastNativeLevel=Date.now();} if (!s || !s.native || s.id !== id) return;
      if (type !== 'level') this.trace(s,'native.callback',{type,code:payload.code,
        textCharacters:typeof payload.text==='string'?payload.text.length:0,audio:!!payload.audio,
        granted:payload.granted,sdk:payload.sdk});
      try {
        if (type === 'started' && s.state === 'starting') { this.clearTimers(s); this.state(s, 'listening'); }
        if(s.options.continuous&&['speechstart','speechend'].includes(type))this.options.onActivity?.(s,type==='speechstart'?'speech-start':'speech-end');
        if (type === 'level') { if(s.options.continuous&&(payload.rms||0)>.012)this.options.onActivity?.(s,'audio');s.peak = Math.max(s.peak, payload.rms || 0); this.options.onLevel?.(payload.rms || 0, s); }
        if (type === 'canceled') { this.cancel(); this.options.onCancel?.(s); }
        if (type === 'error') this.fail(s, Object.assign(failure(payload.code || 'micFailed', payload.message),{diagnostic:payload}));
        if (type === 'result') {
          let blob = null;
          if (payload.audio) blob = new Blob([Uint8Array.from(atob(payload.audio), c => c.charCodeAt(0))], {type:'audio/wav'});
          this.complete(s, {...payload, blob, peak: Math.max(s.peak, payload.peak || 0)});
        }
      } catch (e) { this.fail(s, classify(e)); }
    }
    complete(s, result) {
      if (!this.current(s)) return;
      this.trace(s,'attempt.result',{textCharacters:result.text?.trim().length||0,alternatives:result.alternatives?.length||0,
        audio:!!result.blob,peak:result.peak,durationMs:result.durationMs,browserCode:result.speechError});
      g.KamDebug?.log('microphone','complete',{sessionId:s.id,native:s.native,result});this.detach(s, true);
      if (!s.native && mobileBrowser()) this.release();
      this.session = null; this.options.onState?.('idle', s);
      this.options.onResult?.(result, s);
    }
    fail(s, error) {
      if (!this.current(s)) return;
      this.trace(s,'attempt.failed',{code:error.code,errorName:typeof error.diagnostic==='string'?error.diagnostic:error.cause?.name,
        browserCode:error.cause?.code,didListen:!!s.didListen});
      g.KamDebug?.error('microphone','failed',classify(error),{sessionId:s.id,native:s.native,state:s.state,environment:g.KamDebug?.environment()});this.session = null; this.detach(s, true);
      if (s.native) { try { g.KamNative.cancelMic(s.id); } catch {} }
      this.release(); this.options.onState?.('idle', s); this.options.onError?.(classify(error), s);
    }
    cancel() {
      const s = this.session;g.KamDebug?.log('microphone','cancel',{sessionId:s?.id,native:s?.native}); this.session = null;
      if (!s) return;
      this.trace(s,'attempt.cancelled');
      this.detach(s, true);
      if (s.native) { try { g.KamNative.cancelMic(s.id); } catch {} }
      else if (mobileBrowser()) this.release();
      this.options.onState?.('idle', s);
    }
    release() {g.KamDebug?.log('microphone','release',{tracks:this.stream?.getTracks().length||0}); if (this.stream) this.stream.getTracks().forEach(t => t.stop()); this.stream = null; }
    background() {
      // A system permission sheet can temporarily hide the page. pagehide still cancels.
      if (this.starting){this.trace(this.session,'lifecycle.hiddenWhileStarting');return;}
      this.cancel(); this.release();
    }
  }
  g.KamMicrophone = {Microphone, classify, encodeWav};
})(globalThis);

Object.assign(I18n.dict,{
 appVersion:['智能茶餐廳 · 第八版','Smart Cha Chaan Teng · 8.0'],
 appSubtitle:['語音落單・第八版','VOICE ORDER · 8.0'],
 pairChoicePrompt:['請揀一杯飲品配落新套餐。','Choose a drink for the new set.'],
 startingMic:['正在申請／開啟麥克風，請回應系統提示…','Opening the microphone. Please respond to the system prompt…'],
 micFinishing:['正在完成錄音及辨識…','Finishing recording and recognition…'],
 micTestTitle:['測試麥克風','Test microphone'],micTestStart:['錄四秒測試','Record a 4-second test'],
 micTestHint:['請講「一二三，早餐 A」。聲量條應該會動；四秒後可播放原音，毋須服務金鑰。','Say “one two three, breakfast A”. The level meter should move. Play back the recording after four seconds. No API key needed.'],
 micTestReady:['按下面按鈕開始測試。','Tap below to start the test.'],
 micTestListening:['正在錄四秒，請講話…','Recording for four seconds. Please speak…'],
 micTestSuccess:['錄音完成。請播放，確認能清楚聽到自己。','Recording complete. Play it to check that your voice is clear.'],
 micTestSilent:['錄音完成但未收到聲音。請檢查手機的「麥克風存取」總開關、藍牙耳機及其他正在通話／錄音的程式。','Recording completed without audible input. Check the system microphone toggle, Bluetooth headset and other calling or recording apps.'],
 micTestPrivate:['測試錄音只在本次記憶體播放，不會傳送至 AI，也不會加入餐單。','The test recording stays in memory. It is not sent to AI or added to your order.'],
 micLevel:['收音強度','Microphone level'],micSeconds:['秒','seconds'],micPlayback:['播放測試錄音','Play test recording'],
 micTestStats:['錄音 {seconds} 秒 · 最大收音強度 {level}%','Recorded {seconds}s · Peak input {level}%'],
 micRetry:['再試收音','Try microphone again'],micSettings:['開啟 App 權限設定','Open app permission settings'],
 micHelpTitle:['收音疑難排解','Microphone help'],
 micReportExport:['匯出收音診斷','Export microphone diagnostics'],
 micHelpAndroid:['此 APK 直接使用 Android 麥克風。首次按麥克風後，請在系統提示選「使用 App 時允許」。曾拒絕且不再彈出提示，可按「開啟 App 權限設定」→ 權限 → 麥克風 → 允許。','This APK uses the Android microphone directly. On first use, choose Allow while using the app. If no prompt appears after a previous denial, open app settings → Permissions → Microphone → Allow.'],
 micHelpBrowser:['請用 Android Chrome 或 iPhone／iPad Safari 開啟 HTTPS 網頁，再允許網站使用咪高峰。WhatsApp、下載檔案及內置預覽可能用唔到語音。','Open the HTTPS page in Android Chrome or iPhone/iPad Safari and allow microphone access. Chat and file previews may lack voice support.'],
 micHelpGlobal:['即使已允許 App，Android 的「麥克風存取」總開關關閉仍會令錄音無聲；通話或其他錄音程式也可能佔用收音。','Even with app permission, the Android microphone privacy toggle can mute input. Calls and other recording apps can occupy the microphone.'],
 micHelpSpeech:['如果試咪有聲但仍未轉到文字，請檢查手機語音服務同網絡。iPhone／iPad 請核對 Safari 網站咪高峰權限同 Siri 設定。','If the microphone test plays audio but no words appear, check the device speech service and network. On iPhone/iPad, check the Safari site microphone and Siri settings.'],
 micPermissionHint:['手機網頁用裝置語音辨識直接收音。試咪同指定雲端轉錄會另開錄音。','The mobile website uses device speech recognition for microphone input. The microphone test and selected cloud transcription use a separate recording.'],
 asrHint:['預設使用裝置語音。選擇雲端轉錄供應商後，才會自動把錄音交給所選服務。','Device speech is the default. Recordings are automatically sent to a cloud service only when you select a transcription provider.'],
 recognitionNote:['先用本機詞庫理解文字。若仍未清楚，可以核對文字、重新錄音，或在有原音時按掣用雲端重試。','The local dictionary handles the transcript first. You can check the transcript, record again, or request a cloud retry when the original recording is available.'],
 noSpeech:['未能使用裝置語音服務。請檢查語音服務及語言，或在設定選擇雲端轉錄。','Device speech is unavailable. Check the speech service and language, or select cloud transcription in settings.']
});
Object.assign(I18n.errors,{
 micDenied:['麥克風授權被拒絕或被系統阻擋。按「再試收音」重新申請；若不再出現提示，請開啟 App／瀏覽器的麥克風權限。','Microphone access was denied or blocked. Tap Try microphone again. If no prompt appears, enable microphone permission in app/browser settings.'],
 micDeniedPermanent:['Android 沒有允許此 App 使用麥克風，且未再提供授權提示。請按「開啟 App 權限設定」→ 權限 → 麥克風 → 允許。','Android has not granted microphone access and is no longer showing a prompt. Open app settings → Permissions → Microphone → Allow.'],
 micMissing:['找不到可用麥克風。請連接或啟用收音裝置，再試一次。','No microphone was found. Connect or enable an input device and retry.'],
 micBusy:['麥克風未能啟動，可能正被通話或其他錄音程式使用。請結束通話／錄音，再試一次。','The microphone could not start. A call or another recording app may be using it. Close that input and retry.'],
 micInsecure:['呢個網址未能開咪。請用 HTTPS 網址重新開啟。','Microphone access requires a secure page. Reopen the site over HTTPS.'],
 micPreview:['呢個檔案或聊天預覽開唔到咪。請用 Chrome 或 Safari 開啟 HTTPS 版。','This file or chat preview cannot start the microphone. Open the HTTPS site in Chrome or Safari.'],
 micUnsupported:['呢個瀏覽器或預覽器未提供收音。請用 Android Chrome 或 iPhone／iPad Safari 開啟 HTTPS 版。','This browser or preview does not provide microphone capture. Open the HTTPS site in Android Chrome or iPhone/iPad Safari.'],
 micPolicy:['呢個預覽阻擋咗咪高峰。請用瀏覽器獨立開啟 HTTPS 網址。','This preview blocks microphone access. Open the HTTPS address directly in your browser.'],
 micConstraints:['此收音裝置不支援所需錄音格式。請換用內置麥克風或新版 APK。','The input does not support this recording format. Try the built-in microphone or the new APK.'],
 micInactive:['頁面尚未處於前景。請回到 App，再按麥克風。','The page is not active. Return to the app and tap the microphone again.'],
 micAudioUnsupported:['此裝置／瀏覽器未能建立錄音處理。請用新版 APK，或更新並使用完整瀏覽器。','Audio capture could not be initialized. Use the new APK, or an updated full browser.'],
 micDisconnected:['錄音期間麥克風已斷線或被系統停止。請檢查收音裝置後重試。','The microphone disconnected or was stopped by the system during recording. Check the input device and retry.'],
 micPromptTimeout:['仍未收到麥克風授權結果。請處理系統提示，再按「再試收音」。','No microphone permission response was received. Respond to the system prompt, then try again.'],
 micRecognitionTimeout:['裝置語音服務未有回應。請重試，或在設定填入雲端語音金鑰。','The device speech service did not respond. Retry or enter a cloud speech key in settings.'],
 micNoSpeech:['裝置沒有可用的 Android 語音服務。請啟用／安裝系統語音辨識服務，或在設定填入 MiniMax／MiMo 金鑰。可先按「測試麥克風」確認收音。','No Android speech service is available. Enable/install a system speech recognition service or enter MiniMax/MiMo keys. Test the microphone to check recording separately.'],
 micSpeechNetwork:['收音服務已啟動，但裝置語音服務連線失敗。請檢查網絡，或改用設定內的 MiniMax／MiMo 金鑰。','Input started, but the device speech service could not connect. Check the network or configure MiniMax/MiMo keys.'],
 micSpeechLanguage:['裝置語音服務未提供所選語言。請安裝該語言、換語言，或設定雲端語音服務。','The device speech service does not provide the selected language. Install/change the language or configure cloud speech.'],
 micSilent:['沒有收到可辨識的聲音。請檢查系統「麥克風存取」總開關、耳機及其他錄音程式，再用麥克風測試確認。','No audible input was received. Check the system microphone toggle, headset and other recording apps, then run the microphone test.'],
 micSpeechDenied:['手機或瀏覽器未允許語音辨識。請檢查呢個網站同瀏覽器嘅咪高峰權限，再按咪。','The phone or browser did not allow speech recognition. Check microphone permissions for the site and browser, then tap the mic.'],
 micSpeechUnavailable:['呢個開啟方式未能啟動裝置語音服務。請用 Chrome 或 Safari 開啟 HTTPS 版，再核對手機語音設定。','Device speech could not start here. Open the HTTPS site in Chrome or Safari and check the phone’s speech settings.'],
 micSpeechInterrupted:['今次語音中斷咗。返到落單頁再按咪試吓。','Speech recognition was interrupted. Return to the order page and tap the mic again.'],
 micNoMatch:['頭先裝置冇交到清楚文字呀。試下「測試收音」；有聲嘅話，再睇吓手機語音服務，或者喺設定揀雲端轉錄～','The device did not return clear words. Test the microphone. If it records sound, check your phone’s speech service or choose cloud transcription in settings.'],
 micFailed:['收音遇到未預期問題。請按「測試麥克風」檢查收音，再重試。','Microphone capture failed unexpectedly. Run the microphone test, then retry.']
});

(function(g){
'use strict';
const K=g.Kam, originalAnalyze=K.analyzeLocal, originalParse=K.parseCommand;
const oldControl=K.language.control;
const restart=/^(?:重新(?:再)?(?:叫|點|落單|開始|嚟過|黎過|來過)(?:過)?|重頭(?:再)?(?:嚟|黎|來)?過|由頭(?:再)?(?:叫|點|嚟|黎|來|開始)(?:過)?|從頭(?:再)?(?:叫|點|嚟|黎|來|開始)(?:過)?|推倒重來|砍掉重練)/;
const all='(?:全部|全單|成張單|整張單|呢張單|嗰張單|我張單|成單|整單|成個單|成份單|張單|所有(?:嘢|野|餐點|項目|嘢食)?|我啲嘢|呢啲嘢|購物車|個購物車|成個購物車)';
const erase='(?:取消|刪除|刪走|刪晒|刪曬|清空|清走|清晒|清曬|清零|唔要|不要|撤銷|撤回)';
const clear=new RegExp('^(?:'+all+'(?:都|嘅|既|啲)?'+erase+'(?:晒|曬|晒佢|曬佢)?|'+erase+'(?:晒|曬)?'+all+'|我(?:唔想要|唔要|唔使要)'+all+'|(?:乜|咩)都唔要|(?:唔要|刪|清|取消)(?:晒|曬)(?:佢)?|一筆勾銷)');
const standalone=/(?:另外|另加|另叫|單叫|單點|獨立|額外|分開|多一杯|再加|加多|extra|separate|another)/i;
const menu=id=>K.menu.find(m=>m.id===id);
function control(text){
 const s=K.language.clean(text);
 if(/^(?:唔好|唔使|唔洗|不要|別|毋須|不必|唔係|不是|無需)/.test(s))return oldControl(text);
 for(const [pattern,isRestart] of [[restart,true],[clear,false]]){
  const m=pattern.exec(s);if(!m)continue;
  const tail=s.slice(m[0].length);
  if(tail&&!/^[\s，,；;。.!！]/.test(tail)&&!(isRestart&&/^(?:跟住|然後|再要|再叫|要|叫|點|早餐|早晨|A餐|B餐|C餐|D餐|E餐|F餐|[A-Fa-f]餐)/.test(tail)))continue;
  const rest=tail.replace(/^[\s，,；;。.!！]+/,'').replace(/^(?:跟住|然後|再要|再叫|要|叫|點)\s*/,'');
  return{intent:'clear',restart:isRestart||!!rest,remainder:rest};
 }
 return oldControl(text);
}
K.language.control=control;
function drinkBeforeCombo(text,plan){
 if(!plan.ops?.some(o=>o.type==='add'&&menu(o.item?.id)?.combo))return null;
 const t=K.tc(text),hits=K.findItems(t);
 const firstCombo=hits.find(h=>menu(h.id)?.combo);
 if(!firstCombo)return null;
 const leading=hits.filter(h=>menu(h.id)?.drink&&h.index<firstCombo.index);
 if(!leading.length||standalone.test(t.slice(0,firstCombo.index)))return null;
 // Multiple different drinks for a single set need an explicit choice.
 if(leading.length>1)throw new K.OrderError('needClarification');
 const phrase=t.slice(0,firstCombo.index).replace(/[，,。；;\s]+$/,'');
 const answer=originalAnalyze(phrase,[]);
 if(answer.decision!=='local'||answer.plan.ops?.length!==1||!menu(answer.plan.ops[0].item?.id)?.drink)return null;
 return answer.plan.ops[0].item;
}
function pair(plan,text,cart,selectedUid){
 if(!plan.ops?.some(o=>o.type==='add'&&menu(o.item?.id)?.combo&&o.item.drink==='待選飲品'))return plan;
 const result={...plan,ops:plan.ops.map(o=>({...o,item:o.item&&{...o.item}}))};
 const leading=selectedUid?null:drinkBeforeCombo(text,result);
 const candidates=cart.filter(i=>menu(i.id)?.drink&&i.pendingPair!==false);
 const candidate=selectedUid?candidates.find(i=>i.uid===selectedUid):leading?null:candidates.length===1?candidates[0]:null;
 if(!leading&&!selectedUid&&candidates.length>1)throw new K.OrderError('ambiguousTarget',{plan:result,choices:candidates.map(i=>({index:cart.indexOf(i),uid:i.uid,id:i.id}))});
 if(selectedUid&&!candidate)throw new K.OrderError('missingTarget');
 const drink=leading||candidate;
 if(!drink)return result;
 const op=result.ops.find(o=>o.type==='add'&&menu(o.item?.id)?.combo&&o.item.drink==='待選飲品');
 if(!op)return result;
 const count=Math.min(op.item.qty,drink.qty);
 const base={...op.item,qty:count,drink:drink.drink,drinkStatus:'selected',drinkPrompted:false,
  sugar:drink.sugar,ice:drink.ice,milk:drink.milk,size:drink.size,
  extras:[...new Set([...(op.item.extras||[]),...(drink.extras||[])])]};
 const paired=K.normalize(base);
 const ops=[];
 if(candidate)ops.push({type:'remove',target:{uid:candidate.uid,count}});
 for(const item of result.ops){if(item!==op)ops.push(item);else{ops.push({type:'add',item:paired});if(op.item.qty>count)ops.push({type:'add',item:{...op.item,qty:op.item.qty-count}});}}
 return{...result,ops};
}
function enhance(text,cart,answer){
 if(answer.decision!=='local')return answer;
 try{
  let plan=answer.plan;
  if(plan.intent==='add'){
   if(standalone.test(text))plan={...plan,ops:plan.ops.map(o=>o.type==='add'&&menu(o.item?.id)?.drink?{...o,item:{...o.item,pendingPair:false}}:o)};
   plan=pair(plan,text,cart);
  }
  return{...answer,plan};
 }catch(error){return{decision:'clarify',error};}
}
K.analyzeLocal=(text,cart=[])=>enhance(text,cart,originalAnalyze(text,cart));
K.parseCommand=(text,cart=[])=>{const answer=enhance(text,cart,{decision:'local',plan:originalParse(text,cart)});if(answer.error)throw answer.error;return answer.plan;};
K.pairWithDrink=(plan,cart,uid)=>pair(plan,'',cart,uid);
K.pairMenuItem=(item,cart)=>pair({intent:'add',ops:[{type:'add',item}]},'',cart);
K.orderIntentsVersion=8;
})(globalThis);

/* A listening session is independent of the FIFO which applies its turns.
 * Ending capture never submits an order or drops already accepted turns. */
(function(g){
 'use strict';
 const phrases=[
  '係咁多','就係咁多','咁多先','就咁多','就咁','係咁','得喇','得啦','得嘞',
  '冇喇','冇啦','無喇','無啦','冇嘢喇','冇嘢啦','無嘢喇','無嘢啦','冇其他喇','冇其他啦','無其他喇','無其他啦',
  '冇其他嘢喇','冇其他要加','唔加喇','唔加啦','唔叫喇','唔叫啦','唔使喇','唔使啦','唔使再叫',
  '唔使再聽','唔使聽喇','唔使聽啦','唔使再收音','唔使收音喇','收住先','停住先','停一停','停低先','停啦','停喇',
  '停止收音','停收音','停止錄音','停錄音','停止聆聽','結束聆聽','收音完畢','講完喇','講完啦','講晒喇','講晒啦',
  '講完晒','我講完喇','我講完啦','我講晒喇','我叫完喇','我叫完啦','叫晒喇','叫完喇','叫完啦','點完喇',
  '落住咁多先','落咁多先','叫住咁多先','叫咁多先','食住咁多先','暫時咁多','暫時係咁多','暫時就咁多',
  '暫時唔加','暫時唔叫','暫時唔使','今次係咁多','今次就咁多','今次咁多先','今次叫咁多','今日係咁多',
  '呢張係咁多','張單係咁多','成張單係咁多','到呢度先','到呢度喇','到呢度啦','做到呢度先',
  '唔該晒係咁多','多謝係咁多','ok','okay','ok啦','ok喇','okay啦','okay喇',
  "that's all",'that is all',"that's it",'that is it','all done',"i'm done",'i am done','done ordering','finished ordering',
  'no more','nothing else','no more thanks',"that's all thanks","that's it thanks",'stop listening','stop recording',
  'end recording','end listening','finish listening','finish recording','enough for now',"that's enough",'all for now','done','finished','stop','over',
  '就這樣','就這些','就這麼多','沒有了','沒有其他了','不用了','不用再聽','先點這些','先要這些','點完了','說完了','結束錄音','結束收音','可以了','好的',
 ];
 const normalize=value=>(g.Kam?.tc(String(value??''))||String(value??'')).normalize('NFKC').replace(/[’‘]/g,"'").toLowerCase().trim();
 const trim=value=>value.replace(/^[\s，,。.!！?？；;、：:～~]+|[\s，,。.!！?？；;、：:～~]+$/g,'');
 const closings=[...new Set(phrases.map(value=>trim(normalize(value))))].sort((a,b)=>b.length-a.length);
 const commands=/^(?:唔該|幫我|我想|我要|麻煩|另外|再)?\s*(?:改|轉|換|加|要|叫|刪|取消|唔要|跟|照|再|一|兩|三|四|五|六|七|八|九|十|\d)/;
 function split(value){
  const text=trim(normalize(value));
  if(/^(?:唔好|咪|不要|別|don't|do not)\s*(?:再)?(?:停|結束|stop|end)/i.test(text)||/^(?:繼續聽|繼續收音|繼續錄音|未講完|仲未講完|keep listening|continue listening)$/.test(text))return {text:'',closing:false,keepListening:true};
  for(const phrase of closings){
   if(text===phrase)return {text:'',closing:true,phrase};
   if(!text.endsWith(phrase))continue;
   const before=text.slice(0,-phrase.length),boundary=/[\s，,。.!！?？；;、：:]$/.test(before),prefix=trim(before);
   if(!prefix)continue;
   if(/^[a-z]/.test(phrase)&&/[a-z0-9_]$/i.test(before))continue;
   // A short word inside a dish or a negated request is never an exit.
   if(!boundary&&!commands.test(prefix)&&!g.Kam?.findItems?.(prefix).length)continue;
   if(/(?:唔好|咪|不要|don't|do not)\s*$/.test(prefix))continue;
   if(/^(?:(?:暫時)?唔(?:加|叫|使)(?:喇|啦)?|唔使再叫|不用了)$/.test(phrase))return {text:'',closing:true,phrase,clarify:true};
   return {text:prefix,closing:true,phrase};
  }
  return {text:String(value??'').trim(),closing:false};
 }
 class Session{
  constructor({consume,enqueue=()=>{},discard=()=>{},stop=()=>{},change=()=>{},error=()=>{},log=()=>{},now=()=>performance.now(),setTimer=setTimeout,clearTimer=clearTimeout,idleMs=7000,maxQueue=100}={}){
   Object.assign(this,{consume,onEnqueue:enqueue,onDiscard:discard,onStop:stop,onChange:change,onError:error,log,now,setTimer,clearTimer,idleMs,maxQueue});
   this.active=false;this.processing=false;this.queue=[];this.serial=0;this.sequence=0;this.timer=null;this.readyAt=null;this.lastActivity=null;this.speaking=false;this.waiters=[];
  }
  get pending(){return this.queue.length;}
  status(){return {active:this.active,processing:this.processing,pending:this.pending,sessionId:this.id,sequence:this.sequence,lastActivity:this.lastActivity,speaking:this.speaking};}
  changed(){this.onChange(this.status());}
  start(options={}){
   if(this.active||this.processing||this.pending)return false;
   this.active=true;this.id=options.id||'hands-free-'+(++this.serial);this.options=options;this.sequence=0;this.readyAt=null;this.lastActivity=null;this.speaking=false;
   this.log('started',this.status());this.changed();return true;
  }
  ready(){if(!this.active||this.readyAt!==null)return;this.readyAt=this.now();this.activity('ready');}
  activity(kind='speech'){
   if(!this.active)return;
   if(kind==='speech-start')this.speaking=true;if(kind==='speech-end')this.speaking=false;
   this.lastActivity=this.now();if(this.timer!==null)this.clearTimer(this.timer);this.timer=null;if(this.speaking){this.changed();return;}
   const id=this.id;
   this.timer=this.setTimer(()=>{this.timer=null;if(!this.active||this.id!==id||this.speaking)return;const remaining=this.idleMs-(this.now()-this.lastActivity);if(remaining>0){this.timer=this.setTimer(()=>this.checkIdle(id),remaining);return;}this.stop('silence');},this.idleMs);
   this.changed();
  }
  checkIdle(id){if(!this.active||this.id!==id||this.speaking)return;const remaining=this.idleMs-(this.now()-this.lastActivity);if(remaining>0)this.timer=this.setTimer(()=>this.checkIdle(id),remaining);else this.stop('silence');}
  feed(result,metadata={}){
   if(!this.active)return {accepted:false,reason:'inactive'};
   const original=typeof result==='string'?{text:result}:result||{},text=String(original.text||'').trim();
   if(text)this.activity('transcript');
   const parsed=text?split(text):{text:'',closing:false};
   if(parsed.closing&&!parsed.text){this.stop('closing',parsed.phrase);if(parsed.clarify){this.log('closing-ambiguous',{sessionId:this.id,text});this.onError(Object.assign(Error('voiceClosingAmbiguous'),{code:'voiceClosingAmbiguous'}));}return {accepted:false,closing:true};}
   if(parsed.keepListening){this.log('keep-listening',{sessionId:this.id,text});return {accepted:false,keepListening:true};}
   if(!parsed.text&&!original.blob){if(parsed.closing)this.stop('closing',parsed.phrase);return {accepted:false,closing:parsed.closing};}
   if(this.pending>=this.maxQueue){this.log('queue-full',{sessionId:this.id,text});this.stop('queue-full');this.onError(Object.assign(Error('voiceQueueFull'),{code:'voiceQueueFull'}));return {accepted:false,reason:'queue-full'};}
   const turn={...metadata,id:this.id+'-turn-'+(++this.sequence),sessionId:this.id,sequence:this.sequence,receivedAt:this.now(),result:{...original,text:parsed.text,alternatives:(original.alternatives||[]).map(value=>split(value).text).filter(Boolean)}};
   this.onEnqueue(turn);this.queue.push(turn);this.log('queued',{id:turn.id,sessionId:this.id,sequence:turn.sequence,text:turn.result.text,pending:this.pending});
   this.changed();this.drain();if(parsed.closing)this.stop('closing',parsed.phrase);
   return {accepted:true,closing:parsed.closing,id:turn.id};
  }
  async drain(){
   if(this.processing)return;this.processing=true;this.changed();
   try{
    while(this.queue.length){const turn=this.queue.shift();this.changed();
     try{this.log('processing',{id:turn.id,sessionId:turn.sessionId});await this.consume(turn);this.log('processed',{id:turn.id,sessionId:turn.sessionId});}
     catch(error){this.log('turn-failed',{id:turn.id,error:{code:error?.code,message:error?.message}});this.onError(error,turn);}
    }
   }finally{this.processing=false;this.changed();for(const resolve of this.waiters.splice(0))resolve();}
  }
  settled(){return !this.processing&&!this.pending?Promise.resolve():new Promise(resolve=>this.waiters.push(resolve));}
  stop(reason='manual',phrase='',{discard=false,discardAfter}={}){
   const wasActive=this.active;this.active=false;this.speaking=false;if(this.timer!==null)this.clearTimer(this.timer);this.timer=null;
   const removed=discard?this.queue.splice(0):Number.isInteger(discardAfter)?this.queue.filter(turn=>turn.sessionId===this.id&&turn.sequence>discardAfter):[];
   if(Number.isInteger(discardAfter))this.queue=this.queue.filter(turn=>!removed.includes(turn));
   for(const turn of removed){this.onDiscard(turn,reason);this.log('discarded',{id:turn.id,reason});}
   if(wasActive){this.log('stopped',{...this.status(),reason,phrase});this.onStop(reason,phrase);}
   this.changed();
  }
 }
 g.KamHandsFree={Session,split,closings,normalize,idleMs:7000};
})(globalThis);

/* Bounded recovery for text returned by the speech recognizer. These are
 * full menu phrases and option values. Never replace individual Han characters. */
(function(g){
 'use strict';
 const K=g.Kam,analyze=K.analyzeLocal,parse=K.parseCommand;
 // Keep whole-command substitutions at the end of the utterance. The
 // ordinary change grammar still resolves the original selector and scope.
 const temperaturePhrases=[
  ['轉熱飲','專業飲|專業音|轉業飲|轉葉飲|轉熱音|轉熱陰|傳熱音|專熱飲|轉熱任|轉熱隱|傳熱飲|轉返熱嘅|改返熱嘅|換返熱嘅'],
  ['轉凍飲','傳動飲|轉動飲|專凍飲|轉凍音|轉凍陰|轉冬飲|轉凍隱|轉凍任|傳凍飲|轉洞飲|轉返凍嘅|改返凍嘅|換返凍嘅|專冬飲|傳凍音|轉東飲|專凍音'],
 ];
 const phrases=[
  ...temperaturePhrases,
  ['凍奶茶','凍奶查|凍乃茶|凍奶叉|冬奶查|凍奶搽|東奶茶|冬瀨茶|凍瀨茶|凍懶茶'],
  ['熱奶茶','熱乃茶|熱奶查|熱奶搽|熱奶叉|熱瀨茶|業奶茶|葉奶茶'],
  ['凍檸茶','凍檸查|凍零查|凍寧茶|凍寧查|凍檸叉|東檸茶|凍凝茶|東寧茶'],
  ['熱檸茶','熱檸查|熱零查|熱寧茶|熱檸叉|業檸茶|熱凝茶'],
  ['凍咖啡','凍加啡|凍家啡|凍咖飛|凍加菲|凍咖斐|東啡|凍加飛'],
  ['熱咖啡','熱加啡|熱家啡|熱咖飛|熱加菲|熱咖斐|熱加飛|業咖啡'],
  ['凍鴛鴦','凍冤央|凍鴛央|凍淵鴦|凍冤殃|凍冤養|東冤央|凍冤鴦'],
  ['熱鴛鴦','熱冤央|熱鴛央|熱淵鴦|熱冤養|業鴛鴦'],
  ['熱菜蜜','熱賽蜜|熱菜物|熱菜勿|熱菜麥'],
  ['凍菜蜜','凍賽蜜|凍菜物|凍菜勿|凍菜麥'],
  ['阿華田','阿樺田|阿華填|阿華恬|阿話田'],
  ['好立克','好立黑|好立刻|好粒克|好立客'],
  ['美祿','美錄|美六|美碌|米祿'],
  ['朱古力','珠古力|豬古歷|朱估力|朱古嚦'],
  ['凍檸蜜','凍寧蜜|凍檸密|凍檸物|凍寧密'],
  ['熱檸水','熱寧水|熱檸髓|熱零水|熱檸歲|熱零歲|業檸水'],
  ['凍檸水','凍凝水|東檸水'],
  ['菠蘿油','波羅遊|菠蘿由|波蘿游|波羅柚|波蘿友|菠蘿佑'],
  ['西多士','西多示|西多事|西多史|西多師|西多絲|西多仕'],
  ['腿蛋治','腿蛋字|腿旦字|腿蛋寺|腿蛋誌|腿旦寺'],
  ['蛋治','蛋字|旦字|蛋寺|蛋誌|蛋池'],
  ['奶醬多士','瀨醬多士'],
  ['牛油多士','牛油多仕'],
  ['奶油多士','乃油多士|奶油多示|乃油多事|奶油多史'],
  ['酥皮蛋撻','蘇皮蛋撻|酥皮旦撻|蘇皮旦撻|酥皮蛋塔'],
  ['炸雞翼','炸雞易|炸雞液|炸雞役|乍雞翼|炸雞奕|炸雞逆|炸雞疫'],
  ['瑞士汁雞翼','睡士汁雞翼|瑞士執雞翼|瑞士汁雞易|瑞事汁雞翼'],
  ['炸薯條','乍薯條|炸薯調|炸薯迢|炸殊條|炸薯跳'],
  ['咖喱魚蛋','加喱魚蛋|咖喱魚旦|咖喱如蛋|咖喱魚但|咖喱愚蛋'],
  ['乾炒牛河','干炒牛何|乾炒牛荷|乾抄牛河|乾炒牛賀|乾抄牛荷'],
  ['揚州炒飯','楊洲炒飯|陽州炒飯|揚州炒繁|揚州抄飯|揚州抄繁'],
  ['焗豬扒飯','焗朱扒飯|焗豬爬飯|局朱扒飯|焗豬拍飯'],
  ['鮮蝦雲吞麵','鮮哈雲吞麵|鮮蝦魂吞麵|鮮蝦雲吞綿|鮮蝦雲吞面'],
  ['清湯牛腩麵','清湯牛喃麵|清湯牛纜麵|清湯牛腩綿|清湯牛楠麵'],
  ['少甜','少填|少恬|小田|少田|少舔|少廷'],
  ['走甜','走填|走田|走恬|走舔|走廷'],
  ['半糖','半唐|半塘|判糖|半燙|半堂'],
  ['少冰','少兵|小兵|少丙|少賓|小賓'],
  ['走冰','走兵|走丙|走賓'],
  ['少奶','少乃|小乃|少哪|少瀨'],
  ['走奶','走乃|走哪|走瀨'],
  ['大杯','大盃|大碑|大悲|大背|大卑'],
  ['湯另上','湯令上|湯零上|湯另尚|湯令尚'],
  ['少湯','少堂|少棠|少燙|少塘'],
  ['烘底','空底|烘抵|烘弟'],
  ['飛邊','飛鞭|飛編|飛變'],
  ['方包','方飽|芳包|荒包|方炮'],
  ['反蛋','反但|返旦|返蛋|返但'],
  ['熟蛋','淑蛋|熟但|贖蛋|淑旦'],
  ['煎蛋','煎但'],
  ['熱奶茶','熱懶茶'],['熱檸茶','業凝茶'],['熱咖啡','業加啡'],['熱鴛鴦','熱冤陽'],
  ['熱檸水','熱凝水'],['熱檸蜜','熱凝密'],['熱阿華田','熱阿樺填'],['熱好立克','熱好粒刻'],
  ['熱杏仁霜','熱杏仁箱'],['熱鮮奶','熱鮮瀨'],
  ['凍奶茶','東乃茶'],['凍檸茶','冬寧茶'],['凍咖啡','東咖飛'],['凍鴛鴦','東鴛央'],
  ['凍檸水','冬零水'],['凍檸蜜','東檸密'],['凍檸樂','寧落'],['凍檸七','寧柒'],['凍檸賓','東寧賓'],
  ['餐肉蛋三文治','餐育蛋三文治'],['鹹牛肉蛋治','咸牛育蛋治'],['吞拿魚三文治','吞拿魚三文至'],
  ['芝士三文治','芝士三文智'],['火腿三文治','火腿三文至'],['公司三文治','公司三文智'],
  ['豬扒包','豬拍包'],['雞扒包','雞拍包'],['魚柳包','魚柳飽'],['薯餅','薯併'],
  ['星洲炒米','星洲抄米'],['揚州炒飯','楊洲抄飯'],['焗豬扒飯','焗豬拍繁'],['咖喱牛腩飯','咖喱牛林飯'],
  ['咖喱雞飯','咖喱雞繁'],['叉燒飯','差燒飯'],['番茄炒蛋飯','番茄抄旦飯'],
  ['雲吞麵','雲吞綿'],['餐肉蛋公仔麵','餐肉旦公仔麵'],
  ['少甜','少亭'],['走甜','走亭'],['半糖','半棠'],['少冰','少浜'],['走冰','走浜'],
  ['少奶','少懶'],['走奶','走懶'],['湯另上','湯寧上'],['方包','方胞'],
 ];
 const known=new Set(K.lexicon.entries.map(row=>row.term));
 const variants=new Map();
 for(const [to,forms] of phrases)for(const form of forms.split('|')){
  const from=K.tc(form);
  if(from===to||known.has(from))continue;
  if(variants.has(from)&&variants.get(from)!==to)throw Error('Conflicting speech variant '+from);
  variants.set(from,to);
 }
 const matcher=new RegExp([...variants.keys()].sort((a,b)=>b.length-a.length).join('|'),'g');
 const temperature=new Set(temperaturePhrases.map(([value])=>value));
 const legacyTemperature=new Set(['傳動飲','轉動飲','傳熱飲','轉熱隱']);
 const measure={分:'份',糞:'份',芬:'份',吩:'份',背:'杯',悲:'杯',碑:'杯',卑:'杯'};
 const measureSounds='['+Object.keys(measure).join('')+']',hasMeasure=new RegExp(measureSounds);
 const quantity='('+K.quantity.numPattern+')\\s*('+measureSounds+')';
 const beforeItem=new RegExp(quantity+'\\s*$','i'),afterItem=new RegExp('^\\s*'+quantity+'$','i');
 const spokenScope=new RegExp('^(第|弟|地|其中|其鐘|期中)\\s*('+K.quantity.numPattern+')\\s*[杯碑卑背悲]');
 const menu=new Map(K.menu.map(item=>[item.id,item]));
 function apply(text,patches){
  let result='',offset=0;
  for(const {start,end,to} of patches){
   result+=text.slice(offset,start)+to;offset=end;
  }
  return result+text.slice(offset);
 }
 function quantityPatches(prepared){
  const {original,hits}=prepared,patches=[];
  const items=hits.filter(hit=>hit.row.id&&['item','phonetic'].includes(hit.row.kind));
  const add=(match,offset,item)=>{
   if(!match)return;
   const from=match[2],to=measure[from];
   if((to==='杯')!==!!item.drink)return;
   const start=offset+match.index+match[0].lastIndexOf(from);
   patches.push({start,end:start+from.length,to,from});
  };
  for(const hit of items)add(beforeItem.exec(original.slice(0,hit.start)),0,menu.get(hit.row.id));
  for(const clause of original.matchAll(/[^，,；;。]+/g)){
   const end=clause.index+clause[0].length;
   const within=items.filter(hit=>hit.start>=clause.index&&hit.end<=end);
   if(within.length===1){
    const [hit]=within;
    add(afterItem.exec(original.slice(hit.end,end)),hit.end,menu.get(hit.row.id));
   }
  }
  return patches;
 }
 function recover(text,cart,context,initial){
  const code=initial.error?.code;
  if(!['unrecognizedTokens','notUnderstood','ambiguousTerm','unavailable','needClarification'].includes(code))return initial;
  if(/整單備註|訂單備註|備註|記低|寫低/.test(text))return initial;
  let prepared;
  try{prepared=K.inspectLocal(text);}catch{return initial;}
  const patches=[];let temperatureEdit=false,temperatureAtEnd=false,scopeRepaired=false;
  for(const match of prepared.original.matchAll(matcher)){
   const from=match[0],to=variants.get(from),start=match.index,end=start+from.length;
   const strictTemperature=temperature.has(to)&&!legacyTemperature.has(from);
   if(strictTemperature&&end!==prepared.original.length)continue;
   if(prepared.hits.some(hit=>hit.start<=start&&hit.end>=end))continue;
   temperatureAtEnd||=temperature.has(to)&&end===prepared.original.length;
   temperatureEdit||=strictTemperature;
   patches.push({start,end,to,from});
  }
  if(temperatureAtEnd||[...temperature].some(value=>prepared.original.endsWith(value))){
   const scope=prepared.original.match(spokenScope);
   if(scope){
    const [from,marker,count]=scope,to=(marker.length===1?'第':'其中')+count+'杯';
    if(from!==to){
     patches.unshift({start:0,end:from.length,to,from});
     temperatureEdit=true;
     scopeRepaired=true;
    }
   }
  }
  if(code==='needClarification'&&!scopeRepaired)return initial;
  const covered=hit=>patches.some(patch=>patch.start<=hit.start&&patch.end>=hit.end);
  if(code==='ambiguousTerm'&&!prepared.hits.some(hit=>hit.row.kind==='ambiguous'&&covered(hit)))return initial;
  if(code==='unavailable'){
   const unavailable=prepared.hits.filter(hit=>hit.row.kind==='unavailable');
   if(!unavailable.length||!unavailable.every(covered))return initial;
  }
  let corrected=apply(prepared.original,patches);
  if(hasMeasure.test(corrected)){
   try{
    const parsed=K.inspectLocal(corrected);
    const counts=quantityPatches(parsed);
    if(counts.length){corrected=apply(parsed.original,counts);patches.push(...counts);}
   }catch{/* An exact unavailable or ambiguous phrase retains its original decision. */}
  }
  if(!patches.length)return initial;
  const result=analyze(corrected,cart,context);
  if(result.decision==='fallback'){
   if(temperatureEdit&&temperature.has(corrected))return {...result,decision:'clarify',error:new K.OrderError('missingTarget')};
   return initial;
  }
  if(result.decision==='clarify')return result;
  if(!['add','edit'].includes(result.plan.intent)||result.plan.ops?.some(op=>op.type==='clear'))return initial;
  if(temperatureEdit&&(result.plan.intent!=='edit'||!result.plan.ops.every(op=>op.type==='update'&&op.patch.temperature)))return initial;
  return {...result,phoneticRecovery:true,correctedText:corrected,
   corrections:[...(result.corrections||[]),...patches.map(({from,to})=>({from,to}))]};
 }
 K.analyzeLocal=(text,cart=[],context={})=>recover(text,cart,context,analyze(text,cart,context));
 K.parseCommand=(text,cart=[],context={})=>{
  try{return parse(text,cart,context);}catch(error){
   const result=recover(text,cart,context,{decision:'fallback',error});
   if(result.plan)return result.plan;
   throw result.error;
  }
 };
 K.speechVariants={count:variants.size};
})(globalThis);

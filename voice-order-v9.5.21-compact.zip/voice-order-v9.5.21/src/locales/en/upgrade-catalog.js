/* v9: a main is à la carte until the customer explicitly asks for a set. */
(function (g) {
  'use strict';
  const rows = [
    ['Q1','A','沙嗲牛肉麵','Satay beef noodles',32,'公仔麵',0,'沙爹牛肉麵|沙嗲牛肉湯麵|沙爹牛肉湯麵|沙嗲牛肉|沙爹牛肉|沙嗲牛|沙爹牛|satay beef noodles|satay beef noodle soup|satay beef|satay noodles'],
    ['Q2','B','火腿通粉','Ham macaroni soup',29,'通粉',1,'火腿通心粉|火腿湯通粉|火腿湯通|火腿通|ham macaroni soup|ham and macaroni soup|ham macaroni|ham pasta'],
    ['Q3','C','餐肉雙蛋','Luncheon meat and eggs',30,'',2,'午餐肉雙蛋|餐肉煎雙蛋|午餐肉煎雙蛋|午餐肉配雙蛋|餐肉蛋|餐蛋|luncheon meat and eggs|spam and eggs|spam with eggs'],
    ['Q4','D','叉燒湯麵','BBQ pork noodle soup',35,'公仔麵',8,'蜜汁叉燒湯麵|蜜汁叉燒麵|叉燒即食麵|叉燒公仔麵|叉燒麵|叉燒丁|bbq pork noodles|barbecue pork noodles|barbecued pork noodles|bbq pork noodle soup|char siu noodles|char siu'],
    ['Q5','E','腸仔煎蛋','Sausage and eggs',31,'',9,'腸仔雙蛋|香腸雙蛋|香腸煎蛋|香腸配雞蛋|腸仔煎雙蛋|腸蛋|sausage and eggs|sausages and eggs|sausage with eggs'],
    ['Q6','F','生滾瘦肉粥','Pork congee',28,'',10,'瘦肉粥|生滾靚粥|靚粥|pork congee|pork rice porridge']
  ];
  const L = g.CafeLexicon;
  for (const [id,upgradeTo,name,en,price,noodle,photo,terms] of rows) {
    const aliases = [...new Set([name,en,...terms.split('|')])];
    g.CafeExpansion.foods.push({id,upgradeTo,name,en,price,noodle,photo,aliases,
      cat:'飯麵主食',desc:'單點主食 · 不跟飲品或多士',descEN:'À la carte · No drink or toast',
      hasEgg:['Q3','Q5'].includes(id),base:true,bread:false,allergens:['麩質','大豆',...(['Q3','Q5'].includes(id)?['蛋']:[])]});
    const explicitSet = term => /早餐|早晨|套餐|餐$|breakfast|\bset\b|\bcombo\b|^[a-f]餐$/i.test(term);
    // Rewrite the existing spoken aliases before either matcher is constructed.
    for (const row of L.entries) if (row.id===upgradeTo && !explicitSet(row.term)) {
      row.id=id; row.target=name;
    }
    for (const term of aliases) L.entries.push({kind:'item',id,target:name,term});
    for (const term of aliases.filter(t=>!/[a-z]/i.test(t))) {
      L.entries.push({kind:'item',id,target:name,term:'單點'+term});
      for (const suffix of ['套餐','餐']) L.entries.push({kind:'item',id:upgradeTo,target:'早餐'+upgradeTo,term:term+suffix});
    }
  }
  g.CafeStandaloneRows=rows;
})(globalThis);

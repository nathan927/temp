/* Versioned, data-only extensions to the local ordering grammar. Shared with Node. */
(function (g) {
 'use strict';
 const K=g.Kam, base=K.analyzeLocal, parse=K.parseCommand;
 const schema=1, maxRules=20000, intents=new Set(['add','edit','customize','navigate','service','preview']);
 const categories=['全部','早餐套餐','包點多士','單點小食','飯麵主食','港式飲品'];
 const defaults=Object.freeze({enabled:true,interval:60,batch:16,model:'mimo-v2.6-pro',endpoint:'https://api.xiaomimimo.com/v1/chat/completions',auth:'api-key',backend:''});
 const clean=text=>K.tc(String(text??'').normalize('NFKC')).trim().toLowerCase().replace(/[\s，。！？、；,.!?;]+$/gu,'').replace(/\s+/g,' ');
 const safeText=text=>typeof text==='string'&&text.length<=2000&&!!clean(text)&&!/[\u0000-\u001f<>]|\[redacted\]|data:audio|https?:\/\//i.test(text);
 const gap=result=>!!result.plan?.partialUnresolved?.length||['fallback','clarify'].includes(result.decision)&&['unrecognizedTokens','notUnderstood','needChange'].includes(result.error?.code);
 const withoutUid=({uid,...item})=>item;
 const snapshot=(state={})=>{const cart=(state.cart||[]).slice(0,50).map(i=>K.normalize(i));return {lang:g.KamLocale.id,cart,portionOrder:K.normalizePortionOrder(cart,state.portionOrder),mode:state.mode||'dinein',orderNotes:K.normalizeOrderNotes(state.orderNotes||[])};};
 const signature=state=>JSON.stringify([state.mode,state.cart.map(withoutUid),state.orderNotes,K.normalizePortionOrder(state.cart,state.portionOrder).map(id=>state.cart.findIndex(item=>item.uid===id))]);
 const key=rule=>JSON.stringify([rule.phrase,rule.guard]);
 const empty=()=>({language:g.KamLocale.id,schema,version:'base',parent:null,at:null,rules:[]});
 const pack=(parent,rules,origin)=>({language:g.KamLocale.id,schema,version:K.uid(),parent:parent.version,at:new Date().toISOString(),origin,rules});
 function effect(plan,state){
  if(!intents.has(plan?.intent)||!Array.isArray(plan.ops)||plan.ops.some(o=>o.type==='clear')||plan.orderNotesClear||plan.declineUpgrade)throw Error('unsupported-action');
  if(plan.intent==='navigate'){
   if(plan.ops.length||!plan.categories?.length||plan.categories.some(c=>!categories.includes(c))||plan.focusItem&&!K.menu.some(m=>m.id===plan.focusItem))throw Error('invalid-navigation');
   return JSON.stringify(['navigate',plan.categories,plan.focusItem||null]);
  }
  if(plan.intent==='preview'){
   if(plan.ops.length||!state.cart.length)throw Error('invalid-preview');
   return 'preview';
  }
  if(plan.intent==='service'&&plan.ops.length)throw Error('invalid-service');
  const result=K.transitionDraft(state,plan);
  return JSON.stringify([plan.intent,!!plan.previewAfter,signature(result)]);
 }
 function generic(plan){
  return plan.intent==='navigate'||plan.intent==='service'||plan.intent==='add'&&!plan.mode&&!plan.orderNotesAdd?.length&&!plan.orderNotesRemove?.length&&plan.ops.every(o=>o.type==='add'&&!K.menu.find(m=>m.id===o.item.id)?.drink);
 }
 const shape=state=>JSON.stringify([state.mode,state.cart.map(({id,qty})=>[id,qty]),K.normalizePortionOrder(state.cart,state.portionOrder).map(id=>state.cart.findIndex(item=>item.uid===id))]);
 function ruleGuard(plan,state,rewrite){
  if(generic(plan))return null;
  if(plan.intent==='customize')return 'shape:'+shape(state);
  if(rewrite&&/^(?:跟多|再嚟|照頭先|最後|頭先|上一)/.test(K.language.clean(rewrite)))return null;
  if(plan.intent==='add'&&plan.ops.length&&plan.ops.every(op=>op.type==='add'&&K.menu.find(m=>m.id===op.item.id)?.drink)&&!K.pendingDrinks(state.cart).length)return 'no-pending-drink';
  return rewrite?'shape:'+shape(state):signature(state);
 }
 function guardMatches(rule,state){return rule.guard===null||rule.guard===signature(state)||rule.guard==='shape:'+shape(state)||rule.guard==='no-pending-drink'&&!K.pendingDrinks(state.cart).length;}
 function canonical(plan){
  if(plan.intent==='add'&&plan.ops.length>1&&plan.ops.every(o=>o.type==='add')){const parts=plan.ops.map(op=>canonical({intent:'add',ops:[op]}).at(-1));return parts.every(Boolean)?[parts.join('，')]:[];}
  if(plan.localRewrite)return [plan.localRewrite,...canonical({...plan,localRewrite:null})];
  if(plan.intent==='service')return [plan.mode==='takeaway'?'轉外賣':'轉堂食'];
  if(plan.intent==='preview')return ['睇餐單','睇吓餐單','核對餐單'];
  if(plan.intent==='navigate'&&!plan.focusItem)return ['有咩'+plan.categories.map(c=>({'全部':'餐牌','早餐套餐':'早餐套餐','包點多士':'多士','單點小食':'小食','飯麵主食':'飯麵','港式飲品':'飲品'})[c]).join('同')+'揀'];
  if(plan.intent==='customize'&&plan.orderNotesAdd?.length===1)return plan.orderNotesAdd;
  if(plan.intent==='add'&&plan.ops.length===1){
   const item=plan.ops[0].item,m=K.menu.find(m=>m.id===item?.id);
   if(!m)return [];
   const name=m.combo?'早餐 '+m.id:m.name, qty=item.qty+'份';
   const options=K.details(item).filter(value=>value!=='待選飲品'&&(!m.drink||value!==item.drink)).join(' ');
   const dish=m.drink?item.drink:name;
   const withOptions=[plan.previewAfter?'有冇':'',qty,dish,options].filter(Boolean).join(' ');
   return plan.previewAfter?['有冇'+dish+(item.qty===1?'':qty),withOptions]:[qty+dish,dish,withOptions];
  }
  return [];
 }
 function verify(phrase,rewrite,state,{expected,teacherOnly=false}={}){
  if(!safeText(phrase)||!safeText(rewrite))throw Error('invalid-text');
  phrase=clean(phrase);
  if(!gap(base(phrase,state.cart,state)))throw Error('already-local-or-ambiguous');
  const result=base(rewrite,state.cart,state);
  if(result.decision!=='local')throw Error('rewrite-not-local');
  const plan=result.plan, actual=effect(plan,state);
  if(expected&&actual!==expected)throw Error('effect-mismatch');
  if(!expected&&!teacherOnly)throw Error('missing-expected-effect');
  // With no resolved plan as evidence, require a menu anchor and a non-destructive action.
  if(!expected&&plan.intent==='add'){
   const prepared=K.prepareLocal(phrase,state.cart);
   const ids=new Set(K.findItems(prepared.normalized).map(hit=>hit.id));
   if(/唔(?!該)|不要|不想|不需|無需|取消|除咗|instead|without|\b(?:no|not|never)\b/i.test(phrase)||plan.ops.length!==1||ids.size!==1||plan.ops[0].type!=='add'||!ids.has(plan.ops[0].item.id))throw Error('unverified-food-or-negation');
   const modifiers=prepared.hits.filter(h=>h.row.kind==='option'||h.row.kind==='extra');
   // Existing lexical evidence must survive the rewrite, even when the rest of the sentence is novel.
   for(const hit of modifiers){
    const term=hit.row.target||prepared.original.slice(hit.start,hit.end);
    if(!K.prepareLocal(rewrite,state.cart).normalized.includes(term))throw Error('unverified-option');
   }
   const quantities=K.quantity.classified(prepared.normalized);
   const item=plan.ops[0].item,menuItem=K.menu.find(m=>m.id===item.id);
   if(quantities.length>1||item.qty!==K.quantity.portions(menuItem,quantities[0]))throw Error('unverified-quantity');
  }else if(!expected){
   const anchors={'早餐套餐':/早餐|早晨|套餐|breakfast/i,'包點多士':/麵包|多士|三文治|包點|toast|sandwich/i,'單點小食':/小食|零食|snack/i,'飯麵主食':/飯|麵|主食|rice|noodle/i,'港式飲品':/飲|茶|咖啡|drink/i};
   if(plan.intent!=='navigate'||plan.focusItem||!plan.categories.every(c=>anchors[c]?.test(phrase))||/唔好|唔想|不要|不想|取消|\b(?:not|never)\b/i.test(phrase))throw Error('unverified-action');
  }
  return {phrase,rewrite,guard:ruleGuard(plan,state,rewrite),intent:plan.intent};
 }
 // Successful fallbacks can also yield a portable, typed action when the
 // built-in grammar cannot express the entire result as one utterance.
 function action(plan){
  if(!plan||!intents.has(plan.intent)||plan.declineUpgrade||plan.orderNotesClear||!Array.isArray(plan.ops)||plan.ops.length>50||plan.ops.some(o=>o.type!=='add'))throw Error('nonportable-action');
  if(['navigate','service','preview','customize'].includes(plan.intent)&&plan.ops.length)throw Error('nonportable-action');
  const {intent,mode,previewAfter,categories,focusItem,orderNotesAdd,orderNotesRemove}=plan;
  if(previewAfter!==undefined&&typeof previewAfter!=='boolean')throw Error('invalid-preview');
  const checked=K.readAI('parse',{output_text:JSON.stringify({intent,mode,previewAfter,categories,focusItem,orderNotesAdd,orderNotesRemove,ops:plan.ops.map(o=>({type:'add',item:o.item}))})});
  checked.ops=checked.ops.map(o=>({type:'add',item:withoutUid(o.item)}));
  const encoded=JSON.stringify(checked);
  if(encoded.length>16000||g.KamDebug.sanitizeForResearch(encoded,16000)!==encoded)throw Error('invalid-action-data');
  return checked;
 }
 function verifyAction(phrase,plan,state,expected){
  if(!safeText(phrase)||!gap(base(clean(phrase),state.cart,state)))throw Error('invalid-evidence');
  const program=action(plan);
  if(effect(program,state)!==expected)throw Error('effect-mismatch');
  return {phrase:clean(phrase),program,guard:ruleGuard(program,state),intent:program.intent};
 }
 const meaning=rule=>rule.rewrite??JSON.stringify(rule.program);
 function validRule(rule){
  if(!rule||!safeText(rule.phrase)||rule.phrase!==clean(rule.phrase)||!intents.has(rule.intent)||!(rule.guard===null||typeof rule.guard==='string'&&rule.guard.length<=24000))return false;
  if(rule.rewrite!==undefined)return !rule.program&&safeText(rule.rewrite);
  try{return rule.intent===rule.program?.intent&&JSON.stringify(action(rule.program))===JSON.stringify(rule.program);}catch{return false;}
 }
 function validatePack(value){
  if(value?.language!==g.KamLocale.id)throw Error('rule-language-mismatch');
  if(value?.schema!==schema||typeof value.version!=='string'||!Array.isArray(value.rules)||value.rules.length>maxRules||!value.rules.every(validRule)||new Set(value.rules.map(key)).size!==value.rules.length)throw Error('invalid-rule-pack');
  return value;
 }
 function append(parent,additions,origin){
  const rules=new Map(parent.rules.map(rule=>[key(rule),rule]));
  for(const rule of additions){
   if(!validRule(rule))throw Error('invalid-rule');
   const previous=rules.get(key(rule));
   if(previous&&meaning(previous)!==meaning(rule))throw Error('conflicting-rule');
   if(!previous){
    const overlap=[...rules.values()].find(r=>r.phrase===rule.phrase&&(r.guard===null||rule.guard===null)&&meaning(r)!==meaning(rule));
    if(overlap)throw Error('overlapping-rule');
    rules.set(key(rule),rule);
   }
  }
  if(rules.size>maxRules)throw Error('rule-capacity');
  return rules.size===parent.rules.length?parent:pack(parent,[...rules.values()],origin);
 }
 let packs=[],index=new Map();
 function install(...values){
  const next=new Map();
  for(const value of values.filter(Boolean))for(const rule of validatePack(value).rules){
   const list=next.get(rule.phrase)||[];
   list.push({...rule,version:value.version});next.set(rule.phrase,list);
  }
  packs=values;index=next;
 }
 function interpret(text,cart=[],context={}){
  const original=base(text,cart,context);
  if(!gap(original)||!index.size)return original;
  const candidates=index.get(clean(text));
  if(!candidates)return original;
  const state=snapshot({...context,cart}),guard=signature(state);
  let matched;
  for(const rule of candidates){
   if(!guardMatches(rule,state))continue;
   const candidate=rule.program?{decision:'local',plan:structuredClone(rule.program),normalized:rule.phrase,corrections:[]}:base(rule.rewrite,cart,context);
   if(candidate.decision!=='local'||candidate.plan.intent!==rule.intent)continue;
   try{
    const meaning=effect(candidate.plan,state);
    if(matched&&matched.meaning!==meaning)return original;
    matched={candidate,meaning,rule};
   }catch{}
  }
  return matched?{...matched.candidate,learned:{version:matched.rule.version,phrase:matched.rule.phrase,rewrite:matched.rule.rewrite,ruleType:matched.rule.program?'typed-action':'rewrite'}}:original;
 }
 K.analyzeLocal=interpret;
 K.parseCommand=(text,cart=[],context={})=>{const result=interpret(text,cart,context);return result.plan||parse(text,cart,context);};
 function validateRelease(value,cases){
  const previous=packs;
  install(value);
  try{
   const emptyState=snapshot();
   const probes=['有無腿蛋治','有咩飲品揀','轉外賣','轉堂食','全部唔要辣','沙嗲牛肉麵','早餐 A 熱奶茶','有咩小食揀','有咩包點揀','凍檸茶走冰'];
   for(const text of probes){
    const original=base(text,[]);
    const actual=interpret(text,[]);
    if(original.decision!=='local'||actual.decision!=='local'||actual.learned||effect(original.plan,emptyState)!==effect(actual.plan,emptyState))throw Error('regression:'+text);
   }
   for(const sample of cases.flatMap(c=>c.samples)){
    const selected=value.rules.some(r=>r.phrase===clean(sample.text)&&guardMatches(r,sample.state));
    if(!selected)continue;
    const actual=interpret(sample.text,sample.state.cart,sample.state);
    if(!actual.learned||sample.expected&&effect(actual.plan,sample.state)!==sample.expected)throw Error('evidence-regression');
   }
  }finally{install(...previous);}
 }
 const moduleSource=value=>'// Smart Café learned rule pack, schema '+schema+'\nexport default '+JSON.stringify(validatePack(value),null,2)+';\n';
 g.KamEvolution={defaults,base,clean,gap,snapshot,signature,effect,canonical,verify,verifyAction,append,empty,install,validatePack,validateRelease,moduleSource,key,active:()=>packs.map(p=>p?.version)};
})(globalThis);

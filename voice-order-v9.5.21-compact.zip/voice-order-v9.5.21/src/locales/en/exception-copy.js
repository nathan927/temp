/* Varied leads retain the typed, actionable explanation underneath. */
(function(g){
 'use strict';
 const L=g.I18n,base=L.failureLead,counters=new Map();
 const families={apiInvalidKey:'missingKey',apiForbidden:'missingKey',apiQuota:'providerError',apiRateLimit:'providerError',apiUnavailable:'providerError',apiIncomplete:'invalidJSON',unsafeAIAction:'needClarification',staleVoiceOrder:'staleOrder',auditReadFailed:'storage',apiProbeUnexpected:'invalidJSON',apiProbeLearningFailed:'needClarification'};
 const prefixes=[
  ['','哎呀，','Sorry～','唔使急，','等一等，','嗯，','噢，','哎喲，'],
  ['','Sorry, ','One moment. ','Let’s take a moment. ','Just a moment. ','Hang on a moment. ','Okay, ','All right, '],
 ];
 L.exceptionLead=(code,lang='tc')=>{
  if(['micNoMatch','micSilent','micRecognitionTimeout','deviceTranscriptMissing','recordShort','notUnderstood','unrecognizedTokens'].includes(code))return L.voiceFailCopy(lang);
  const key=code+'|'+lang,index=counters.get(key)||0;counters.set(key,(index+1)%128);
  const prefix=prefixes[lang==='en'?1:0][Math.floor(index/16)],lead=base(families[code]||code,lang);
  return (lang==='sc'?L.toSC(prefix):prefix)+lead;
 };
 Object.assign(L.dict,{
  invalidJSON:['後備服務啱啱答得唔完整，呢次未改張單。可以再試，或者拆短少少講吖。','The service reply could not be read safely. Your draft was kept; retry or split the request.'],
  invalidPlan:['後備服務未交到可用嘅改單方案，今次先唔改。你再講清楚餐名同份數吖。','The service did not return a usable order change. Say the item and quantity again.'],
  emptyResponse:['後備服務冇答返落單內容呀。張單幫你留住，再試一次吖。','The service returned no order details. Your draft is kept; please retry.'],
  providerError:['後備服務今次未跟到，張單幫你留好。可以再試，或者喺餐牌揀返。','The fallback service could not finish. Your draft is kept; retry or use the menu.'],
  missingKey:['未有可用嘅後備服務金鑰喎。去設定加返 key 同揀好服務，再試吖。','No fallback API key is configured. Add a key and select the service in Settings.'],
  invalidProvider:['後備服務未揀啱，去設定重新揀返服務，再試一次吖。','Check the fallback service selection in Settings, then retry.'],
  apiIncomplete:['後備服務未答完，今次未改張單。你可以再試，或者拆短少少講。','The service reply was incomplete. Your draft was kept; retry or split the request.'],
 });
})(globalThis);

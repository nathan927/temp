/* Recommendation grammar, explicit filter patches and catalog-based candidates. */
(function(g){
 'use strict';
 const K=g.Kam,parse=K.parseCommand,analyze=K.analyzeLocal;
 // Recipes with unspecified fillings are excluded conservatively from pork-free
 // suggestions. Shop-specific recipes may refine these catalog attributes.
 const beef=new Set(['A','P8','R1','R5','R9','Q1']);
 const pork=new Set(['B','C','D','E','F','P3','P7','P11','P12','P17','P20','P21','R2','R3','R4','R7','R10','R11','R12','Q2','Q3','Q4','Q5','Q6']);
 const local=new Set(['A','B','C','D','E','F','P1','P2','P5','P13','P16','N1','R1','R2','R3','Q1','T1','T2','T4','T14','T15','T16','T17','T23','T24','T25','T28']);
 for(const m of K.menu)m.dietary={beef:beef.has(m.id),pork:pork.has(m.id),bread:!!m.bread,localSpecial:local.has(m.id)};
 const noun='(?:牛肉類|牛肉|牛腩|牛扒|沙嗲牛(?:肉)?|沙爹牛(?:肉)?|牛|豬肉類|豬肉|豬扒|豬排|叉燒|火腿|午餐肉|餐肉|腸仔|香腸|豬|麵包|包點類|包類|包點|三文治|多士|方包|包|beef\\b|pork\\b|bread\\b|buns?\\b|sandwich(?:es)?\\b|toast\\b)';
 const nouns=noun+'(?:(?:同埋|同|及|和|、|\\s+and\\s+)?'+noun+')*';
 const noPrefix='(?:唔好推介|唔好推薦|唔想食|唔好有|唔食|唔要|唔想要|不吃|不要|不含|避開|no\\s+|without\\s+|don.t eat\\s+|do not eat\\s+)';
 const noSuffix='(?:類)?(?:全部|都)?(?:唔食|唔要|不要|不吃|就免(?:喇|啦)?|免喇)';
 const negative=new RegExp(noPrefix+'(?:任何)?('+nouns+')(?:'+noSuffix+')?|('+nouns+')'+noSuffix,'gi');
 const positive=new RegExp('(?:可以食返|可以要返|食返|要返)('+nouns+')|('+nouns+')(?:可以食返|可以要返|冇問題)','gi');
 const request=/(?:有[冇無咩乜](?:好)?介紹|有咩好食|唔知食[乜咩]|食[咩乜]好|推介(?:下|吓)?|推薦(?:一下|下)?|介紹(?:一下)?|換(?:個|一個)組合|下一個組合|有[冇無]第二款|recommend(?:ations?)?|suggest(?:ions?)?|what is popular|popular|best sell(?:er|ing)?|another (?:combo|suggestion)|something else)/gi;
 const localPhrase=/(?:(?:想|要|有[冇無咩乜])(?:試|食)?)?(?:有)?(?:傳統港式|地道|港式|香港|本地|茶餐廳|茶記|招牌)(?:特[色式]|經典|招牌|風味|味道)?(?:嘅)?(?:嘢食|嘢|食物)?/g;
 const budgetPrefix=/(?:預算|预算|HKD\s*|\$|under\s*|below\s*|唔好超過|最多|上限)\s*(\d+(?:\.\d+)?)(?:\s*(?:蚊|元|港元|dollars?))?/gi;
 const budgetSuffix=/(\d+(?:\.\d+)?)\s*(?:蚊|元|港元)(?:以下|以內|內搞掂|內|以內搞掂)/g;
 function applyDiet(filter,words,value){
  if(/牛|beef/i.test(words))filter.noBeef=value;
  if(/豬|叉燒|火腿|餐肉|腸仔|香腸|pork/i.test(words))filter.noPork=value;
  if(/包|三文治|多士|bread|bun|sandwich|toast/i.test(words))filter.noBread=value;
 }
 function recommendationPlan(text,cart=[],context={}){
  const original=K.language.clean(K.tc(text).replace(/^(?:請問(?:一下|下|吓)?|我想問(?:下|吓)?|想問(?:下|吓)?)[\s，,]*/,''));
  request.lastIndex=0;localPhrase.lastIndex=0;
  const hasRequest=request.test(original),hasLocal=localPhrase.test(original);
  if(!hasRequest&&!hasLocal&&!context.recommendationActive)return null;
  if(!hasRequest&&K.findItems(original).length)return null;
  // Preserve category browsing and exact dish inquiries in the existing parser.
  if(K.conversationalIntent?.(text,cart)?.intent==='navigate')return null;
  let rest=original,filter={},touched=false;
  rest=rest.replace(/清除(?:全部)?篩選(?:條件)?|重設篩選|冇忌口|唔使忌口/g,()=>{touched=true;Object.assign(filter,{noBeef:false,noPork:false,noBread:false,vegetarian:false,noPeanut:false,localSpecial:false,budget:null});return' ';});
  const dietEdits=[];
  for(const [pattern,value] of [[positive,false],[negative,true]])for(const m of rest.matchAll(pattern))dietEdits.push({index:m.index,words:m[1]||m[2],value});
  for(const edit of dietEdits.sort((a,b)=>a.index-b.index)){applyDiet(filter,edit.words,edit.value);touched=true;}
  rest=rest.replace(positive,' ').replace(negative,' ');
  rest=rest.replace(/(?:唔使|取消|解除)(?:預算|價錢)(?:限制)?|不限預算/g,()=>{filter.budget=null;touched=true;return' ';});
  rest=rest.replace(budgetPrefix,(_,n)=>{filter.budget=Number(n);touched=true;return' ';});
  rest=rest.replace(budgetSuffix,(_,n)=>{filter.budget=Number(n);touched=true;return' ';});
  rest=rest.replace(localPhrase,()=>{filter.localSpecial=true;touched=true;return' ';});
  rest=rest.replace(/素食|vegetarian/gi,()=>{filter.vegetarian=true;touched=true;return' ';});
  rest=rest.replace(/花生(?:敏感|過敏)|peanut allergy/gi,()=>{filter.noPeanut=true;touched=true;return' ';});
  rest=rest.replace(request,' ')
   .replace(/\b(?:any|what|do|you|please|thanks|me|some|something|else)\b/gi,' ')
   .replace(/(?:另一個|換個|換一個|再|其他|第二款|下一個)?(?:推介|推薦|介紹|組合)/g,' ')
   .replace(/今次|全部|都|任何|類|先|想|試|食|嘅|嘢食|嘢|有冇|有無|有咩|有乜|有|個|一個|同埋|同|兼|及|和|就|喇|啦|再|其他|換|唔該|多謝|please|thanks/gi,' ')
   .replace(/[\p{P}\p{S}\s]/gu,'');
  if(rest){if(!hasRequest&&!hasLocal)return null;throw new K.OrderError('unrecognizedTokens',{tokens:rest});}
  if(!hasRequest&&!hasLocal&&!touched)return null;
  return{intent:'recommend',ops:[],next:/再|其他|第二款|下一個|換|another|else|next/i.test(original),filter};
 }
 function validateFilter(filter={}){
  if(!filter||typeof filter!=='object'||Array.isArray(filter))throw new K.OrderError('invalidPlan');
  if(Object.keys(filter).some(k=>!['noBeef','noPork','noBread','localSpecial','vegetarian','noPeanut','budget'].includes(k)))throw new K.OrderError('invalidPlan');
  const out={};
  for(const key of ['noBeef','noPork','noBread','localSpecial','vegetarian','noPeanut']){
   if(filter[key]!==undefined){if(typeof filter[key]!=='boolean')throw new K.OrderError('invalidPlan');out[key]=filter[key];}
  }
  if(filter.budget!==undefined&&filter.budget!==null&&filter.budget!==''){
   const n=Number(filter.budget);if(!Number.isFinite(n)||n<0||n>100000)throw new K.OrderError('invalidPlan');out.budget=n;
  }
  return out;
 }
 function dietaryAllowed(i,f){
  const m=K.menu.find(m=>m.id===i.id),d=m?.dietary;if(!d)return false;
  return !(f.noBeef&&(d.beef||i.extras?.includes('X6'))||f.noPork&&(d.pork||i.extras?.some(id=>['X3','X4','X5','X7'].includes(id)))||f.noBread&&d.bread);
 }
 function recommendationAllowed(candidate,availability={},filter={},prices={}){
  const f=validateFilter(filter);
  if(f.vegetarian||f.noPeanut||!candidate?.items?.length)return false;
  try{
   for(const raw of candidate.items){const i=K.normalize(raw);if(!dietaryAllowed(i,f))return false;K.ensureAvailable(i,availability);}
   if(f.localSpecial&&!candidate.items.some(i=>K.menu.find(m=>m.id===i.id)?.dietary.localSpecial))return false;
   return f.budget===undefined||K.total(candidate.items,prices)<=f.budget;
  }catch(error){if(error instanceof K.OrderError)return false;throw error;}
 }
 function recommendations(orders=[],availability={},filter={},prices={}){
  const f=validateFilter(filter);if(f.vegetarian||f.noPeanut)return[];
  const availableDrink=K.drinks.find(d=>d==='熱奶茶'&&availability[K.drinkItem(d)?.id]!==false)||K.drinks.find(d=>!['待選飲品','不需要飲品'].includes(d)&&K.drinkItem(d)&&availability[K.drinkItem(d).id]!==false)||'熱水';
  const make=id=>{const m=K.menu.find(m=>m.id===id);return m?K.normalize({...K.defaults(m),...(m.combo?{drink:availableDrink}:{})}):null;};
  const sales={};for(const o of orders.filter(o=>o.status==='completed'))for(const i of o.items||[])if(Number.isInteger(i.qty)&&i.qty>0&&K.menu.some(m=>m.id===i.id))sales[i.id]=(sales[i.id]||0)+i.qty;
  const curated=[{ids:['A','P1'],reason:'signature'},{ids:['B','P5'],reason:'classic'},{ids:['C','S3'],reason:'hearty'},{ids:['D','P2'],reason:'chef'},{ids:['E','P3'],reason:'sharing'},{ids:['F','P1'],reason:'gentle'}];
  const result=[],seen=new Set();
  function append(ids,reason,sold){const items=ids.map(make);if(items.some(i=>!i))return;const c={ids,items,reason,...(sold?{sales:sold}:{})};if(!recommendationAllowed(c,availability,f,prices))return;const key=items.map(i=>i.id+':'+i.drink).join('|');if(!seen.has(key)){seen.add(key);result.push(c);}}
  for(const id of Object.keys(sales).sort((a,b)=>sales[b]-sales[a]))append([id],'bestseller',sales[id]);
  for(const c of curated)append(c.ids,c.reason);
  // Curated sets alone cannot satisfy bread exclusions or smaller budgets.
  // Generate alternatives from actual, priced and available catalog entries.
  const beverage=K.drinkItem(availableDrink);
  for(const m of K.menu.filter(m=>!m.drink).sort((a,b)=>Number(b.dietary.localSpecial)-Number(a.dietary.localSpecial))){
   if(!m.combo&&beverage)append([m.id,beverage.id],m.dietary.localSpecial?'local':'catalog');
   append([m.id],m.dietary.localSpecial?'local':'catalog');
  }
  return result;
 }
 K.recommendationPlan=recommendationPlan;K.recommendations=recommendations;K.recommendationAllowed=recommendationAllowed;K.validateRecommendationFilter=validateFilter;
 K.parseCommand=(text,cart=[],context={})=>recommendationPlan(text,cart,context)||parse(text,cart,context);
 K.analyzeLocal=(text,cart=[],context={})=>{try{const plan=recommendationPlan(text,cart,context);return plan?{decision:'local',plan,normalized:K.language.clean(text),corrections:[]}:analyze(text,cart,context);}catch(error){return{decision:error.code==='unrecognizedTokens'?'fallback':'clarify',error};}};
 Object.assign(g.I18n.dict,{
  recommendUpdated:['推介已更新，請重新揀。','Recommendations changed. Please choose again.'],
  recommendReset:['清除篩選條件','Clear preferences'],
  reasonLocal:['從餐牌揀選的港式特色，符合目前篩選條件。','Hong Kong classics matching your current preferences.'],
  reasonCatalog:['按目前條件從餐牌揀選，價錢以現行餐牌計。','Catalog items matching your preferences at current menu prices.'],
  reasonHearty:['餐肉雙蛋配薯條，份量滿足。','Luncheon meat and eggs with fries.']
 });
})(globalThis);

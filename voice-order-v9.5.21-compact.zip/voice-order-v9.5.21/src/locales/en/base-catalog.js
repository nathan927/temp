(function(g){
'use strict';
const foodRows=[
 ['P7','餐肉蛋三文治','Luncheon meat & egg sandwich',28,'餐蛋治|餐肉蛋治|午餐肉蛋治|午餐肉雞蛋三文治|餐肉雞蛋三明治|餐肉蛋三明治|spam egg sandwich|luncheon meat egg sandwich'],
 ['P8','鹹牛肉蛋三文治','Corned beef & egg sandwich',32,'咸牛肉蛋治|鹹牛肉蛋治|咸牛蛋治|鹹牛蛋治|牛肉蛋治|鹹牛肉雞蛋三明治|corned beef egg sandwich|corned beef and egg sandwich'],
 ['P9','吞拿魚三文治','Tuna sandwich',30,'吞拿魚治|吞拿魚三明治|鮪魚三文治|金槍魚三明治|吞拿治|吞拿三文治|tuna mayo sandwich|tuna sandwich'],
 ['P10','芝士三文治','Cheese sandwich',26,'芝士治|起司三明治|芝士三明治|芝士夾包|芝士方包|起司三文治|cheese sandwich|plain cheese sandwich'],
 ['P11','火腿三文治','Ham sandwich',24,'火腿治|腿治|火腿三明治|淨火腿三文治|火腿方包|火腿夾包|ham sandwich|plain ham sandwich'],
 ['P12','公司三文治','Club sandwich',48,'公司治|公司三明治|三層公司治|club sandwich'],
 ['P13','奶醬多士','Peanut butter & condensed milk toast',24,'奶醬多|奶醬厚多士|花生醬煉奶多士|煉奶花生醬多士|奶醬厚多|奶醬吐司|peanut condensed milk toast|peanut butter and condensed milk toast'],
 ['P14','果占多士','Jam toast',20,'占多|果占多|果醬多士|草莓占多士|士多啤梨占多士|占醬多士|jam toast|strawberry jam toast'],
 ['P15','鮮牛油多士','Butter toast',20,'牛油多|鮮油多|牛油多士|鮮油多士|淨牛油多|厚切牛油多士|butter toast|buttered toast'],
 ['P16','原味菠蘿包','Plain pineapple bun',18,'菠蘿包|菠蘿飽|淨菠蘿包|原味菠蘿包|不夾牛油菠蘿包|菠蘿麵包|plain pineapple bun|pineapple bun'],
 ['P17','香煎豬扒包','Pork chop bun',38,'豬扒包|豬排包|香煎豬排包|豬扒漢堡|豬扒麵包|煎豬扒包|pork chop bun|pork chop burger'],
 ['P18','香煎雞扒包','Chicken steak bun',38,'雞扒包|雞排包|香煎雞排包|雞扒漢堡|雞扒麵包|煎雞扒包|chicken bun|chicken steak bun'],
 ['P19','香脆魚柳包','Fish fillet bun',36,'魚柳包|魚排包|炸魚柳包|魚柳漢堡|魚柳麵包|脆魚包|fish burger|fish fillet bun'],
 ['P20','港式熱狗','Hong Kong hot dog',28,'熱狗|腸仔包|香腸包|熱狗包|港式腸仔包|長包熱狗|hot dog|sausage hot dog'],
 ['P21','火腿芝士三文治','Ham & cheese sandwich',30,'腿芝治|火腿芝士治|腿芝士治|火腿起司三明治|火腿芝士三明治|火腿芝士方包|ham cheese sandwich|ham and cheese sandwich'],
 ['P22','花生醬多士','Peanut butter toast',22,'醬多|花生醬多|花生多士|花生醬厚多士|淨花生醬多士|花生醬吐司|peanut toast|peanut butter toast'],
 ['S1','香脆炸雞翼','Fried chicken wings',32,'炸雞翼|香脆雞翼|脆雞翼|炸雞翅|香炸雞翼|炸雞中翼|fried wings|fried chicken wings'],
 ['S2','瑞士汁雞翼','Swiss sauce chicken wings',36,'瑞士雞翼|瑞士汁翼|豉油雞翼|甜豉油雞翼|瑞士雞翅|瑞士翼|swiss wings|swiss chicken wings'],
 ['S3','香脆薯條','French fries',26,'薯條|炸薯條|香炸薯條|脆薯條|炸薯仔條|fries|french fries'],
 ['S4','咖喱魚蛋','Curry fish balls',24,'咖哩魚蛋|咖喱魚丸|咖哩魚丸|魚蛋|咖喱魚旦|港式咖喱魚蛋|curry fishballs|curry fish balls'],
 ['S5','香脆魚豆腐','Fried fish tofu',24,'魚豆腐|炸魚豆腐|脆魚豆腐|魚腐|炸魚腐|香炸魚豆腐|fish tofu|fried fish tofu'],
 ['S6','香脆春卷','Spring rolls',24,'春卷|炸春卷|炸春捲|春捲|脆春卷|香炸春卷|spring rolls|fried spring rolls'],
 ['S7','香脆薯餅','Hash browns',22,'薯餅|炸薯餅|脆薯餅|薯仔餅|香炸薯餅|馬鈴薯餅|hash browns|hash brown'],
 ['S8','香煎雙蛋','Two fried eggs',18,'雙蛋|煎雙蛋|雙煎蛋|兩隻煎蛋|雙太陽蛋|煎蛋一份|two fried eggs|fried eggs'],
 ['R1','乾炒牛河','Beef chow fun',58,'干炒牛河|乾炒牛肉河粉|牛河|牛肉炒河粉|乾炒牛肉河|炒牛河|beef chow fun|dry fried beef noodles'],
 ['R2','星洲炒米','Singapore vermicelli',56,'星州炒米|星洲炒米粉|新加坡炒米|星米|星洲米粉|singapore noodles|singapore vermicelli'],
 ['R3','揚州炒飯','Yangzhou fried rice',58,'揚洲炒飯|楊州炒飯|楊洲炒飯|揚州蛋炒飯|揚州飯|yangzhou fried rice'],
 ['R4','焗豬扒飯','Baked pork chop rice',62,'焗豬排飯|焗茄汁豬扒飯|茄汁焗豬扒飯|焗豬扒炒飯|焗豬排炒飯|豬扒焗飯|baked pork chop rice|tomato baked pork rice'],
 ['R5','咖喱牛腩飯','Curry beef brisket rice',62,'咖哩牛腩飯|咖喱牛腩配飯|牛腩咖喱飯|咖哩牛腩配飯|咖喱牛腩白飯|牛腩飯咖喱|curry beef rice|curry beef brisket rice'],
 ['R6','咖喱雞飯','Curry chicken rice',58,'咖哩雞飯|咖喱雞肉飯|雞肉咖喱飯|咖哩雞肉飯|咖喱雞配飯|咖喱雞白飯|curry chicken rice|chicken curry rice'],
 ['R7','蜜汁叉燒飯','BBQ pork rice',52,'叉燒飯|叉烧饭|蜜汁叉燒配飯|叉燒白飯|叉燒碟頭飯|叉燒配飯|char siu rice|bbq pork rice'],
 ['R8','番茄炒蛋飯','Tomato & egg rice',48,'蕃茄炒蛋飯|茄蛋飯|番茄蛋飯|蕃茄蛋飯|番茄滑蛋飯|茄汁炒蛋飯|tomato egg rice|tomato and egg rice'],
 ['R9','清湯牛腩麵','Beef brisket noodle soup',52,'牛腩麵|牛腩湯麵|清湯牛腩麵|牛腩公仔麵|清湯牛腩|牛腩粉麵|beef brisket noodles|beef brisket noodle soup'],
 ['R10','鮮蝦雲吞麵','Wonton noodle soup',45,'雲吞麵|雲吞湯麵|鮮蝦雲吞湯麵|細蓉|細容|雲吞幼麵|wonton noodles|wonton noodle soup'],
 ['R11','餐肉煎蛋公仔麵','Spam & egg noodle soup',42,'餐蛋麵|餐肉蛋麵|餐蛋公仔麵|午餐肉蛋麵|餐肉雞蛋麵|餐肉蛋公仔麵|spam egg noodles|luncheon meat egg noodles'],
 ['R12','香煎豬扒出前一丁','Pork chop Demae noodles',48,'豬扒丁|豬扒丁麵|豬扒出前一丁|豬排丁麵|豬排出前一丁|豬扒湯丁|pork chop demae noodles|pork chop instant noodles']
];
const foods=foodRows.map((r,n)=>({id:r[0],name:r[1],en:r[2],price:r[3],aliases:r[4].split('|'),photo:100+n,cat:n<16?'包點多士':n<24?'單點小食':'飯麵主食',desc:n<16?'即叫即製 · 港式經典':n<24?'即叫即做 · 熱辣香脆':'即叫即炒 · 餐廳經典',descEN:n<16?'Made to order · Hong Kong classic':n<24?'Freshly prepared · Served hot':'Cooked to order · Café favourite',bread:n<16,defaultToast:['P7','P8','P9','P10','P11','P12','P13','P14','P15','P21','P22'].includes(r[0])?'烘底':'正常多士',base:n>=24,spicy:['S4','R2','R5','R6'].includes(r[0]),noodle:n>=32?(r[0]==='R12'?'出前一丁':['R9','R10'].includes(r[0])?'幼麵':'公仔麵'):undefined,hasEgg:r[0]==='S8',allergens:['蛋','奶','麩質','大豆',...(['P13','P22'].includes(r[0])?['花生']:[]) ]}));
const drinkRows=[
 ['檸水','Lemon water',22,0,'檸檬水|檸水|lemon water','零水|檸誰'],['檸蜜','Lemon honey',24,3,'檸檬蜜糖|檸蜜|檸檬蜂蜜|lemon honey','零蜜|寧蜜'],['西洋菜蜜','Watercress honey',22,0,'菜蜜|西洋菜蜜|watercress honey','西洋菜密|菜密'],['阿華田','Ovaltine',24,3,'阿華田|華田|柯華田|ovaltine','阿華甜|阿花田'],['好立克','Horlicks',24,3,'好立克|好立剋|horlicks','好力克|好立刻'],['美祿','Milo',24,3,'美祿|美禄|milo','美鹿|美陸'],['朱古力','Chocolate',24,3,'朱古力|熱朱古力|巧克力|chocolate','朱姑力|豬古力'],['杏仁霜','Almond drink',24,3,'杏仁霜|杏仁茶|almond drink','杏仁雙|杏人霜'],['鮮奶','Fresh milk',24,3,'鮮奶|純牛奶|牛奶|fresh milk','鮮乃|先奶'],
 ['檸樂','Lemon cola',28,8,'檸樂|檸檬可樂|lemon cola','零樂|寧樂','cold'],['檸七','Lemon 7up',28,8,'檸七|檸檬七喜|lemon 7up','零七|寧七','cold'],['鹹檸七','Salted lemon 7up',30,10,'鹹檸七|咸檸七|鹹檸檬七喜|salted lemon 7up','咸零七|鹹零七','cold'],['鹹檸樂','Salted lemon cola',30,10,'鹹檸樂|咸檸樂|鹹檸檬可樂|salted lemon cola','咸零樂|鹹零樂','cold'],['檸賓','Lemon Ribena',26,6,'檸賓|檸檬利賓納|lemon ribena','零賓|檸冰'],['利賓納','Ribena',24,4,'利賓納|黑加侖子汁|黑加侖汁|ribena','利賓立|利賓那'],['可樂','Cola',20,5,'可樂|可口可樂|cola|coke','可落|可洛','cold'],['七喜','7up',20,5,'七喜|七喜汽水|7up|seven up','七起|七禧','cold'],['忌廉梳打','Cream soda',20,5,'忌廉汽水|忌廉梳打|cream soda','忌簾梳打|忌廉疏打','cold'],['忌廉溝鮮奶','Cream soda with milk',28,8,'忌廉鮮奶|忌廉溝鮮奶|cream soda milk|cream soda with milk','忌簾溝鮮奶|忌廉溝先奶','cold'],['紅豆冰','Red bean ice',32,12,'紅豆冰|紅豆奶冰|red bean ice','紅豆兵|紅豆邊','cold'],['菠蘿冰','Pineapple ice',30,10,'菠蘿冰|菠蘿冰飲|pineapple ice','波羅冰|菠蘿兵','cold'],['什果賓治','Fruit punch',32,12,'雜果賓治|什果賓治|fruit punch','什果賓智|雜果賓至','cold'],['檸啡','Lemon coffee',28,6,'檸啡|檸檬咖啡|lemon coffee','零啡|檸非'],['薑煲可樂','Ginger cola',28,8,'薑煲可樂|薑可樂|ginger cola|hot ginger cola','姜煲可樂|薑煲可落','hot']
];
const drinks=drinkRows.map((r,n)=>{const mode=r[6]||'both',drink=(mode==='cold'?'凍':'熱')+r[0];return{id:'T'+(n+5),name:r[0],en:r[1],price:r[2],comboSupplement:r[3],aliases:r[4].split('|'),phonetic:r[5].split('|'),photo:200+n,cat:'港式飲品',drink,family:r[0],temperatures:mode==='both'?['熱','凍']:[mode==='cold'?'凍':'熱'],milkAllowed:n>=3&&n<=8,adjustSugar:![9,10,11,12,15,16,17,18,23].includes(n),desc:mode==='both'?'凍熱可選 · 即叫即調':mode==='cold'?'冰涼特飲 · 港式滋味':'熱飲限定 · 薑香暖胃',descEN:mode==='both'?'Hot or iced · Prepared to order':mode==='cold'?'Iced specialty · Hong Kong classic':'Hot only · Warming ginger',allergens:n>=3&&n<=8||[18,19].includes(n)?['奶']:[]};});
const extras=[['X1','加蛋','Extra egg',6,'加蛋|加隻蛋|加一隻蛋|加煎蛋|加多隻蛋|extra egg','food'],['X2','加芝士','Extra cheese',5,'加芝士|加起司|加一片芝士|加芝士片|extra cheese','food'],['X3','加火腿','Extra ham',6,'加火腿|加片火腿|加一片火腿|extra ham','food'],['X4','加餐肉','Extra luncheon meat',8,'加餐肉|加午餐肉|加一片餐肉|extra spam|extra luncheon meat','food'],['X5','加腸仔','Extra sausage',6,'加腸仔|加香腸|加一條腸仔|extra sausage','food'],['X6','加牛肉','Extra beef',12,'加牛肉|加沙嗲牛肉|extra beef','main'],['X7','加豬扒','Extra pork chop',15,'加豬扒|加豬排|extra pork chop','main'],['X8','加雞扒','Extra chicken steak',15,'加雞扒|加雞排|extra chicken steak','main'],['X9','加檸檬','Extra lemon',2,'加檸檬|多檸檬|多片檸檬|extra lemon','drink'],['X10','加雪糕','Ice cream scoop',6,'加雪糕|加一球雪糕|extra ice cream','drink']].map(([id,name,en,price,terms,group])=>({id,name,en,price,terms:terms.split('|'),group}));
g.CafeExpansion={foods,drinks,extras};
})(globalThis);

(function(g){
'use strict';
const entries=[];
function add(kind,target,terms,meta={}){for(const term of terms.split('|').map(s=>s.trim()).filter(Boolean))entries.push({kind,target,term,...meta});}
const products={
 A:['早餐A','沙嗲牛肉早餐|沙爹牛肉早餐|沙嗲牛肉餐|沙爹牛肉餐|沙嗲牛肉湯麵|沙爹牛肉湯麵|沙嗲牛肉麵|沙爹牛肉麵|沙嗲牛肉|沙爹牛肉|沙嗲牛|沙爹牛|沙嗲牛餐|沙爹牛餐|satay beef breakfast|satay beef set|satay beef noodles|satay beef noodle soup|satay beef|satay noodles'],
 B:['早餐B','火腿通粉早餐|火腿通心粉早餐|火腿通粉餐|火腿通心粉餐|火腿通心粉|火腿湯通粉|火腿湯通|火腿通粉|火腿通|ham macaroni breakfast|ham macaroni set|ham macaroni soup|ham and macaroni soup|ham macaroni|ham pasta'],
 C:['早餐C','餐肉雙蛋早餐|午餐肉雙蛋早餐|午餐肉煎雙蛋|午餐肉配雙蛋|午餐肉雙蛋|餐肉雙蛋|餐肉蛋早餐|午餐肉蛋早餐|餐蛋早餐|餐蛋餐|餐肉蛋餐|餐肉蛋|餐蛋|luncheon meat and eggs|luncheon meat breakfast|spam and eggs|spam with eggs|spam breakfast'],
 D:['早餐D','叉燒湯麵早餐|叉燒湯麵餐|蜜汁叉燒湯麵|蜜汁叉燒麵|叉燒湯麵|叉燒即食麵|叉燒公仔麵|叉燒麵|叉燒麵餐|barbecue pork noodles|barbecued pork noodles|bbq pork noodle soup|bbq pork noodles|char siu noodles|char siu'],
 E:['早餐E','腸仔煎蛋早餐|腸仔雙蛋早餐|香腸雙蛋早餐|香腸煎蛋早餐|香腸配雞蛋|腸仔煎雙蛋|腸仔雙蛋|香腸雙蛋|腸仔煎蛋|香腸煎蛋|腸仔蛋餐|腸蛋餐|腸蛋|sausage and eggs|sausages and eggs|sausage with eggs|sausage breakfast'],
 F:['早餐F','生滾靚粥早餐|生滾瘦肉粥早餐|生滾瘦肉粥|瘦肉粥早餐|瘦肉粥餐|靚粥早餐|瘦肉粥|靚粥|粥餐|pork congee breakfast|pork congee set|pork congee|pork rice porridge|congee breakfast'],
 P1:['冰火菠蘿油','冰火菠蘿油|冰火菠蘿包配牛油|菠蘿包夾牛油|菠蘿包加牛油|菠蘿包配牛油|菠蘿油|冰火菠蘿包|菠蘿油包|蘿柚|pineapple bun with butter|pineapple bun and butter|pineapple butter bun|buttered pineapple bun'],
 P2:['金黃港式西多士','金黃港式西多士|港式西多士|金黃西多士|花生醬西多士|西多士|西多|夏蕙姨|夏蕙|hong kong french toast|hk french toast|peanut butter french toast|french toast'],
 P6:['滑蛋三文治','滑蛋三文治|雞蛋三文治|蛋三文治|雞蛋三明治|蛋三明治|滑蛋治|炒蛋治|淨蛋治|蛋治|egg sandwich|scrambled egg sandwich|plain egg sandwich|egg-only sandwich'],
 P3:['火腿滑蛋三文治','火腿滑蛋三文治|火腿雞蛋三文治|火腿蛋三文治|火腿雞蛋三明治|火腿蛋三明治|火腿滑蛋三明治|火腿炒蛋三文治|火腿蛋治|腿蛋治|腿蛋三文治|火腿滑蛋治|隊Q住|ham and egg sandwich|ham egg sandwich|ham and scrambled egg sandwich|ham & egg sandwich|ham sandwich with eggs'],
 P4:['奶油厚多士','奶油厚多士|奶油厚切多士|牛油煉奶多士|煉奶牛油多士|奶油多士|奶油多|厚切奶油多|butter and condensed milk toast|condensed milk and butter toast|condensed milk toast'],
 P5:['酥皮蛋撻','酥皮蛋撻兩件|酥皮蛋撻|香酥蛋撻|港式蛋撻|雞蛋蛋撻|蛋撻|蛋塔|flaky egg tarts|flaky egg tart|hong kong egg tarts|egg tarts|egg tart'],
 N1:['豉油皇炒麵','豉油皇炒麵|豉油王炒麵|豉油皇炒麪|豉油王炒麪|港式豉油皇炒麵|港式炒麵|豉油皇|豉油王|炒麵|soy sauce fried noodles|soy sauce chow mein|hong kong fried noodles|fried noodles'],
 T1:['熱奶茶','招牌絲襪奶茶|港式絲襪奶茶|絲襪奶茶|港式奶茶|熱絲襪奶茶|熱奶茶|熱奶|奶茶|hot milk tea|hong kong milk tea|signature milk tea|milk tea'],
 T2:['凍檸茶','手打凍檸茶|港式凍檸茶|凍檸檬茶|冰檸檬茶|冰鎮檸茶|凍檸茶|冰檸茶|冷檸茶|凍檸|爆檸|凍0T|iced lemon tea|cold lemon tea|ice lemon tea|lemon iced tea'],
 T3:['熱咖啡','即磨香濃咖啡|即磨咖啡|即磨熱啡|熱咖啡|熱啡|熱非|咖啡|熱齋啡|汪阿姐|hot coffee|freshly brewed coffee|brewed coffee|coffee'],
 T4:['鴛鴦','港式鴛鴦|招牌鴛鴦|鴛鴦|央|yuen yeung|yuanyang|yin yang|yuenyeung|coffee mixed with milk tea|coffee blended with milk tea|咖啡溝奶茶|奶茶溝咖啡']
};
for(const [id,[target,terms]]of Object.entries(products))add('item',target,terms,{id});
for(const [letter,cn,words]of [['A','甲','A|a|Ａ|欸|誒|誒伊|alpha'],['B','乙','B|b|Ｂ|比|bee|bravo'],['C','丙','C|c|Ｃ|西|see|charlie'],['D','丁','D|d|Ｄ|迪|dee|delta'],['E','戊','E|e|Ｅ|伊|ee|echo'],['F','己','F|f|Ｆ|eff|foxtrot']]){
 add('item','早餐'+letter,`早餐${cn}|早晨${cn}|${cn}餐|套餐${cn}|${cn}號早餐|早餐${letter}|${letter}餐|套餐${letter}|套餐 ${letter}|${letter}套餐|${letter}號餐|${letter}號早餐|早晨${letter}|早餐 ${letter}|早餐${cn}餐|breakfast ${letter}|breakfast set ${letter}|set ${letter}|combo ${letter}`,{id:letter});
 for(const v of words.split('|'))if(!/^[a-fＡ-Ｆ]$/i.test(v))add('phonetic','早餐'+letter,`早餐${v}|早晨${v}|${v}餐`,{id:letter,requires:'set-code'});
}
add('item','早餐A出前一丁','沙嗲牛肉丁麵|沙爹牛肉丁麵|沙嗲牛丁|沙爹牛丁',{id:'A'});
add('item','早餐D出前一丁','叉燒出前一丁|叉燒丁麵|叉燒丁',{id:'D'});
add('item','凍奶茶','凍絲襪奶茶|冰絲襪奶茶|凍奶茶|凍奶|冰奶茶|冷奶茶|凍T|冬T|iced milk tea|cold milk tea|ice milk tea',{id:'T1'});
add('item','熱奶茶轉煉奶','茶走|熱茶走|奶茶轉煉奶|milk tea with condensed milk',{id:'T1'});
add('item','凍奶茶轉煉奶','凍茶走|iced milk tea with condensed milk',{id:'T1'});
add('item','凍檸茶','檸茶|檸檬茶|lemon tea',{id:'T2'});
add('item','熱檸茶','熱檸檬茶|熱檸茶|熱檸|熱0T|hot lemon tea',{id:'T2'});
add('item','凍咖啡','凍咖啡|冰咖啡|冷咖啡|冰鎮咖啡|凍啡|凍非|iced coffee|cold coffee|ice coffee',{id:'T3'});
add('item','熱咖啡走奶走甜','齋啡|齋非|熱齋非|飛砂走奶|飛沙走奶|black coffee without sugar|unsweetened black coffee',{id:'T3'});
add('item','熱咖啡走奶','black coffee|hot black coffee',{id:'T3'});
add('item','凍咖啡走奶','凍齋啡|凍齋非|iced black coffee|cold black coffee',{id:'T3'});
add('item','熱咖啡轉煉奶','啡走|熱啡走|咖啡轉煉奶|coffee with condensed milk',{id:'T3'});
add('item','凍咖啡轉煉奶','凍啡走|iced coffee with condensed milk',{id:'T3'});
add('item','凍鴛鴦','招牌凍鴛鴦|凍鴛鴦|冰鴛鴦|冷鴛鴦|凍央|iced yuen yeung|cold yuen yeung|iced yin yang',{id:'T4'});
add('item','熱鴛鴦','熱鴛鴦|熱央|hot yuen yeung|hot yin yang',{id:'T4'});
for(const [base,id,family] of [['奶茶','T1','奶茶'],['絲襪奶茶','T1','奶茶'],['咖啡','T3','咖啡'],['檸茶','T2','檸茶'],['檸檬茶','T2','檸茶'],['鴛鴦','T4','鴛鴦']])for(const [prefix,temp] of [['熱','熱'],['凍','凍'],['冰','凍'],['冷','凍'],['冰鎮','凍']])add('item',temp+family,prefix+base,{id});
add('item','凍咖啡走奶走甜','凍齋啡|凍齋非',{id:'T3'});
const modifiers=[
 ['noodle','出前一丁','出前一丁|出前丁麵|出前丁|食丁|丁麵|轉丁麵|轉丁面|丁麪|demae iccho|demae|nissin'],
 ['noodle','公仔麵','公仔麵|即食麵|方便麵|速食麵|泡麵|instant noodles|instant noodle'],
 ['noodle','通粉','通粉|通心粉|通心麵|macaroni'],['noodle','米粉','米粉|米粉底|rice vermicelli|rice noodles|vermicelli'],['noodle','意粉','意粉|意大利粉|義大利麵|spaghetti'],
 ['sugar','走甜','走甜|走糖|飛砂|飛沙|唔要糖|唔落糖|不加糖|不要糖|無糖|免糖|不放糖|無砂糖|糖唔要|no sugar|without sugar|zero sugar|sugar free|unsweetened'],
 ['sugar','少甜','少甜|少糖|微甜|糖少啲|少啲糖|甜少啲|糖少一點|少放糖|less sugar|less sweet|light sugar'],['sugar','半糖','半糖|一半糖|五成糖|半份糖|half sugar'],['sugar','多甜','多甜|多糖|加甜|糖多啲|多啲糖|extra sugar|more sugar'],['sugar','正常甜','正常甜|正常糖|標準糖|regular sugar|normal sugar'],
 ['ice','走冰','走冰|去冰|無冰|免冰|唔要冰|唔落冰|不要冰|不加冰|冰唔要|no ice|without ice|ice free'],['ice','少冰','少冰|微冰|冰少啲|少啲冰|冰少一點|less ice|light ice'],['ice','多冰','多冰|加冰多啲|冰多啲|多啲冰|extra ice|more ice'],['ice','正常冰','正常冰|標準冰|normal ice|regular ice'],
 ['milk','走奶','走奶|免奶|無奶|唔要奶|唔落奶|不要奶|不加奶|奶唔要|no milk|without milk'],['milk','少奶','少奶|奶少啲|少啲奶|奶少一點|less milk|light milk'],['milk','多奶','多奶|奶多啲|多啲奶|奶多一點|extra milk|more milk'],['milk','轉煉奶','轉煉奶|轉練奶|用煉奶|改煉奶|換煉奶|with condensed milk'],['milk','正常奶','正常奶|normal milk|regular milk'],
 ['egg','炒蛋','炒蛋|滑蛋|嫩炒蛋|炒滑蛋|滑炒蛋|scrambled eggs|scrambled egg'],['egg','太陽蛋','太陽蛋|單面蛋|單面煎蛋|太陽煎蛋|sunny side up|sunny-side-up'],['egg','反蛋','反蛋|翻蛋|雙面蛋|雙面煎蛋|兩面煎蛋|煎兩面|反面煎蛋|over easy|over medium|both sides'],['egg','熟蛋','熟蛋|全熟蛋|熟透蛋|全熟煎蛋|煎熟啲|well done eggs|fully cooked eggs'],['egg','走蛋','走蛋|免蛋|唔要蛋|不要蛋|不加蛋|no egg|no eggs|without eggs'],
 ['portion','加底','加底|加麵底|加粉底|粉麵加底|主食加量|extra base|extra noodles|extra pasta|large portion'],['portion','少底','扣底|少底|主食減量|粉少啲|少粉|smaller portion|less pasta|less vermicelli'],['portion','正常份量','正常份量|regular portion'],
 ['broth','湯另上','湯另上|湯分開|湯另外上|湯另外裝|湯分裝|湯另裝|另上湯|broth on the side|soup on the side|separate soup'],['broth','走湯','走湯|免湯|無湯|唔要湯|不要湯|不加湯|no soup|no broth|without soup'],['broth','少湯','少湯|湯少啲|少啲湯|少一點湯|less soup|less broth'],['broth','正常湯','正常湯|regular broth'],
 ['toast','烘底飛邊','烘底飛邊|飛邊烘底|烘底兼飛邊|去邊再烘|toasted no crusts'],['toast','烘底','烘底|烘多士|麵包烘底|烘脆啲|烘一烘|toasted bread|toast the bread'],['toast','飛邊','飛邊|去邊|去麵包邊|不要麵包邊|麵包去皮|去包邊|no crust|no crusts|crusts off'],
 ['note','走青','走青|飛青|不要蔥和芫茜|唔要蔥同芫茜|no herbs|no spring onion or coriander'],['note','走蔥','走蔥|唔要蔥|不要蔥|不加蔥|不加蔥花|蔥花唔要|no spring onion|no onion'],['note','走芫茜','走芫茜|走香菜|唔要芫茜|不要芫茜|不要香菜|no coriander|no cilantro'],['note','走醬','走醬|走色|免醬|不要醬|唔要醬|不加醬汁|no sauce|without sauce'],['note','醬汁另上','醬汁另上|醬另上|醬汁分開|醬另裝|另上醬|sauce on the side|separate sauce'],['note','多醬汁','多醬汁|多色|加色|多醬|醬多啲|extra sauce|more sauce'],['note','少油','少油|油少啲|清淡少油|less oil'],['note','少鹽','少鹽|鹽少啲|少放鹽|less salt'],['note','走牛油','走牛油|唔要牛油|不要牛油|no butter|without butter'],['note','走花生','走花生|唔要花生|不要花生|不加花生|no peanuts|no peanut|without peanuts']
];
for(const [field,target,terms]of modifiers)add('modifier',target,terms,{field});
add('modifier','通粉少底','通粉少啲',{field:'portion'});
add('modifier','出前一丁','demae noodles|demae iccho noodles|nissin noodles',{field:'noodle'});
const commands=[
 ['加','加|加多|加返|加埋|再加|另加|另叫|再要|另外要|再嚟|add|plus'],['轉','轉|改|改做|改成|轉做|轉成|換|換成|換做|換去|改為|改番|改返|change|switch|replace|make it|reduce to|increase to|change quantity to|減到|加到|減走|扣|少返'],['取消','取消|刪除|刪走|刪掉|移除|唔要嗰份|不要那份|remove|delete|cancel'],['撤銷','撤銷|撤回|復原|回復上一步|上一步|undo|undo that'],['照舊','照舊|再嚟一份|再來一份|重複上一份|再要同一款|same again|repeat last|another one'],['睇單','睇單|睇吓張單|看看訂單|查看餐單|核對|預覽|結帳|結賬|埋單|買單|落單|確認|得喇|可以喇|好喇|OK|okay|review order|preview|checkout|confirm'],['清空餐單','清空餐單|清空購物袋|全部取消|全部唔要|全部不要|清空|clear order|clear cart|cancel everything|remove everything'],['行街','行街|拎走|外賣|打包|攞走|帶走|takeaway|take away|takeout|take out|to go'],['堂食','堂食|喺度食|係度食|這裡吃|在這裡吃|dine in'],['有冇好介紹','有冇好介紹|有無好介紹|有咩好介紹|有乜好介紹|有甚麼推薦|有什麼推薦|推薦一下|推薦|推介|介紹|食咩好|唔知食乜|唔知食咩|有咩好食|recommend|recommendations|any recommendations|suggest|suggestions|what do you recommend|what is popular|best seller|best selling|popular'],['再介紹其他','再介紹其他|再推介其他|再推薦其他|換個組合|換一個組合|另一個組合|再介紹一個|有冇第二款|有沒有別的推薦|換個推介|下一個組合|suggest another combo|another suggestion|another combo|something else|show another combo']
];
for(const [target,terms]of commands)add('command',target,terms);
const phonetics=[
 ['冰火菠蘿油','波羅油|波蘿油|菠羅油|菠蘿有|菠蘿尤|菠蘿游','P1'],['金黃港式西多士','西多時|西多市|西多是','P2'],['火腿滑蛋三文治','火腿蛋三文志|火腿蛋三文智|火腿蛋三文至|火腿蛋三明志|腿蛋三文志|火腿蛋至','P3'],['滑蛋三文治','蛋至|蛋志|蛋三文志|滑蛋三文志|雞蛋三文志|滑蛋三明志','P6'],['奶油厚多士','奶油多時|奶油多市','P4'],['酥皮蛋撻','蛋達|蛋韃|蛋闥|酥皮蛋達','P5'],['早餐A','沙爹牛育|沙嗲牛育|沙爹牛玉|沙嗲牛玉','A'],['早餐B','火腿通分|火腿通芬|火腿通份','B'],['早餐C','餐肉雙旦|午餐肉雙旦','C'],['早餐D','差燒麵|差燒湯麵|叉燒湯綿','D'],['早餐E','腸仔煎旦|香腸雙旦|腸仔雙旦','E'],['早餐F','瘦肉周|瘦肉舟|瘦肉足','F'],['豉油皇炒麵','豉油黃炒麵|豉油王炒綿|豉油皇炒綿','N1'],['凍檸茶','凍零茶|凍檸查|凍靈茶|凍檸渣','T2'],['熱奶茶','熱奶查|絲襪奶查','T1'],['凍奶茶','凍奶查','T1'],['熱咖啡','熱咖非|熱加啡|熱飛','T3'],['凍咖啡','凍咖非|凍加啡|凍飛','T3'],['凍鴛鴦','凍鴛央|凍冤鴦','T4']
];
for(const [target,terms,id]of phonetics)add('phonetic',target,terms,{id,requires:'whole-phrase'});
for(const [target,terms,field]of [['少冰','小冰','ice'],['少甜','小甜','sugar'],['走青','走清','note'],['出前一丁','出錢一丁|出前一叮|叮麵','noodle'],['反蛋','反旦|翻旦','egg'],['炒蛋','炒旦','egg'],['轉煉奶','轉練奶','milk']])add('phonetic',target,terms,{field,requires:'option-context'});
const ambiguous=[
 ['菠蘿包|菠蘿飽|pineapple bun',['P1'],'plainBun'],['多士|厚多士|厚切多士|toast',['P4','P2'],'toastType'],['奶油|牛油多|鮮油多',['P4'],'toastSpread'],['凍茶|熱茶|一杯茶|茶|tea',['T1','T2'],'teaType'],['凍飲|熱飲|drink',['T1','T2','T3','T4'],'drinkType'],['粉麵|湯麵|noodles',['A','B','D'],'noodleType'],['餐肉|午餐肉|腸仔|香腸|火腿',['C','E','P3'],'dishOrIngredient'],['咖喱|加哩|咖哩',[],'curryNotCoffee'],['小米粥|白粥|靚女',[],'plainCongee']
];
for(const [terms,ids,reason]of ambiguous)add('ambiguous','',terms,{ids,reason});
const unavailable='白飯|靚仔|白粥|靚女|小米粥|皮蛋瘦肉粥|皮蛋粥|艇仔粥|魚片粥|魚腩粥|及第粥|雞粥|鮑魚粥|羅宋湯|紅湯|忌廉湯|白湯|粟米忌廉湯|是日例湯|餐蛋治|餐肉蛋治|午餐肉三文治|鹹牛肉三文治|鹹牛肉蛋治|未嘔住|鮮牛肉三文治|吞拿魚三文治|芝士三文治|公司三文治|總匯三明治|總匯三文治|奶醬多士|奶醬多|花生醬多士|占醬多士|果占多士|占多|乾炒牛河|濕炒牛河|豉椒牛河|星洲炒米|廈門炒米|揚州炒飯|福建炒飯|西炒飯|咸魚雞粒炒飯|菠蘿炒飯|咖喱雞飯|咖喱牛腩飯|咖喱飯|焗豬扒飯|焗海鮮飯|焗雞皇飯|粟米肉粒飯|粟米斑腩飯|叉燒飯|燒肉飯|燒鵝飯|油雞飯|豉油雞飯|雙拼飯|三寶飯|常餐|午餐|午市套餐|下午茶餐|豬扒包|雞扒包|魚柳包|熱狗|漢堡包|雞翼|炸雞翼|瑞士雞翼|炸薯條|咖喱魚蛋|雲吞麵|細蓉|大蓉|雲吞|水餃麵|牛腩麵|牛筋麵|魚蛋粉|魚片頭河粉|車仔麵|撈丁|乾撈麵|公仔撈麵|豬潤麵|豬肝麵|阿華田|好立克|美祿|朱古力|熱朱古力|凍朱古力|肥妹|敗家仔|檸七|檸檬七喜|檸賓|檸檬利賓納|檸樂|檸檬可樂|鹹檸七|鹹檸樂|忌廉溝鮮奶|忌廉鮮奶|鮮奶茶|杏仁霜|滾水蛋|炸彈|和尚跳海|滾水清蛋|西洋菜蜜|檸蜜|柚子蜜|熱檸水|凍檸水|檸水|凍檸啡|熱檸啡|梳打水|奶昔|紅豆冰|蓮子冰|菠蘿冰|什果賓治|冰淇淋|雪糕|拿鐵|latte|cappuccino|mocha|plain rice|plain congee|borscht|cream soup|curry rice|ham sandwich|corned beef sandwich|tuna sandwich|rice noodles with beef|beef chow fun|chicken wings|french fries|ovaltine|horlicks|hot chocolate';
add('unavailable','',unavailable);
g.CafeLexicon={version:3,entries,products,modifiers,commands};
})(globalThis);

(function(g){
const X=g.CafeExpansion,L=g.CafeLexicon;if(!X||!L)return;
const add=(kind,target,terms,meta={})=>terms.forEach(term=>L.entries.push({kind,target,term,...meta}));
const supported=new Set();
for(const m of X.foods){const terms=[m.name,m.en,...m.aliases,'港式'+m.name,'招牌'+m.name];for(const term of terms)supported.add(term.toLowerCase());add('item',m.name,terms,{id:m.id});}
for(const m of X.drinks){const terms=[m.name,m.en,...m.aliases];for(const term of terms)supported.add(term.toLowerCase());add('item',m.drink,terms,{id:m.id});for(const temp of m.temperatures){const variants=[temp,...(temp==='凍'?['冰','冷']:[])];for(const prefix of variants)for(const term of [m.family,...m.aliases.filter(v=>!/[a-z]/i.test(v)&&!v.startsWith('熱'))]){supported.add((prefix+term).toLowerCase());add('item',temp+m.family,[prefix+term],{id:m.id});}const en=(temp==='凍'?'iced ':'hot ')+m.en;supported.add(en.toLowerCase());supported.add(((temp==='凍'?'cold ':'hot ')+m.en).toLowerCase());add('item',temp+m.family,[en,(temp==='凍'?'cold ':'hot ')+m.en],{id:m.id});}add('phonetic',m.drink,m.phonetic,{id:m.id,requires:'whole-phrase'});for(const temp of m.temperatures)add('phonetic',temp+m.family,m.phonetic.map(t=>temp+t),{id:m.id,requires:'whole-phrase'});}
for(const x of X.extras){add('modifier',x.name,x.terms,{field:'extras'});const noun=x.name.slice(1);add('modifier','免'+x.name,['取消'+x.name,'唔要'+x.name,'不要'+x.name,'刪除'+x.name,'免'+x.name,'remove '+x.en.toLowerCase(),'no '+x.en.toLowerCase()],{field:'extras'});}
for(const [target,terms,field]of [
 ['大杯',['大杯','加大杯','轉大杯','large size','large cup','upsize'],'size'],['標準杯',['標準杯','細杯','普通杯','regular size','regular cup'],'size'],['轉鮮奶',['轉鮮奶','換鮮奶','用鮮奶','改鮮奶','fresh milk instead','with fresh milk'],'milk'],['轉燕麥奶',['轉燕麥奶','換燕麥奶','用燕麥奶','改燕麥奶','oat milk','with oat milk'],'milk'],
 ['不辣',['不辣','走辣','唔辣','唔要辣','不要辣','no spice','not spicy','no chilli'],'spice'],['少辣',['少辣','微辣','小辣','mild spice','mild spicy'],'spice'],['中辣',['中辣','medium spice','medium spicy'],'spice'],['大辣',['大辣','勁辣','多辣','extra spicy','hot spicy'],'spice'],['正常辣',['正常辣','標準辣','regular spice'],'spice'],
 ['少醬',['少醬','少汁','醬少啲','less sauce'],'sauce'],['正常醬汁',['正常醬汁','正常醬','regular sauce'],'sauce'],['走青',['走芽菜','唔要芽菜','no bean sprouts'],'note']
])add('modifier',target,terms,{field});
// A newly sold item takes priority over the old unavailable/ambiguous placeholder.
L.entries=L.entries.filter(e=>!(['unavailable','ambiguous'].includes(e.kind)&&supported.has(e.term.toLowerCase())));
add('phonetic','奶醬多士',['奶醬多時','奶將多士'],{id:'P13'});add('phonetic','乾炒牛河',['乾炒牛何','干炒牛何'],{id:'R1'});add('phonetic','揚州炒飯',['楊洲炒反','揚州炒反'],{id:'R3'});add('phonetic','焗豬扒飯',['焗豬爬飯','局豬扒飯'],{id:'R4'});add('phonetic','餐肉蛋三文治',['餐肉蛋三文志','餐蛋至'],{id:'P7'});
add('command','飲品稍後',['等陣先','等陣先叫','等陣叫飲品','遲啲先叫飲品','之後叫','遲啲叫','飲品遲啲先叫','啲飲品陣間先叫','杯嘢飲等陣先','杯嘢飲遲啲先','遲少少先叫飲品','飲品等陣先','飲品之後叫','稍後叫飲品','稍後再叫','later','order drinks later','drink later','drinks later']);add('item','熱薑煲可樂',['薑汁可樂','熱薑可樂','熱薑煲可樂','煲薑可樂','boiled ginger cola'],{id:'T28'});add('modifier','幼麵',['幼麵','細麵','蛋麵','thin egg noodles'],{field:'noodle'});add('modifier','河粉',['河粉','河粉底','flat rice noodles'],{field:'noodle'});L.version=4;
})(globalThis);

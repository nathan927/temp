/* Cantonese menu questions: browse a category or prepare an exact dish for review. */
(function(g){
 'use strict';
 const K=g.Kam,parse=K.parseCommand,analyze=K.analyzeLocal;
 const categories=[
  {id:'全部',label:'all',aliases:['全部餐點','全部餐牌','全部餐單','全部食物','所有餐點','所有餐牌','所有食物','成個餐牌','成張餐牌','整個餐牌','整張餐牌','完整餐牌','餐牌','餐單','所有嘢','全部','食物','嘢食','野食','食啲乜','食啲咩','all items','everything','full menu','menu','food','食']},
  {id:'早餐套餐',label:'catBreakfast',aliases:['早餐套餐','早晨套餐','早餐類','早餐餐牌','早餐餐單','早餐選擇','早餐組合','早晨餐','早餐','早飯','早歺','套餐類','套餐餐牌','套餐選擇','套餐組合','套餐','餐類','breakfast sets','breakfast set','breakfast','set meals','meal sets','combos','sets']},
  {id:'包點多士',label:'catBakery',aliases:['包點多士','麵包多士','三文治多士','三文治類','三明治類','三文治','三明治','多士類','多士','厚多士','烘多士','包點類','包點','麵包類','麵包','麪包','飽點','飽類','包類','包包','包','點心包點','bakery and toast','bakery','sandwiches','sandwich','toast','bread','buns']},
  {id:'單點小食',label:'catSnack',aliases:['單點小食','小食餐牌','小食類','小食','小吃','小吃類','小菜小食','炸物','炸嘢','煎炸小食','炸小食','食啲小食','零食','配菜','side dishes','sides','snacks','snack','appetizers']},
  {id:'飯麵主食',label:'catMains',aliases:['飯麵主食','飯麵類','飯麵','飯粉麵','粉麵飯','粉麵類','湯粉麵','粉麵','飯類','飯餸','碟頭飯','炒飯類','飯','麵類','湯麵類','麵食','麵','粥粉麵飯','粥類','粥','主食類','主食','正餐','rice and noodles','rice dishes','rice','noodle dishes','noodles','mains','main dishes','congee']},
  {id:'港式飲品',label:'catDrinks',aliases:['港式飲品','飲品餐牌','飲品餐單','飲品類','飲品選擇','飲品','飲料類','飲料','嘢飲','野飲','飲嘅','飲的','飲啲嘢','飲下嘢','飲吓嘢','凍熱飲','冷熱飲','熱飲類','熱飲','凍飲類','凍飲','冷飲','特飲','茶水','茶類','咖啡類','汽水類','奶茶類','茶飲','beverages','beverage','drinks','drink','hot drinks','cold drinks','iced drinks','refreshments','飲','飲嘢']}
 ];
 const escape=s=>s.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
 const aliasRows=categories.flatMap(c=>c.aliases.map(alias=>({alias:K.tc(alias).toLowerCase(),category:c.id})) ).sort((a,b)=>b.alias.length-a.alias.length);
 const query=/(?:有(?:啲|些什么|些什麼)?[咩乜]|有邊|有甚麼|有什麼|有乜嘢|乜嘢|咩款|咩種類|邊啲|邊款|邊種|乜款|咩好|what|which|show|browse|睇|看|望|瞄|帶我|去|揀|選擇|選項|選|介紹|搵|找|導航|跳|開|轉|切換|嗎|嘛|有冇|有無|有沒有|有否|喺邊|係邊|在哪|邊度)/i;
 const negative=/(?:唔好|唔想|唔使|唔洗|唔駛|唔要|唔叫|唔食|唔飲|唔係|不要|不想|不需要|別|毋須|咪)(?:再|去|幫|帶|睇|看|叫|食|飲|加|要|開|轉|取消)?|\b(?:do not|don't|dont|no thanks|not now)\b/i;
 const polite=/^(?:唔該(?:晒|曬|你(?!哋|地|們))?|麻煩(?:晒|曬|你(?!哋|地|們))?|請問(?:一下|下)?|我想問(?:一下|下|吓)?|想問(?:一下|下|吓)?|問(?:一下|下|吓)|請|你好|喂|hello|please|can you|could you)\s*/i;
 function clean(text){let s=K.tc(text).replace(/嚇/g,'吓').replace(/有(?:啲)?([咩乜])(?:嘢|野)/g,'有$1').trim().replace(/[，,。.!！?？；;]+$/g,'');for(let n=0;n<8;n++){const next=s.replace(polite,'').replace(/^(?:幫我|同我|替我|畀我|俾我)\s*/,'').replace(/^[\s，,。.!！?？]+/g,'').trim();if(next===s)break;s=next;}return s;}
 const openAliasRows=[...aliasRows,...['奶茶','咖啡','汽水','茶','檸茶','鴛鴦'].map(alias=>({alias,category:'港式飲品'}))].sort((a,b)=>b.alias.length-a.alias.length);
 function categoryHits(text){
  const rows=/(?:有(?:啲)?[咩乜]|有邊|什麼|甚麼|邊啲|邊款|what|which)/i.test(text)?openAliasRows:aliasRows;
  const s=K.tc(text).toLowerCase(),hits=[];
  for(let at=0;at<s.length;){const row=rows.find(r=>s.startsWith(r.alias,at)&&(!/^[a-z]/i.test(r.alias)||(!/[a-z]/i.test(s[at-1]||'')&&!/[a-z]/i.test(s[at+r.alias.length]||''))));
   if(row){hits.push({start:at,end:at+row.alias.length,...row});at+=row.alias.length;}else at++;
  }return hits;
 }
 const fillerWords=['你哋餐廳','你地餐廳','你哋店','你地店','你哋','你地','你們','你店','你度','呢度','這裏','這裡','貴店','店內','而家','依家','今日','現在','現時','仲有','重有','有沒有','有冇','有無','有否','有啲咩','有乜嘢','有什麼','有甚麼','有咩','有乜','有邊啲','有邊款','有邊種','有啲','有些','有得','供應','可以','可唔可以','可不可以','有','賣','買','食','飲','叫','點','咩嘢','乜嘢','咩','乜','邊啲','邊款','邊種','種類','款式','款','類別','類','選擇','選項','選','揀','嘅','的','畀我','俾我','幫我','同我','帶我','跳去','跳到','去到','睇睇','睇一睇','睇下','睇吓','睇返','睇番','睇','看看','看一下','看下','看','望下','望吓','瞄下','搵下','搵吓','搵','找','轉去','轉到','轉返','轉番','轉','切換到','切換','打開','開返','開番','開','展示','顯示','介紹下','介紹吓','介紹','導航去','導航到','導航','頁面','頁','嗰版','嗰頁','部分','分類','版面','一欄','一類','嗰類','嗰欄','嗰邊','嗰度','先','就','都','仲','重','下','吓','返','番','一下','一吓','啲','點樣','點','呀','啊','吖','啦','喇','呢','喎','囉','咯','啫','嘛','嗎','嘢','野','同埋','以及','或者','同','和','與','及','可供','得唔得','好','啱','唔知','想','要','我','到','去','入','得','咗','吖嘛','多謝','謝謝','喺邊度','係邊度','響邊度','喺邊','係邊','邊度','在哪裡','在哪裏','在哪','邊一頁','邊一版','落去','落到','下面','下邊','下便','上面','碌落去','碌落','拉落','捲到','捲去','滾到','睇埋','順便','邊幾款','邊幾種','幾款','幾種','嚟','埋','兼','俾','畀','個','張','份','杯','版','唔該晒','唔該曬','唔該你','唔該','麻煩你','麻煩','請問'];
 const fillerRE=new RegExp(fillerWords.sort((a,b)=>b.length-a.length).map(escape).join('|'),'g');
 const englishFiller=/\b(?:what|which|do|does|you|have|serve|sell|available|any|some|is|are|there|can|could|i|we|see|view|look|at|show|me|us|the|a|an|your|please|to|go|open|browse|category|section|options|choices|and|or|today|now|thanks|thank)\b/gi;
 const refuses=text=>negative.test(text.replace(/(?:唔要|不要|唔使|唔洗|唔駛)(?:糖|奶|冰|蛋|蔥|芫茜|湯|醬|汁|辣|花生)/g,''));
 function navigation(text){
  const s=clean(text);if(refuses(s))return null;
  if(/^(?:(?:第[一二兩三四五六七八九十\d]+份|全部|所有|每份|其中一份|頭先|最後)\s*)?(?:改|轉|換|要)(?:做|成|為|返|番)?(?:套餐|凍飲|熱飲)(?:呀|啊|啦|喇|先)?$/.test(s))return null;
  const hits=categoryHits(s);if(!hits.length)return null;
  let left=s.split('');for(const h of hits)for(let n=h.start;n<h.end;n++)left[n]=' ';
  const remainder=left.join('').replace(fillerRE,' ').replace(englishFiller,' ').replace(/[\p{P}\p{S}\s]/gu,'');
  if(remainder)return null;
  const bare=hits.length===1&&s.toLowerCase()===hits[0].alias;
  if(!bare&&!query.test(s)&&!/(?:有冇|有無|有沒有)/.test(s))return null;
  let ids=[...new Set(hits.map(h=>h.category))];if(ids.length>1&&ids.includes('全部'))ids=hits.some(h=>h.category==='全部'&&/全部|所有|完整|成張|成個|整張|整個/.test(h.alias)&&/餐牌|餐單|食物|餐點/.test(h.alias))?['全部']:ids.filter(id=>id!=='全部');
  return {intent:'navigate',categories:ids,ops:[],reason:'category-question'};
 }
 const existsPrefix=/^(?:(?:你哋(?:餐廳|店)?|你地(?:餐廳|店)?|你們|你度|呢度|這裏|這裡|貴店|店內)\s*)?(?:(?:而家|依家|今日|現在|現時|仲|重)\s*){0,3}(?:有沒有|有冇|有無|有否|有没|有得(?:叫|點|食|飲|買)?|有|賣唔賣|做唔做|整唔整|供唔供應|可唔可以(?:叫|點|要|食|飲|買)|可不可以(?:叫|點|要|吃|喝|買)|能不能(?:叫|點|要|吃|喝)|(?:如果|假如)有|do you have|do you serve|do you sell|is there|can i (?:have|get|order))\s*/i;
 const existsSuffix=/\s*(?:仲|重)?(?:有沒有|有冇|有無|有否|有得(?:叫|點|食|飲|買)|有嗎|有嘛|有咩|賣唔賣|做唔做|供唔供應|得唔得|可唔可以(?:叫|點|食|飲)?|available)\s*(?:呀|啊|吖|啦|呢|喎|嗎|嘛|啫|囉|咯|唔該|多謝|please|thanks)*$/i;
 const tail=/(?:仲有冇|仲有無|可唔可以|得唔得|係咪有|有得叫|有得食|有得飲|供應|可以叫|可以食|可以飲|畀我揀|俾我揀|有就要|有就叫|有就畀我|有就俾我|就要|就叫|賣|叫|食|飲|呀|啊|吖|啦|喇|呢|喎|嘛|嗎|啫|囉|咯|先|唔該(?:晒|曬)?|多謝(?:晒|曬)?|謝謝|please|thanks|thank you)[\s，,。.!！?？]*$/i;
 function inquiry(text,cart){
  const s=clean(text);if(refuses(s))return null;
  const price=/幾(?:多)?(?:錢|銀)|咩價|乜價|價錢|價位|how much|\bprice\b/i.test(s);
  if(price){const hits=K.findItems(s);if(hits.length===1){const m=K.menu.find(m=>m.id===hits[0].id);return {intent:'navigate',categories:[m.cat],focusItem:m.id,ops:[],reason:'item-price'};}return null;}
  let body=s.replace(existsPrefix,'');const prefix=body!==s;
  const withoutSuffix=body.replace(existsSuffix,'');const suffix=withoutSuffix!==body;body=withoutSuffix;if(prefix)body=body.replace(/^(?:得食|得飲|得叫|得買|賣|供應|整|做)\s*/,'');
  if(!prefix&&!suffix)return null;
  for(let n=0;n<8;n++){const next=body.replace(tail,'').trim();if(next===body)break;body=next;}
  if(!K.findItems(body).length)return null;
  const plan=parse(body,cart);
  if(!['add','edit'].includes(plan.intent)||!plan.ops?.length)return null;
  return {...plan,previewAfter:true,reason:'specific-item-question'};
 }
 function interpret(text,cart=[]){
  if(typeof text!=='string'||!text.trim())return null;if(text.length>2000)throw new K.OrderError('invalidInput');
  // Category-only grammar must consume the complete sentence. Exact dish names
  // and modifiers cannot disappear into broad category words such as 麵 or 包.
  return navigation(text)||inquiry(text,cart);
 }
 K.conversationalIntent=interpret;K.navigationCategories=categories;
 K.parseCommand=(text,cart=[])=>interpret(text,cart)||parse(text,cart);
 K.analyzeLocal=(text,cart=[])=>{const at=performance.now();try{const plan=interpret(text,cart);return plan?{decision:'local',plan,normalized:clean(text),corrections:[],elapsedMs:performance.now()-at}:analyze(text,cart);}catch(error){return {decision:error.code==='unrecognizedTokens'?'fallback':'clarify',error,elapsedMs:performance.now()-at};}};
 Object.assign(g.I18n.dict,{
  browseCategory:['已顯示：{name}','Showing: {name}'],
  voiceStats:['語音與本地判斷成效','Voice and local interpretation performance'],statsAll:['全部期間','All time'],statsToday:['今日','Today'],statsWeek:['最近七日','Last 7 days'],
  statsReceived:['已接收語音訊息','Voice messages received'],statsAPI:['曾呼叫 API 的訊息','Messages using an API'],statsLocal:['完全本地完成','Completed without app API'],statsModel:['需 API 解析的訊息','Messages using API interpretation'],
  statsEligible:['有 API 可用時接收 {n} 段，其中 {used} 段曾呼叫 API（{pct}%）。','{n} messages received with API available; {used} used it ({pct}%).'],
  statsDefinition:['每段已收到結果的落單語音或上傳錄音只計一次；重試不重複計數。麥克風測試、文字及手動操作不計。裝置語音服務本身的網絡行為不計入本程式 API。','Each received order recording or upload counts once, including retries. Mic tests, text and manual actions are excluded. Network use inside the device speech service is not counted as an app API call.'],
  statsASRLocal:['API 轉錄後，本地理解成功','API transcription, local interpretation'],statsASR:['曾用 API 轉錄','Used API transcription'],statsResolved:['已完成理解','Resolved'],statsClarify:['待用戶澄清','Needs clarification'],statsFailed:['未能完成','Failed'],statsPending:['處理中','Processing'],statsCalls:['API 請求次數','API requests'],statsRetries:['原音重試次數','Recording retries'],
  statsProvider:['供應商','Provider'],statsSuccess:['成功','Successful'],statsFailure:['失敗','Failed'],statsDaily:['每日統計','Daily statistics'],statsRecent:['最近訊息（最多 30 段）','Recent messages (up to 30)'],statsReason:['首次本地判斷／回退原因','First local decision / fallback reason'],statsNoData:['暫未接收落單語音。','No order voice messages yet.'],statsExport:['匯出完整統計 JSON','Export statistics JSON'],statsReset:['重設統計','Reset statistics'],statsResetTitle:['清除累計語音統計？','Reset voice statistics?'],statsResetHint:['會清除統計及訊息歷史，餐單和訂單不受影響。請先匯出需要保留的統計。','Clears statistics and message history. Your cart and orders are kept. Export the statistics first.'],statsStorage:['統計未能寫入本機儲存，請先匯出。','Statistics could not be saved locally. Export them before closing.']
 });
})(globalThis);

/* One validated path from an unresolved local phrase to a draft operation. */
(function(g){
 'use strict';
 const K=g.Kam;
 const eligible=result=>!!result?.plan?.partialUnresolved?.length||['fallback','clarify'].includes(result?.decision)&&['unrecognizedTokens','notUnderstood','needChange'].includes(result.error?.code);
 function providers(settings={},configured=[]){
  if(settings.parser==='off')return [];
  const preferred=['minimax','mimo'].includes(settings.parser)?settings.parser:null;
  return [...new Set([preferred,...configured].filter(p=>p&&configured.includes(p)))];
 }
 function failure(error,status){
  if(error instanceof K.OrderError)return error;
  const code=status===401?'apiInvalidKey':status===403?'apiForbidden':status===402?'apiQuota':status===429?'apiRateLimit':status>=500?'apiUnavailable':status===408||error?.name==='TimeoutError'||error?.name==='AbortError'?'timeout':status?'providerError':error?.name==='TypeError'?'network':'providerError';
  return new K.OrderError(code,{...(status?{status}:{})});
 }
 function validate(raw,state){
  const plan=K.readAI('parse',{output_text:JSON.stringify(raw)});
  if(['add','edit'].includes(plan.intent)&&!plan.ops.length&&!plan.preserveDraft)throw new K.OrderError('needChange');
  if(plan.intent==='clear'||plan.ops.some(op=>op.type==='clear')||plan.orderNotesClear)throw new K.OrderError('unsafeAIAction');
  // readAI validates JSON shape; transitionDraft checks applicability, stock,
  // target uniqueness, quantities, order notes and all clauses atomically.
  K.transitionDraft(state,plan,state.availability);
  return plan;
 }
 async function resolve({text,cart=[],context={},settings={},configured=[],parse,observe=()=>{},current=()=>true}={}){
  const local=K.analyzeLocal(text,cart,context);observe({phase:'local',result:local});
  const partial=!!local.plan?.partialUnresolved?.length;
  if(local.decision==='local'&&!partial)return {plan:local.plan,source:'dictionary',local};
  if(!eligible(local))throw local.error;
  const list=providers(settings,configured);if(!list.length){if(partial)return {plan:local.plan,source:'dictionary',local};throw local.error;}
  const state={...context,cart};let last;
  for(const provider of list){
   observe({phase:'api-request',provider});
   try{
    const raw=await parse(provider,text,cart,state);
    if(!current())throw new K.OrderError('staleVoiceOrder');
    const plan=validate(raw,state);
    if(partial){
     if(plan.intent!=='add'||plan.ops.some(op=>op.type!=='add'))throw new K.OrderError('apiLostKnownItems');
     const signature=item=>{const {uid,qty,pendingPair,drinkPrompted,...rest}=K.normalize(item);return JSON.stringify(rest);};
     const counts=new Map();for(const op of plan.ops){const key=signature(op.item);counts.set(key,(counts.get(key)||0)+op.item.qty);}
     for(const op of local.plan.ops){const key=signature(op.item),remaining=(counts.get(key)||0)-op.item.qty;if(remaining<0)throw new K.OrderError('apiLostKnownItems');counts.set(key,remaining);}
    }
    observe({phase:'validated',provider,plan});
    return {plan,source:'model',provider,local};
   }catch(error){
    last=failure(error);observe({phase:'api-failed',provider,error:last});
    if(['staleVoiceOrder','ambiguousTarget','notApplicable','conflictingOptions','invalidQty','unsafeAIAction','needClarification'].includes(last.code)){if(partial)break;throw last;}
   }
  }
  if(partial){observe({phase:'partial-preserved',error:last});return {plan:local.plan,source:'dictionary',local,partialApiError:last};}
  throw last||local.error;
 }
 K.fallbackFlow={eligible,providers,failure,validate,resolve};
 Object.assign(g.I18n.dict,{
  apiInvalidKey:['後備服務未認到呢條 API key，去設定核對金鑰同服務類型，再試一次吖。','The service rejected this API key. Check the key and API profile in Settings.'],
  apiForbidden:['呢條 key 暫時用唔到呢個模型。去設定揀返帳戶可用嘅服務，再試吖。','This key cannot access the selected model. Check its permissions and API profile.'],
  apiQuota:['後備服務嘅用量暫時唔夠喇。張單幫你留住，可以手動揀餐或者補回用量再試。','The service quota is exhausted. Your draft is kept; use the menu or restore quota.'],
  apiRateLimit:['後備服務而家有啲忙，等一陣再試吖。頭先嗰張單仲喺度。','The service is rate limited. Wait a moment and retry; your draft is kept.'],
  apiUnavailable:['後備服務暫時接唔到，張單幫你留好。可以再試，或者直接喺餐牌揀。','The fallback service is temporarily unavailable. Retry or use the menu; your draft is kept.'],
  unsafeAIAction:['呢個回覆會影響成張單，我想先問清楚。你講想改邊幾份吖，張單先幫你留住。','That response would affect the whole draft. Specify the items to change; I kept the draft.'],
  staleVoiceOrder:['你啱啱已經改過張單，舊回覆我先唔套用。照而家張單再講一次想點改吖。','The draft changed while the service was answering. Repeat the change for the current draft.'],
  auditReadFailed:['完整紀錄暫時讀唔齊，今次未下載。請再試，或者保持此頁開住先。','The complete history could not be read. No partial download was made. Retry while keeping this page open.'],
 });
})(globalThis);

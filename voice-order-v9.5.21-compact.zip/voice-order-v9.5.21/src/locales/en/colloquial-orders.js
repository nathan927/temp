/* Short references to the most recently added portion of the open draft. */
(function(g){
 'use strict';
 const K=g.Kam,baseAnalyze=K.analyzeLocal,baseParse=K.parseCommand;
 const grammar='colloquial-order';
 const {numPattern}=K.quantity;
 const same='我都要同一款|我都要一樣|我都要同樣|我都要同款|跟頭先一樣|同頭先一樣|重複頭先嗰份|照頭先嗰份|跟頭先嗰份|一份一樣|一份同款|一模一樣|再嚟同一款|再要同一款|再嚟個一樣|再嚟一個一樣|同一款|照頭先|照舊|照樣|同款|一樣|同樣|同上';
 const copyPhrase=new RegExp('^(?:'+same+')');
 const copyCount=new RegExp('^(跟多|再跟多|照樣再嚟|照舊再加|照頭先再加|同款再加|同樣再加|嚟多|來多|加多|再加多|再加|要多|叫多|整多|加返|添多|多|再嚟|再來|再要|再叫|再整)\\s*(?:多\\s*)?(?:('+numPattern+')\\s*)?([份個杯件碟碗])','i');
 const copyQualifier=/^\s*(?:一模一樣|同頭先一樣|同一款|一樣|同款|照頭先|照舊)\s*/;
 const override=/^\s*(?:但係|但系|但是|不過|不過就|但)\s*(?:係)?\s*(?:想要|想飲|想食|要|轉做|改做|換成|轉|改|換|配)?\s*|^\s*(?:想要|想飲|要|轉做|改做|換成|轉|改|換|配)\s*/;
 const contrast=/^(?:但係|但系|但是|不過|但)/;
 const speechRepair=/^(?:我)?(?:頭先|啱啱|剛才|剛剛)?(?:講錯|說錯|叫錯|落錯)(?:咗|左|了)?/;
 const recent='(?:頭先|啱啱|剛才|剛剛|最後|上一)(?:嘅)?(?:嗰[份個件]|一[份個件]|[份個件])';
 const remove='(?:唔要|不要|取消|刪走|攞走|撇走)';
 const removeRecent=new RegExp('^(?:'+recent+remove+'|'+remove+recent+')$');
 const negated=/^(?:我)?(?:唔好|唔使|唔洗|唔駛|咪|不要|唔要)/;
 const scopeAmbiguous=/^(?:成張單|整張單|成單|全單|全部|所有|同隔離枱)(?:都|要|再嚟|再叫)?(?:一樣|同款|照舊|照樣|同上)$/;
 const sameOrder=()=>({intent:'edit',ops:[],preserveDraft:true,grammar});
 const err=(code,data)=>{throw new K.OrderError(code,data);};
 // The shared cleaner treats sentence-final 先 as a filler. Here it is
 // part of the reference 照頭先, including before a transcribed pause.
 const clean=value=>K.language.clean(K.tc(value).replace(/照頭先/g,'照頭先')).replace(/照頭先/g,'照頭先');
 function copySpec(text){
  const amount=copyCount.exec(text);
  const literal=amount?null:copyPhrase.exec(text);
  const match=amount||literal;
  if(!match)return null;
  let tail=text.slice(match[0].length).trim();
  const qualifier=amount&&copyQualifier.exec(tail);
  if(qualifier)tail=tail.slice(qualifier[0].length);
  const connector=override.exec(tail);
  if(tail&&!connector&&!qualifier&&!/^跟多|^再跟多|^照|^同款再|^同樣再/.test(match[0]))return null;
  return {
   count:amount?{value:K.number(amount[2]??'一'),unit:amount[3],raw:amount[2]??'一'}:null,
   tail:connector?tail.slice(connector[0].length):tail,
   hasOverride:!!connector,
  };
 }
 function classified(text){
  return copySpec(text)||speechRepair.test(text)||removeRecent.test(text)||scopeAmbiguous.test(text);
 }
 function recognizes(text){
  if(classified(text))return true;
  const neg=negated.exec(text);
  return !!neg&&negatedCommand(text.slice(neg[0].length));
 }
 function negatedCommand(text){return !!(classified(text)||classified(text.replace(/^再/,'')));}
 function previous(cart,order){
  const id=K.normalizePortionOrder(cart,order).at(-1);
  const item=cart.find(line=>line.uid===id);
  if(!item)err('noRecentPortion');
  return item;
 }
 function copyPortion(spec,source,context){
  const menu=K.menu.find(item=>item.id===source.id);
  if(spec.count?.unit==='杯'&&!menu.drink)err('repeatPortionUnit');
  const qty=K.quantity.portions(menu,spec.count);
  if(qty>20)err('invalidQty');
  let item=K.normalize({...source,qty});
  if(spec.hasOverride&&!spec.tail)err('repeatNeedsOption');
  if(spec.tail){
   const temperature=/^(熱|凍)(?:飲|嘅|的)?$/.exec(spec.tail);
   let patch;
   if(temperature)patch={temperature:temperature[1]};
   else{
    const options=K.changeGrammar.slots(spec.tail,[item],true);
    if(options.foods.length||Object.keys(options.select).length)err('repeatNeedsOption');
    patch={...options.patch,...(options.drink?{drink:options.drink}:{})};
   }
   if(!Object.keys(patch).length)err('repeatNeedsOption');
   // Update a temporary copy using the same menu and modifier rules as a real edit.
   const updated=K.applyPlan([item],{intent:'edit',ops:[{type:'update',target:{uid:item.uid},patch}]},context.availability);
   item=updated.items[0];
   const effective=context.orderNotes?.length?K.effectiveItems([item],context.orderNotes)[0]:item;
   const conflict=Object.keys(patch).map(key=>key==='temperature'?'drink':key)
    .find(key=>Object.hasOwn(K.options,key)&&item[key]!==effective[key]);
   if(conflict)err('orderNoteConflict',{name:menu.name,option:conflict});
  }
  return {intent:'add',ops:[{type:'add',item}],grammar};
 }
 function single(text,cart,context){
  const neg=negated.exec(text);
  if(neg&&negatedCommand(text.slice(neg[0].length)))return sameOrder();
  if(scopeAmbiguous.test(text))err('repeatNeedsTarget');
  const repair=speechRepair.exec(text);
  const removeLast=removeRecent.test(text);
  if(repair&&repair[0]!==text&&!removeRecent.test(text.slice(repair[0].length)))err('repeatNeedsTarget');
  if(repair||removeLast){
   const item=previous(cart,context.portionOrder);
   return {intent:'edit',ops:[{type:'remove',target:{uid:item.uid,count:1}}],grammar};
  }
  const spec=copySpec(text);
  return spec?copyPortion(spec,previous(cart,context.portionOrder),context):null;
 }
 function clauses(text){
  const parts=[];
  for(const raw of text.split(/[，,；;。]+|(?:跟住|然後)(?=跟多|照樣|講錯|頭先一個)/)){
   const part=clean(raw);
   if(!part)continue;
   const previousCopy=copySpec(parts.at(-1)||'');
   if(previousCopy&&contrast.test(part))parts[parts.length-1]+=' '+part;
   else if(previousCopy&&K.changeGrammar.modifierOnly(part)){
    parts[parts.length-1]+=(previousCopy.hasOverride||previousCopy.tail?' ':'但要')+part;
   }else parts.push(part);
  }
  return parts;
 }
 function interpret(value,cart,context){
  if(typeof value!=='string'||!/[一樣同跟照再講說叫落刪唔剛最後頭啱取攞撇不嚟來加要整添多]/.test(value))return null;
  const text=clean(value),parts=clauses(text);
  if(!parts.some(recognizes))return null;
  const firstRepair=speechRepair.exec(parts[0]);
  if(parts.length===2&&firstRepair?.[0]===parts[0]&&removeRecent.test(parts[1]))parts.shift();
  const originalIds=new Set(cart.map(item=>item.uid));
  let items=cart.map(K.normalize),order=K.normalizePortionOrder(items,context.portionOrder);
  if(parts.length===1){
   const plan=single(parts[0],items,{...context,portionOrder:order});
   if(plan?.ops[0]?.target&&!originalIds.has(plan.ops[0].target.uid)){
    plan.ops[0].target={index:items.findIndex(item=>item.uid===plan.ops[0].target.uid),count:1};
   }
   return plan;
  }
  // A correction followed by other content could mean a replacement or a
  // change to the same item. Require the user to specify that separately.
  if(speechRepair.test(parts[0])&&parts.length===2&&/^(?:唔好|咪)(?:取消|刪走|刪除)$/.test(parts[1]))return sameOrder();
  if(parts.slice(0,-1).some(part=>speechRepair.test(part)||removeRecent.test(part)))err('repeatNeedsTarget');
  const ops=[];
  for(const part of parts){
   try{
    const own=single(part,items,{...context,portionOrder:order});
    const local=own?null:baseAnalyze(part,items,{...context,portionOrder:order});
    const plan=own||local.plan;
    if(!plan)throw local.error||new K.OrderError('needClarification');
    if((!own&&plan.intent!=='add')||plan.partialUnresolved?.length||plan.mode||plan.orderNotesAdd?.length||
     plan.ops.some(op=>!['add','remove'].includes(op.type)))err('needClarification');
    for(const op of plan.ops){
     if(op.target?.uid&&!originalIds.has(op.target.uid)){
      const {uid,...target}=op.target;
      ops.push({...op,target:{...target,index:items.findIndex(item=>item.uid===uid)}});
     }else ops.push(op);
    }
    const result=K.applyPlan(items,plan,context.availability,order);
    items=result.items;order=result.portionOrder;
   }catch(error){
    err(error.code||'needClarification',{...error.data,editClause:part});
   }
  }
  return {intent:ops.length&&ops.every(op=>op.type==='add')?'add':'edit',ops,grammar,...(!ops.length?{preserveDraft:true}:{})};
 }
 K.analyzeLocal=(text,cart=[],context={})=>{
  try{
   const plan=interpret(text,cart,context);
   return plan?{decision:'local',plan,normalized:clean(text),corrections:[]}:baseAnalyze(text,cart,context);
  }catch(error){return {decision:'clarify',error};}
 };
 K.parseCommand=(text,cart=[],context={})=>interpret(text,cart,context)||baseParse(text,cart,context);
})(globalThis);

/* User-authored aliases feed the normal local parser. No commands are
 * stored as executable plans and no alias is applied recursively. */
(function(g){
 'use strict';
 const K=g.Kam,analyze=K.analyzeLocal,parse=K.parseCommand;
 const maxPairs=250,sourceLimit=80;
 const textKey=value=>K.tc(String(value??'')).normalize('NFKC')
  .replace(/([\p{Script=Han}])\s+(?=[\p{Script=Han}])/gu,'$1').replace(/\s+/g,' ').trim().toLowerCase();
 const safeTarget=value=>typeof value==='string'&&value.trim()&&value.length<=2000&&!/[<>\u0000-\u001f]/.test(value);
 const safeSource=value=>value.length<=sourceLimit&&[...value.matchAll(/[\p{L}\p{N}]/gu)].length>=2&&
  /^[\p{L}\p{N}][\p{L}\p{N}\p{M} '’.-]*$/u.test(value);
 const orderExamples=['我要一樣','跟多份','跟多份但要熱奶茶','講錯咗','剛才一個唔要','取消上一份','轉堂食','轉外賣',
  '睇餐單','核對餐單','確認落單','有冇好介紹','有咩飲品揀','睇餐牌','還原頭先','清空餐單',
  '第三行改少冰','跟餐','再嚟兩份','飲品遲啲先揀','唔要餐具'];
 const priorities={unavailable:6,item:5,modifier:4,command:3,phonetic:2,ambiguous:1};
 const lexicon=new Map();
 for(const row of K.lexicon.entries){
  if((priorities[lexicon.get(row.term)?.kind]||0)<priorities[row.kind])lexicon.set(row.term,row);
 }
 const choices=new Map();
 for(const row of lexicon.values()){
  if(['unavailable','ambiguous'].includes(row.kind))continue;
  const kind=row.baseTerm?'command':row.field?'modifier':row.id&&row.kind!=='command'?'item':'command';
  choices.set(row.term,{text:row.term,kind,hint:row.target!==row.term?row.target:''});
 }
 for(const text of [...orderExamples,...K.language.clearPhrases,...K.language.resetPhrases]){
  const key=textKey(text);
  choices.set(key,{text,kind:'command',hint:''});
 }
 const builtins=[...choices.entries()];
 const compare=new Intl.Collator('zh-HK').compare;
 const isToken=target=>['item','modifier'].includes(choices.get(textKey(target))?.kind);
 const err=(code,data)=>{throw new K.OrderError(code,data);};
 function normalize(rows){
  if(!Array.isArray(rows))return [];
  const seen=new Set(),result=[];
  for(const row of rows.slice(0,maxPairs)){
   if(!row||typeof row.source!=='string'||row.source.length>sourceLimit||!safeTarget(row.target))continue;
   const key=textKey(row.source),target=row.target.trim();
   if(!safeSource(key)||key===textKey(target)||seen.has(key)||lexicon.has(key)||choices.has(key))continue;
   seen.add(key);result.push({source:row.source.trim(),target});
  }
  return result;
 }
 function search(value,extra=[]){
  const query=textKey(value);
  if(!query)return [];
  const found=new Map(builtins.filter(([key])=>key.includes(query)));
  for(const text of extra)if(safeTarget(text)){
   const key=textKey(text);
   if(key.includes(query)&&!found.has(key))found.set(key,{text,kind:'command',hint:''});
  }
  return [...found.entries()].sort(([a],[b])=>Number(b.startsWith(query))-Number(a.startsWith(query))||
   Number(b===query)-Number(a===query)||a.length-b.length||compare(a,b)).map(([,row])=>row);
 }
 function save(rows,source,target,cart=[],context={},editIndex=-1){
  source=String(source??'').trim();target=String(target??'').trim();
  const key=textKey(source),destination=textKey(target);
  if(!safeSource(key)||source.length>sourceLimit)err('manualPairSourceInvalid');
  if(!safeTarget(target)||!destination||key===destination)err('manualPairTargetInvalid');
  const next=normalize(rows);
  if(next.some((row,i)=>i!==editIndex&&textKey(row.source)===key))err('manualPairDuplicate');
  if(editIndex<0&&next.length>=maxPairs)err('manualPairLimit',{n:maxPairs});
  const sample=['A','B','C','D','E','F','T1','P1','Q1'].map((id,index)=>K.normalize({
   id,uid:'preview-'+index,drink:index<7?'凍奶茶':'',
  }));
  const drafts=[cart,[],sample,sample.slice(0,1)];
  if(lexicon.has(key)||choices.has(key)||drafts.some(items=>{
   const result=analyze(source,items,context);
   return result.decision==='local'&&!result.learned||result.decision==='clarify'&&
    !['unrecognizedTokens','notUnderstood','emptyInput','invalidInput'].includes(result.error?.code);
  }))err('manualPairSourceKnown');
  const rule=choices.get(destination);
  if(!rule||rule.kind==='command'){
   const contextErrors=new Set(['ambiguousTarget','missingTarget','emptyCart','notApplicable','fixedSugar']);
   const accepted=drafts.some(items=>{
    const result=analyze(target,items,context);
    return result.decision==='local'&&!result.plan.partialUnresolved?.length&&!result.plan.noteFallback||
     result.decision==='clarify'&&contextErrors.has(result.error?.code);
   });
   if(!accepted)err('manualPairTargetInvalid');
  }
  const pair={source,target};
  if(editIndex>=0&&editIndex<next.length)next[editIndex]=pair;
  else next.push(pair);
  return next;
 }
 const latin=ch=>/[a-z\d]/i.test(ch||'');
 function embedded(value,pairs){
  const text=textKey(value),spans=[];
  const tokens=pairs.filter(pair=>isToken(pair.target)).map(pair=>({...pair,key:textKey(pair.source)}))
   .sort((a,b)=>b.key.length-a.key.length);
  if(!tokens.length)return null;
  for(let at=0;at<text.length;){
   const token=tokens.find(({key})=>text.startsWith(key,at)&&
    !(latin(key[0])&&latin(text[at-1]))&&!(latin(key.at(-1))&&latin(text[at+key.length])));
   if(!token){at++;continue;}
   spans.push({start:at,end:at+token.key.length,from:token.source,to:token.target});
   at+=token.key.length;
  }
  if(!spans.length)return null;
  // Protect existing tokens that contain the user's phrase as a substring.
  // inspectLocal cleans politeness, so compare spans on its own source text.
  let known=[];
  try{const inspected=K.inspectLocal(text);const offset=text.indexOf(inspected.original);
   if(offset>=0)known=inspected.hits.map(hit=>({start:hit.start+offset,end:hit.end+offset}));
  }catch{}
  const used=spans.filter(span=>!known.some(hit=>hit.start<=span.start&&hit.end>=span.end));
  if(!used.length)return null;
  let output='',start=0;
  for(const span of used){
   output+=text.slice(start,span.start)+' '+span.to+' ';
   start=span.end;
  }
  return {text:(output+text.slice(start)).trim(),corrections:used.map(({from,to})=>({from,to}))};
 }
 function mapped(value,cart,context){
  if(!context.manualPairs?.length||typeof value!=='string'||value.length>2000)return null;
  const pairs=normalize(context.manualPairs);
  const raw=textKey(value),clean=textKey(K.language.clean(value));
  const exact=pairs.find(pair=>[raw,clean].includes(textKey(pair.source)));
  const rewrite=exact?{text:exact.target,corrections:[{from:exact.source,to:exact.target}]}:embedded(value,pairs);
  if(!rewrite)return null;
  // Keep existing commands even if a restored pair uses the same phrase.
  const original=analyze(value,cart,context);
  if(original.decision==='local'&&!original.learned&&!original.plan.partialUnresolved?.length)return original;
  const result=analyze(rewrite.text,cart,context);
  if(result.decision!=='local')return {...result,decision:'clarify'};
  return {...result,correctedText:rewrite.text,corrections:[...rewrite.corrections,...(result.corrections||[])]};
 }
 K.manualPairs={search,save,normalize,sourceLimit,isToken};
 K.analyzeLocal=(value,cart=[],context={})=>mapped(value,cart,context)||analyze(value,cart,context);
 K.parseCommand=(value,cart=[],context={})=>{
  const result=mapped(value,cart,context);
  if(result){if(result.plan)return result.plan;throw result.error;}
  return parse(value,cart,context);
 };
})(globalThis);

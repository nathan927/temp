(function (g) {
  'use strict';
  const K=g.Kam, originalParse=K.parseCommand, originalAnalyze=K.analyzeLocal;
  const dish=id=>K.menu.find(m=>m.id===id);
  const positive=/(?:跟餐|改(?:做|成|為)?套餐|轉(?:做|成)?套餐|換套餐|要套餐|要餐(?=$|[\s，,。.!！?？；;]|熱|凍)|升級(?:做|成)?套餐|make\s+(?:it\s+)?a\s+(?:set|combo)|upgrade\s+to\s+(?:a\s+)?(?:set|combo))/ig;
  const negative=/(?:唔|不|不要|唔使|唔洗|毋須|無需|唔好|唔係)(?:要|改|轉|做|成|為|升級)*\s*(?:跟餐|套餐|要餐(?=$|[\s，,。.!！?？；;]|熱|凍))|(?:淨係|只要|維持)?單點(?:就得|得喇)?$|\b(?:no|without)\s+(?:set|combo)\b/i;
  function eligible(cart) { return cart.filter(i=>dish(i.id)?.upgradeTo); }
  function upgradePlan(text,cart=[]) {
    const cleaned=K.language.clean(text),clean=cleaned==='餐'&&/要餐/.test(K.tc(text))?'要餐':cleaned;
    if (/^跟餐(?:杯[嘢野]飲|飲品|嗰杯|[嘢野]飲)/.test(clean)) return null;
    if (negative.test(clean)) {
      const hits=K.findItems(clean),targets=eligible(cart).filter(i=>hits.some(h=>h.id===i.id));
      if(hits.length&&!targets.length)return originalParse(clean.replace(negative,'').trim(),cart);
      if (!eligible(cart).length) throw new K.OrderError('noUpgradeable');
      return {intent:'edit',ops:[],declineUpgrade:true};
    }
    positive.lastIndex=0;
    if (!positive.test(clean)) return null;
    positive.lastIndex=0;
    const rest=clean.replace(positive,' ').trim();
    const hits=K.findItems(rest), mains=hits.filter(h=>dish(h.id)?.upgradeTo);
    if(hits.some(h=>!dish(h.id)?.drink&&!dish(h.id)?.upgradeTo))throw new K.OrderError('needClarification');
    const ordinal=rest.match(/第([一二兩三四五六七八九十\d]+)(?:份|個|項|餐)?/);
    let candidates=eligible(cart);
    if(ordinal) candidates=cart[Number(K.number(ordinal[1]))-1]?[cart[K.number(ordinal[1])-1]].filter(i=>dish(i.id)?.upgradeTo):[];
    else if (/頭先|最後|啱啱|上一份/.test(rest)) candidates=candidates.slice(-1);
    else if(mains.length) candidates=candidates.filter(i=>mains.some(h=>h.id===i.id));
    // A dish named in a new order can be upgraded in that same utterance.
    if(mains.length && (!candidates.length || /^(?:再加|另外|另叫|加多)/.test(clean)) && !ordinal) {
      let revised=rest;
      for(const h of [...mains].reverse()) revised=revised.slice(0,h.index)+dish(dish(h.id).upgradeTo).name+revised.slice(h.end);
      return originalParse(revised,cart);
    }
    if(!candidates.length) throw new K.OrderError(cart.some(i=>dish(i.id)?.combo)?'alreadyCombo':'noUpgradeable');
    const all=/全部|所有|每份/.test(rest);
    if(candidates.length>1&&!all) throw new K.OrderError('ambiguousTarget',{choices:candidates.map(i=>({index:cart.indexOf(i),uid:i.uid,id:i.id})),upgrade:true,text});
    let optionText=rest;
    for(const h of [...mains].reverse()) optionText=optionText.slice(0,h.index)+' '.repeat(h.end-h.index)+optionText.slice(h.end);
    optionText=optionText.replace(/第[一二兩三四五六七八九十\d]+(?:份|個|項|餐)?|頭先|最後|啱啱|上一份|全部|所有|每份/g,' ');
    // Validate every remaining word rather than silently dropping an unknown request.
    const prepared=optionText.trim()?K.prepareLocal(optionText,cart):{normalized:'',unknown:[]};
    if(optionText.trim()&&prepared.unknown.length) throw new K.OrderError('unrecognizedTokens',{tokens:prepared.unknown.join('、')});
    const {patch,conflicts}=K.parsePatch(prepared.normalized);
    if(conflicts.length) throw new K.OrderError('conflictingOptions',{options:conflicts});
    return {intent:'edit',ops:candidates.map(i=>({type:'update',target:{uid:i.uid,...(/其中一[份個]|one\s+of/i.test(clean)?{count:1}:{})},patch:{...patch,id:dish(i.id).upgradeTo}}))};
  }
  K.upgradePlan=upgradePlan;
  K.upgradeCandidates=eligible;
  K.parseCommand=(text,cart=[])=>upgradePlan(text,cart)||originalParse(text,cart);
  K.analyzeLocal=(text,cart=[])=>{
    try {const plan=upgradePlan(text,cart);return plan?{decision:'local',plan,normalized:K.language.clean(text),corrections:[]}:originalAnalyze(text,cart);}
    catch(error){return {decision:['unrecognizedTokens'].includes(error.code)?'fallback':'clarify',error};}
  };
  K.orderIntentsVersion=9;
  Object.assign(g.I18n.dict,{
    appVersion:['智能茶餐廳 · 第九版 9.5.21','Smart Cha Chaan Teng · 9.5.21'],
    appSubtitle:['語音落單・第九版 9.5.21','VOICE ORDER · 9.5.21'],
    upgradeTitle:['想唔想跟餐？','Make it a set?'],
    upgradeHint:['可講「跟餐」、「改套餐」或「要餐」。轉套餐會保留主食選項；熱飲已包，凍飲按餐牌加價。','Say “make it a set”. Main options are kept. Hot drink included; iced drinks cost extra.'],
    upgradeButton:['改套餐','Make it a set'],keepStandalone:['維持單點','Keep à la carte'],
    upgradePrice:['套餐主食價 {price}（每份）','Set base {price} per portion'],
    noUpgradeable:['餐單內沒有可轉套餐的單點主食。','There is no à la carte main eligible for a set.'],
    alreadyCombo:['這份已經係套餐，毋須再加一份。','This is already a set.'],
    settingsPassword:['設定密碼','Settings password'],settingsGate:['輸入密碼進入設定','Enter the password to open settings'],
    settingsUnlock:['進入設定','Open settings'],settingsWrong:['密碼不正確，請再試。','Incorrect password. Please try again.'],
    debugLog:['詳細 Debug Log','Detailed debug log'],debugHint:['記錄本機操作、解析、權限及語音流程；金鑰、密碼和原始錄音會遮蔽。','Local actions, parsing, permissions and speech events. Keys, passwords and raw audio are redacted.'],
    debugRefresh:['更新環境及權限狀態','Refresh environment and permissions'],debugExport:['匯出 JSON','Export JSON'],
    debugCopy:['複製記錄','Copy log'],debugClear:['清除記錄','Clear log'],debugFilter:['搜尋事件／錯誤','Search events / errors'],
    debugEmpty:['沒有符合篩選的記錄。','No matching entries.'],backSettings:['返回設定','Back to settings'],
    debugCopied:['記錄已複製','Log copied'],debugCount:['共 {n} 項；顯示最後 {shown} 項','{n} entries; showing the last {shown}']
  });
})(globalThis);

/* Recover recurring transcripts from the supplied 2026-11-05 field log.
 * Keep substitutions inside complete menu phrases and gate short replies on
 * explicit draft/recommendation context. Never invent missing ASR text. */
(function(g){
 'use strict';
 const K=g.Kam,analyze=K.analyzeLocal,parse=K.parseCommand;
 const grammar='field-recovery';
 const keep=()=>({intent:'edit',ops:[],preserveDraft:true,grammar});
 const fail=code=>{throw new K.OrderError(code);};
 function rewrite(value){
  if(typeof value!=='string')return value;
  return K.tc(value)
   .replace(/((?:早餐|早晨)\s*)(?:波|bo)(?:\s*餐)?(?=$|多謝|唔該|[\s，,。；;!?！？呀啊吖啦喇]|[一二兩三四五六七八九十\d份個凍熱飲轉改加唔])/gi,'$1B')
   .replace(/波\s*餐|\bbo\s*餐/gi,'B餐')
   .replace(/((?:早餐|早晨)\s*)(先|試|師|時|士|示|司|思|詩|斯|絲|西|啲|衣)(?=$|多謝|唔該|[\s，,。；;!?！？呀啊吖啦喇]|[一二兩三四五六七八九十\d份個餐凍熱飲轉改加唔])/g,
    (_,prefix,word)=>prefix+(word==='啲'?'D':word==='衣'?'E':'C'))
   .replace(/((?:早餐|早晨)\s*[A-F])\s*飲(?=(?:凍|熱)?(?:奶茶|檸(?:檬)?茶|咖啡|鴛鴦|菜蜜|西洋菜蜜|檸水|檸蜜|阿華田|好立克|美祿))/gi,'$1 ')
   .replace(/^((?:(?:老細|師傅|伙記|夥記|唔該|麻煩你)[\s，,]*)*)(?:餵|喂)[\s，,]*(?=有[冇無咩乜]|介紹|推介)/,'$1');
 }
 function special(value,cart,context){
  if(typeof value!=='string')return null;
  const text=K.language.clean(value);
  // A question about cancellation is not permission to remove anything.
  if(/^(?:要唔要|係咪唔要|係咪取消)(?:佢|嗰份|張單|訂單)?$/.test(text))fail('cancelQuestion');
  const cancel='(?:取消|刪走|清空)(?:而家|依家|呢張|張)?(?:訂單|訂餐|落單|草稿)';
  if(new RegExp('^(?:唔好|咪|唔使|不要)'+cancel+'$').test(text))return keep();
  if(new RegExp('^'+cancel+'$').test(text)){
   if(!cart.length)fail('draftEmptyCancel');
   return {intent:'clear',ops:[],grammar};
  }
  const next=/^(?:換(?:一些|一啲|一套|套|另一套|第二套|第二款|個款|款)|轉(?:一套|另一套|第二套)|再(?:換一套|換款))$/;
  if(next.test(text)){
   if(!context.recommendationActive)fail('recommendNeedsContext');
   return {intent:'recommend',ops:[],next:true,filter:{},grammar};
  }
  const dine='(?:煮飯堂食|煮返堂食|轉飯堂食)';
  if(new RegExp('^(?:唔好|咪|唔使|不要)'+dine+'$').test(text))return keep();
  if(new RegExp('^'+dine+'$').test(text))return {intent:'service',mode:'dinein',ops:[],grammar};
  if(/^(?:凍|熱)(?:啲)?$/.test(text)){
   const targets=cart.filter(item=>item.drink&&!['待選飲品','不需要飲品'].includes(item.drink));
   if(targets.length!==1)fail('temperatureNeedsTarget');
   return {intent:'edit',ops:[{type:'update',target:{uid:targets[0].uid},patch:{temperature:text[0]}}],grammar};
  }
  return null;
 }
 K.analyzeLocal=(text,cart=[],context={})=>{
  try{
   const normalized=rewrite(text),plan=special(normalized,cart,context);
   const result=plan?{decision:'local',plan,normalized,corrections:[]}:analyze(normalized,cart,context);
   if(normalized!==text&&result.plan)return {...result,phoneticRecovery:true,correctedText:normalized,
    corrections:[{from:text,to:normalized},...(result.corrections||[])]};
   return result;
  }catch(error){return {decision:'clarify',error};}
 };
 K.parseCommand=(text,cart=[],context={})=>special(rewrite(text),cart,context)||parse(rewrite(text),cart,context);
 K.fieldRecovery={rewrite};
 Object.assign(g.I18n.dict,{
  cancelQuestion:['想取消邊份呀？講清楚先，我幫你留住張單～','Which item would you like to cancel? I kept your draft.'],
  draftEmptyCancel:['而家冇未送出嘅餐點要取消喎～已落單嘅可以去「我的訂單」睇返。','There is no open draft to cancel. Check My Orders for submitted orders.'],
  recommendNeedsContext:['想換邊款呀？你可以話「有咩介紹」，我再幫你揀一套～','What would you like to change? Ask for a recommendation to see another combination.'],
  temperatureNeedsTarget:['想邊杯轉凍熱呀？講埋飲品名，我即刻幫你跟～','Which drink should I change? Please say its name.'],
 });
})(globalThis);

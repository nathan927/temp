(function(g){
'use strict';
const menu=[
 {id:'A',name:'沙嗲牛肉早餐',en:'Satay beef breakfast',price:42,cat:'早餐套餐',photo:0,badge:'招牌推介',desc:'秘製沙嗲牛肉湯麵 · 牛油多士 · 炒蛋',combo:true,noodle:'公仔麵',aliases:['早餐A','A餐','沙嗲牛肉麵套餐','沙嗲牛肉餐','沙爹牛肉餐']},
 {id:'B',name:'火腿通粉早餐',en:'Ham macaroni breakfast',price:39,cat:'早餐套餐',photo:1,badge:'經典之選',desc:'火腿清湯通粉 · 牛油多士 · 炒蛋',combo:true,noodle:'通粉',aliases:['早餐B','B餐','火腿通粉套餐','火腿通粉餐']},
 {id:'C',name:'餐肉雙蛋早餐',en:'Luncheon meat & eggs',price:40,cat:'早餐套餐',photo:2,desc:'香煎午餐肉 · 太陽雙蛋 · 牛油多士',combo:true,aliases:['早餐C','C餐','餐肉雙蛋套餐','餐肉雙蛋餐']},
 {id:'D',name:'叉燒湯麵早餐',en:'BBQ pork noodle breakfast',price:45,cat:'早餐套餐',photo:8,badge:'師傅推介',desc:'蜜汁叉燒湯麵 · 牛油多士 · 炒蛋',combo:true,noodle:'公仔麵',aliases:['早餐D','D餐','叉燒湯麵套餐','叉燒麵餐']},
 {id:'E',name:'腸仔煎蛋早餐',en:'Sausage & egg breakfast',price:41,cat:'早餐套餐',photo:9,desc:'香煎腸仔 · 雙蛋 · 厚切多士',combo:true,aliases:['早餐E','E餐','腸仔煎蛋套餐','腸仔煎蛋餐']},
 {id:'F',name:'生滾靚粥早餐',en:'Congee breakfast',price:38,cat:'早餐套餐',photo:10,desc:'綿滑瘦肉粥 · 即炸油條',combo:true,aliases:['早餐F','F餐','瘦肉粥套餐','瘦肉粥餐','粥餐']},
 {id:'P1',name:'冰火菠蘿油',en:'Pineapple bun & butter',price:24,cat:'包點多士',photo:3,badge:'每日新鮮焗',desc:'酥脆菠蘿包 · 厚切冰牛油',aliases:['菠蘿油','菠萝油']},
 {id:'P2',name:'金黃港式西多士',en:'Hong Kong French toast',price:32,cat:'包點多士',photo:4,badge:'必食',desc:'香濃花生醬夾心 · 牛油 · 糖漿',aliases:['西多士','西多']},
 {id:'P6',name:'滑蛋三文治',en:'Egg sandwich',price:24,cat:'包點多士',photo:16,desc:'即炒滑蛋 · 鬆軟方包 · 不含火腿',aliases:['蛋治','蛋三文治','雞蛋三文治']},
 {id:'P3',name:'火腿滑蛋三文治',en:'Ham & egg sandwich',price:28,cat:'包點多士',photo:5,desc:'即炒滑蛋 · 火腿 · 鬆軟方包',aliases:['火腿蛋三文治','腿蛋治','火腿蛋治']},
 {id:'P4',name:'奶油厚多士',en:'Condensed milk toast',price:22,cat:'包點多士',photo:12,desc:'金黃厚多士 · 牛油煉奶',aliases:['奶油多','奶油多士','厚多士']},
 {id:'P5',name:'酥皮蛋撻（兩件）',en:'Flaky egg tarts',price:20,cat:'包點多士',photo:13,desc:'每日新鮮焗 · 酥皮蛋香',aliases:['酥皮蛋撻','蛋撻','蛋挞']},
 {id:'N1',name:'豉油皇炒麵',en:'Soy sauce fried noodles',price:36,cat:'單點小食',photo:11,desc:'大火快炒 · 芽菜韭菜 · 鑊氣十足',aliases:['炒麵','炒面','豉油皇']},
 {id:'T1',name:'招牌絲襪奶茶',en:'Signature milk tea',price:22,cat:'港式飲品',photo:6,desc:'茶香濃郁 · 絲滑回甘',drink:'熱奶茶',aliases:['奶茶','熱奶茶','热奶茶']},
 {id:'T2',name:'手打凍檸茶',en:'Iced lemon tea',price:25,cat:'港式飲品',photo:7,desc:'新鮮檸檬 · 錫蘭紅茶',drink:'凍檸茶',aliases:['凍檸茶','冻柠茶','凍檸','冻柠']},
 {id:'T3',name:'即磨香濃咖啡',en:'Freshly brewed coffee',price:22,cat:'港式飲品',photo:14,desc:'深焙即磨 · 醇厚甘香',drink:'熱咖啡',aliases:['咖啡','熱啡','热啡','熱咖啡','斋啡','齋啡']},
 {id:'T4',name:'招牌凍鴛鴦',en:'Iced yuen yeung',price:25,cat:'港式飲品',photo:15,desc:'咖啡遇上奶茶 · 港式黃金比例',drink:'凍鴛鴦',aliases:['凍鴛鴦','鴛鴦','鸳鸯','冻鸳鸯']}
];
const expansion=g.CafeExpansion||{foods:[],drinks:[],extras:[]};menu.push(...expansion.foods,...expansion.drinks);
const drinks=['熱奶茶','熱咖啡','熱檸茶','熱鴛鴦','凍奶茶','凍咖啡','凍檸茶','凍鴛鴦','熱水','不需要飲品','待選飲品'];
const noodles=['公仔麵','出前一丁','通粉','米粉','意粉','幼麵','河粉'];
const sugars=['正常甜','少甜','半糖','走甜','多甜'];
const ices=['正常冰','少冰','走冰','多冰'];
const eggs=['炒蛋','太陽蛋','反蛋','熟蛋','走蛋'];
const portions=['正常份量','加底','少底'];
const broths=['正常湯','少湯','走湯','湯另上'];
const slicedBread=['方包','方包飛邊'];
const toasts=['正常多士','烘底','飛邊','烘底飛邊',...slicedBread];
const canSwapBread=m=>['A','B','C','D','E','P4','P13','P14','P15','P22'].includes(m.id);
const milks=['正常奶','走奶','少奶','多奶','轉煉奶','轉鮮奶','轉燕麥奶'];
for(const m of expansion.drinks)for(const temp of m.temperatures){drinks.push(temp+m.family);m.aliases.push(temp+m.family);}
const sizes=['標準杯','大杯'],spices=['正常辣','不辣','少辣','中辣','大辣'],sauces=['正常醬汁','少醬','走醬','醬汁另上','多醬汁'];
let convert=s=>s;try{if(g.OpenCC)convert=g.OpenCC.Converter({from:'cn',to:'tw'});}catch{}
const tc=s=>convert(String(s??'').normalize('NFKC')).replace(/冬(?=[0Tt央檸奶啡])/g,'凍').replace(/[面麪]/g,'麵').replace(/凍0T/gi,'凍檸茶').replace(/熱?0T/gi,'熱檸茶').replace(/凍T\b/gi,'凍奶茶').replace(/啡啡/g,'咖啡');
const uid=()=>g.crypto?.randomUUID?.()||'i'+Date.now().toString(36)+Math.random().toString(36).slice(2,9);
class OrderError extends Error{constructor(code,data={}){super(code);this.code=code;this.data=data;}}
const fail=(code,data)=>{throw new OrderError(code,data);};
const options={drink:drinks,noodle:noodles,sugar:sugars,ice:ices,egg:eggs,portion:portions,broth:broths,toast:toasts,milk:milks,size:sizes,spice:spices,sauce:sauces};
for(const m of menu){m.available=true;m.hasEgg=m.hasEgg??(!!m.combo&&m.id!=='F');m.bread=m.bread??(!!m.combo||['P1','P2','P3','P4','P6'].includes(m.id));m.base=m.base??!!m.noodle;m.recommended=['A','B','P1','P2','T1'].includes(m.id);m.allergens=m.allergens||(m.id==='P2'?['蛋','奶','麩質','花生']:m.id.startsWith('T')?['奶']:m.id==='N1'?['麩質','大豆']:['蛋','奶','麩質']);}
for(const [id,,terms] of g.CafeHK?.items||[]){
 const item=menu.find(m=>m.id===id);if(item)item.aliases.push(...terms.split('|'));
}
const aliases={A:['沙嗲牛肉早餐','沙爹牛肉早餐','satay beef breakfast','satay beef set'],B:['火腿通粉早餐','ham macaroni breakfast','ham macaroni set'],C:['餐肉雙蛋早餐','spam breakfast'],D:['叉燒湯麵早餐','bbq pork noodle breakfast'],E:['腸仔煎蛋早餐','sausage breakfast'],F:['生滾靚粥早餐','congee breakfast','pork congee breakfast'],P1:['菠蘿油','蘿柚','pineapple bun','pineapple butter bun'],P2:['西多士','西多','夏蕙姨','french toast'],P3:['火腿蛋治','腿蛋治','隊Q住','ham and egg sandwich'] ,P6:['蛋治','蛋三文治','雞蛋三文治','egg sandwich'],P4:['奶油多','奶油多士','condensed milk toast'],P5:['蛋撻','egg tart','egg tarts'],N1:['豉油皇','炒麵','fried noodles'],T1:['絲襪奶茶','奶茶','茶走','milk tea'],T2:['凍檸茶','凍檸','爆檸','凍0T','iced lemon tea','cold lemon tea'],T3:['熱咖啡','熱啡','咖啡','齋啡','齋非','啡走','汪阿姐','飛砂走奶','飛沙走奶','coffee','black coffee'],T4:['鴛鴦','央','yuen yeung','yin yang']};
for(const [id,terms] of Object.entries({T1:['熱奶茶','凍奶茶'],T2:['熱檸茶','凍檸茶'],T3:['熱咖啡','凍咖啡'],T4:['熱鴛鴦','凍鴛鴦']}))aliases[id].push(...terms);
const glossary=[
 ['熱啡／汪阿姐','熱咖啡','Hot coffee'],['凍檸／爆檸／凍0T','凍檸茶','Iced lemon tea'],['央／鴛鴦','咖啡與奶茶混合','Coffee and milk tea'],['丁麵／食丁','轉出前一丁，加 $3','Demae Iccho noodles, +$3'],['飛砂／飛沙／走甜','不加糖','No sugar'],['走奶','不加奶','No milk'],['飛砂走奶','咖啡不加糖、不加奶','Black coffee, no sugar'],['茶走','奶茶以煉奶代替淡奶','Milk tea with condensed milk'],['啡走','咖啡以煉奶代替淡奶','Coffee with condensed milk'],['少甜／少糖','減少糖量','Less sugar'],['半糖','半份糖','Half sugar'],['走冰／去冰','不加冰','No ice'],['少冰','減少冰量','Less ice'],['走青／飛青','不要蔥及芫茜','No spring onion or coriander'],['走蔥／走芫茜','不要指定香草配料','Omit the named herb'],['反蛋','兩面煎蛋','Egg fried on both sides'],['太陽蛋','單面煎蛋','Sunny-side-up egg'],['熟蛋','全熟蛋','Fully cooked egg'],['走蛋','不加蛋','No egg'],['加底','主食加量，加 $5','Extra base, +$5'],['扣底／少底','減少通粉、米粉或意粉；整塊麵餅不拆減','Smaller pasta or vermicelli portion'],['走湯','不加湯','No broth'],['湯另上','湯與主食分開','Broth on the side'],['烘底','烘烤麵包','Toasted bread'],['飛邊','去麵包皮','Remove bread crusts'],['走醬／走色','不加醬汁','No sauce'],['醬另上','醬汁分開','Sauce on the side'],['加色／多色','多醬汁，交廚房核對','Extra sauce; kitchen note'],['行街／拎走','外賣自取','Takeaway'],['堂食／喺度食','在餐廳用餐','Dine in'],['加單／加多','新增餐點','Add an item'],['轉／改／換','修改現有選項','Change an existing selection'],['取消／唔要','移除指定餐點','Remove the named item'],['照舊／再嚟一份','重複上一份餐點','Repeat the last item'],['蘿柚','菠蘿油','Pineapple bun with butter'],['夏蕙姨','西多士','French toast'],['隊Q住','火腿雞蛋三文治','Ham and egg sandwich'],['靚仔','白飯，本餐牌未供應','Plain rice; unavailable on this menu'],['靚女','白粥，本餐牌未供應','Plain congee; unavailable on this menu'],['紅湯','羅宋湯，本餐牌未供應','Borscht; unavailable on this menu'],['白湯','忌廉湯，本餐牌未供應','Cream soup; unavailable on this menu'],['炒底／打爛','白飯轉炒飯，本餐牌未供應','Fried rice base; unavailable on this menu'],['雙扣','少料兼少主食，需店員核對','Less topping and base; confirm with staff']
];
function defaults(m){return {uid:uid(),id:m.id,qty:1,noodle:m.noodle||'',drink:m.combo?'待選飲品':m.drink||'',sugar:'正常甜',ice:'正常冰',egg:!m.hasEgg?'走蛋':['C','E','Q3','Q5'].includes(m.id)?'太陽蛋':'炒蛋',portion:'正常份量',broth:'正常湯',toast:m.defaultToast||'正常多士',milk:'正常奶',note:'',drinkStatus:m.combo?'missing':'selected',drinkPrompted:false,pendingPair:!!m.drink&&!m.combo,extras:[],size:'標準杯',spice:'正常辣',sauce:'正常醬汁'};}
function normalize(input){
 if(!input||typeof input!=='object')fail('invalidItem');const m=menu.find(x=>x.id===input.id);if(!m)fail('unknownItem');
 const r=defaults(m);r.uid=typeof input.uid==='string'&&/^[\w-]{1,80}$/.test(input.uid)?input.uid:r.uid;
 const qty=Number(input.qty??1);if(!Number.isInteger(qty)||qty<1||qty>20)fail('invalidQty');r.qty=qty;
 for(const [k,vals]of Object.entries(options)){if(input[k]!==undefined&&input[k]!==''){if(!vals.includes(input[k]))fail('invalidOption',{option:k});r[k]=input[k];}}
 if(slicedBread.includes(r.toast)&&!canSwapBread(m))fail('notApplicable',{option:'toast',name:m.name});
 if(!m.combo&&!m.drink){r.drink='';r.milk='正常奶';r.sugar='正常甜';r.ice='正常冰';}
 if(!m.noodle){r.noodle='';r.broth='正常湯';}if(!m.base)r.portion='正常份量';
 if(m.drink&&!m.combo){const family=m.family?m.temperatures.map(v=>v+m.family):m.id==='T1'?['熱奶茶','凍奶茶']:m.id==='T2'?['熱檸茶','凍檸茶']:m.id==='T3'?['熱咖啡','凍咖啡']:['熱鴛鴦','凍鴛鴦'];if(!family.includes(r.drink))fail('drinkFamily');}
 if(r.portion==='少底'&&['公仔麵','出前一丁'].includes(r.noodle))fail('wholeNoodle');
 if(m.drink&&!m.combo)r.pendingPair=input.pendingPair!==false;else r.pendingPair=false;if(m.combo){r.drinkStatus=r.drink==='待選飲品'?(input.drinkStatus==='deferred'?'deferred':'missing'):'selected';r.drinkPrompted=!!input.drinkPrompted;}if(!m.hasEgg)r.egg='走蛋';if(!m.combo&&!m.drink)r.size='標準杯';if(!m.spicy)r.spice='正常辣';const additions=input.extrasAdd||[],removals=input.extrasRemove||[];if(!Array.isArray(input.extras||[])||!Array.isArray(additions)||!Array.isArray(removals))fail('invalidOption');r.extras=[...new Set([...(input.extras||[]),...additions])].filter(id=>!removals.includes(id));if(r.extras.some(id=>!allowedExtras(m,r).some(x=>x.id===id)))fail('notApplicable',{option:'extras',name:m.name});if(!drinkMilkAllowed(r.drink)&&r.milk!=='正常奶')fail('notApplicable',{option:'milk',name:m.name});const dm=drinkItem(r.drink);if(dm?.adjustSugar===false&&r.sugar!=='正常甜')fail('fixedSugar');r.note=String(input.note||'').trim().slice(0,240);return r;
}
function drinkItem(value){return menu.find(m=>m.drink&&m.drink.replace(/^[熱凍]/,'')===String(value).replace(/^[熱凍]/,''));}
function pendingDrinks(items){return items.filter(i=>mByEngine(i.id)?.combo&&i.drink==='待選飲品');}
const drinkFields=new Set(['uid','qty','drink','milk','sugar','ice','size','drinkStatus','drinkPrompted','extras']);
function foodIdentity(item){
 const food=Object.fromEntries(Object.entries(item).filter(([key])=>!drinkFields.has(key)));
 return JSON.stringify({...food,extras:item.extras.filter(id=>!['X9','X10'].includes(id))});
}
function completedDrinkUids(oldItems,newItems){
 const oldUids=new Set(oldItems.map(item=>item.uid)),newUids=new Set(newItems.map(item=>item.uid)),next=newItems.map(normalize);
 if(newUids.size!==next.length)return [];
 let index=0;const completed=[];
 for(const raw of oldItems){
  const old=normalize(raw);
  if(next[index]?.uid!==old.uid)return [];
  if(old.drink!=='待選飲品'){
   if(JSON.stringify(old)!==JSON.stringify(next[index++]))return [];
   continue;
  }
  const food=foodIdentity(old);let remaining=old.qty;
  while(remaining>0){
   const item=next[index++];
   if(!item||item.qty>remaining||item.uid!==old.uid&&oldUids.has(item.uid)||foodIdentity(item)!==food)return [];
   remaining-=item.qty;
   if(!['待選飲品','不需要飲品'].includes(item.drink))completed.push(item.uid);
  }
 }
 return index===next.length?completed:[];
}
function canCompleteDrinks(oldItems,newItems){return completedDrinkUids(oldItems,newItems).length>0;}
function drinkMilkAllowed(value){const m=drinkItem(value);return m?m.milkAllowed??['T1','T3','T4'].includes(m.id):false;}
function allowedExtras(m,i=defaults(m)){return expansion.extras.filter(x=>x.group==='drink'?!!i.drink&&!['不需要飲品','待選飲品'].includes(i.drink)&&(x.id==='X9'?/檸/.test(i.drink):i.drink.startsWith('凍')):x.group==='main'?!!(m.combo||m.base):!!(m.combo||m.base||/^P(?:3|6|7|8|9|10|11|12|17|18|19|20|21)$/.test(m.id)));}
function applicable(m,k,i=defaults(m)){return k==='drink'?!!(m.combo||m.drink):k==='milk'?!!i.drink&&drinkMilkAllowed(i.drink):k==='sugar'?!!i.drink&&drinkItem(i.drink)?.adjustSugar!==false:k==='ice'?i.drink.startsWith('凍'):k==='size'?!!i.drink&&!['不需要飲品','待選飲品'].includes(i.drink):['noodle','broth'].includes(k)?!!m.noodle:k==='portion'?!!m.base:k==='egg'?!!m.hasEgg:k==='toast'?!!m.bread:k==='spice'?!!m.spicy:k==='sauce'?!!(m.bread||m.base||m.id.startsWith('S')):true;}
function optionValues(m,k,i=defaults(m)){
 if(k==='toast'&&!canSwapBread(m))return toasts.filter(value=>!slicedBread.includes(value));
 return k==='drink'&&m.drink?(m.family?m.temperatures.map(v=>v+m.family):drinks.filter(v=>v.replace(/^[熱凍]/,'')===m.drink.replace(/^[熱凍]/,''))):options[k];}
function drinkSupplement(value){if(!value||value==='不需要飲品'||value==='熱水'||value==='待選飲品')return 0;const m=drinkItem(value);if(m?.comboSupplement!==undefined)return m.comboSupplement+(m.temperatures.length===2&&value.startsWith('凍')?3:0);return value.startsWith('凍')?3:0;}
function breakdown(raw,prices={}){const i=normalize(raw),m=menu.find(x=>x.id===i.id),base=Number.isFinite(+prices[m.id])?+prices[m.id]:m.price;const adjustments=[];const temp=m.drink?(m.temperatures?.length===1?0:(i.drink.startsWith('凍')?3:0)-(m.drink.startsWith('凍')?3:0)):m.combo?drinkSupplement(i.drink):0;if(temp||m.combo&&!['待選飲品','不需要飲品'].includes(i.drink))adjustments.push({label:i.drink,amount:temp});if(m.noodle&&i.noodle==='出前一丁'&&m.noodle!=='出前一丁')adjustments.push({label:i.noodle,amount:3});if(m.base&&i.portion==='加底')adjustments.push({label:i.portion,amount:5});if(i.drink&&i.size==='大杯')adjustments.push({label:'大杯',amount:5});if(i.drink&&i.milk==='轉鮮奶')adjustments.push({label:'轉鮮奶',amount:3});if(i.drink&&i.milk==='轉燕麥奶')adjustments.push({label:'轉燕麥奶',amount:5});for(const id of i.extras){const x=expansion.extras.find(x=>x.id===id);adjustments.push({label:x.name,amount:x.price});}const unitPrice=base+adjustments.reduce((n,x)=>n+x.amount,0);return{base,adjustments,unitPrice,qty:i.qty,lineTotal:unitPrice*i.qty};}
function ensureAvailable(i,availability={},skipMain=false){if(!skipMain&&availability[i.id]===false)fail('soldOut',{name:mByEngine(i.id)?.name});const d=drinkItem(i.drink);if(d&&availability[d.id]===false)fail('soldOut',{name:d.name});return i;}
function unit(i,prices={}){return breakdown(i,prices).unitPrice;}

function total(items,prices={}){return items.reduce((n,i)=>n+unit(i,prices)*i.qty,0);}
function details(i){const m=menu.find(m=>m.id===i.id);return[m.noodle&&i.noodle,m.hasEgg&&i.egg,i.drink==='待選飲品'&&i.drinkStatus==='deferred'?'跟餐飲品稍後補叫':i.drink,i.drink&&i.sugar!=='正常甜'&&i.sugar,i.drink.startsWith('凍')&&i.ice!=='正常冰'&&i.ice,i.drink&&i.milk!=='正常奶'&&i.milk,m.base&&i.portion!=='正常份量'&&i.portion,m.noodle&&i.broth!=='正常湯'&&i.broth,i.toast!=='正常多士'&&i.toast,i.size&&i.size!=='標準杯'&&i.size,m.spicy&&i.spice!=='正常辣'&&i.spice,i.sauce&&i.sauce!=='正常醬汁'&&i.sauce,...(i.extras||[]).map(id=>expansion.extras.find(x=>x.id===id)?.name),i.note].filter(Boolean);}
const chineseDigits='零〇一二兩三四五六七八九十廿卅卌百千萬半孖';
const hanQuantity='(?:負|[-−])?['+chineseDigits+']+';
const englishNumbers={a:1,an:1,one:1,two:2,three:3,four:4,five:5,six:6,seven:7,eight:8,nine:9,ten:10,eleven:11,twelve:12,thirteen:13,fourteen:14,fifteen:15,sixteen:16,seventeen:17,eighteen:18,nineteen:19,twenty:20};
const englishOverLimit='(?:twenty[- ](?:one|two|three|four|five|six|seven|eight|nine)|(?:thirty|forty|fifty|sixty|seventy|eighty|ninety)(?:[- ](?:one|two|three|four|five|six|seven|eight|nine))?)';
const numPattern='(?:[-−]?\\d+(?:[.點]\\d+)?|'+hanQuantity+'|\\b(?:'+englishOverLimit+'|'+Object.keys(englishNumbers).join('|')+')\\b)';
const hanClassifiers='份個杯件塊片隻條粒碗碟盤客套餐盅煲兜盒樽瓶罐支枝袋包串對打籃桶扎紮啖撮';
const classifierPattern='(?:打半|['+hanClassifiers+']|(?:servings?|portions?|sets?|cups?|pieces?|slices?|plates?|bowls?|bottles?|cans?|packs?|boxes?)\\b)';
const tailQuantity=new RegExp('('+numPattern+')\\s*(?:('+classifierPattern+')(?:\\s+of)?)?\\s*$','i');
const headQuantity=new RegExp('^\\s*(?:要(?:返|番)?\\s*)?('+numPattern+')\\s*('+classifierPattern+')','i');
const classifiedQuantity=new RegExp('('+numPattern+')\\s*('+classifierPattern+')','gi');
function number(value){
 const s=String(value??'').normalize('NFKC').trim().toLowerCase().replace(/兩/g,'二').replace(/〇/g,'零').replace(/−/g,'-').replace(/點/g,'.');
 if(Object.hasOwn(englishNumbers,s))return englishNumbers[s];
 if(/^-?\d+(?:\.\d+)?$/.test(s))return Number(s);
 const digits='零一二三四五六七八九';
 if(s.length===1&&digits.includes(s))return digits.indexOf(s);
 if(s==='半')return .5;
 if(s==='孖')return 2;
 const ten=s.match(/^([二三四五六七八九]?)十([一二三四五六七八九]?)$/);
 if(ten)return (ten[1]?digits.indexOf(ten[1]):1)*10+(ten[2]?digits.indexOf(ten[2]):0);
 const short=s.match(/^([廿卅卌])([一二三四五六七八九]?)$/);
 return short?('廿卅卌'.indexOf(short[1])+2)*10+(short[2]?digits.indexOf(short[2]):0):NaN;
}
function qtyMatch(match){
 return match?{value:number(match[1]),unit:match[2]||'',raw:match[1],index:match.index}:null;
}
const quantity={numPattern,classifierPattern,hanClassifiers,tail:text=>qtyMatch(tailQuantity.exec(text)),head:text=>qtyMatch(headQuantity.exec(text)),classified:text=>Array.from(text.matchAll(classifiedQuantity),qtyMatch),strip:text=>text.replace(classifiedQuantity,' '),portions:portionsOrdered,forTarget:quantityForTarget};
function portionsOrdered(menuItem,count){
 if(!count)return 1;
 const {value,unit,raw}=count;
 const units=unit==='打半'?value*12+6:value*(unit==='打'?12:unit==='對'?2:1);
 if(!Number.isInteger(units)||units<1||value<1&&!(value===.5&&unit==='打'))fail('invalidQty');
 if(menuItem.id==='P5'&&(/^(?:件|個|隻|塊|片|粒|對|打半|打|pieces?)$/i.test(unit)||!unit&&/^[a-z0-9]/i.test(raw))){
  if(units%2)fail('tartPack');
  return units/2;
 }
 return units;
}
const itemMatchers=menu.flatMap(item=>[...new Set([...(aliases[item.id]||[]),...(item.aliases||[]),item.name,item.en].flatMap(term=>[String(term).normalize('NFKC'),tc(term)]))].map(term=>({id:item.id,re:new RegExp(term.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'),'gi')}))),itemHitCache=new Map();
function foundItems(text){if(itemHitCache.has(text))return itemHitCache.get(text).map(h=>({...h}));const candidates=[];let m;const re=/(?:早餐|早晨|套餐|breakfast\s*(?:set)?|set|combo)\s*([a-f])\b|([a-f])\s*餐/gi;while((m=re.exec(text)))candidates.push({index:m.index,end:re.lastIndex,id:(m[1]||m[2]).toUpperCase()});for(const row of itemMatchers){row.re.lastIndex=0;while((m=row.re.exec(text)))candidates.push({index:m.index,end:row.re.lastIndex,id:row.id});}const milkEdits=[...text.matchAll(/(?:轉|換|改|用)(?:鮮奶|燕麥奶)|(?:with|instead of)\s+(?:fresh|oat)\s+milk/gi)].map(m=>({start:m.index,end:m.index+m[0].length}));for(let n=candidates.length-1;n>=0;n--)if(mDrink(candidates[n].id)&&milkEdits.some(m=>candidates[n].index>=m.start&&candidates[n].end<=m.end))candidates.splice(n,1);candidates.sort((a,b)=>a.index-b.index||(b.end-b.index)-(a.end-a.index));const hits=[];for(const h of candidates)if(!hits.some(x=>h.index<x.end&&h.end>x.index))hits.push(h);if(itemHitCache.size>2000)itemHitCache.delete(itemHitCache.keys().next().value);itemHitCache.set(text,hits);return hits.map(h=>({...h}));}
const patterns={
 noodle:[[/出前一丁|丁麵|食丁|demae\s*iccho|demae|nissin/i,'出前一丁'],[/公仔麵|即食麵|instant\s*noodles?/i,'公仔麵'],[/通粉|macaroni/i,'通粉'],[/米粉|rice\s*(?:noodles?|vermicelli)|vermicelli/i,'米粉'],[/意粉|spaghetti/i,'意粉']],
 drink:[[/凍(?:咖啡|啡)|(?:iced|cold)\s*(?:black\s*)?coffee/i,'凍咖啡'],[/熱(?:咖啡|啡)|齋[啡非]|啡走|汪阿姐|(?:飛砂|飛沙)走奶|(?:hot|black)\s*coffee/i,'熱咖啡'],[/凍檸(?:茶)?|爆檸|凍0t|(?:iced|cold)\s*lemon\s*tea/i,'凍檸茶'],[/熱檸(?:茶)?|hot\s*lemon\s*tea/i,'熱檸茶'],[/凍奶(?:茶)?|(?:iced|cold)\s*milk\s*tea/i,'凍奶茶'],[/熱奶(?:茶)?|茶走|hot\s*milk\s*tea/i,'熱奶茶'],[/凍鴛鴦|凍央|(?:iced|cold)\s*(?:yuen\s*yeung|yin\s*yang)/i,'凍鴛鴦'],[/熱鴛鴦|熱央|(?:hot)\s*(?:yuen\s*yeung|yin\s*yang)/i,'熱鴛鴦'],[/熱水|hot\s*water/i,'熱水'],[/奶茶|milk\s*tea/i,'熱奶茶'],[/咖啡|coffee/i,'熱咖啡'],[/鴛鴦|yuen\s*yeung|yin\s*yang/i,'熱鴛鴦']],
 sugar:[[/飛[砂沙]|齋[啡非]|走甜|走糖|無糖|唔要糖|不加糖|no\s*sugar|sugar\s*free|unsweetened/i,'走甜'],[/半糖|half\s*sugar/i,'半糖'],[/少甜|少糖|less\s*(?:sweet|sugar)/i,'少甜'],[/多甜|多糖|extra\s*sugar/i,'多甜'],[/正常甜|正常糖|regular\s*sugar/i,'正常甜']],
 ice:[[/走冰|去冰|無冰|唔要冰|no\s*ice|without\s*ice/i,'走冰'],[/少冰|less\s*ice|light\s*ice/i,'少冰'],[/多冰|extra\s*ice/i,'多冰'],[/正常冰|regular\s*ice/i,'正常冰']],
 milk:[[/茶走|啡走|煉奶|condensed\s*milk/i,'轉煉奶'],[/走奶|唔要奶|不加奶|齋[啡非]|black\s*coffee|no\s*milk|without\s*milk/i,'走奶'],[/少奶|less\s*milk/i,'少奶'],[/多奶|extra\s*milk/i,'多奶'],[/正常奶|regular\s*milk/i,'正常奶']],
 egg:[[/走蛋|唔要蛋|no\s*eggs?/i,'走蛋'],[/反蛋|over\s*easy|over\s*medium|both\s*sides/i,'反蛋'],[/太陽蛋|單面蛋|sunny\s*side\s*up/i,'太陽蛋'],[/熟蛋|全熟|well\s*done\s*eggs?/i,'熟蛋'],[/炒蛋|滑蛋|scrambled\s*eggs?/i,'炒蛋']],
 portion:[[/加底|extra\s*(?:base|noodles|pasta)|large\s*portion/i,'加底'],[/扣底|少底|少粉|small(?:er)?\s*portion|less\s*(?:pasta|vermicelli)/i,'少底'],[/正常份量|regular\s*portion/i,'正常份量']],
 broth:[[/湯另上|湯分開|broth\s*on\s*the\s*side|soup\s*on\s*the\s*side/i,'湯另上'],[/走湯|唔要湯|no\s*(?:broth|soup)|without\s*soup/i,'走湯'],[/少湯|less\s*(?:broth|soup)/i,'少湯'],[/正常湯|regular\s*broth/i,'正常湯']],
 toast:[[/烘底.*飛邊|飛邊.*烘底|toasted.*no\s*crust/i,'烘底飛邊'],[/飛邊|去邊|no\s*crust|crusts?\s*off/i,'飛邊'],[/烘底|烘多士|toasted\s*bread|toast\s*the\s*bread/i,'烘底']]
};
for(const m of expansion.drinks){const variants=m.temperatures.map(temp=>[temp+m.family,temp+m.family]);variants.push([m.family,m.drink]);for(const [term,value] of variants.sort((a,b)=>b[0].length-a[0].length))patterns.drink.unshift([new RegExp(term.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'),'i'),value]);}
patterns.drink=[...drinks.filter(v=>!['待選飲品','不需要飲品'].includes(v)).sort((a,b)=>b.length-a.length).map(v=>[new RegExp(v.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'),'i'),v]),...patterns.drink];
patterns.toast.unshift([/方包飛邊/i,'方包飛邊'],[/方包/i,'方包'],[/正常多士|regular\s*toast/i,'正常多士']);patterns.noodle.unshift([/幼麵/i,'幼麵'],[/河粉/i,'河粉']);patterns.milk.unshift([/轉燕麥奶/i,'轉燕麥奶'],[/轉鮮奶/i,'轉鮮奶']);patterns.size=[[/大杯/i,'大杯'],[/標準杯/i,'標準杯']];patterns.spice=[[/不辣/i,'不辣'],[/少辣/i,'少辣'],[/中辣/i,'中辣'],[/大辣/i,'大辣'],[/正常辣/i,'正常辣']];patterns.sauce=[[/醬汁另上/i,'醬汁另上'],[/走醬/i,'走醬'],[/少醬/i,'少醬'],[/多醬汁/i,'多醬汁'],[/正常醬汁/i,'正常醬汁']];
function parsePatch(text,{strict=false}={}){const patch={},conflicts=[];for(const [key,rows]of Object.entries(patterns)){const matches=[];for(const [re,val]of rows){const m=re.exec(text);if(m&&!matches.some(x=>m.index>=x.index&&m.index+m[0].length<=x.end))matches.push({val,index:m.index,end:m.index+m[0].length});}if(matches.length){matches.sort((a,b)=>a.index-b.index);const last=matches[matches.length-1];patch[key]=last.val;const unique=[...new Set(matches.map(x=>x.val))];if(unique.length>1&&(strict||!/改|轉|換|而係|instead|change|make\s*it|rather|to\s/i.test(text)))conflicts.push(key);}}
 const notes=[];for(const [re,note]of [[/走青|飛青|no\s*(?:spring\s*onion|herbs|coriander)/i,'走青（蔥及芫茜）'],[/走蔥|唔要蔥|no\s*onion/i,'走蔥'],[/走芫茜|no\s*coriander/i,'走芫茜'],[/醬另上|醬汁另上|sauce\s*on\s*the\s*side/i,'醬汁另上'],[/走醬|走色|no\s*sauce/i,'走醬'],[/加色|多色|多醬汁|extra\s*sauce/i,'多醬汁'],[/少油|less\s*oil/i,'少油'],[/少鹽|less\s*salt/i,'少鹽'],[/唔要牛油|走牛油|no\s*butter/i,'走牛油'],[/走花生|唔要花生|no\s*peanut/i,'不加花生；須店員確認過敏風險']])if(re.test(text))notes.push(note);if(notes.length)patch.note=notes.join('；');for(const x of expansion.extras){if(text.includes('免'+x.name))patch.extrasRemove=[...(patch.extrasRemove||[]),x.id];else if(text.includes(x.name))patch.extrasAdd=[...(patch.extrasAdd||[]),x.id];}return{patch,conflicts};}
function checkApplicable(m,patch,current=defaults(m)){const i={...current,...patch};for(const k of Object.keys(patch)){if(['id','qty','note','extras','extrasAdd','extrasRemove','drinkStatus','drinkPrompted','qtyDelta','temperature'].includes(k)||patch[k]===defaults(m)[k])continue;if(k==='sugar'&&drinkItem(i.drink)?.adjustSugar===false)fail('fixedSugar',{name:m.name});if(!applicable(m,k,i))fail('notApplicable',{option:k,name:m.name});}}
const extraDrink=new RegExp('(?:另外|再加|加多|另加|另叫|再要|再嚟|再來|單叫|單點|額外|加\\s*(?:'+numPattern+'\\s*)?'+classifierPattern+'|extra|separate|\\badd\\b|another|plus)','i');
const separateDish=/(?:[，,；;。]|同埋|跟住|然後|以及|同|及|和|與|\band\b)/i;
function parseAdd(text){
 const t=tc(text),all=foundItems(t),hasCombo=all.some(x=>mByEngine(x.id).combo);
 const main=all.filter((h,n)=>{
  if(!mDrink(h.id)||!hasCombo)return true;
  const gap=t.slice(all[n-1]?.end??0,h.index);
  return extraDrink.test(gap)||separateDish.test(gap)&&!!quantity.tail(gap);
 });
 if(!main.length)fail('notUnderstood');
 const gaps=main.map((h,n)=>t.slice(h.end,main[n+1]?.index??t.length));
 const prefixes=main.map((h,n)=>quantity.tail(n?gaps[n-1]:t.slice(0,h.index).replace(/[，,、；;\s]+$/u,'')));
 const tails=gaps.map((gap,n)=>prefixes[n+1]?gap.slice(0,prefixes[n+1].index):gap);
 const suffixes=tails.map((tail,n)=>{
  const atStart=quantity.head(tail);
  if(atStart||n<main.length-1||foundItems(tail).length)return atStart;
  const atEnd=quantity.tail(tail);
  return atEnd&&(atEnd.unit||!tail.slice(0,atEnd.index).trim())?atEnd:null;
 });
 // With no separator, a number between two dishes normally starts the
 // next dish. A postfix number on that next dish can disambiguate it.
 for(let n=main.length-1;n>0;n--){
  if(suffixes[n]&&prefixes[n]&&!suffixes[n-1]&&!tails[n-1].trim()){
   suffixes[n-1]=prefixes[n];prefixes[n]=null;
  }
 }
 const items=[],warnings=[];
 for(let n=0;n<main.length;n++){
  const h=main[n],m=mByEngine(h.id),ownTail=tails[n],seg=t.slice(h.index,h.end)+ownTail;
  const before=prefixes[n],postfix=suffixes[n];
  const qty=portionsOrdered(m,before||postfix);
  if(before&&postfix&&qty!==portionsOrdered(m,postfix))fail('invalidQty');
  const {patch,conflicts}=parsePatch(ownTail);
  if(m.drink){const drink=patterns.drink.find(([pattern])=>pattern.test(seg));if(drink)patch.drink=drink[1];}
  checkApplicable(m,patch);
  if(conflicts.length)fail('conflictingOptions',{options:conflicts});
  const item=Object.assign(defaults(m),patch,{qty});
  if(m.id==='T2'&&!/熱|hot/i.test(seg))item.drink='凍檸茶';
  if(m.id==='T4'&&!/熱|hot/i.test(seg))item.drink='凍鴛鴦';
  items.push(normalize(item));
 }
 if(/早餐\s*[g-z]|set\s*[g-z]\b/i.test(t))warnings.push('unknownSet');
 return {items,warnings};
}
const mByEngine=id=>menu.find(m=>m.id===id);const mDrink=id=>!!mByEngine(id)?.drink;
function resolveTarget(target={},cart){
 const suitable=(i)=>target.pendingDrink?cart[i].drink==='待選飲品':target.kind==='drink'?!!cart[i].drink&&cart[i].drink!=='不需要飲品':target.kind==='noodle'?!!mByEngine(cart[i].id).noodle:target.kind==='combo'?!!mByEngine(cart[i].id).combo:target.kind==='food'?!mByEngine(cart[i].id).drink:true;
 let list=cart.map((_,i)=>i).filter(suitable);
 if(target.uid)return list.filter(i=>cart[i].uid===target.uid);
 if(Number.isInteger(target.index))return cart[target.index]&&suitable(target.index)?[target.index]:[];
 if(target.last)return list.length?[list[list.length-1]]:[];
 if(target.id){const exact=list.filter(i=>cart[i].id===target.id);if(exact.length)return exact;const m=mByEngine(target.id);if(m?.drink&&target.kind==='drink')return list.filter(i=>cart[i].drink.replace(/^[熱凍]/,'')===m.drink.replace(/^[熱凍]/,''));return[];}
 if(target.drinkFamily)list=list.filter(i=>cart[i].drink.replace(/^[熱凍]/,'')===target.drinkFamily);if(target.drink)list=list.filter(i=>cart[i].drink===target.drink);return list;
}
function quantityForTarget(cart,target,match){
 const count=qtyMatch(match),indexes=resolveTarget(target,cart);
 const quantities=new Set(indexes.map(index=>portionsOrdered(mByEngine(cart[index].id),count)));
 if(quantities.size>1)fail('needClarification');
 return quantities.values().next().value??portionsOrdered({},count);
}
function singleCommand(text,cart=[]){const t=tc(text).trim(),empty={ops:[],warnings:[]};if(!t)fail('emptyInput');
 const unavailable=[[/靚仔|白飯|plain\s*rice/i,'白飯'],[/靚女|白粥|plain\s*congee/i,'白粥'],[/紅湯|羅宋湯|borscht/i,'羅宋湯'],[/白湯|忌廉湯|cream\s*soup/i,'忌廉湯'],[/炸彈|和尚跳海/,'該款飲品']].find(([r])=>r.test(t));if(unavailable)fail('unavailable',{name:unavailable[1]});
 if(/有[冇無]好介紹|有咩好介紹|推[薦介]|介紹|食咩好|recommend|suggest|best\s*sell|popular|another\s*(?:combo|suggestion)|其他組合|換[個一]組合/i.test(t)){return{...empty,intent:'recommend',next:/其他|再|另一|換|another|different|else|next/i.test(t),filter:{budget:(t.match(/(?:\$|HKD\s*|under\s*|below\s*|預算|预算)(\d+)|(\d+)蚊以[內下]/i)||[]).slice(1).find(Boolean),noBeef:/唔食牛|不吃牛|no\s*beef/i.test(t),vegetarian:/素食|vegetarian/i.test(t),noPeanut:/花生敏感|peanut\s*allergy/i.test(t)}};}
 if(/^(?:撤[銷回]|復原|undo|undo\s*that|上一步)[。.!！]?$/i.test(t))return{...empty,intent:'undo'};
 if(/^(?:全部(?:取消|唔要|清空)|清空(?:餐單|購物袋)?|cancel\s*everything|clear\s*(?:all|order|cart)|remove\s*everything)[。.!！]?$/i.test(t))return{...empty,intent:'clear'};
 if(/^(?:睇單|預覽|核對|結[賬帳]|買單|埋單|落單|確認|ok|okay|confirm|checkout|check\s*out|preview|review\s*(?:order)?)[。.!！]?$/i.test(t))return{...empty,intent:'preview'};
 if(/^(?:行街|拎走|外賣|打包|take\s*away|takeout|to\s*go)[。.!！]?$/i.test(t))return{...empty,intent:'service',mode:'takeaway'};
 if(/^(?:堂食|喺度食|在這[裏裡]吃|dine\s*in)[。.!！]?$/i.test(t))return{...empty,intent:'service',mode:'dinein'};
 const repeat=t.match(/^(?:再嚟|再來|再要|再叫)\s*(.+)$/);
 const repeatCount=repeat&&quantity.tail(repeat[1]);
 if((repeatCount?.index===0||/照舊|再嚟一份|再來一份|same\s*again|another\s*one|repeat\s*(?:that|last)/i.test(t))&&!foundItems(t).length){
  if(!cart.length)fail('emptyCart');
  const last=cart.at(-1),qty=portionsOrdered(mByEngine(last.id),repeatCount);
  return {...empty,intent:'add',ops:[{type:'add',item:{...last,uid:uid(),qty}}]};
 }
 const remove=!/免加/.test(t)&&/取消|刪[除掉]|唔要|不要|remove|cancel|delete|take\s*off/i.test(t)&&!/(?:唔要|不要)(?:糖|奶|冰|蔥|蛋|湯|醬|花生)|no\s*(?:milk|sugar|ice|onion|egg|soup|peanut)/i.test(t);
 const edit=!!cart.length&&(/改|轉|換|change|switch|replace|make\s*(?:it|the)|instead|reduce|increase|第二|第一|頭先|第\d|last\s*(?:one|item)|first\s*(?:one|item)|second|third/i.test(t)||!foundItems(t).length&&Object.keys(parsePatch(t).patch).length>0);
 if(remove||edit){let target={};const ordinal=t.match(/第([一二三四五六七八九十兩\d]+)(?:份|個|項|杯)?|\b(first|second|third|fourth|fifth)\b/i);if(ordinal)target.index=ordinal[1]?number(ordinal[1])-1:['first','second','third','fourth','fifth'].indexOf(ordinal[2].toLowerCase());else if(/頭先|最後|上一|last\s*(?:one|item|drink)|previous/i.test(t))target.last=true;
  const hits=foundItems(t);const first=hits[0];if(first&&!target.last&&target.index===undefined)target.id=first.id;if(/所有|全部|每[份杯個]|all\b|both\b/i.test(t))target.all=true;
  if(!first&&/嗰杯|那杯|杯嘢飲|飲品|the\s*drink|coffee|milk\s*tea/i.test(t)&&!target.last&&target.index===undefined)target.kind='drink';
  const split=/其中一[份個杯]|一[份個杯]改|one\s*of\s*(?:them|the)/i.test(t);if(split){target.count=1;if(first&&mDrink(first.id))delete target.id;}
  if(remove){if(/杯|飲品|drink|coffee|tea/i.test(t))target.kind='drink';return{...empty,intent:'edit',ops:[{type:'remove',target}]};}
  const optionText=(()=>{let a=t.split('');for(const h of hits)if(!mDrink(h.id))for(let j=h.index;j<h.end;j++)a[j]=' ';return a.join('');})();const {patch,conflicts}=parsePatch(optionText);if(target.index!==undefined||target.last||target.count){if(first&&mDrink(first.id))delete target.id;}if(conflicts.length)fail('conflictingOptions',{options:conflicts});const q=t.match(new RegExp('(?:改(?:做|成|為)?|轉|change(?:\\s*it)?\\s*to|make\\s*it|reduce\\s*to|increase\\s*to)\\s*('+numPattern+')\\s*('+classifierPattern+')','i'));if(q)patch.qty=quantityForTarget(cart,target,q);
  if(first&&hits.length>1&&/換|改|轉|replace.+with|switch.+to/i.test(t)){const last=hits[hits.length-1];if(last.id!==first.id&&(!mByEngine(first.id).combo||mByEngine(last.id).combo))patch.id=last.id;}if(patch.id&&[first?.id,hits.at(-1)?.id].some(id=>['P3','P6'].includes(id))){const rest=t.replace(/火腿滑蛋三文治|滑蛋三文治/g,' ');if(!/炒蛋|滑蛋|反蛋|熟蛋|太陽蛋|走蛋|scrambled|sunny|over easy/i.test(rest))delete patch.egg;}
  if(first&&mDrink(first.id)&&!cart.some(i=>i.id===first.id)&&Object.keys(patch).length){delete target.id;if(!Object.keys(target).length)target={};}if(!Object.keys(patch).length)fail('needChange');if(target.id===undefined&&target.index===undefined&&!target.uid){if(['drink','milk','sugar','ice'].some(k=>patch[k]))target.kind='drink';else if(patch.noodle||patch.portion||patch.broth)target.kind='noodle';}return{...empty,intent:'edit',ops:[{type:'update',target,patch}]};
 }
 const r=parseAdd(t);return{intent:'add',ops:r.items.map(item=>({type:'add',item})),warnings:r.warnings};
}
function parseCommand(text,cart=[]){
 const clean=tc(text);const clauses=clean.split(/(?:[，,；;。]\s*|\s+(?:and\s+then|then)\s+)(?=(?:其中|第[一二三四五六七八九十\d]|再加|加多|另外|改|轉|換|取消|刪|one of|change|remove|add|make))/i).flatMap(c=>c.split(/(?=其中一[份個杯]|one\s+of\s+them)/i)).map(s=>s.trim()).filter(Boolean);
 if(clauses.length<2)return singleCommand(clean,cart);
 let simulated=cart.map(normalize),ops=[],warnings=[];
 for(const c of clauses){const p=singleCommand(c,simulated);if(!['add','edit'].includes(p.intent))fail('needClarification');try{simulated=applyPlan(simulated,p).items;}catch(e){if(e.code==='ambiguousTarget')fail('needClarification');throw e;}ops.push(...p.ops);warnings.push(...(p.warnings||[]));}
 return{intent:'edit',ops,warnings};
}
function mergePatch(base,patch){const r={...base,...patch};
 if(patch.toast==='方包'&&['飛邊','烘底飛邊','方包飛邊'].includes(base.toast))r.toast='方包飛邊';
 if(patch.toast==='飛邊'&&slicedBread.includes(base.toast))r.toast='方包飛邊';if(patch.sauce!==undefined&&patch.sauce!==base.sauce){const derived=new Set(['走醬','醬汁另上','多醬汁']),kept=String(base.note||'').split('；').filter(n=>n&&!derived.has(n)),added=String(patch.note||'').split('；').filter(Boolean);r.note=[...new Set([...kept,...added])].join('；');}if(patch.drink&&patch.drink!==base.drink){if(!patch.milk&&!drinkMilkAllowed(r.drink))r.milk='正常奶';if(!patch.sugar&&drinkItem(r.drink)?.adjustSugar===false)r.sugar='正常甜';if(!r.drink.startsWith('凍'))r.ice='正常冰';if(!patch.extras)r.extras=(base.extras||[]).filter(id=>allowedExtras(mByEngine(r.id),r).some(x=>x.id===id));}return r;}
// Each entry points to one portion in chronological order. Several entries
// may point to the same displayed line after identical portions are grouped.
function normalizePortionOrder(cart,order){
 const counts=new Map(cart.map(item=>[item.uid,item.qty]));
 if(Array.isArray(order)&&order.length<=100){
  const remaining=new Map(counts);
  for(const id of order)remaining.set(id,(remaining.get(id)||0)-1);
  if([...remaining.values()].every(count=>count===0))return order.slice();
 }
 return cart.flatMap(item=>Array(item.qty).fill(item.uid));
}
function updatePortionOrder(order,id,delta){
 if(!order)return;
 if(delta>0)order.push(...Array(delta).fill(id));
 for(let n=order.length-1;n>=0&&delta<0;n--){
  if(order[n]===id){order.splice(n,1);delta++;}
 }
}
function moveRecentPortions(order,from,to,count){
 if(!order)return;
 for(let n=order.length-1;n>=0&&count>0;n--){
  if(order[n]===from){order[n]=to;count--;}
 }
}
function reconcilePortionOrder(before,order,after){
 const result=normalizePortionOrder(before,order),newCounts=new Map(after.map(item=>[item.uid,item.qty]));
 const oldCounts=new Map(before.map(item=>[item.uid,item.qty]));
 for(const item of before)updatePortionOrder(result,item.uid,Math.min(0,(newCounts.get(item.uid)||0)-item.qty));
 for(const item of after)updatePortionOrder(result,item.uid,Math.max(0,item.qty-(oldCounts.get(item.uid)||0)));
 return result;
}
function applyPlan(cart,plan,availability={},portionOrder){
 let next=cart.map(normalize);
 const changes=[],order=portionOrder===undefined?null:normalizePortionOrder(next,portionOrder);
 if(plan.intent==='clear')return{items:[],changes:next.map(i=>({type:'remove',id:i.id,before:i})),...(order?{portionOrder:[]}:{})};
 for(const op of plan.ops||[]){
  if(op.type==='clear'){changes.push(...next.map(i=>({type:'remove',id:i.id,before:i})));next=[];if(order)order.length=0;continue;}
  if(op.type==='add'){const i=ensureAvailable(normalize(op.item),availability);i.uid=uid();next.push(i);updatePortionOrder(order,i.uid,i.qty);changes.push({type:'add',id:i.id,qty:i.qty,after:i});continue;}
  if(!['update','remove'].includes(op.type))fail('invalidPlan');const indexes=resolveTarget(op.target,next).filter(index=>!op.patch?.temperature||!op.target?.kind||op.target.kind!=='drink'||!!next[index].drink&&!['待選飲品','不需要飲品'].includes(next[index].drink));if(!indexes.length)fail('missingTarget');if(indexes.length>1&&!op.target?.all)fail('ambiguousTarget',{choices:indexes.map(index=>({index,uid:next[index].uid,id:next[index].id}))});
  for(const n of [...indexes].reverse()){const old=next[n],oldMenu=mByEngine(old.id),count=op.target?.count;
   if(count!==undefined&&(!Number.isInteger(count)||count<1||count>old.qty))fail('invalidQty');
   if(op.type==='remove'){
    if(op.target?.kind==='drink'&&oldMenu.combo){
     const withoutDrink=normalize({...old,drink:'不需要飲品',milk:'正常奶',sugar:'正常甜',ice:'正常冰',size:'標準杯',extras:old.extras.filter(id=>!['X9','X10'].includes(id))});
     if(count&&count<old.qty){
      const separated={...withoutDrink,uid:uid(),qty:count};
      next[n]={...old,qty:old.qty-count};
      next.splice(n+1,0,separated);
      moveRecentPortions(order,old.uid,separated.uid,count);
     }else next[n]=withoutDrink;
     changes.push({type:'update',id:old.id,before:{...old,qty:count??old.qty},after:{...withoutDrink,qty:count??old.qty}});
    }else{
     const removed=count??old.qty;
     if(removed<old.qty)next[n]={...old,qty:old.qty-removed};
     else next.splice(n,1);
     updatePortionOrder(order,old.uid,-removed);
     changes.push({type:'remove',id:old.id,before:{...old,qty:removed}});
    }
    continue;
   }
   const patch={...(op.patch||{})};if(patch.qtyDelta!==undefined){if(!Number.isInteger(patch.qtyDelta)||Math.abs(patch.qtyDelta)>20)fail('invalidQty');patch.qty=old.qty+patch.qtyDelta;delete patch.qtyDelta;if(patch.qty===0){next.splice(n,1);updatePortionOrder(order,old.uid,-old.qty);changes.push({type:'remove',id:old.id,before:old});continue;}}
   if(op.target?.kind==='drink'&&oldMenu.combo&&(patch.qty!==undefined||patch.qtyDelta!==undefined)&&patch.qty!==old.qty)fail('drinkQuantityChange');if(patch.temperature){if(!['熱','凍'].includes(patch.temperature)||!old.drink||['待選飲品','不需要飲品'].includes(old.drink))fail('needChange');patch.drink=patch.temperature+old.drink.replace(/^[熱凍]/,'');delete patch.temperature;}
   const newId=patch.id||(oldMenu.drink&&patch.drink?drinkItem(patch.drink)?.id:old.id),m=mByEngine(newId);if(!m)fail('unknownItem');const skipMain=newId===old.id&&old.drink==='待選飲品'&&!!patch.drink;if(availability[newId]===false&&!skipMain)fail('soldOut',{name:m.name});
   let base=newId===old.id?old:{...defaults(m),qty:old.qty};if(newId!==old.id&&(oldMenu.upgradeTo===m.id||m.upgradeTo===oldMenu.id)){for(const k of ['noodle','egg','portion','broth','toast','spice','sauce'])if(applicable(m,k,base)&&applicable(oldMenu,k,old))base[k]=old[k];base.note=old.note;base.extras=old.extras.filter(id=>allowedExtras(m,base).some(x=>x.id===id));}else if(newId!==old.id&&oldMenu.combo&&m.combo){for(const k of ['drink','drinkStatus','drinkPrompted','sugar','ice','milk','size'])base[k]=old[k];base.extras=old.extras.filter(id=>['X9','X10'].includes(id));}else if(newId!==old.id&&oldMenu.drink&&m.drink){base.size=old.size;if(drinkMilkAllowed(patch.drink||base.drink))base.milk=old.milk;if(m.adjustSugar!==false)base.sugar=old.sugar;if((patch.drink||base.drink).startsWith('凍'))base.ice=old.ice;}
   checkApplicable(m,patch,base);
   const split=count&&old.qty>count;
   const updated=ensureAvailable(normalize({...mergePatch(base,patch),uid:split?uid():old.uid,...(split?{qty:count}:{})}),availability,skipMain);
   if(split){
    next[n]={...old,qty:old.qty-count};
    next.splice(n+1,0,updated);
    moveRecentPortions(order,old.uid,updated.uid,count);
   }else{
    next[n]=updated;
    updatePortionOrder(order,old.uid,updated.qty-old.qty);
   }
   changes.push({type:'update',id:newId,uid:updated.uid,fields:Object.keys(patch),before:split?{...old,qty:count}:old,after:updated});
  }
 }
 if(next.length>50||next.reduce((n,i)=>n+i.qty,0)>100)fail('orderLimit');return{items:next,changes,...(order?{portionOrder:order}:{})};
}
function recommendations(orders=[],availability={},filter={},prices={}){if(filter.vegetarian||filter.noPeanut)return[];const sales={};for(const o of orders.filter(o=>o.status==='completed'))for(const i of o.items||[])sales[i.id]=(sales[i.id]||0)+i.qty;const ranked=Object.keys(sales).filter(id=>menu.find(m=>m.id===id)?.combo&&availability[id]!==false).sort((a,b)=>sales[b]-sales[a]);const curated=[{ids:['A','P1'],reason:'signature'},{ids:['B','P5'],reason:'classic'},{ids:['C','S3'],reason:'hearty'},{ids:['D','P2'],reason:'chef'},{ids:['E','P3'],reason:'sharing'},{ids:['F','P1'],reason:'gentle'}];const list=[];if(ranked.length)list.push({ids:[ranked[0]],reason:'bestseller',sales:sales[ranked[0]]});for(const c of curated)list.push(c);return list.filter(c=>c.ids.every(id=>availability[id]!==false)&&(!filter.noBeef||!c.ids.includes('A'))).map(c=>({...c,items:c.ids.map(id=>{const m=menu.find(m=>m.id===id);return normalize({...defaults(m),...(m.combo?{drink:'熱奶茶'}:{})});})})).filter(c=>!filter.budget||total(c.items,prices)<=+filter.budget);}
const prompt='You are a transactional Hong Kong cha chaan teng order interpreter. Interpret an English-speaking customer on the English page. Use only this page language, its catalog and its own supplied context; never borrow learned phrases from another language. NO CHAT. Output JSON only: {"intent":"add|edit|recommend|undo|clear|preview|service|navigate|customize","ops":[{"type":"add","item":{...}} or {"type":"update|remove","target":{"uid":"existing UID" or "index":0 or "id":"A" or "all":true,"count":1 optional},"patch":{...}}],"warnings":[],"unresolved":[],"next":false,"filter":{},"mode":"dinein|takeaway"}. Optional localRewrite: give one canonical English utterance using menu names, explicit quantities, options and target, with exactly the same draft effect and preview behavior, so a local interpreter can replay it. Omit it if ambiguous. Use canonical Traditional Chinese option values. 公司三文治 is the club sandwich; never substitute it for 總匯三文治 or a generic triple-decker sandwich. Accept Cantonese quantity classifiers flexibly (份, 個, 杯, 件, 塊, 條, 碟, and others) before or after each named dish. 加份, 加多份, 再加份 mean one additional portion. Preserve each exact quantity in mixed orders. Egg tarts are sold in packs of two; an explicit piece count must be even. 轉外賣,打包,拎走,叫外賣 set mode takeaway; 轉堂食,喺度食 set mode dinein. Bare mode changes return intent service with no item operations and preserve the cart. Fees are computed locally; never invent fees, alter rates or add packaging as food. Whole-order cooking requests return intent customize, ops [], orderNotesAdd:[the request]. Use orderNotesRemove/orderNotesClear when explicitly requested. If food parameters cannot represent a cooking request, preserve its full wording as a kitchen note. Never interpret 唔要餐具 as removing food. A specific availability question such as 有無腿蛋治 prepares that exact catalog item as a draft with previewAfter true; never confirm it. Category-only questions such as 有咩飲呀 / 有咩飲品揀 return intent navigate, ops [], categories using only 全部,早餐套餐,包點多士,單點小食,飯麵主食,港式飲品. Navigation never adds, removes or edits food. Price-only questions browse the matching item, never add it. Negative or ambiguous requests need clarification. 全部唔要喇 and 重新落單 clear the current draft only. A reset followed by new items uses an op type clear before the adds. 改叫A餐 replaces the sole matching food/set, preserves its quantity and included beverage, and never adds a second meal. 飲品改做X changes the included drink; standalone drinks change their catalog ID. Never ask customers to repeat default noodle/egg choices. Never invent items, prices, availability, sales, allergies or confirmations. Bare main names such as 沙嗲牛肉麵 are standalone Q1-Q6, with no drink. Explicit 早餐A-F are sets. 跟餐 / 改套餐 / 要餐 upgrades an existing eligible Q item to its upgradeTo ID, preserving quantity and food customisations. If multiple mains qualify, request clarification. Never add a duplicate meal for an upgrade. Each set includes one drink. If the drink is not specified, use 待選飲品 and drinkStatus missing; never assume milk tea. 客人說等陣先/之後叫 means keep drink pending with drinkStatus deferred. Standard hot drinks add zero, standard iced drinks add only 3. A bare drink after a pending set fills its included drink unless explicitly extra. For A改B / 由A改做B, A and its old modifiers select existing lines and ONLY B supplies the patch. Exact old temperature/sugar/noodle/egg values must match; never retarget a missing A to another item. Bare 正常 on a beverage means 正常甜. 其中一杯/其中一份 splits one portion, while 第一份 is the whole first cart line. 唔好將A改B preserves the draft; 唔係要A，改要B is a correction. Validate all clauses atomically. Preserve context: modify existing items when asked, standalone extra drink only if explicitly extra. Ordinals are zero-based cart LINE indexes, not quantity. If target ambiguous or unknown slang, add unresolved and do not guess. Partial changes must not be applied. One of two portions: target.count=1 splits that line. Spoken confirm/OK returns intent preview; never commit orders. Recommendations output intent recommend only, ops [], with filter containing ONLY constraints explicitly changed in this utterance (noBeef, noPork, noBread, localSpecial, budget, vegetarian, noPeanut); omit absent constraints so previous filters survive a next request. Use false or budget null only when explicitly lifted. Selection is generated from the local catalog and verified sales. Missing details of new items default to catalog. Tea/coffee chow: condensed milk, not no milk. 飛砂走奶=no sugar,no milk coffee. 走青=no spring onion/coriander. 食丁=Demae +3. 扣底 cannot split an instant noodle cake. Extras are IDs from Extras catalog. Item.extras is an array; update patch.extrasAdd and patch.extrasRemove modify it without erasing others. Never invent addon prices. Catalog '+JSON.stringify(menu.map(m=>({id:m.id,name:m.name,en:m.en,combo:m.combo,noodle:m.noodle,drink:m.drink,temperatures:m.temperatures,spicy:m.spicy})))+' Extras '+JSON.stringify(expansion.extras)+' Options '+JSON.stringify(options)+' Glossary '+JSON.stringify(glossary)+'.';
function spec(op,p){const key=String(p.key||'').trim();if(!key)fail('missingKey');if(!['minimax','mimo'].includes(p.provider))fail('invalidProvider');if(op==='parse'){const text=String(p.text||'').trim();if(!text||text.length>2000)fail('invalidInput');const context=JSON.stringify({cart:(p.cart||[]).slice(0,50).map(normalize),mode:p.mode||'dinein',orderNotes:(p.orderNotes||[]).slice(0,12),language:p.language||'tc',speechLanguage:p.speechLanguage||(p.language==='sc'?'zh-CN':p.language==='en'?'en-HK':'zh-HK'),text});if(p.provider==='minimax')return{url:p.apiProfile==='global'?'https://api.minimax.io/v1/text/chatcompletion_v2':'https://api.minimaxi.com/v1/text/chatcompletion_v2',headers:{Authorization:'Bearer '+key,'Content-Type':'application/json'},body:{model:p.model||'MiniMax-M2.7',messages:[{role:'system',content:prompt},{role:'user',content:context}],stream:false,max_completion_tokens:2400,reasoning_split:true,...(/M3/.test(p.model||'')?{reasoning_effort:'low'}:{})}};return{url:p.apiProfile==='token-cn'?'https://token-plan-cn.xiaomimimo.com/v1/chat/completions':p.apiProfile==='token-sgp'?'https://token-plan-sgp.xiaomimimo.com/v1/chat/completions':'https://api.xiaomimimo.com/v1/chat/completions',headers:{'api-key':key,'Content-Type':'application/json'},body:{model:p.model||'mimo-v2.6-flash',messages:[{role:'system',content:prompt},{role:'user',content:context}],stream:false,max_completion_tokens:2400,thinking:{type:'disabled'},response_format:{type:'json_object'}}};}if(op!=='asr')fail('invalidPlan');if(typeof p.audio!=='string'||p.audio.length>5800000||!/^UklGR/.test(p.audio))fail('invalidAudio');if(p.provider==='minimax')return{url:p.apiProfile==='global'?'https://api.minimax.io/v1/speech_to_text':'https://api.minimaxi.com/v1/speech_to_text',headers:{Authorization:'Bearer '+key,language:p.language==='en'?'en':p.language==='sc'?'zh':'yue'},multipart:{model:'asr-1.0',response_format:'json',audio:p.audio}};return{url:p.apiProfile==='token-cn'?'https://token-plan-cn.xiaomimimo.com/v1/chat/completions':p.apiProfile==='token-sgp'?'https://token-plan-sgp.xiaomimimo.com/v1/chat/completions':'https://api.xiaomimimo.com/v1/chat/completions',headers:{'api-key':key,'Content-Type':'application/json'},body:{model:'mimo-v2.5-asr',messages:[{role:'user',content:[{type:'input_audio',input_audio:{data:'data:audio/wav;base64,'+p.audio,format:'wav'}}]}],asr_options:{language:p.language==='en'?'en':p.language==='sc'?'zh':'auto'},stream:false}};}
function content(d){if(d?.base_resp?.status_code)fail('providerError',{status:d.base_resp.status_code});return d.output_text||d.output?.filter(x=>x.type==='message').flatMap(x=>x.content||[]).filter(x=>x.type==='output_text').map(x=>x.text||'').join('')||d.choices?.[0]?.message?.content||d.text||'';}
function readAI(op,data){let text=content(data);if(op==='parse'&&typeof text==='string')text=text.replace(/^\s*<think>[\s\S]*?<\/think>\s*/,'');if(typeof text!=='string'||!text.trim())fail('emptyResponse');if(op==='asr')return{text:text.trim()};let p;try{p=JSON.parse(text.replace(/^```(?:json)?\s*/,'').replace(/\s*```$/,''));}catch{fail('invalidJSON');}if(p.unresolved?.length)fail('needClarification',{text:p.unresolved.map(String).join('; ')});if(!['add','edit','recommend','undo','clear','preview','service','navigate','customize'].includes(p.intent)||!Array.isArray(p.ops)||p.ops.length>50)fail('invalidPlan');if(p.intent==='recommend'){if(p.ops.length)fail('invalidPlan');g.Kam?.validateRecommendationFilter?.(p.filter||{});}if(p.intent==='navigate'&&(!Array.isArray(p.categories)||!p.categories.length||p.categories.some(c=>!['全部','早餐套餐','包點多士','單點小食','飯麵主食','港式飲品'].includes(c))||p.ops.length||p.focusItem&&!menu.some(m=>m.id===p.focusItem)))fail('invalidPlan');if(p.mode!==undefined&&!['dinein','takeaway'].includes(p.mode))fail('invalidPlan');if(p.intent==='service'&&!p.mode)fail('invalidPlan');for(const field of ['orderNotesAdd','orderNotesRemove'])if(p[field]!==undefined&&(!Array.isArray(p[field])||p[field].length>12||p[field].some(n=>typeof n!=='string'||!n.trim()||n.length>240)))fail('invalidPlan');if(p.orderNotesClear!==undefined&&typeof p.orderNotesClear!=='boolean')fail('invalidPlan');const validFields=new Set(['id','qty',...Object.keys(options),'note','extras','extrasAdd','extrasRemove','drinkStatus','drinkPrompted','qtyDelta','temperature']);for(const o of p.ops){if(o.type==='clear')continue;else if(o.type==='add')o.item=normalize(o.item);else if(['remove','update'].includes(o.type)){if(!o.target||typeof o.target!=='object')fail('invalidPlan');if(o.type==='update'){if(!o.patch||Object.keys(o.patch).some(k=>!validFields.has(k)))fail('invalidPlan');}}else fail('invalidPlan');}return p;}
g.Kam={menu,normalizePortionOrder,reconcilePortionOrder,findItems:foundItems,number,ensureAvailable,quantity,extraDrink,drinkItem,pendingDrinks,canCompleteDrinks,completedDrinkUids,extras:expansion.extras,applicable,optionValues,allowedExtras,drinkSupplement,drinkMilkAllowed,breakdown,drinks,noodles,sugars,ices,eggs,portions,broths,toasts,milks,options,glossary,aliases,defaults,normalize,unit,total,details,parseCommand,parseAdd,parsePatch,applyPlan,resolveTarget,canSwapBread,recommendations,spec,readAI,OrderError,uid,tc};
})(globalThis);

(function(g){
'use strict';const K=g.Kam,L=g.CafeLexicon;
const add=(target,terms,kind='command',field)=>terms.forEach(term=>L.entries.push({kind,target,term,...(field?{field}:{})}));
add('轉',['改叫','轉叫','改食','改要','換返','換番','改返','改番','轉返','轉番','改成','改做','換做','轉做','改為','換成','轉成','調做','改一改做','剩返','剩番','淨要','只要','減到','加到','減少','減返','減番','減']);add('轉熱',['轉熱','轉熱飲','轉返熱','改熱','改做熱','換熱']);add('轉凍',['轉凍','轉凍飲','轉返凍','改凍','改做凍','換凍']);add('唔係',['唔係']);
add('取消',['唔要','不要','唔使要','唔洗要','唔駛要','刪走','刪除','刪掉','撇走','攞走嗰份','唔食嗰份']);
for(const subject of ['杯嘢飲','杯野飲','飲品','啲飲品'])for(const when of ['陣間','等陣','遲少少','遲啲']){add('飲品稍後',[subject+when+'先']);for(const verb of ['叫','揀'])add('飲品稍後',[subject+when+'先'+verb]);}
add('正常多士',['正常多士','regular toast'],'modifier','toast');
add('飲品',['飲品','嘢飲','野飲','杯嘢飲','杯野飲','跟餐飲品','跟餐嘢飲','跟餐野飲','跟餐嗰杯','嗰杯飲品','我杯飲品','嗰杯嘢飲']);
add('照舊',['再嚟個一樣','再嚟一個一樣','再叫一份一樣','再嚟同一款','再要同一款','同頭先一樣','跟頭先一樣','照頭先','重複頭先嗰份']);
add('撤銷',['回返上一步','返上一步','撤銷頭先嗰步','還原頭先','取消上一步','復原上一步']);
for(const [target,terms,field]of [
 ['少甜',['糖少啲','少啲糖','少少糖','唔好咁甜','唔好太甜','甜度低啲'],'sugar'],['走甜',['唔使糖','唔洗糖','唔駛糖','唔好落糖','唔落砂糖','砂糖唔要','糖走晒','走晒糖'],'sugar'],
 ['少冰',['冰少啲','少啲冰','唔好咁多冰','落少啲冰','少少冰'],'ice'],['走冰',['唔使冰','唔洗冰','唔好落冰','冰走晒','走晒冰','唔加冰'],'ice'],
 ['走奶',['唔使奶','唔洗奶','唔好落奶','奶唔使落','奶走晒','走晒奶'],'milk'],['少奶',['奶少啲','落少啲奶','少少奶'],'milk'],
 ['湯另上',['個湯分開','湯分開上','湯分開裝','個湯另外上','湯另放'],'broth'],['走青',['啲蔥芫茜唔要','蔥同芫茜唔要','唔要青'],'note'],
 ['烘底',['麵包烘一烘','個包烘一烘','烘脆少少','烘脆啲'],'toast'],['飛邊',['麵包邊唔要','啲邊唔要','切走包邊'],'toast'],
 ['加底',['麵底加多啲','粉麵加多啲','加多少少底'],'portion'],['少底',['飯少啲','少啲飯','少飯','粉少啲'],'portion']
])add(target,terms,'modifier',field);
for(const row of L.entries.slice().filter(e=>e.kind==='modifier'&&e.field)){for(const prefix of ['全部','所有','每份都','每杯都'])L.entries.push({...row,term:prefix+row.term,target:'全部 '+row.target});}
const clearPhrases=['全部唔要','全部唔要晒','全部都唔要','全單唔要','全單取消','張單取消','張單清晒','清空餐單','清空張單','清空','清晒','清晒佢','刪晒','刪晒佢','全部刪走','全部刪除','取消晒','全部取消','所有餐點唔要','所有嘢唔要','成張單唔要','整張單取消','清除全部','clear order','clear cart','cancel everything','remove everything'];
const resetPhrases=['清晒重新嚟','成張單重新叫','整張單重新叫','取消頭先嗰單再叫','啱啱嗰單作廢，重新落單','由零開始叫過','由零開始落單','清空之後重新叫','頭先嗰張唔要，重新叫','重新落單','重新叫過','重新叫','重新點餐','重新點過','重新嚟過','由頭叫過','由頭落過單','由頭落單','重頭叫過','重頭嚟過','重頭再嚟','再落過張單','再叫過','重新開始','重來','start over','restart order'];
const escape=s=>s.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
function clean(value){let s=K.tc(value).trim();if(s.length>2000)throw new K.OrderError('invalidInput');s=s.replace(/頭([一二兩三四五六七八九十\d]+)(?=[份個項件款碟杯])/g,'第$1').replace(/[呀啊啦喇囉](?=[，,；;。])/g,'').replace(/^[\s，,。.!！?？]+|[\s，,。.!！?？]+$/g,'');for(let n=0;n<8;n++){const old=s;s=s.replace(/^[\s，,。.!！?？]+|[\s，,。.!！?？]+$/g,'').replace(/^(?:老細|老闆|夥記|伙記|師傅)[\s，,：:]*|^(?:幫我落|我就要|想嗌|嗌|(?:幫我|同我)?整(?=\s*[一二兩三四五六七八九十廿\d份杯個件碟]))\s*/,'').replace(/^(?:唔該[晒曬]|唔該你|唔該|麻煩你|麻煩|幫我|幫手|可唔可以|可不可以|可以幫我|請你|請|我想要|我想叫|我想食|我想飲(?!品)|我想|我要|同我|替我|將|把)\s*/,'').replace(/(?:唔該[晒曬]|唔該|多謝[晒曬]|多謝|謝謝|呀|啊|吖|啦|喇|囉|咯|喎|啫|嘞|了|好嗎|好嘛|咁呀|就得喇|就得|先啦|(?<!等陣|陣間|遲啲|之後)先|丫)[\s，,。.!！?？]*$/,'').trim();if(s===old)break;}return s;}
function control(text){const s=clean(text);if(/^(?:唔好|唔使|唔洗|唔駛|唔需要|不需要|不要|唔係(?:話)?)(?:再)?(?:重新(?:落單|叫過|叫|開始)|由頭叫過|清空(?:餐單|張單)?|全部取消|全部唔要)$/.test(s))return{negated:true};for(const p of resetPhrases.map(K.tc).sort((a,b)=>b.length-a.length)){if(s.toLowerCase().startsWith(p)){const rest=s.slice(p.length).replace(/^[\s，,。;；]+/,'').replace(/^(?:跟住|然後|再要|再叫|要|叫)\s*/,'');return{intent:'clear',restart:true,remainder:rest};}}for(const p of clearPhrases.map(K.tc).sort((a,b)=>b.length-a.length)){if(s.toLowerCase()===p)return{intent:'clear',remainder:''};if(s.toLowerCase().startsWith(p)&&/^[，,；;。]/.test(s.slice(p.length)))return{intent:'clear',restart:true,remainder:s.slice(p.length).replace(/^[\s，,。;；]+/,'')};}return null;}
function clauses(text){const revised=clean(text).replace(/((?:第[一二兩三四五六七八九十\d]+[份個項件款碟杯]?|頭先(?:嗰份)?|最後(?:嗰份)?|上一份))\s*(?:唔要|不要)\s*[，,；;]\s*(?=(?:轉叫|改叫|換成|改做|轉做|改要))/g,'$1');return revised.split(/(?:[，,；;。]\s*|(?:同埋|跟住|然後)\s*)(?=(?:另外|再加|加多|加返|改叫|轉叫|第[一二三四五六七八九十\d]|取消|刪走|飲品改|飲品轉|杯嘢飲|全部轉))/).map(s=>s.trim()).filter(Boolean);}
function ordinal(text){const m=text.match(/第([一二兩三四五六七八九十\d]+)(?:份|個|項|杯|餐)?/);if(m)return{index:K.number(m[1])-1};if(/頭先|最後|上一份|啱啱/.test(text))return{last:true};return{};}
const removeLine=text=>/^攞走(?:第[一二兩三四五六七八九十\d]+[份個項件款碟杯]?|(?:頭先|最後)(?:嗰份)?|上一份)$/.test(text);
function temperatureChange(text){
 const match=text.match(/^(?:跟餐嗰杯|杯[嘢野]飲|[嘢野]飲|嗰杯|飲品)?\s*(?:改|轉|換|調|要)(?:做|返|番|成)?\s*(凍|熱)(?:飲|嘅|的)?$/);
 if(!match)return null;
 // Bare "要凍飲" is a category request, not an edit to an unspecified item.
 if(/^要/.test(text))return null;
 return {intent:'edit',ops:[{type:'update',target:{kind:'drink'},patch:{temperature:match[1]}}]};
}
function context(p,cart){if(!cart.length)return null;const t=p.original,norm=p.normalized,hits=K.findItems(norm),food=hits.filter(h=>!K.menu.find(m=>m.id===h.id)?.drink),drink=hits.filter(h=>K.menu.find(m=>m.id===h.id)?.drink),target=ordinal(t);if(/所有|全部|每份|每杯|成單/.test(t))target.all=true;
 // Negation inside a known option is a preparation request, not cancellation.
 const commandText=t.split('');
 for(const hit of p.hits)if(hit.row.field&&['modifier','phonetic'].includes(hit.row.kind))
  commandText.fill(' ',hit.start,hit.end);
 const command=commandText.join('');
 const beverage=/飲品|嘢飲|野飲|跟餐嗰杯|嗰杯/.test(t),change=/改|轉|換|調/.test(t),remove=/取消|刪|唔要|唔使要|唔洗要/.test(command)&&!/^唔係/.test(t);
 if(removeLine(t))return{intent:'edit',ops:[{type:'remove',target}]};
 if(remove&&!change&&!beverage&&/其中一[份個]/.test(t)){target.count=1;if(food.length&&target.index===undefined&&!target.last)target.id=food[0].id;else if(drink.length&&target.index===undefined&&!target.last){target.id=drink[0].id;target.kind='drink';}return{intent:'edit',ops:[{type:'remove',target}]};}
 if((beverage||!food.length&&remove&&drink.length)&&!/(?:另外|加多|再加|另加|單點|單叫)/.test(t)){
  target.kind='drink';if(remove&&!change){if(drink.length)target.drinkFamily=K.menu.find(m=>m.id===drink[0].id).drink.replace(/^[熱凍]/,'');return{intent:'edit',ops:[{type:'remove',target}]};}
  const {patch,conflicts}=K.parsePatch(norm);if(conflicts.length&&!change)throw new K.OrderError('conflictingOptions');if(!patch.drink&&/(?:轉|改|換)[做返番成]?\s*(?:凍|熱)(?:飲|嘅|的)?$/.test(t))patch.temperature=/凍(?:飲|嘅|的)?$/.test(t)?'凍':'熱';if(Object.keys(patch).length)return{intent:'edit',ops:[{type:'update',target,patch}]};
 }
 const verb=norm.search(/轉|改|換/),repair=/^唔係/.test(t);const next=repair?food.at(-1):food.find(h=>h.index>verb&&verb>=0);if(next&&(change||repair)){
  const before=repair?food[0]:food.find(h=>h.end<=verb);if(before&&target.index===undefined&&!target.last)target.id=before.id;else if(target.index===undefined&&!target.last)target.kind=K.menu.find(m=>m.id===next.id).combo&&cart.some(i=>K.menu.find(m=>m.id===i.id).combo)?'combo':'food';
  const {patch,conflicts}=K.parsePatch(norm.slice(next.end));if(conflicts.length)throw new K.OrderError('conflictingOptions');patch.id=next.id;return{intent:'edit',ops:[{type:'update',target,patch}]};
 }
 const {numPattern,classifierPattern}=K.quantity,amount='\\s*('+numPattern+')\\s*('+classifierPattern+')';
 const qty=t.match(new RegExp('(?:改做|改成|改要|轉做|要返|改返|剩返|剩番|淨要|改為|減到|加到|只要|(?:個餐|嗰份|呢份|嗰個餐|主餐|餐點)要)'+amount,'i'));
 const relative=t.match(new RegExp('(?:加多|加返|加|減少|減返|減番|減走|減|扣(?:返|番)?|少返|唔要其中|取消其中)'+amount+'$','i'));
 if(qty||relative){
  if(food.length&&target.index===undefined&&!target.last)target.id=food[0].id;
  const count=K.quantity.forTarget(cart,target,qty||relative);
  const patch=qty?{qty:count}:{qtyDelta:count*(/減|扣|少返|唔要|取消/.test(relative[0])?-1:1)};
  return {intent:'edit',ops:[{type:'update',target,patch}]};
 }
 if(/^(?:飲品|杯嘢飲|杯野飲|嘢飲|野飲)?(?:全部)?(?:轉|改|換)(?:做|返|番)?(?:凍|熱)(?:飲|嘅|的)?$/.test(t)){target.kind='drink';return{intent:'edit',ops:[{type:'update',target,patch:{temperature:/凍(?:飲|嘅|的)?$/.test(t)?'凍':'熱'}}]};}
 return null;
}
for(const row of L.entries)if(['轉熱','轉凍'].includes(row.target))row.requires='terminal';for(const m of K.menu){const names=[m.name,...(m.aliases||[]).filter(v=>!/[a-z]/i.test(v))];for(const name of names){if(['三文治','三明治'].includes(name))continue;for(const verb of ['唔要','取消','刪走','唔使要','唔洗要'])L.entries.push({kind:'command',target:'取消 '+(m.drink||m.name),term:verb+name,id:m.id});}}L.entries.push({kind:'ambiguous',target:'',term:'三文治',ids:['P6','P3','P7','P9','P11'],reason:'sandwichFilling'},{kind:'ambiguous',target:'',term:'三明治',ids:['P6','P3','P7','P9','P11'],reason:'sandwichFilling'});L.version=6;K.language={clean,control,context,clauses,temperatureChange,removeLine,clearPhrases,resetPhrases};
})(globalThis);

(function(g){
'use strict';
const K=g.Kam,source=g.CafeLexicon;if(!K||!source)throw Error('Local recognition dependencies missing');
// Official menu names participate in the same longest-phrase scan as aliases.
for(const m of K.menu)for(const term of [m.name,m.en])if(term)source.entries.push({kind:'item',id:m.id,term,target:m.combo?'早餐'+m.id:m.drink||m.name});
const raw=s=>K.tc(s).replace(/([\p{Script=Han}])\s+(?=[\p{Script=Han}])/gu,'$1').replace(/\s+/g,' ').trim();
const trie=new Map(),priority={unavailable:6,item:5,modifier:4,command:3,phonetic:2,ambiguous:1};
const unique=new Map();
for(const row of source.entries){const term=raw(row.term).toLowerCase();if(!term)continue;const key=term+'\0'+row.kind+'\0'+row.target;unique.set(key,{...row,term});}
const orderPrefixes=['加','加多','再加','加份','加多份','再加份','加一份','加多一份','再加一份','叫份','要份','嚟份','再嚟份'];
for(const row of [...unique.values()]){
 if(!row.id||!['item','phonetic'].includes(row.kind))continue;
 for(const prefix of orderPrefixes){
  const term=prefix+(/^[a-z0-9]/i.test(row.term)?' ':'')+row.term;
  const target=prefix+' '+row.target;
  const key=term+'\0'+row.kind+'\0'+target;
  if(!unique.has(key))unique.set(key,{...row,term,target,baseTerm:row.term});
 }
}
const entries=[...unique.values()];
for(const row of entries){let node=trie;for(const ch of row.term){if(!node.has(ch))node.set(ch,new Map());node=node.get(ch);}if(!node.has(''))node.set('',[]);node.get('').push(row);}
function scan(text){const hits=[];const lower=text.toLowerCase();for(let at=0;at<lower.length;){let node=trie,best=null;for(let end=at;end<lower.length&&node.has(lower[end]);end++){node=node.get(lower[end]);if(!node.has(''))continue;const term=lower.slice(at,end+1);if(/^[a-z0-9]/.test(term)&&at>0&&/[a-z0-9]/i.test(lower[at-1]))continue;if(/[a-z0-9]$/.test(term)&&end+1<lower.length&&/[a-z0-9]/i.test(lower[end+1]))continue;const rows=node.get('').filter(r=>r.requires!=='terminal'||!lower.slice(end+1).trim()).sort((a,b)=>priority[b.kind]-priority[a.kind]);if(!rows.length)continue;best={start:at,end:end+1,row:rows[0]};}if(best){hits.push(best);at=best.end;}else at++;}return hits;}
const fillers=['係','啱啱','啲嘢','張單','嗰張','呢張','可唔可以','可不可以','幫手','將','把','我杯','我','晒','曬','番','返','先至','呢個餐','嗰個餐','個餐','主餐','嗰份餐','杯野飲','野飲','喎','囉','喇','嘅','啫','麻煩你幫我','唔該幫我','麻煩幫我','可唔可以幫我','可以幫我','麻煩你','唔該你','幫我','唔該','麻煩','請幫我','請','我想要','我想食','我想飲','我想叫','我想點','我要','我就要','我要食','我要飲','我需要','來一份','畀我','俾我','要','嚟','來','叫','點','加埋','加返','加多','個','份','杯','件','碗','隻','款','套','餐','另外','再','仲','同埋','還有','跟住','然後','之後','接住','以及','同','和','與','配','跟','先','就','都','呀','啊','吖','啦','喇','呢','唔該晒','多謝','謝謝','嗰份','嗰個','嗰杯','嗰','這份','那份','呢份','呢個','那個','那杯','飲品','嘢飲','餐點','餐單','項目','第一','第二','第三','第四','第五','第六','第七','第八','第九','第十','第','頭先','最後','上一','其中','所有','全部','每','一半','照','做','成','為','啲','的','得','了','好','得喇','唔食牛','不吃牛','素食','花生敏感','花生過敏','預算','蚊以下','蚊以內','元以下','元以內','元','蚊','港元','以內','以下'];
const escaped=s=>s.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
fillers.push('額外','單叫','單點','嗌多',...K.quantity.hanClassifiers,'再嚟','再來','再叫','再落','再要','要多','嚟多','多要','叫多','兼','順便','項');
const fillerRE=new RegExp(fillers.sort((a,b)=>b.length-a.length).map(escaped).join('|'),'g');
const englishRE=/\b(?:please|could|can|would|i|we|you|like|want|have|give|me|us|a|an|some|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|thirteen|fourteen|fifteen|sixteen|seventeen|eighteen|nineteen|twenty|first|second|third|fourth|fifth|last|previous|item|items|line|lines|set|sets|cup|cups|piece|pieces|portion|portions|of|them|the|this|that|it|with|and|then|to|as|for|both|all|another|also|instead|rather|under|below|budget|hkd|dollar|dollars|no beef|vegetarian|peanut allergy|within|only|now|thank you|thanks)\b/gi;
function leftover(text,hits){const chars=text.split('');for(const h of hits)for(let n=h.start;n<h.end;n++)chars[n]=' ';return K.quantity.strip(chars.join('')).replace(fillerRE,' ').replace(englishRE,' ').replace(/[零〇一二兩三四五六七八九十廿百\d]+/g,' ').replace(/[\p{P}\p{S}\s]+/gu,' ').trim().split(/\s+/).filter(Boolean);}
function inspectLocal(text){
 const original=raw(K.language?K.language.clean(text):text);
 if(!original)throw new K.OrderError('emptyInput');
 if(original.length>2000)throw new K.OrderError('invalidInput');
 return {original,hits:scan(original)};
}
function prepare(text,cart=[]){const {original,hits}=inspectLocal(text),unavailable=hits.filter(h=>h.row.kind==='unavailable');if(unavailable.length)throw new K.OrderError('unavailable',{name:unavailable.map(h=>h.row.target||original.slice(h.start,h.end)).join('、')});
 const contextual=cart.length>0||hits.some(h=>h.row.kind==='item'||h.row.kind==='phonetic'&&h.row.id);
 const ambiguous=hits.find(h=>h.row.kind==='ambiguous'||h.row.requires==='option-context'&&!contextual);
 if(ambiguous){
  const reason=ambiguous.row.reason||'optionContext';
  const wantsSlicedBread=reason==='toastType'&&hits.some(h=>h.row.field==='toast'&&['方包','方包飛邊'].includes(h.row.target));
  const ids=wantsSlicedBread?K.menu.filter(m=>!m.combo&&K.canSwapBread(m)).map(m=>m.id):ambiguous.row.ids||[];
  throw new K.OrderError('ambiguousTerm',{term:original.slice(ambiguous.start,ambiguous.end),ids,reason,start:ambiguous.start,end:ambiguous.end,original});
 }
 let normalized='',at=0;const corrections=[];
 for(const h of hits){normalized+=original.slice(at,h.start);const part=(h.row.kind==='command'&&(h.row.target==='加'||h.row.target==='照舊'&&hits.some(hit=>hit.row.id))?h.row.term:h.row.target||original.slice(h.start,h.end)).replace(/((?:熱|凍)(?:咖啡|奶茶))(?=走奶|走甜|轉煉奶)/g,'$1 ').replace(/走奶走甜/g,'走奶 走甜');normalized+=' '+part+' ';if(h.row.kind==='phonetic'&&raw(part)!==raw(original.slice(h.start,h.end)))corrections.push({from:original.slice(h.start,h.end),to:part});at=h.end;}
 normalized+=original.slice(at);return{original,normalized,hits,unknown:leftover(original,hits),corrections};
}
const legacy=K.parseCommand;
function followupPlan(plan,text,cart){const waiting=K.pendingDrinks(cart);if(!waiting.length||plan.intent!=='add'||!plan.ops.length||!plan.ops.every(o=>K.menu.find(m=>m.id===o.item?.id)?.drink)||K.extraDrink.test(text))return plan;const total=waiting.reduce((n,i)=>n+i.qty,0),requested=plan.ops.reduce((n,o)=>n+o.item.qty,0);if(requested>total)throw new K.OrderError('drinkQuantity');if(waiting.length>1&&plan.ops.length>1)throw new K.OrderError('needClarification');const ops=[];for(const o of plan.ops){const i=o.item,all=waiting.length>1&&i.qty===total,target=waiting.length===1?{uid:waiting[0].uid,count:i.qty}:all?{pendingDrink:true,all:true}:{pendingDrink:true,count:i.qty};const patch={drink:i.drink,sugar:i.sugar,ice:i.ice,milk:i.milk,size:i.size,extrasAdd:i.extras,drinkStatus:'selected'};ops.push({type:'update',target,patch});}return{intent:'edit',ops,localRewrite:plan.localRewrite};}
function parseDetailed(text,cart=[]){const control=K.language?.control(text);if(control){if(control.negated)return{plan:{intent:'edit',ops:[],preserveDraft:true},prepared:{normalized:K.language.clean(text),corrections:[]}};if(control.remainder){const result=parseDetailed(control.remainder,[]);if(!['add','edit'].includes(result.plan.intent))throw new K.OrderError('needChange');return{plan:{intent:'edit',ops:[{type:'clear'},...result.plan.ops]},prepared:result.prepared};}return{plan:{intent:'clear',ops:[],restart:!!control.restart},prepared:{normalized:K.language.clean(text),corrections:[]}};}const parts=K.language?.clauses(text)||[text];if(parts.length>1){let simulated=cart.map(K.normalize),ops=[],corrections=[];const originalIds=new Set(cart.map(i=>i.uid));for(const part of parts){const result=parseDetailed(part,simulated),p=result.plan;if(!['add','edit','clear'].includes(p.intent))throw new K.OrderError('needClarification');if(p.intent==='clear')ops.push({type:'clear'});else{for(const o of p.ops){if(o.target?.uid&&!originalIds.has(o.target.uid)){const index=simulated.findIndex(i=>i.uid===o.target.uid);o.target={...o.target,index};delete o.target.uid;}ops.push(o);}}simulated=K.applyPlan(simulated,p).items;corrections.push(...(result.prepared.corrections||[]));}return{plan:{intent:'edit',ops},prepared:{normalized:K.language.clean(text),corrections}};}const temperature=cart.length&&K.language?.temperatureChange(K.language.clean(text));if(temperature)return{plan:temperature,prepared:{normalized:K.language.clean(text),corrections:[]}};const prepared=prepare(text,cart);if(prepared.unknown.length)throw new K.OrderError('unrecognizedTokens',{tokens:prepared.unknown.join('、')});let plan;const waiting=K.pendingDrinks(cart);if(/飲品稍後/.test(prepared.normalized)){const foods=K.findItems(prepared.normalized).filter(h=>K.menu.find(m=>m.id===h.id)?.combo);if(foods.length&&!/第[一二三四五六七八九十\d]|頭先/.test(prepared.original)){const add=legacy(prepared.normalized.replace(/飲品稍後/g,''),[]);for(const o of add.ops)if(o.type==='add'&&K.menu.find(m=>m.id===o.item.id)?.combo&&o.item.drink==='待選飲品')o.item.drinkStatus='deferred';return{plan:add,prepared};}if(!waiting.length)throw new K.OrderError('missingTarget');plan={intent:'edit',ops:waiting.map(i=>({type:'update',target:{uid:i.uid},patch:{drinkStatus:'deferred',drinkPrompted:true}}))};}else plan=K.language?.context(prepared,cart)||followupPlan(legacy(prepared.normalized,cart),prepared.original,cart);return{plan,prepared};}
function analyzeLocal(text,cart=[]){const start=globalThis.performance?.now?.()??Date.now();try{const {plan,prepared}=parseDetailed(text,cart);return{decision:'local',plan,normalized:prepared.normalized,corrections:prepared.corrections,elapsedMs:(globalThis.performance?.now?.()??Date.now())-start};}catch(error){const clarify=['ambiguousTerm','ambiguousTarget','conflictingOptions','needChange','missingTarget','wholeNoodle','notApplicable','unavailable','emptyInput','emptyCart','orderLimit','invalidQty','invalidInput','tartPack','drinkQuantity','fixedSugar'].includes(error.code);return{decision:clarify?'clarify':'fallback',error,elapsedMs:(globalThis.performance?.now?.()??Date.now())-start};}}
function parseCommand(text,cart=[]){return parseDetailed(text,cart).plan;}
function searchMenu(query){const text=raw(query).toLowerCase();if(!text)return K.menu;const hits=scan(raw(query)),ids=new Set(hits.flatMap(h=>h.row.id?[h.row.id]:h.row.ids||[]));return K.menu.filter(m=>ids.has(m.id)||raw(m.name+' '+m.en+' '+m.id).toLowerCase().includes(text));}
const byItem=Object.fromEntries(K.menu.map(m=>[m.id,entries.filter(e=>e.id===m.id&&['item','phonetic'].includes(e.kind))]));
const stats={entries:entries.length,itemAliases:entries.filter(e=>e.kind==='item').length,phonetic:entries.filter(e=>e.kind==='phonetic').length,modifiers:entries.filter(e=>e.kind==='modifier').length,commands:entries.filter(e=>e.kind==='command').length,unavailable:entries.filter(e=>e.kind==='unavailable').length,ambiguous:entries.filter(e=>e.kind==='ambiguous').length};
K.followupPlan=followupPlan;K.parseCommand=parseCommand;K.analyzeLocal=analyzeLocal;K.prepareLocal=prepare;K.inspectLocal=inspectLocal;K.searchMenu=searchMenu;K.lexicon={entries,byItem,stats,version:7};
})(globalThis);

(function(g){
'use strict';
const K=g.Kam;
// Both microphone paths use the same policy for competing transcripts.
function voicePlanError(plan,cart,context){
 try{K.transitionDraft({...context,cart},plan,context.availability);}
 catch(error){if(error.code!=='ambiguousTarget'||plan.ops?.length!==1)return error;}
 return null;
}
function voiceClarification(error,text){
 return Object.assign(error,{transcript:text,voiceClarification:true});
}
function voicePlanMeaning(plan){
 return JSON.stringify({...plan,ops:plan.ops.map(op=>op.type==='add'?{...op,item:{...op.item,uid:null}}:op)});
}
function voiceSuggestion(text,local,cart,context){
 const base=local.correctedText||text;
 const readable=(local.corrections||[]).reduce((value,{from,to})=>from?value.replace(from,to):value,base);
 if(readable===base)return base;
 const checked=K.analyzeLocal(readable,cart,context);
 return checked.plan&&voicePlanMeaning(checked.plan)===voicePlanMeaning(local.plan)?readable:base;
}
function voiceCandidates(text,alternatives,cart,context){
 const candidates=[];
 let conflictingAlternative=false;
 const transcripts=(Array.isArray(alternatives)?alternatives:[]).filter(x=>typeof x==='string').map(x=>x.trim());
 for(const candidate of [...new Set(transcripts)].slice(0,5)){
  if(!candidate||candidate===text)continue;
  const local=K.analyzeLocal(candidate,cart,context),plan=local.plan;
  if(local.decision==='fallback')continue;
  if(local.decision==='clarify'||['clear','undo'].includes(plan.intent)||plan.ops?.some(op=>op.type==='clear')||
     voicePlanError(plan,cart,context)){conflictingAlternative=true;continue;}
  candidates.push({text:local.correctedText||candidate,plan});
 }
 return {candidates,conflictingAlternative};
}
// 杯 is also a real drink classifier. Recover this code only when every
// usable alternative agrees on the complete breakfast order, including quantity.
function corroboratedBreakfast(text,candidates,cart,context){
 if(!candidates.length||!text)return null;
 const clean=K.language.clean(text);
 const quantity='(?:(?:'+K.quantity.numPattern+')\\s*)?[份個]';
 const heard=new RegExp('^(?:(?:要|叫|再叫|再要|俾我|畀我|呢)\\s*)?(?:'+quantity+'\\s*)?(?:早餐|早晨)\\s*杯(?:\\s*'+quantity+')?$','i');
 if(!heard.test(clean))return null;
 const corrected=clean.replace(/((?:早餐|早晨)\s*)杯/,'$1B');
 const local=K.analyzeLocal(corrected,cart,context);
 if(local.decision!=='local'||local.plan.intent!=='add'||!local.plan.ops?.some(op=>op.type==='add'&&op.item?.id==='B')||
    voicePlanError(local.plan,cart,context))return null;
 const expected=voicePlanMeaning(local.plan);
 if(candidates.some(candidate=>voicePlanMeaning(candidate.plan)!==expected))return null;
 return {...local,text:corrected,corrections:[{from:text,to:corrected}]};
}
function resolveDeviceVoice({localText='',localAlternatives=[],cart=[],context={},observe=()=>{}}){
 const text=String(localText??'').trim();
 let error;
 if(text){
  const local=K.analyzeLocal(text,cart,context);
  observe({provider:'device',text,result:local});
  if(local.decision==='local'){
   const invalid=voicePlanError(local.plan,cart,context);
   if(invalid)throw voiceClarification(invalid,text);
   const sensitiveEdit=local.plan.intent==='edit'&&local.plan.ops.length>0;
   if(local.phoneticRecovery||local.corrections?.length||sensitiveEdit||local.plan.grammar==='colloquial-order'){
    const {candidates,conflictingAlternative}=voiceCandidates(text,localAlternatives,cart,context);
    const expected=voicePlanMeaning(local.plan);
    const disagree=candidates.filter(candidate=>voicePlanMeaning(candidate.plan)!==expected);
    if(conflictingAlternative||disagree.length)throw voiceClarification(new K.OrderError('confirmTranscript',{
     candidates:[...new Set([voiceSuggestion(text,local,cart,context),...disagree.map(candidate=>candidate.text)])],
    }),text);
   }
   return {...local,text:local.correctedText||text,provider:'device',source:'dictionary'};
  }
  if(local.decision==='clarify')throw voiceClarification(local.error,text);
  error=local.error;
 }
 const {candidates,conflictingAlternative}=voiceCandidates(text,localAlternatives,cart,context);
 const recovered=conflictingAlternative?null:corroboratedBreakfast(text,candidates,cart,context);
 if(recovered)return {...recovered,provider:'device',source:'dictionary'};
 if(candidates.length)throw voiceClarification(new K.OrderError('confirmTranscript',{candidates:candidates.map(c=>c.text)}),text);
 return {error};
}
// A single recording is retained by the caller and passed unchanged to both providers.
async function resolveVoice({audio,localText='',localAlternatives=[],cart=[],context={},available=()=>true,canParse=()=>true,asr,parse,transformASR,progress=()=>{},observe=()=>{}}){
 if(!audio)throw new K.OrderError('invalidAudio');
 const device=resolveDeviceVoice({localText,localAlternatives,cart,context,observe});
 if(device.plan)return device;
 let error=device.error,clarification;
 for(const provider of ['minimax','mimo']){
  if(!available(provider))continue;
  progress(provider,'asr');
  try{
   const result=await asr(provider,audio);
   let text=String((typeof result==='string'?result:result?.text)||'').trim();
   if(transformASR&&text){const transformed=transformASR(text,provider);if(transformed?.control)return {control:transformed.control,text,provider,source:'control'};if(transformed&&typeof transformed.text==='string')text=transformed.text;}
   if(!text)continue;
   const local=K.analyzeLocal(text,cart,context);
   observe({provider,text,result:local});
   if(local.decision==='clarify'){clarification=voiceClarification(local.error,text);break;}
   if(local.decision==='local'){
    const invalid=voicePlanError(local.plan,cart,context);
    if(invalid){clarification=voiceClarification(invalid,text);break;}
    return {...local,text:local.correctedText||text,provider,source:'dictionary'};
   }
   if(!canParse(provider)){clarification=voiceClarification(local.error,text);break;}
   progress(provider,'parse');
   const plan=K.followupPlan(await parse(provider,text,cart),text,cart);
   const invalid=voicePlanError(plan,cart,context);
   if(invalid)throw invalid;
   return {plan,text,provider,source:'model'};
  }catch(e){error=e;}
 }
 throw clarification||error||new K.OrderError('missingKey');
}
K.resolveDeviceVoice=resolveDeviceVoice;
K.resolveVoice=resolveVoice;
})(globalThis);

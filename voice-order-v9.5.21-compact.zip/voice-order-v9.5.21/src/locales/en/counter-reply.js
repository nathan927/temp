(function(g){
 'use strict';
 const K=g.Kam,L=g.I18n;
 const variants={
  add:[
   ['好呀，啱啱幫你加好。','得喇，呢幾樣記低咗。','收到，寫入餐單喇。','冇問題，幫你加咗。','好嘞，餐單加好喇。','得，呢次加咗下面嗰啲。','聽到喇，幫你記咗落單。','呢幾樣幫你寫好喇。'],
   ['Got it, I added those.','Those are on the draft.','All set, they’re added.','I’ve put those on your order.','Sure, here’s what I added.','I caught those and added them.','The new items are in.','Here are the items I noted.'],
  ],
  update:[
   ['好，幫你改好喇。','收到，啱啱改咗呢啲。','得喇，新配搭記低咗。','好嘞，餐單改好喇。','幫你照啱啱講嘅改咗。','冇問題，改好呢份。','跟返你講嘅改咗喇。','啱啱嗰個改動寫好喇。'],
   ['Done, I made that change.','I’ve updated the draft.','Here’s what changed.','That adjustment is in.','I’ve noted the new choice.','Sure, I made the update.','Your new choice is on the order.','I’ve made the changes you asked for.'],
  ],
  remove:[
   ['好，幫你取消咗。','收到，呢啲已經刪咗。','得喇，攞走咗下面嗰啲。','啱啱幫你刪好喇。','好嘞，呢幾樣取消咗。','跟你講嘅，呢啲攞走咗。','冇問題，刪走咗你指嗰啲。','幫你減走呢幾份喇。'],
   ['Done, I removed those.','Those are off the draft.','Sure, I took those off.','Here’s what I removed.','I’ve cancelled those portions.','Those items have been removed.','I made the removal you asked for.','I’ve taken the portions below off.'],
  ],
  mixed:[
   ['得，啱啱嗰幾步跟好喇。','好呀，一齊幫你處理咗。','收到，下面係今次嘅改動。','逐樣跟好咗喇。','好嘞，睇返啱啱處理嗰幾樣。','你頭先講嗰幾步已記低。','冇問題，成句幫你跟好咗。','啱啱嗰幾樣都處理好喇。'],
   ['I’ve done those steps.','Here’s what I did in that request.','All those changes are in.','I handled those together.','Here’s the rundown.','I made the updates below.','I’ve followed the steps you gave me.','Here’s how the draft changed.'],
  ],
  undo:[
   ['好，幫你復原咗。','啱啱嗰步撤銷喇。','得喇，回到改之前。','好嘞，還原咗嗰步。','收到，上一個改動復原咗。','幫你退返一步喇。','冇問題，已經還原。','上一個操作撤回咗。'],
   ['Done, I undid that.','The last step is undone.','I’ve restored the previous draft.','Back to the previous version.','I took back that change.','The last change has been reversed.','Sure, I rolled back one step.','That step has been restored.'],
  ],
  info:[
   ['好，幫你處理好。','得喇，睇吓下面。','收到你嘅要求。','好嘞，呢邊已經跟好。','好呀，幫你準備咗。','得，依家可以睇返喇。','冇問題，啱啱處理好喇。','呢一步幫你跟到喇。'],
   ['All set, here you go.','Sure, take a look below.','Got it, here’s the result.','That step is done.','I’ve got that ready.','Here’s what you asked for.','Okay, that’s sorted.','Ready for you to check.'],
  ],
  kept:[
   ['好，張單照舊。','收到，幫你留返原樣。','得喇，呢一步冇改餐單。','好嘞，配搭照你原先揀嘅。','張單保留原先嗰樣。','冇問題，餐點照舊。','知道喇，保留返原本嘅餐點。','好呀，跟返你原本嘅揀法。'],
   ['Okay, the draft stays as it was.','Got it, I kept your choices.','Your order stays the same.','Sure, I left those options in place.','I’ve kept your original draft.','Your existing choices are still there.','All right, I kept the original items.','The draft is as you had it.'],
  ],
 };
 const closings=[
  ['','可以繼續講呀。','你核對一下吖。','睇啱就可以繼續～','仲有想改嘅可以話我知。','你得閒睇一睇張單吖。'],
  ['Take a quick look.','You can keep going.','Check that it looks right.','Have a look at the draft.','Tell me if you want another change.','Review it whenever you’re ready.'],
 ];
 const counters=new Map();
 function next(kind,lang='tc'){
  const language=lang==='en'?1:0,key=kind+'|'+lang,starts=(variants[kind]||variants.info)[language],ends=closings[language];
  const index=counters.get(key)||0;
  counters.set(key,(index+1)%(starts.length*ends.length));
  const sentence=starts[index%starts.length]+(language?' ':'')+ends[Math.floor(index/starts.length)];
  return lang==='sc'?L.toSC(sentence):sentence;
 }
 const drinkOptions=new Set(['milk','sugar','ice','size']);
 const equivalent=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
 function describe(changes,beforeNotes=[],afterNotes=[],lang='tc'){
  const t=(key,data)=>L.text(key,lang,data),label=value=>L.label(value,lang);
  const menu=item=>K.menu.find(m=>m.id===item.id);
  const name=item=>L.name(menu(item),lang);
  const extras=item=>item.extras.map(id=>K.extras.find(extra=>extra.id===id)?.name).filter(Boolean);
  const effective=(item,notes)=>item&&K.effectiveItems([item],notes)[0];
  const entries=[];
  for(const change of changes){
   const before=effective(change.before,beforeNotes),after=effective(change.after,afterNotes);
   if(change.type==='add'&&after){
    const options=K.details(after).map(label).join(lang==='en'?', ':'、');
    entries.push({kind:'add',line:t('counterAddItem',{n:after.qty,name:name(after),options:options?t('counterOptions',{options}):''})});
   }else if(change.type==='remove'&&before){
    entries.push({kind:'remove',line:t('counterRemoveItem',{n:before.qty,name:name(before)})});
   }else if(before&&after){
    const edits=[];
    if(before.id!==after.id)edits.push(t('counterChangedValue',{from:name(before),to:name(after)}));
    if(before.qty!==after.qty)edits.push(t('counterQtyChange',{from:before.qty,to:after.qty}));
    for(const key of Object.keys(K.options)){
     if(before[key]===after[key]||!after[key]||!K.applicable(menu(after),key,after))continue;
     if(drinkOptions.has(key)&&['','待選飲品','不需要飲品'].includes(after.drink))continue;
     edits.push(t('counterField',{field:t(key),value:label(after[key])}));
    }
    if(!equivalent(before.extras,after.extras))edits.push(t('counterField',{field:t('extras'),value:extras(after).map(label).join('、')||t('counterNone')}));
    if(before.note!==after.note)edits.push(t('counterField',{field:t('note'),value:after.note||t('counterNone')}));
    if(before.drinkStatus!==after.drinkStatus&&after.drink==='待選飲品')edits.push(label(K.details(after).find(value=>value.includes('飲品'))||after.drink));
    if(edits.length)entries.push({kind:'update',line:t('counterUpdateItem',{n:after.qty,name:name(before),options:edits.join(lang==='en'?', ':'、')})});
   }
  }
  for(const note of afterNotes)if(!beforeNotes.includes(note))entries.push({kind:'update',line:t('counterAddNote',{note})});
  for(const note of beforeNotes)if(!afterNotes.includes(note))entries.push({kind:'remove',line:t('counterRemoveNote',{note})});
  const kinds=new Set(entries.map(entry=>entry.kind));
  return {kind:kinds.size>1?'mixed':entries[0]?.kind||'kept',lines:entries.map(entry=>entry.line)};
 }
 g.KamCounterReply={next,describe,kinds:Object.keys(variants),variantsPerKind:48};
})(globalThis);

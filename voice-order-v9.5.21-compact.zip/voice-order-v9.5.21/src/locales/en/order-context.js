/* Order-wide context: deterministic packaging, mode changes and kitchen notes. */
(function(g){
 'use strict';
 const K=g.Kam,baseParse=K.parseCommand,baseAnalyze=K.analyzeLocal;
 const MAX_NOTES=12,MAX_NOTE_LENGTH=240;
 function normalizeNotes(notes=[]){if(!Array.isArray(notes)||notes.length>MAX_NOTES)throw new K.OrderError('invalidOrderNotes');const out=[];for(const value of notes){if(typeof value!=='string'||value.length>MAX_NOTE_LENGTH)throw new K.OrderError('invalidOrderNotes');const s=value.trim();if(s&&!out.includes(s))out.push(s);}return out;}
 function pricing(items,prices={},mode='dinein',version=1){
  if(!['dinein','takeaway'].includes(mode)||![0,1].includes(version))throw new K.OrderError('invalidPlan');
  const foodSubtotal=K.total(items,prices),foodKinds=new Set(items.filter(i=>!K.menu.find(m=>m.id===i.id)?.drink).map(i=>i.id));
  const takeaway=version===1&&mode==='takeaway'&&items.length>0,boxes=takeaway?foodKinds.size:0,bags=takeaway?1:0;
  const charges={version,boxBasis:'distinct-food',boxes,bags,boxRate:1,bagRate:1,boxFee:boxes,bagFee:bags,total:boxes+bags};
  return {foodSubtotal,charges,total:foodSubtotal+charges.total};
 }
 function clean(text){let s=K.tc(text).replace(/嚇/g,'吓').trim();for(let n=0;n<6;n++){const before=s;s=s.replace(/^(?:請問(?:一下|下)?|我想問(?:下|吓)?|想問(?:下|吓)?|你好)[\s，,]*/,'').replace(/^(唔該|麻煩)(?:你哋|你地|你們)/,'$1').replace(/^(?:你哋|你地|你們)(?:可唔可以)?/,'').trim();if(s===before)break;}return K.language.clean(s).replace(/[，,。;；.!！?？]+$/g,'').trim();}
 const TAKE='(?:轉(?:做|成|去|返|番)?外賣|改(?:做|成|去)?外賣|換外賣|叫外賣|要外賣|外賣自取|外賣帶走|外賣|打包帶走|打包|包走|拎返屋企|攞返屋企|拎返去食|攞返去食|拎走|攞走|帶走|行街|take\\s*away|takeout|to\\s*go)';
 const DINE='(?:轉(?:做|成|去|返|番)?堂食|改(?:做|成|去)?堂食|換堂食|要堂食|全堂食|全單堂食|堂食|留喺度食|喺度食埋|喺度用餐|喺舖頭食|喺鋪頭食|坐低食|喺呢度食|喺度食|係度食|在這[裏裡]吃|dine\\s*in|eat\\s*here)';
 const prefix='(?:(?:由|從)?(?:堂食|外賣)(?:改|轉)(?:做|成|去)?\\s*)?(?:(?:呢張單|嗰張單|張單|成張單|整張單|呢單|今次|依家|而家|只要|淨係|幫我|同我|我要|我想|就|都|全部)\\s*)*';
 const explicitNote=/^(?:整單備註|訂單備註|備註|記低|寫低)(?:係|是|為|做|一下|下)?[：:\s]*(.+)$/;
 const suffix='(?:先|呀|啊|啦|喇|呢|吖|唔該|多謝|please|thanks)*';
 const modeOnly=new RegExp('^'+prefix+'('+TAKE+'|'+DINE+')\\s*'+suffix+'$','i');
 function modeClause(text){const s=clean(text),m=s.match(modeOnly);if(!m)return null;return new RegExp('^'+TAKE+'$','i').test(m[1])?'takeaway':'dinein';}
 function noteInfo(value){
  const raw=clean(value),body=raw.replace(/^(?:全部|全單|成張單|整張單|每份|所有(?:食物|餐點)?)(?:都|一律)?\s*/,'').replace(/唔要辣|不要辣|走辣|免辣|唔落辣|唔加辣/g,'不辣').replace(/唔好咁辣/g,'少辣').replace(/(?:不要|唔要|走)香菜/g,'走芫茜');
  if(/除外|除咗|除了|但係|唯獨|其中/.test(body))return {raw,patch:{},unknown:[body],known:false};
  let prepared;try{prepared=K.prepareLocal(body,[]);}catch(error){return{raw,patch:{},unknown:error.data?.tokens?[error.data.tokens]:[body],known:false};}
  const {patch,conflicts}=K.parsePatch(prepared.normalized);
  if(prepared.unknown.length||conflicts.length||K.findItems(prepared.normalized).length||!Object.keys(patch).length)return {raw,patch:{},unknown:prepared.unknown.length?prepared.unknown:[body],known:false};
  return {raw,patch,unknown:[],known:true};
 }
 function noteKey(value){const info=noteInfo(value);if(!info.known)return 'text:'+K.tc(value).replace(/[\p{P}\s]/gu,'');const keys=Object.keys(info.patch).sort();if(keys.length===1&&['extrasAdd','extrasRemove'].includes(keys[0]))return 'extra:'+info.patch[keys[0]].slice().sort().join(',');return 'rule:'+keys.join(',')+(keys.includes('note')?':'+info.patch.note:'');}
 function mergeNotes(old,add=[],remove=[],clear=false){let next=clear?[]:normalizeNotes(old);const removed=new Set(remove.map(noteKey));next=next.filter(n=>!removed.has(noteKey(n)));for(const note of normalizeNotes(add)){const key=noteKey(note);next=next.filter(n=>noteKey(n)!==key);next.push(note);}return normalizeNotes(next);}
 function effectiveItems(items,notes=[]){
  const rules=normalizeNotes(notes).map(noteInfo).filter(n=>n.known);
  return items.map(raw=>{let i=K.normalize(raw);const m=K.menu.find(m=>m.id===i.id);
   for(const {patch}of rules){for(const [field,value]of Object.entries(patch)){
    const extraRule=['extrasAdd','extrasRemove'].includes(field),beverage=['drink','milk','sugar','ice','size'].includes(field)||extraRule&&value.every(id=>K.extras.find(x=>x.id===id)?.group==='drink');
    if(beverage){if(!i.drink||['待選飲品','不需要飲品'].includes(i.drink)||!K.applicable(m,field,i))continue;}
    else if(m.drink)continue;
    if(field==='note'){const note=[...new Set([i.note,value].filter(Boolean))].join('；');if(note.length<=240)i.note=note;continue;}
    if(!K.applicable(m,field,i))continue;
    if(extraRule){const values=value.filter(id=>K.allowedExtras(m,i).some(x=>x.id===id)||field==='extrasRemove'&&i.extras.includes(id));if(values.length)i=K.normalize({...i,[field]:values});continue;}
    try{i=K.normalize({...i,[field]:value});}catch(error){if(!['wholeNoodle','notApplicable','fixedSugar'].includes(error.code))throw error;}
   }}return i;
  });
 }
 function customize(text){
  const s=clean(text);
  if(/^(?:取消|刪除|移除|清除|清空)(?:全部|整單|全單|成張單|訂單)?(?:備註|要求)$/.test(s))return {intent:'customize',ops:[],orderNotesClear:true};
  const remove=s.match(/^(?:取消|刪除|移除|唔使|唔洗|唔駛)\s*((?:全部|全單|整張單|成張單).+)$/);
  if(remove)return {intent:'customize',ops:[],orderNotesRemove:[remove[1]]};
  const all=s.match(/^(?:全部|全單|成張單|整張單|每份|所有(?:食物|餐點)?)(?:都|一律)?\s*(.+)$/);
  const explicit=s.match(explicitNote);
  if(!all&&!explicit)return null;
  const body=(all||explicit)[1];if(!explicit&&/跟餐|改.*套餐|轉.*套餐|要餐/.test(body))return null;
  // Existing clear, repeat, quantity, drink removal and meal replacement commands keep their semantics.
  if(!explicit&&(/^(?:刪|清|取消|移除|重新|重頭|再叫|再嚟|唔要(?:晒|曬|喇|啦|$)|不要$)/.test(body)||/^(?:唔要|不要)(?:飲品|嘢飲|野飲)$/.test(body)||/^(?:改|轉|換)/.test(body)||K.findItems(body).some(h=>!K.menu.find(m=>m.id===h.id)?.drink)))return null;
  const note=explicit?body:'全部'+body;
  if(note.length>MAX_NOTE_LENGTH)throw new K.OrderError('invalidOrderNotes');
  const info=noteInfo(note);
  const adds=info.known?[...new Set(Object.entries(info.patch).flatMap(([key,value])=>['extrasAdd','extrasRemove'].includes(key)?value.map(id=>'全部'+(key==='extrasRemove'?'免':'')+(K.extras.find(x=>x.id===id)?.name||id)):key==='note'?(value.includes('花生')?['全部走花生']:value.split('；').map(n=>'全部'+n.replace('（蔥及芫茜）',''))):['全部'+(key==='spice'&&value==='不辣'?'唔要辣':value)]))]:[note];
  return {intent:'customize',ops:[],orderNotesAdd:adds,noteFallback:!info.known,unlearnedTokens:info.unknown};
 }
 function special(text,cart){
  if(K.language.control(text))return null;
  const s=clean(text),mode=modeClause(s);if(mode)return{intent:'service',mode,ops:[]};if(/^(?:全部|全單|所有)/.test(s)&&K.conversationalIntent?.(s,cart)?.intent==='navigate')return null;
  if(explicitNote.test(s))return customize(s);
  if(K.language.removeLine(s))return null;
  const parts=s.split(/[，,；;。]+/).map(p=>p.trim()).filter(Boolean);
  if(parts.length>1&&parts.some(p=>modeClause(p)||customize(p))){
   let simulated=cart.map(K.normalize),ops=[],nextMode,adds=[],removes=[],clear=false,fallback=false,tokens=[];
   const original=new Set(cart.map(i=>i.uid));
   for(const part of parts){const p=special(part,simulated)||baseParse(part,simulated);
    if(!['add','edit','customize','service','clear'].includes(p.intent))throw new K.OrderError('needClarification');
    if(p.mode){if(nextMode&&nextMode!==p.mode)throw new K.OrderError('conflictingService');nextMode=p.mode;}
    if(p.intent==='clear'){ops.push({type:'clear'});adds=[];removes=[];clear=true;simulated=[];}
    else{for(const op of p.ops||[]){const copy=structuredClone(op);if(copy.target?.uid&&!original.has(copy.target.uid)){copy.target.index=simulated.findIndex(i=>i.uid===copy.target.uid);delete copy.target.uid;}ops.push(copy);}simulated=K.applyPlan(simulated,p).items;}
    if(p.orderNotesClear){clear=true;adds=[];removes=[];}adds.push(...(p.orderNotesAdd||[]));removes.push(...(p.orderNotesRemove||[]));fallback||=!!p.noteFallback;tokens.push(...(p.unlearnedTokens||[]));
   }
   return{intent:'edit',ops,...(nextMode?{mode:nextMode}:{}),orderNotesAdd:adds,orderNotesRemove:removes,orderNotesClear:clear,noteFallback:fallback,unlearnedTokens:tokens};
  }
  const note=customize(s);if(note)return note;
  const equipment=/^(?:唔要|不要|唔使|唔洗)(?:餐具|筷子|叉|匙羹|飲管)/.test(s);const cooking=/^(?:切開|剪開|分裝|乾身啲|熟少少|(?:醬|汁).*(?:分開|另外)|唔好太油|唔好加辣)/.test(s);if(equipment||cooking&&baseAnalyze(s,cart).decision!=='local'){const info=noteInfo(s);return{intent:'customize',ops:[],orderNotesAdd:['特別要求：'+s],noteFallback:true,unlearnedTokens:info.unknown.length?info.unknown:[s]};}
  // A mode at the start/end of a new food order is interpreted together, atomically.
  const lead=s.match(new RegExp('^'+prefix+'('+TAKE+'|'+DINE+')[\\s：:]*([\\s\\S]+)$','i'));
  if(lead&&lead[2]&&!/^(?:唔|不|別|冇)/.test(lead[2])){const p=special(lead[2],cart)||baseParse(lead[2],cart);if(!['add','edit','customize'].includes(p.intent))throw new K.OrderError('needClarification');return{...p,mode:new RegExp('^'+TAKE+'$','i').test(lead[1])?'takeaway':'dinein'};}
  const tail=s.match(new RegExp('^([\\s\\S]+?)\\s*('+TAKE+'|'+DINE+')\\s*'+suffix+'$','i'));if(tail){const p=special(tail[1],cart)||baseParse(tail[1],cart);if(!['add','edit','customize'].includes(p.intent))throw new K.OrderError('needClarification');return{...p,mode:new RegExp('^'+TAKE+'$','i').test(tail[2])?'takeaway':'dinein'};}
  return null;
 }
 // Group identical draft portions after the complete command has addressed its line numbers.
 function groupDraft(items,portionOrder){
  const result=[],groups=new Map();
  const order=portionOrder===undefined?null:K.normalizePortionOrder(items,portionOrder);
  for(const raw of items){
   const item=K.normalize(raw),{uid,qty,pendingPair,drinkPrompted,...options}=item;
   const key=JSON.stringify({...options,extras:options.extras.slice().sort()});
   const group=groups.get(key),moved=group?Math.min(20-group.qty,qty):0;
   if(moved){
    group.qty+=moved;
    group.pendingPair=group.pendingPair&&pendingPair;
    group.drinkPrompted=group.drinkPrompted||drinkPrompted;
    let remaining=moved;
    for(let n=0;order&&n<order.length&&remaining;n++){
     if(order[n]===uid){order[n]=group.uid;remaining--;}
    }
   }
   if(moved<qty){
    const line={...item,qty:qty-moved};
    result.push(line);groups.set(key,line);
   }
  }
  return {cart:result,portionOrder:order};
 }
 const groupDraftLines=items=>groupDraft(items).cart;
 function transition(state,plan,availability={}){
  if(plan.mode&&!['dinein','takeaway'].includes(plan.mode))throw new K.OrderError('invalidPlan');
  const result=K.applyPlan(state.cart,plan,availability,state.portionOrder??null),notes=mergeNotes(state.orderNotes||[],plan.orderNotesAdd||[],plan.orderNotesRemove||[],plan.intent==='clear'||plan.orderNotesClear||(plan.ops||[]).some(op=>op.type==='clear')),mode=plan.mode||state.mode||'dinein';
  const items=effectiveItems(result.items,notes);
  if(notes.length&&['source-change-destination','atomic-changes'].includes(plan.grammar)){
   const itemIndex=new Map(result.items.map((item,index)=>[item.uid,index]));
   for(const change of result.changes){
    if(change.type!=='update')continue;
    const index=itemIndex.get(change.uid);
    if(index===undefined)continue;
    const field=change.fields.find(key=>Object.hasOwn(K.options,key)&&items[index][key]!==result.items[index][key]);
    if(field)throw new K.OrderError('orderNoteConflict',{name:K.menu.find(m=>m.id===change.id).name,option:field});
   }
  }
  for(const i of items)K.ensureAvailable(i,availability,state.cart.some(old=>old.uid===i.uid&&old.id===i.id));
  return {cart:result.items,portionOrder:result.portionOrder,mode,orderNotes:notes,effectiveItems:items,changes:result.changes};
 }
 function checkoutFields(state,prices=state.prices||{}){
  const orderNotes=normalizeNotes(state.orderNotes||[]),baseItems=state.cart.map(K.normalize),items=effectiveItems(baseItems,orderNotes);
  return {items,baseItems,orderNotes,mode:state.mode,table:state.table,pricingVersion:1,...pricing(items,prices,state.mode,1)};
 }
 function verifyCheckout(fields,availability={},allowExisting=false){
  if(!fields.items.length)throw new K.OrderError('emptyCart');
  for(const item of fields.items)K.ensureAvailable(item,availability,allowExisting);
  if(K.pendingDrinks(fields.items).some(i=>i.drinkStatus==='missing'))throw new K.OrderError('missingDrink');
 }
 const orderDate=new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Hong_Kong',year:'2-digit',month:'2-digit',day:'2-digit'});
 function orderNumber(now,token){
  const date=Object.fromEntries(orderDate.formatToParts(new Date(now)).map(part=>[part.type,part.value]));
  const suffix=String(token||K.uid()).replace(/[^a-z0-9]/gi,'').slice(-8).toUpperCase().padStart(8,'0');
  return 'KK-'+date.year+date.month+date.day+'-'+suffix;
 }
 async function placeOrder(readState,fields,{token,now,send,save}){
  const state=readState();
  if(state.orders.some(o=>o.token===token))return null;
  let order={id:orderNumber(now,token),token,at:now,updatedAt:now,...fields,prices:{...state.prices},status:'received',paid:false,revision:1,revisions:[],paidAmount:0};
  if(send)order=await send(order);
  await save({orders:[order,...readState().orders],cart:[],orderNotes:[]});
  return order;
 }
 K.checkoutFields=checkoutFields;K.verifyCheckout=verifyCheckout;K.placeOrder=placeOrder;
 K.groupDraft=groupDraft;K.groupDraftLines=groupDraftLines;K.normalizeOrderNotes=normalizeNotes;K.orderNoteInfo=noteInfo;K.mergeOrderNotes=mergeNotes;K.effectiveItems=effectiveItems;K.orderPricing=pricing;K.transitionDraft=transition;K.contextCommand=special;
 K.parseCommand=(text,cart=[])=>special(text,cart)||baseParse(text,cart);
 K.analyzeLocal=(text,cart=[])=>{try{const plan=special(text,cart);return plan?{decision:'local',plan,normalized:clean(text),corrections:[]}:baseAnalyze(text,cart);}catch(error){return {decision:['unrecognizedTokens','notUnderstood'].includes(error.code)?'fallback':'clarify',error};}};
 Object.assign(g.I18n.dict,{
  packaging:['外賣包裝費','Takeaway packaging'],boxFee:['餐盒 {n} 個 × $1','{n} box(es) × $1'],bagFee:['膠袋 {n} 個 × $1','{n} bag(s) × $1'],packagingPolicy:['每款食物一盒 $1；同款合計一盒。飲品免盒費；每張非空外賣單膠袋 $1。','One $1 box per distinct food item, combining identical dishes. Drinks have no box fee. One $1 bag per non-empty takeaway order.'],
  orderNotes:['整張訂單備註','Whole-order kitchen notes'],orderNotesHint:['適用於整張訂單；確認後會連同餐點交給廚房。','Applies to the whole order and is sent to the kitchen after confirmation.'],orderNotePlaceholder:['例如：全部走青、全部唔要辣、醬汁分開裝','e.g. no garnish for all food, no chilli, sauces packed separately'],addOrderNote:['加入備註','Add note'],removeOrderNote:['移除這項備註','Remove this note'],clearOrderNotes:['清除整單備註','Clear order notes'],noteSaved:['已保留整單要求，請核對備註。','Whole-order request saved. Please check the note.'],noteOnly:['已寫入廚房備註','Saved as a kitchen note'],invalidOrderNotes:['備註最多 12 項，每項最多 240 字。','Up to 12 notes, each up to 240 characters.'],conflictingService:['同一句有堂食及外賣兩種要求，請講清楚要邊一種。','Both dine-in and takeaway were requested. Please choose one.'],serverOrderMismatch:['伺服器回覆的費用或備註不一致，請先核對門店紀錄。餐單仍保留，未顯示為成功收單。','The server returned inconsistent fees or notes. Check the store records first. Your cart is kept and the order is not shown as successfully received.'],serverOrderContext:['門店伺服器尚未支援新版包裝費及整單備註，訂單未送出。請更新伺服器或使用單機模式。','The store server does not support packaging fees and order notes yet. Nothing was submitted. Update it or use local mode.'],serviceChanged:['已轉為{name}，餐點已保留。','Changed to {name}. Your items are kept.']
 });
})(globalThis);

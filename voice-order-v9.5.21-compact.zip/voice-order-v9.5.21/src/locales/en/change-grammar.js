/* Slot-based Cantonese edits. Menu vocabulary is data; A→B pairs are never enumerated.
 * Selectors describe the OLD value. Patches contain only the RIGHT-hand side.
 * Resolve to stable UIDs and simulate every operation before returning any plan.
 */
(function(g){
 'use strict';
 const K=g.Kam,baseParse=K.parseCommand,baseAnalyze=K.analyzeLocal;
 const menu=id=>K.menu.find(m=>m.id===id),err=(code,data)=>{throw new K.OrderError(code,data);};
 const verb=/(?:改一改做|改(?:做|成|為|叫|要|食|返|番)?|轉(?:做|成|為|叫|返|番)?|換(?:做|成|為|返|番|去)?|調做)/;
 const negative=/^(?:唔好|唔使|唔洗|唔駛|唔需要|唔係要|咪)(?:再)?(?:將|把)?/;
 const beverage=/飲品|杯[嘢野]飲|[嘢野]飲|嗰杯/;
 const ordinalSource='第\\s*([零〇一二兩三四五六七八九十廿卅卌\\d]+)\\s*([份個項杯餐碟件行列款號])?';
 const ordinalPattern=new RegExp(ordinalSource);
 const ordinalAtStart=new RegExp('^'+ordinalSource);
 const sameLine=/^(?:同一[份行杯]|嗰[份杯])(?:再)?(?:改做|改)?/;
 const hasOrdinal=t=>ordinalPattern.test(t);
 const startsOrdinal=t=>ordinalAtStart.test(t);
 const rowRemoval=new RegExp('^(?:取消|刪走|刪除|唔要)('+ordinalSource+')$|^('+ordinalSource+')(?:取消|刪走|刪除|唔要)$');
 const exactQuantity=new RegExp('^'+K.quantity.numPattern+'\\s*'+K.quantity.classifierPattern+'$','i');
 const partial=new RegExp('其中\\s*('+K.quantity.numPattern+')\\s*([份個杯件碟碗項])');
 const fieldKind=k=>['drink','sugar','ice','milk','size','temperature'].includes(k)?'drink':null;
 function clean(text){return K.language.clean(text).replace(/[「」『』“”"']/g,'').trim();}
 // A modifier may itself start with a change verb (轉鮮奶, 轉燕麥奶).
 // Tokenize those values before looking for the boundary between old and new.
 const verbModifiers=[...new Set([...Object.values(K.options).flat(),...K.lexicon.entries.filter(r=>r.kind==='modifier').map(r=>r.term)].filter(s=>verb.test(s)))].sort((a,b)=>b.length-a.length);
 function boundary(text){
  const spans=[];for(let at=0;at<text.length;){const token=verbModifiers.find(s=>text.startsWith(s,at));if(token){spans.push({start:at,end:at+token.length});at+=token.length;}else at++;}
  const re=new RegExp(verb.source,'g');let match;
  while((match=re.exec(text)))if(!spans.some(s=>match.index>=s.start&&match.index<s.end))return{index:match.index,length:match[0].length};
  // A terminal modifier can also be the request: 凍奶茶轉鮮奶.
  const last=spans.at(-1);return last&&last.start>0&&last.end===text.length?{index:last.start,length:0}:null;
 }
 function slots(fragment,cart=[],destination=false){
  const original=fragment;
  const ordinals=[...fragment.matchAll(new RegExp(ordinalSource,'g'))];
  const [ordinal]=ordinals;
  const index=ordinal?K.number(ordinal[1])-1:undefined;
  const amount=partial.exec(fragment),count=amount?K.number(amount[1]):undefined;
  const all=/所有|全部|每份|每杯|成單/.test(fragment);
  const last=/頭先|最後|上一份|啱啱/.test(fragment);
  if(ordinals.length>1||ordinal&&(last||all))err('needClarification');
  if(ordinal&&(!Number.isSafeInteger(index)||index<0))err('missingTarget');
  if(fragment.includes('其中')&&(!amount||fragment.slice(amount.index+amount[0].length).includes('其中')))err('needClarification');
  if(amount&&(!Number.isInteger(count)||count<1||count>20))err('invalidQty');
  if(amount&&all)err('needClarification');
  const select={...(ordinal?{index}:{}),...(last?{last:true}:{}),...(all?{all:true}:{}),...(amount?{count,unit:amount[2]}:{})};
  const drinkContext=beverage.test(fragment);
  let body=fragment.replace(partial,' ').replace(ordinalPattern,' ').replace(/頭先|最後|上一份|啱啱|所有|全部|每份|每杯|成單/g,' ')
   .replace(/跟餐(?=嗰杯|杯[嘢野]飲|飲品)|(?:嗰杯|杯)(?:飲品|[嘢野]飲)|[嘢野]飲|飲品|嗰杯|隻蛋|主食|主餐|嗰份|呢份|單點|嘅|(?:由|從|將|把)/g,' ').trim();
  if(!destination)body=body.replace(/個麵底|麵底/g,' ').trim();
  // Bare 正常 in a beverage edit means normal sugar. Named fields remain explicit.
  body=body.replace(/正常(?!甜|糖|冰|奶|湯|辣|醬|份量|多士)/g,'正常糖');
  if(!body)return{select,drinkContext,foods:[],drinks:[],patch:{},original};
  const prepared=K.prepareLocal(body,cart);
  if(prepared.unknown.length)err('unrecognizedTokens',{tokens:prepared.unknown.join('、')});
  // The lexicon ignores quantity filler in ordinary speech. In an edit,
  // an unattached count could mean either the new quantity or a split.
  let end=0,unmatched='';
  for(const hit of prepared.hits){
   unmatched+=prepared.original.slice(end,hit.start)+' ';
   end=hit.end;
  }
  unmatched+=prepared.original.slice(end);
  if(K.quantity.classified(unmatched).length)err('editQuantityScope');
  if(prepared.hits.some(h=>h.row.kind==='command'))err('needClarification');
  const hits=K.findItems(prepared.normalized),foods=hits.filter(h=>!menu(h.id).drink),drinks=hits.filter(h=>menu(h.id).drink);
  if(foods.length>1||drinks.length>1)err('needClarification');
  let rest=prepared.normalized.split('');for(const h of hits)for(let n=h.index;n<h.end;n++)rest[n]=' ';
  const {patch,conflicts}=K.parsePatch(rest.join(''),{strict:true});
  // Explicit beverage hits were already removed above. 鮮奶 inside the milk
  // modifier must not create a second, contradictory beverage selector.
  if(patch.drink==='熱鮮奶'&&patch.milk==='轉鮮奶')delete patch.drink;
  if(conflicts.length)err('conflictingOptions',{options:conflicts});
  let drink;
  if(drinks.length){const h=drinks[0];drink=K.parsePatch(prepared.normalized.slice(h.index,h.end)).patch.drink||menu(h.id).drink;}
  return{select,drinkContext,foods,drinks,patch,drink,original};
 }
 function candidates(old,cart,kind,rowIds){
  let list=cart.map((i,index)=>({i,index}));const s=old.select;
  if(Number.isInteger(s.index)){
   list=list.filter(x=>rowIds?x.i.uid===rowIds[s.index]:x.index===s.index);
   if(!list.length)err('missingTarget',{row:s.index+1,rows:rowIds?.length??cart.length});
  }
  if(old.foods.length)list=list.filter(x=>x.i.id===old.foods[0].id);
  if(old.drink){const explicit=/熱|凍|冰|冷|hot|iced|cold/i.test(old.original);list=list.filter(x=>explicit?x.i.drink===old.drink:x.i.drink.replace(/^[熱凍]/,'')===old.drink.replace(/^[熱凍]/,''));}
  if(kind==='drink')list=list.filter(x=>!!x.i.drink&&x.i.drink!=='不需要飲品');
  if(kind==='food')list=list.filter(x=>!menu(x.i.id).drink);
  if(kind==='bread')list=list.filter(x=>K.canSwapBread(menu(x.i.id)));
  for(const [key,value]of Object.entries(old.patch)){
   if(key==='extrasAdd')list=list.filter(x=>value.every(id=>x.i.extras.includes(id)));
   else if(key==='extrasRemove')err('needClarification');
   // The sauce field is authoritative. A matching kitchen annotation is not
   // an additional selector (manual option changes need not create that note).
   else if(key==='note'&&old.patch.sauce===value)continue;
   else list=list.filter(x=>JSON.stringify(x.i[key])===JSON.stringify(value));
  }
  if(s.last)list=list.slice(-1);
  if(!list.length)err('missingTarget',Number.isInteger(s.index)?{row:s.index+1,mismatch:true}:undefined);
  return list;
 }
 function scopedPlan(list,all,operation,grammar){
  const planFor=rows=>({intent:'edit',ops:rows.map(({i})=>operation(i)),grammar});
  if(list.length>1&&!all)err('ambiguousTarget',{
   choices:list.map(row=>({index:row.index,uid:row.i.uid,id:row.i.id,plan:planFor([row])})),
  });
  return planFor(list);
 }
 function partialRemoval(t,cart,rowIds){
  if(!t.includes('其中')||!/取消|刪走|刪除|唔要/.test(t))return null;
  if(negative.test(t))return {intent:'edit',ops:[],preserveDraft:true,grammar:'negated-change'};
  const remove=t.match(/^(?:取消|刪走|刪除|唔要)(.+)$|^(.+?)(?:取消|刪走|刪除|唔要)(其中.+)$/);
  if(!remove)return null;
  const old=slots(remove[1]||remove[2]+remove[3]);
  const kind=old.select.unit==='杯'||old.drinkContext||old.drink?'drink':null;
  if(!old.select.count)err('needClarification');
  const list=candidates(old,cart,kind,rowIds);
  const plan=scopedPlan(list,false,i=>({type:'remove',target:{uid:i.uid,count:old.select.count,...(kind?{kind}:{})}}),'partial-removal');
  K.applyPlan(cart,plan);
  return plan;
 }
 const spokenCode=[...new Set(['B','C',...g.CafeHK.setNames.C.split('|'),...Object.values(g.CafeHK.breakfastHomophones).flat()])]
  .sort((a,b)=>b.length-a.length).join('|');
 const breakfastQuantity=new RegExp('((?:早餐|早晨)\\s*(?:'+spokenCode+'))(?![a-z])\\s*('+K.quantity.numPattern+')\\s*[分芬](?=$|[\\s，,。！!？?呀啊啦喇囉吖]|唔該)','gi');
 const breakfastDigits=new RegExp('((?:早餐|早晨)\\s*(?:'+spokenCode+'|[A-G]))(?=\\d+\\s*[份個餐])','gi');
 const terminalBreakfastC=new RegExp('((?:早餐|早晨)\\s*)是(?=\\s*(?:(?:'+K.quantity.numPattern+')\\s*[份分芬個])?\\s*(?:$|[呀啊啦喇囉吖。！!？?]|唔該))','g');
 const eggTokens='炒蛋|抄蛋|炒旦|抄旦|煎蛋|煎旦|太陽蛋|反蛋|熟蛋';
 const noisyEggChange=new RegExp('^((?:(?:唔好|唔使|咪)\\s*)?(?:(?:第[一二兩三四五六七八九十\\d]+[份個項餐]|(?:早餐|早晨)[A-F])\\s*)?(?:'+eggTokens+'))\\s*[糕蓋]\\s*((?:'+eggTokens+'))$','i');
 function normalizeSpeech(text){
  const value=K.tc(text),spoken=clean(value);
  if(/^(?:整單備註|訂單備註|備註|記低|寫低)/.test(spoken))return value;
  const temp=spoken.match(/^(?:杯嘢|杯野|杯飲品|嗰杯|呢杯|杯嘢飲|杯野飲|杯飲品想)?(?:整(?:返|做)?|改(?:返|做)?|轉(?:返|做)?|換(?:返|做)?|要返)(凍|熱)(?:啲|少少|飲)$/);
  if(temp)return '轉'+temp[1]+'飲';
  const phrase=value.replace(/訓/g,'份')
   .replace(/(^|[\s，,。；;叫要嗌嚟來加畀俾一二兩三四五六七八九十廿\d])瞓(?=\s*[\p{Script=Han}A-Za-z])/gu,'$1份')
   .replace(/(早餐|早晨)\s*[:：-]\s*(?=[a-gＡ-Ｇ])/gi,'$1')
   .replace(/^(?:(?:唔該|麻煩你|幫我|我想|想)\s*)*改(?:張|餐)?單\s*(?:做|叫|轉|要|改|想要)?\s*/,'改做')
   .replace(/^(?:(?:唔該|麻煩你|幫我|請)\s*)*(?:幫我落單要|幫手落單要|我想嗌返|我嗌返|想嗌返|我想嚟返|俾返我|畀返我|嚟返)(?=\s*[一二兩三四五六七八九十廿\d份杯個件碗])/,'要')
   .replace(terminalBreakfastC,'$1C')
   .replace(breakfastQuantity,'$1$2份')
   .replace(breakfastDigits,'$1 ');
  if(!/[糕蓋]/.test(phrase))return phrase;
  const egg=clean(phrase);
  return noisyEggChange.test(egg)?egg.replace(noisyEggChange,'$1改$2'):phrase;
 }
 function bareModifier(t,cart){
  if(cart.length!==1||!t||/^(?:加|再|另|要|唔係|全部|所有|全單|整張單|成張單|每份|每杯)/.test(t))return false;
  try{
   const p=K.prepareLocal(t,cart);
   return !p.unknown.length&&p.hits.length>0&&p.hits.every(h=>h.row.kind==='modifier'||h.row.kind==='phonetic'&&h.row.field);
  }catch{return false;}
 }
 function modifierOnly(text){
  if(!text)return false;
  const {original,hits}=K.inspectLocal(text);
  let end=0;
  for(const hit of hits){
   if(!(hit.row.kind==='modifier'||hit.row.kind==='phonetic'&&hit.row.field)||original.slice(end,hit.start).trim())return false;
   end=hit.end;
  }
  return end>0&&!original.slice(end).trim();
 }
 function bareRowEdit(text,cart,rowIds){
  if(!startsOrdinal(text))return null;
  const {original,hits}=K.inspectLocal(text);
  const modifier=hits.find(hit=>hit.row.kind==='modifier'||hit.row.kind==='phonetic'&&hit.row.field);
  if(!modifier||!modifierOnly(original.slice(modifier.start)))return null;
  return single(original.slice(0,modifier.start)+'改做'+original.slice(modifier.start),cart,rowIds);
 }
 function single(text,cart,rowIds){
  const t=clean(text);if(!cart.length)return null;
  if(!verb.test(t)){
   if(bareModifier(t,cart))return single('改做'+t,cart,rowIds);
   if(rowRemoval.test(t)){
    const [selector,,unit]=ordinalPattern.exec(t);
    const kind=unit==='杯'?'drink':null;
    const [{i}]=candidates(slots(selector,cart),cart,kind,rowIds);
    return {intent:'edit',ops:[{type:'remove',target:{uid:i.uid,...(kind?{kind}:{})}}],grammar:'row-removal'};
   }
   return bareRowEdit(t,cart,rowIds)||partialRemoval(t,cart,rowIds);
  }
  // New orders and kitchen notes keep their established grammar.
  if(/^(?:另外|再加|另加|加多|再要|再嚟|再叫|整單備註|訂單備註|備註|記低|寫低)/.test(t)||K.language.control(t))return null;
  if(negative.test(t))return{intent:'edit',ops:[],preserveDraft:true,grammar:'negated-change'};
  const repair=t.match(/^唔係(.+?)[，,]?\s*(?:而係|係)(.+)$/);
  let left,right;
  if(repair){left=repair[1];right=repair[2];}
  else{const m=boundary(t);if(!m)return null;left=t.slice(0,m.index);right=t.slice(m.index+m.length);}
  if(!right.trim()){if(t.includes('其中')||hasOrdinal(t))err('needChange');return null;}
  if(/唔好|唔使|唔洗|唔駛|唔需要|咪/.test(left))return{intent:'edit',ops:[],preserveDraft:true,grammar:'negated-change'};
  // A specified quantity before a dish is a new order, not a missing old target.
  if(K.quantity.head(left)&&!/^第|其中/.test(left))return null;
  // Pure quantity operations, mode changes, recommendation and upgrade offers
  // remain in their dedicated grammars. Named dish upgrades are handled here.
  const implicit=!left.trim();
  if(implicit&&cart.length!==1&&!/^(?:凍|熱)$/.test(right))return null;
  if(/^(?:去)?(?:堂食|外賣)/.test(right))return null;
  const isUpgrade=/^套餐(?:$|\s|[熱凍])/.test(right.trim());
  if(isUpgrade&&!K.findItems(left).length&&!/第|頭先|最後|全部|所有|其中/.test(left))return null;
  const breadSubject=/^(?:多士|麵包|厚多士|烘多士|方包)$/.test(left.trim())&&/方包|白麵包|烘|飛邊/i.test(right);
  const old=slots(breadSubject?'':left,cart);
  if(Number.isInteger(old.select.index)&&!old.select.count&&exactQuantity.test(right.trim())){
   const drink=old.drinkContext||ordinalPattern.exec(left)?.[2]==='杯';
   const [{i}]=candidates(old,cart,drink?'drink':null,rowIds);
   const qty=K.quantity.portions(menu(i.id),K.quantity.head(right));
   const plan={intent:'edit',ops:[{type:'update',target:{uid:i.uid,...(drink?{kind:'drink'}:{})},patch:{qty}}],grammar:'row-quantity'};
   K.applyPlan(cart,plan);
   return plan;
  }
  const temperature=right.trim().match(/^(凍|熱)(?:飲|嘅|的)?$/);
  let next;if(temperature)next=slots('');else if(isUpgrade){const option=right.trim().replace(/^套餐/,'');next=slots(option,cart,true);}else next=slots(right,cart,true);
  if(next.select.index!==undefined||next.select.last||next.select.all||old.select.count&&next.select.count)err('needClarification');
  const count=old.select.count??next.select.count,unit=old.select.unit??next.select.unit;
  if(count&&old.select.all)err('needClarification');
  let patch={...next.patch};
  if(next.foods.length)patch.id=next.foods[0].id;
  if(next.drink)patch.drink=next.drink;
  if(temperature)patch.temperature=temperature[1];
  if(!Object.keys(patch).length&&!isUpgrade){
   // A numeric destination is handled by the existing quantity grammar.
   if(K.quantity.head(right)&&!count)return null;
   err('needChange');
  }
  // The destination determines what changes. An old beverage may refine a
  // meal selector without turning a meal replacement into a beverage edit.
  const replacingFood=!!patch.id||isUpgrade;
  const kind=replacingFood?'food':old.drinkContext||old.drink||Object.keys(patch).some(k=>fieldKind(k))?'drink':old.foods.length?'food':null;
  if(unit==='杯'&&kind!=='drink')err('needClarification');
  const sole=implicit&&cart.length===1;
  const soleEggChange=cart.length===1&&cart[0].qty===1&&menu(cart[0].id).combo&&
   !Object.keys(old.select).length&&!old.foods.length&&!old.drinks.length&&!old.drinkContext&&
   Object.keys(old.patch).length===1&&!!old.patch.egg&&Object.keys(patch).length===1&&!!patch.egg;
  const list=sole||soleEggChange||breadSubject&&cart.length===1?[{i:cart[0],index:0}]:candidates(old,cart,breadSubject?'bread':kind,rowIds);
  const plan=scopedPlan(list,old.select.all,i=>{
   const update={...patch};if(isUpgrade){if(!menu(i.id).upgradeTo)err(menu(i.id).combo?'alreadyCombo':'noUpgradeable');update.id=menu(i.id).upgradeTo;}
   if(update.id&&kind==='drink')err('notApplicable',{option:'drink',name:menu(i.id).name});
   if(sole||soleEggChange||breadSubject){
    const invalid=Object.keys(update).find(k=>fieldKind(k)&&(!i.drink||i.drink==='不需要飲品')||
      k==='toast'&&(!menu(i.id).bread||['方包','方包飛邊'].includes(update[k])&&!K.canSwapBread(menu(i.id)))||
      ['egg','noodle','broth','portion','spice'].includes(k)&&!K.applicable(menu(i.id),k,i));
    if(invalid&&!update.id)err('notApplicable',{option:invalid,name:menu(i.id).name});
   }
   // Never turn an explicit food name into a beverage-only selection by guessing.
   const destination=menu(update.id||i.id);
   if(update.drink&&!destination.combo&&!destination.drink)err('notApplicable',{option:'drink'});
   return{type:'update',target:{uid:i.uid,...(count?{count}:{}),...(kind==='drink'&&!sole?{kind:'drink'}:{})},patch:update};
  },'source-change-destination');
  K.applyPlan(cart,plan); // validates options, splitting, limits and identities atomically
  return plan;
 }
 function editParts(text){
  const chunks=text.split(/[，,；;。]+|(?:同埋|跟住|然後)(?=.+(?:改|轉|換))/).map(x=>x.trim()).filter(Boolean);
  const parts=[];
  for(const chunk of chunks){
   const previous=parts.at(-1);
   if(previous&&startsOrdinal(previous)){
    const modifier=clean(chunk.replace(sameLine,''));
    if(modifierOnly(modifier)){
     parts[parts.length-1]+=' '+modifier;
     continue;
    }
    if(sameLine.test(chunk))err('needClarification',{editClause:chunk});
   }
   parts.push(chunk);
  }
  return parts;
 }
 function interpret(text,cart=[],context={}){
  if(typeof text!=='string')return null;if(text.length>2000)err('invalidInput');
  const t=clean(text).replace(/(?:唔要|不要)[，,；;]\s*(?=(?:改|轉|換))/, '');if(!cart.length||(!verb.test(t)&&!t.includes('其中')&&!hasOrdinal(t)&&!bareModifier(t,cart))||K.language.control(t))return null;
  const correction=t.match(/^唔係(?:要)?(.+?)[，,；;]\s*(?:改(?:要|叫|做)?|轉(?:做|叫)?|而係|係)(.+)$/);
  if(correction)return single(correction[1]+'改做'+correction[2],cart);
  if(negative.test(t))return single(t,cart);
  if(/^唔係/.test(t))return single(t,cart);
  const parts=editParts(t);
  if(parts.length<2)return single(parts[0]||t,cart);
  let simulated=cart.map(K.normalize),ops=[],handled=false;const originalIds=new Set(cart.map(i=>i.uid));
  // In a batch of edits, line numbers refer to the draft shown before speech.
  // An initial add clause keeps the established sequential add-then-edit syntax.
  let rowIds=cart.map(i=>i.uid);
  const splitRows=new Set();
  for(const part of parts){let own,p;
   try{
    own=single(part,simulated,rowIds);
    p=own||baseParse(part,simulated,context);
    if(!ops.length&&p.intent==='add')rowIds=null;
    handled||=!!own;
    if(!['add','edit'].includes(p.intent))return null;
    if(rowIds&&!own&&startsOrdinal(part)){
     p={...p,ops:p.ops.map(op=>{
      if(!Number.isInteger(op.target?.index))return op;
      const {index,...target}=op.target;
      if(!rowIds[index])err('missingTarget',{row:index+1,rows:rowIds.length});
      return {...op,target:{...target,uid:rowIds[index]}};
     })};
    }
    for(const raw of p.ops||[]){
     const op=structuredClone(raw);
     if(op.target?.uid){
      if(rowIds&&(startsOrdinal(part)||rowRemoval.test(part))&&splitRows.has(op.target.uid))err('needClarification');
      const index=simulated.findIndex(i=>i.uid===op.target.uid);
      if(op.target.count<simulated[index]?.qty)splitRows.add(op.target.uid);
      if(!originalIds.has(op.target.uid)){op.target.index=index;delete op.target.uid;}
     }
     ops.push(op);
    }
    simulated=K.applyPlan(simulated,p,context.availability).items;
   }catch(error){
    const code=error.code==='ambiguousTarget'?'needClarification':error.code;
    if(rowIds&&code&&parts.some(hasOrdinal))err(code,{...error.data,editClause:part});
    if(error.code==='ambiguousTarget')err(code);
    throw error;
   }
  }
  return handled?{intent:'edit',ops,grammar:'atomic-changes'}:null;
 }
 K.changeGrammar={version:2,interpret,slots,modifierOnly};
 K.parseCommand=(text,cart=[],context={})=>{
  const normalized=normalizeSpeech(text);return interpret(normalized,cart,context)||baseParse(normalized,cart,context);
 };
 K.analyzeLocal=(text,cart=[],context={})=>{const at=performance.now();try{
  const normalized=normalizeSpeech(text),plan=interpret(normalized,cart,context);
  return plan?{decision:'local',plan,normalized:clean(normalized),corrections:[],elapsedMs:performance.now()-at}:baseAnalyze(normalized,cart,context);
 }catch(error){
  const scoped=error.data?.editClause||typeof text==='string'&&hasOrdinal(text)&&verb.test(text);
  return{decision:!scoped&&['unrecognizedTokens','notUnderstood'].includes(error.code)?'fallback':'clarify',error,elapsedMs:performance.now()-at};
 }};
})(globalThis);

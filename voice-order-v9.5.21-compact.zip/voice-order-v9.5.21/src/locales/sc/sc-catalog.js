/* Mandarin phrases are registered as complete menu/option tokens before
 * lexicon compilation. Homophones never replace unrelated Han characters. */
(function(g){'use strict';const entries=g.CafeLexicon.entries;
const items=[
 ['P1','菠蘿油','菠萝包夹黄油|菠萝包加黄油|黄油菠萝包|菠萝油包'],['P2','西多士','港式法式吐司|法式西多士|法式吐司'],
 ['P3','腿蛋治','火腿鸡蛋三明治|火腿炒蛋三明治|火腿滑蛋三明治'],['P6','蛋治','鸡蛋三明治|炒鸡蛋三明治|滑蛋三明治'],
 ['P7','餐肉蛋三文治','午餐肉鸡蛋三明治|午餐肉蛋三明治'],['P9','吞拿魚三文治','金枪鱼三明治|吞拿鱼三明治'],['P10','芝士三文治','奶酪三明治|芝士三明治'],
 ['P11','火腿三文治','火腿三明治'],['P14','果占多士','果酱吐司|果酱多士'],['P15','鮮牛油多士','黄油吐司|黄油多士'],['P4','奶油多士','炼奶黄油吐司|奶油吐司'],
 ['S1','炸雞翼','油炸鸡翅|香脆炸鸡翅|炸鸡翅|炸鸡次|炸机翅'],['S2','瑞士汁雞翼','瑞士汁鸡翅'],
 ['T1','熱奶茶','热奶查|热乃茶|热奶叉|温奶茶|奶茶热的|热的奶茶|热奈茶'],['T1','凍奶茶','冰奶查|冰乃茶|冰奶叉|冰奈茶|冰的奶茶|冷奶茶|奶茶冰的'],
 ['T2','熱檸茶','热柠檬查|热宁檬茶|热柠萌茶|温柠檬茶|柠檬茶热的'],['T2','凍檸茶','冰柠檬查|冰宁檬茶|冰柠萌茶|冰的柠檬茶|冷柠檬茶|柠檬茶冰的'],
 ['T3','熱咖啡','热咖非|热咖飞|热加啡|温咖啡|咖啡热的'],['T3','凍咖啡','冰咖非|冰咖飞|冰加啡|冰的咖啡|冷咖啡|咖啡冰的'],
 ['T4','熱鴛鴦','热鸳央|热冤鸯|温鸳鸯'],['T4','凍鴛鴦','冰鸳央|冰冤鸯|冰的鸳鸯'],
 ['T7','熱西洋菜蜜','热西洋菜密|热菜密'],['T7','凍西洋菜蜜','冰西洋菜密|冰菜密'],
];
const modifiers=[['sugar','走甜','不放糖|不加糖|不要糖|无糖|零糖|免糖|糖就不用了'],['sugar','少甜','少放糖|少加糖|微糖|少一点糖'],['sugar','半糖','一半糖|半份糖'],
 ['ice','走冰','不放冰|不要冰|无冰|冰就不用了|去冰'],['ice','少冰','少放冰|少加冰|少一点冰'],['milk','走奶','不放奶|不要奶|不加奶'],['milk','少奶','少加奶|少放奶'],
 ['toast','方包','白面包|白吐司|切片面包|不烤面包'],['toast','方包飛邊','白面包去边|白面包去皮'],['toast','飛邊','面包去边|吐司去边|去面包边'],
 ['egg','炒蛋','炒鸡蛋'],['egg','太陽蛋','煎鸡蛋|单面煎蛋'],['egg','反蛋','双面煎蛋|两面煎蛋'],['egg','走蛋','不加鸡蛋|不要鸡蛋'],
 ['broth','湯另上','汤分开装|汤单独装|汤另装|汤另外上'],['portion','少底','少一点饭|米饭少一点'],['sauce','少醬','少一点酱|少放酱'],['spice','不辣','不放辣椒|不要辣椒|不加辣椒']];
for(const[id,target,words]of items)for(const term of words.split('|'))entries.push({kind:'item',id,target,term});
for(const[field,target,words]of modifiers)for(const term of words.split('|'))entries.push({kind:'modifier',field,target,term});
for(const id of 'ABCDEF')for(const term of [id+'套餐',id+'号套餐','早餐'+id+'套餐','早餐'+id+'号'])entries.push({kind:'item',id,target:'早餐'+id,term});
entries.push({kind:'ambiguous',term:'吐司',target:'',ids:['P4','P2'],reason:'toastType'});
g.CafeMandarinCatalog={items,modifiers,count:items.reduce((n,r)=>n+r[2].split('|').length,0)+modifiers.reduce((n,r)=>n+r[2].split('|').length,0)+24};
})(globalThis);

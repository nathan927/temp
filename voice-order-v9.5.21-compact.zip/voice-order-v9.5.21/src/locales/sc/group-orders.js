/* Explicitly separated add-only clauses may be saved independently. A clause
 * that refers to another clause or changes an existing item remains atomic. */
(function(g){
 'use strict';
 const K=g.Kam,baseAnalyze=K.analyzeLocal,baseParse=K.parseCommand;
 const boundary=/[，,；;。]+|(?:同埋|跟住|然後)(?=(?:[一二兩三四五六七\d]+\s*[份個杯碗碟件]|(?:早餐|早晨)[A-F]))/g;
 const unsafe=/^(?:唔好|唔要|不要|咪|取消|刪|清|改|轉|換|第[一二兩三四五六七八九十\d]|其中|所有|全部|每份|每杯|照舊|再嚟同|同頭先|頭先|最後|上一份|訂單備註|整單備註)/;
 const reference=/(?:嗰份|呢份|同上|一樣|照舊|頭先|之前嗰|上述|其他人都|全部都|每人都)/;
 function segments(text){
  if(typeof text!=='string'||text.length>2000)return [];
  return text.split(boundary).map(s=>s.trim()).filter(Boolean);
 }
 function independent(parts){return parts.length>=2&&parts.length<=12&&
  parts.every(p=>!unsafe.test(p)&&!reference.test(p)&&!/(?:唔係|而係|改做|轉做|取消|撤銷|重新落單|先唔要)/.test(p));}
 function unresolvedClause(text,error){
  const detail=error?.data;
  const data=detail&&Object.fromEntries(['name','option','tokens','term'].filter(key=>typeof detail[key]==='string').map(key=>[key,detail[key]]));
  return {text,code:error?.code||'needClarification',...(data&&Object.keys(data).length?{data}:{})};
 }
 function parseGroup(text,cart=[],context={}){
  const parts=segments(text);if(!independent(parts))return null;
  const accepted=[],unresolved=[],corrections=[];
  for(const part of parts){
   const command=part.replace(/^另一\s*([份個杯件碟碗])(?=[\p{Script=Han}A-Za-z])/u,'一$1')
    .replace(/^其餘\s*([一二兩三四五六七\d]+)\s*([份個杯件碟碗])(?=[\p{Script=Han}A-Za-z])/u,'$1$2');
   // Empty cart prevents a free standing modifier from editing a previous
   // person's meal, and every complete clause must add real catalog lines.
   const result=baseAnalyze(command,[],context),plan=result.plan;
   if(plan&&plan.intent!=='add'||plan?.mode||plan?.orderNotesAdd?.length)return null;
   if(result.decision!=='local'||plan?.intent!=='add'||!plan.ops?.length||
      plan.ops.some(op=>op.type!=='add')){
    unresolved.push(unresolvedClause(part,result.error));continue;
   }
   try{
    const next=K.transitionDraft({cart,orderNotes:[],mode:'dinein'},
      {intent:'add',ops:[...accepted,...plan.ops]},context.availability);
    if(next.cart.length>50||next.cart.reduce((n,i)=>n+i.qty,0)>100)throw new K.OrderError('orderLimit');
    accepted.push(...plan.ops);corrections.push(...(result.corrections||[]));
   }catch(error){unresolved.push(unresolvedClause(part,error));}
  }
  // An unheard allergy, negation or correction may apply to the entire group.
  // Do not save a subset when that scope cannot be established safely.
  if(unresolved.some(({text})=>/敏感|過敏|花生|唔要|不要|唔好|唔食|不吃|免加|取消|改(?:做|叫|返)|轉(?:做|叫|返)|換(?:做|成)|唔係|除咗|除外/.test(text)))return null;
  if(!accepted.length)return null;
  return {decision:'local',plan:{intent:'add',ops:accepted,
    ...(unresolved.length?{partialUnresolved:unresolved}:{}),grammar:'separated-group-add'},
    normalized:text,corrections};
 }
 K.analyzeLocal=(text,cart=[],context={})=>{
  const original=baseAnalyze(text,cart,context),parts=segments(text);
  if(!independent(parts))return original;
  // Segmented interpretation also prevents a modifier after a separator from
  // leaking onto another diner's meal. A clear, complete result stays local.
  const group=parseGroup(text,cart,context);
  return group||original;
 };
 K.parseCommand=(text,cart=[],context={})=>{
  const group=parseGroup(text,cart,context);
  return group?.plan||baseParse(text,cart,context);
 };
 K.groupOrderSegments=segments;
})(globalThis);

/* Mandarin intent repair, shared by text, device transcripts, cloud replay and
 * manual pair validation. Scope and quantities still use the canonical engine. */
(function(g){'use strict';const K=g.Kam,analyze=K.analyzeLocal,parse=K.parseCommand;
const number='[零〇一二两兩三四五六七八九十廿\\d]+';
function rewrite(value){if(typeof value!=='string')return value;let s=K.tc(value);
 s=s.replace(/^(?:(?:請|麻煩))?(?:給我|幫我)(?:來|上)?\s*/,' ').replace(/倆(?=[份杯個碗盤]|早餐)/g,'兩').replace(/仨(?=[份杯個碗盤]|早餐)/g,'三').replace(/([一二兩三四五六七八九十\d]+[份杯個碗盤])兒(?=早餐|奶茶|咖啡|檸檬茶|三明治|炸雞)/g,'$1').replace(/不要太甜|不想太甜/g,'少甜');
 s=s.replace(/^(?:您好|你好|服務員|老闆)(?:[，,：:\s]*)/,'').replace(/^(?:給我來|給我上|幫我來|幫忙來|我想來|我要來|麻煩來|請來|來上)\s*/,'要').replace(/^來(?=[一二兩三四五六七八九十\d份杯個])/,'要');
 s=s.replace(/飲料/g,'飲品').replace(/炒雞蛋/g,'炒蛋').replace(/煎雞蛋/g,'煎蛋');
 s=s.replace(new RegExp('第('+number+')(?:個套餐|個餐|份餐)(?:的)?','g'),'第$1行').replace(new RegExp('(第'+number+'[份個行杯])的','g'),'$1');
 s=s.replace(/(第[一二兩三四五六七八九十\d]+[份個行杯])(?:雞蛋|麵包|吐司)(?=改|換|轉)/g,'$1');
 s=s.replace(/^(?:把)?(?:雞蛋|蛋|麵包|吐司|多士)(?=改|換|轉)/,'').replace(/^(?:蛋炒的|炒的)(?:換成|改成|換)煎的$/,'改煎蛋');
 s=s.replace(/所有飲品都/g,'全部飲品').replace(/每杯飲品都/g,'全部飲品').replace(/換成熱的|換成熱飲|換熱的|改熱的/g,'轉熱飲').replace(/換成冰的|換成冷的|換成冰飲|改冰的/g,'轉凍飲');
 s=s.replace(/^(?:再來|再上|再要)一份(?:一樣的|相同的|同樣的)$/,'跟多份').replace(/^(?:我也要|我也來|我要)(?:一樣的|同樣的|相同的)$/,'我要一樣');
 s=s.replace(/^(?:剛才|剛剛)(?:那個|那份|那一份|那一個)(?:我)?不要(?:了)?$/,'剛才一個唔要').replace(/^(?:最後一個|最後一份|上一個|上一份)(?:我)?不要(?:了)?$/,'剛才一個唔要');
 s=s.replace(/^(?:別|不要|不用)取消(?:訂單|餐單|全部)?$/,'不要取消訂單');
 s=s.replace(/^(?:打包外帶|打包帶走|改成外帶|換成外帶|外帶)$/,'轉外賣').replace(/^(?:在這裏吃|在這裡吃|改成堂食)$/,'轉堂食');
 s=s.replace(/(?:套餐的|套餐跟餐|跟餐的)飲品/g,'飲品').replace(/(?:飲品)(?:要|選擇|選|配)(?=(?:熱|冰|凍|冷))/g,'飲品');
 // A comma before an uncounted included drink does not create a second item.
 s=s.replace(/((?:早餐\s*[A-F]|[A-F]套餐))\s*[，,]\s*(?:配(?:一杯)?|飲品(?:要|選|改成)?\s*)?((?:熱|冰|凍|冷)(?:奶茶|咖啡|檸檬茶|檸茶|鴛鴦))/gi,'$1$2');
 s=s.replace(/(再來一份|再上一份)(?:但是|但|不過)(?:要|換成|改成)/g,'跟多份但要');
 return s;}
function distribution(text){
 const cleaned=K.language.clean(text),header=new RegExp('^('+number+')杯(奶茶|咖啡|檸檬茶|檸茶|鴛鴦)[，,\\s]+(.+)$').exec(cleaned);if(!header)return null;
 const rest=header[3],parts=[...rest.matchAll(new RegExp('('+number+')杯(.*?)(?='+number+'杯|$)','g'))];if(!parts.length)return null;
 const leftovers=rest.replace(new RegExp('('+number+')杯(.*?)(?='+number+'杯|$)','g'),'').replace(/[，,；;\s]/g,'');if(leftovers)throw new K.OrderError('needClarification');
 const total=K.number(header[1]);let allocated=0;const ops=[],unresolved=[];
 for(const part of parts){const qty=K.number(part[1]),tail=part[2].replace(/^[，,；;\s]+|[，,；;\s]+$/g,'');if(qty<1||qty>20)throw new K.OrderError('invalidQty');allocated+=qty;const temp=/^(冰|凍|冷|熱)的?$/.exec(tail);
 if(!temp){if(/不要|不喝|不吃|敏感|過敏|取消|清空|換|改|唔/.test(tail))throw new K.OrderError('needClarification');unresolved.push({text:part[0].replace(/[，,；;\s]+$/g,''),code:'unrecognizedTokens',data:{tokens:tail}});continue;}
 const r=analyze(qty+'杯'+(temp[1]==='熱'?'熱':'凍')+header[2],[]);if(!r.plan||r.plan.ops.some(o=>o.type!=='add'))throw r.error||new K.OrderError('needClarification');ops.push(...r.plan.ops);}
 if(allocated!==total)throw new K.OrderError('invalidQty');if(!ops.length)throw new K.OrderError('needClarification');return{intent:'add',ops,grammar:'mandarin-distribution',...(unresolved.length?{partialUnresolved:unresolved}:{})};
}
function completeAdds(text){const r=analyze(text,[],{cart:[]});return r.decision==='local'&&r.plan?.intent==='add'&&r.plan.ops?.length&&!r.plan.partialUnresolved?.length&&r.plan.ops.every(o=>o.type==='add')?r.plan:null;}
function compound(text,cart,context){
 const cleaned=K.language.clean(text),negative=/^我?(?:不要|不想要|不喝|不吃)(.+?)[，,；;]+(?:我)?(?:要|想要|換成|改成)(.+)$/.exec(text);
 if(negative){const rejected=completeAdds(negative[1]),wanted=completeAdds(negative[2]);if(!rejected||!wanted)throw new K.OrderError('needClarification');const item=rejected.ops[0].item,matches=cart.filter(i=>i.id===item.id||item.drink&&i.drink===item.drink);
 if(!matches.length)return wanted;if(matches.length!==1||wanted.ops.length!==1)throw new K.OrderError('ambiguousTarget');const index=cart.indexOf(matches[0]);const r=analyze('第'+(index+1)+'行改做'+negative[2],cart,context);if(r.plan?.intent!=='edit'||r.plan.partialUnresolved?.length)throw r.error||new K.OrderError('needClarification');return r.plan;}
 const refusal=/^我?(?:不要|不想要|不喝|不吃)(.+)$/.exec(text);if(refusal&&!/[，,；;]/.test(refusal[1])){const rejected=completeAdds(refusal[1]);if(rejected){const item=rejected.ops[0].item,matches=cart.filter(i=>i.id===item.id||item.drink&&i.drink===item.drink);return matches.length?{intent:'edit',ops:matches.map(i=>({type:'remove',target:{uid:i.uid}})),grammar:'mandarin-refusal'}:{intent:'edit',ops:[],preserveDraft:true,grammar:'mandarin-refusal'};}}
 const all=/^(.+)[，,]飲品都(?:要|選|配|換成)?(.+)$/.exec(cleaned);if(all){const meals=completeAdds(all[1]),drink=completeAdds('一杯'+all[2]);if(!meals||!drink||!meals.ops.every(o=>K.menu.find(m=>m.id===o.item.id)?.combo)||drink.ops.length!==1||!K.menu.find(m=>m.id===drink.ops[0].item.id)?.drink)throw new K.OrderError('needClarification');const d=K.normalize(drink.ops[0].item);return{intent:'add',ops:meals.ops.map(o=>({...o,item:{...o.item,drink:d.drink,sugar:d.sugar,ice:d.ice,milk:d.milk,size:d.size,extras:d.extras}})),grammar:'mandarin-shared-drinks'};}
 const customized=new RegExp('^((?:'+number+'份)?早餐[A-F][^，,；;]*)(?:[，,]\\s*|(?=雞蛋|蛋炒的|麵包|吐司|多士))((?:雞蛋|蛋|炒蛋|麵包|吐司|多士|飲品).+)$','i').exec(cleaned);
 if(customized&&!/^飲品都/.test(customized[2])){const meals=completeAdds(customized[1]);if(meals?.ops.length===1&&K.menu.find(m=>m.id===meals.ops[0].item.id)?.combo){let tail=customized[2].replace(/^(?:蛋炒的|炒蛋)(?:換成|改成|換)煎的$/,'改煎蛋').replace(/^(?:雞蛋|蛋|麵包|吐司|多士)(?=改|換|轉)/,'');const temp=K.applyPlan([],meals).items,r=analyze(tail,temp,{...context,cart:temp});if(!r.plan||r.plan.intent!=='edit'||r.plan.partialUnresolved?.length||!r.plan.ops.length||r.plan.ops.some(o=>o.type!=='update'||o.patch.id||o.patch.qty||o.patch.qtyDelta))throw r.error||new K.OrderError('needClarification');const result=K.applyPlan(temp,r.plan).items;return{intent:'add',ops:result.map(item=>({type:'add',item})),grammar:'mandarin-attached-customization'};}}
 const split=new RegExp('^('+number+')份早餐([A-F])[，,]\\s*(.+)$','i').exec(cleaned);if(split&&(context.lang==='sc'||context.language==='sc'||context.mandarin)&&new RegExp('^'+number+'[份杯](?:熱|冰|凍|冷)?(?:奶茶|咖啡|檸檬茶|檸茶|鴛鴦)').test(split[3])){const r=analyze(split[3],[],{cart:[]});if(r.plan?.intent!=='add'||!r.plan.ops?.length||r.plan.partialUnresolved?.length||!r.plan.ops.every(o=>o.type==='add'&&K.menu.find(m=>m.id===o.item.id)?.drink))throw r.error||new K.OrderError('needClarification');if(r.plan.ops.reduce((n,o)=>n+o.item.qty,0)!==K.number(split[1]))throw new K.OrderError('invalidQty');return{intent:'add',ops:r.plan.ops.map(o=>{const d=K.normalize(o.item);return{type:'add',item:{id:split[2].toUpperCase(),qty:d.qty,drink:d.drink,sugar:d.sugar,ice:d.ice,milk:d.milk,size:d.size,extras:d.extras}};}),grammar:'mandarin-meal-drinks'};}
 return null;
}
function resolve(text,cart,context){const normalized=rewrite(text),plan=compound(normalized,cart,{...context,mandarin:true,lang:'sc',language:'sc'})||distribution(normalized);let result=plan?{decision:'local',plan,corrections:[]}:analyze(normalized,cart,context);
 if(normalized!==text&&result.plan)result={...result,correctedText:normalized,corrections:[{from:text,to:normalized},...(result.corrections||[])]};return result;}
K.analyzeLocal=(text,cart=[],context={})=>{try{return resolve(text,cart,context);}catch(error){return{decision:'clarify',error};}};
K.parseCommand=(text,cart=[],context={})=>{const normalized=rewrite(text);return compound(normalized,cart,{...context,mandarin:true,lang:'sc',language:'sc'})||distribution(normalized)||parse(normalized,cart,context);};K.mandarin={rewrite};
})(globalThis);

/* Simplified page is a Mandarin experience, not Cantonese with different glyphs. */
(function(g){'use strict';const L=g.I18n;
Object.assign(L.scDict,{
 micPolicy:'这个预览阻挡了麦克风，请用完整浏览器独立打开 HTTPS 页面，再试一次。',noRecentPortion:'还没有上一份餐点可以重复或取消。先说说想吃什么吧～',
 brand:'智能茶餐厅',bag:'我的餐单',homeVoiceEyebrow:'现点现做 · 语音点餐',homeVoiceHeading:'说一句，马上记进餐单',homeMicHint:'说完稍停一下，餐点就会出现在“我的餐单”。',
 currentDraftHint:'核对餐点后，点确认才会送单',currentEmptyTitle:'还没有餐点',currentEmptyHint:'点麦克风，说说你想吃什么',draftReady:'餐单已更新，您可以继续说或确认下单。',
 startMic:'点击开始说话',stopMic:'点击停止收音',startingMic:'正在开启麦克风，请回应系统权限提示…',listening:'正在听，您请说…',voiceNeedsAttention:'请看下面的提示',
 confirmTranscript:'确认刚才听到的内容',editTranscript:'修改听到的文字',requestUnchanged:'原来的餐单先帮您留着，您说清楚我再改。',
 unavailable:'不好意思呀，我们没有卖{name}。换点别的好吃的吧～',soldOut:'哎呀，{name}今天卖完啦！看看其他餐点吧～',
 cantCustomize:'{name}暂时做不了“{option}”这个要求，咱们换个做法吧～',thisItem:'这款餐点',thisOption:'这个做法',drinkTemperature:'冷热',
 fixedSugar:'这杯本身就有甜味，没法再减糖啦。想喝无糖的，可以换一款～',
 unrecognizedTokens:'刚才“{tokens}”这一段没听清，麻烦再说一次呀～',notUnderstood:'刚才那句还没听明白，再说一次餐名，我帮您记～',
 needChange:'想怎么改呢？比如说“改少糖”或者“换热的”就行～',missingTarget:'还没找到您想改的那份。说说餐名，或者第几行吧～',
 needClarification:'我怕改错，您分开说，我一项项记～',conflictingOptions:'这两个要求有点冲突，您选一个，我马上改～',invalidQty:'数量有点对不上，麻烦再说一次要几份～',
 ambiguousTarget:'有好几份都符合，您想改哪一份呢？',emptyCart:'餐单还是空的呢，先说说想吃什么吧～',invalidOption:'这款暂时没有这个选项，咱们换一个吧～',
 partialUnresolved:'听清楚的 {n} 份已经放进「我的餐单」了。“{tokens}”这一段还没听清，请只重复这一段就好～',partialClauseReason:'“{text}”还没加进去。{reason}',
 partialNeedsAttention:'已经听清的餐点先记下了，还有下面几处需要补充：',partialNeedsRepeat:'“{text}”这一段没听清，您再说一次吧。',
 drinkQuestion:'套餐饮料还没选，要稍后再点吗？',drinkPending:'套餐饮料待选',drinkDeferred:'套餐饮料稍后再点',deferDrink:'稍后再点饮料',chooseDrink:'现在选饮料',drinkFollowup:'补点套餐饮料',
 missingDrink:'先选一杯套餐饮料，或者点“稍后再点饮料”就行。',drinkPriceHint:'标准热饮已包含，不加价；标准冰饮加 $3。特色饮品按列出的差价升级。',
 menuNote:'套餐含标准热饮；标准冰饮加 $3。特色饮品、加配与其他升级均按选项明码标价。',
 voiceCounterReply:'刚才帮您处理好了',voiceAdded:'好呀，已经记上啦～',voiceChanged:'好，已经帮您改好啦～',voiceKept:'收到，原来的餐单留着～',voiceNoted:'好呀，这个要求记下啦～',added:'好呀，已经加上 {n} 项～',updated:'好，已经帮您改好啦～',
 counterAddItem:'加了 {n} 份 {name}{options}',counterRemoveItem:'取消了 {n} 份 {name}',counterUpdateItem:'改了 {n} 份 {name}，{options}',counterField:'{field}改为{value}',counterChangedValue:'{from}换成{to}',
 counterQtyChange:'份数从 {from} 改为 {to}',counterAddNote:'加了整单备注“{note}”',counterRemoveNote:'取消了整单备注“{note}”',counterService:'现在是{name}。',counterUndo:'已撤销上一步。餐单现在有 {n} 份。',counterCleared:'未确认的餐单已清空。',
 counterRecommended:'刚帮您找到了下面这些推荐。',counterPreview:'餐单现在有 {n} 份。',counterNone:'没有',
 sessionOnlyHint:'这些餐点已经送单。还没选套餐饮料的，可以在原单继续补点。',finishAmendFirst:'先确认或取消当前修改，再继续操作吧。',
 cancelQuestion:'您想取消哪一份？说清楚再改，原来的餐单先留着～',draftEmptyCancel:'现在没有未送出的餐点需要取消，已下单的可以去“我的订单”查看。',
 recommendNeedsContext:'您想换哪一款呢？说“有什么推荐”，我再帮您选一套～',temperatureNeedsTarget:'想把哪杯改成冰的或热的？说说饮料名吧～',
 repeatNeedsTarget:'先点一份餐，再说“再来一份一样的”，我就知道跟哪份啦。',repeatNeedsOption:'想再来一份怎么配？说说餐名或饮料吧～',
 handsFreeMode:'连续点餐（7 秒没声音自动停止）',handsFreeSettingHint:'默认开启。每段说完就更新草稿，再继续听。“就这些”“没有了”“OK”等会停止收音，不会自动送单。',
 handsFreeHint:'可以接着说；7 秒没声音会停止，说“就这些”也可以。',handsFreeReady:'连续点餐已开启，点麦克风就能开始。',handsFreeListening:'正在继续听～说“就这些”，或再点麦克风就停止。',
 handsFreeQueued:'还在听；正按顺序处理 {n} 段话。',handsFreeFinishing:'已停止收音，还有 {n} 段已听到的内容正在处理。',handsFreeStopped:'已经停止收音，餐单帮您留好了。',
 voiceClosingAmbiguous:'最后那句是想取消这份，还是说完了呢？原单先保留；要删餐可以说“取消上一份”，说完可以说“就这些”。',
 voiceQueueFull:'刚才收到好多段啦，先处理已经听到的内容。稍等一下，再点麦克风补充剩下的吧。',
 deviceTranscriptMissing:'设备还没传回语音文字。原单留着，请再说一次；也可以先测试麦克风。',micNoMatch:'设备刚才没传回清楚的文字。先测试收音；有声音的话，再检查语音服务或选择云端转录吧。',
 micDenied:'麦克风权限还没允许。点“再试收音”；没有权限提示的话，到浏览器或 App 设置开启麦克风。',micSpeechDenied:'手机或浏览器没有允许语音识别，请检查这个网站及浏览器的麦克风权限，再试一次。',
 micSpeechNetwork:'设备语音服务连接失败，餐单留着。请检查网络，或者在设置选择云端转录。',micSpeechLanguage:'设备语音服务暂时不支持当前语言，请安装对应语言或选择云端转录。',micRecognitionTimeout:'设备语音服务一直没有回应，先保留餐单。再试一次，或者在设置选云端转录吧。',
 micSilent:'没收到清楚的声音。检查麦克风总开关、耳机和其他录音应用，再做一次收音测试吧。',recordShort:'刚才录音太短啦，再说一次，我认真听～',
 micSpeechInterrupted:'刚才语音中断啦，回到点餐页，再点麦克风试试。',micSpeechUnavailable:'这里没能开启设备语音服务，请用完整浏览器打开 HTTPS 页面，再检查手机语音设置。',
 unexpectedFailure:'刚才这一步遇到点问题，原单先留着。再试一次，或者直接在餐牌选吧。',
 invalidJSON:'后备服务刚才没答完整，餐单没有改。您再试一次，或拆成短句说吧。',invalidPlan:'后备服务没给出可用的修改方案，先不改餐单。麻烦再说清餐名和份数。',
 emptyResponse:'后备服务没传回点餐内容，餐单留着，再试一次吧。',providerError:'后备服务这次没处理好，餐单已保留。可以重试，或在餐牌直接选。',
 missingKey:'还没有可用的后备服务金钥。在设置加入 API key 并选好服务，再试一次吧。',invalidProvider:'后备服务还没选对，到设置重新选择，再试一次吧。',
 apiInvalidKey:'后备服务不接受这条 API key，请到设置核对金钥和服务类型，再试一次。',apiForbidden:'这条 key 暂时不能使用当前模型，请在设置选择账户可用的服务或模型。',
 apiRateLimit:'后备服务现在有点忙，等一会儿再试吧。餐单帮您留着。',apiUnavailable:'后备服务暂时连接不上，原单已保留。可以重试，也可以直接选餐。',apiQuota:'后备服务的用量暂时不够，餐单保留着。可以直接选餐，或恢复用量后再试。',
 unsafeAIAction:'这个回覆会影响整张餐单，先不改。您说清楚要改哪几份吧。',staleVoiceOrder:'您刚才已经改过餐单，旧回覆先不套用。请按现在的餐单再说一次想怎么改。',
 auditReadFailed:'完整记录暂时没读齐，这次没有下载。请保持页面开启，再试一次。',
 manualPairIntro:'把您习惯的说法，配对到现有餐点、配搭或指令。保存配对时不会下单，说出新叫法时才会使用。',manualPairTarget:'等同的现有说法',manualPairType:'输入一个字，就会列出所有符合的现有说法。',
 manualPairSourceInvalid:'新叫法至少要有两个字，请使用中文、英文字母或数字。',manualPairTargetInvalid:'还找不到可以配对的现有说法。请选一个候选，或输入完整指令。',manualPairDuplicate:'这个新叫法已有配对，可以在下面点“修改”。',manualPairSourceKnown:'系统已经认识这个说法，请换个新叫法，避免覆盖原有指令。',
 manualPairSaved:'配对已经保存。',manualPairRemoved:'配对已经删除。',manualPairNoMatches:'暂时没有候选，可以继续输入完整指令，保存时会再核对。',
 voiceLanguageLocked:'语音语言跟随页面：简体中文用普通话，繁体中文用粤语，English 用英语。',
 mimoProfile:'MiMo API 类型',standardKey:'一般 API key',chinaRegion:'中国',singaporeRegion:'新加坡',minimaxRegion:'MiniMax API 地区',globalRegion:'国际',minimaxModel:'MiniMax 模型',mimoModel:'MiMo 模型',
});
const originalFail=L.voiceFailCopy,originalLead=L.exceptionLead;let failed=0;
const begins=['哎呀','不好意思呀','抱歉','刚才听漏了一点','稍等一下','哎哟','我再认真听听','这句差点就听全了','刚才声音有点模糊','刚才没接住这句','再给我一次机会','我想确认清楚'];
const ends=['麻烦再说一次～','您再说一遍，我马上记～','请再讲一次餐名吧～','慢慢说一遍，我帮您记下～','把没听清那段再说一次吧～','再来一次，我在听～','重复一下刚才那句就好～','再告诉我一次吧～','请再说一遍想怎么点～','重说一次，我接着记～','咱们再试一下吧～'];
L.voiceFailCopy=(lang='tc')=>{if(lang!=='sc')return originalFail(lang);const i=failed++%132;return begins[i%12]+'，'+ends[Math.floor(i/12)];};
const counts=new Map(),kindLeads=['这一步我想先确认一下。','我怕弄错，先问清楚。','原来的餐单先帮您留着。','这次还需要补充一点信息。','咱们再核对一下这个要求。','这一步暂时没能完成。','我先停一下，避免改错。','稍等，看看下面怎么处理。'];
L.exceptionLead=(code,lang='tc')=>{if(lang!=='sc')return originalLead(code,lang);if(['micNoMatch','micSilent','micRecognitionTimeout','deviceTranscriptMissing','recordShort','notUnderstood','unrecognizedTokens'].includes(code))return L.voiceFailCopy(lang);const i=counts.get(code)||0;counts.set(code,(i+1)%128);return ['','哎呀，','不好意思，','稍等一下，','别着急，','嗯，','这边提醒一下，','我再帮您确认一下，'][Math.floor(i/16)]+kindLeads[i%8]+(i%16<8?'':'我们一步步来。');};
const starts={add:['好呀，已经加上啦。','收到，刚才点的记下了。','没问题，餐单加好了。','您说的这几样已经记上。','好嘞，已经加进草稿。','刚才这些都记好了。','已经帮您写进餐单。','好，新增餐点记下啦。'],update:['好，已经改好了。','收到，刚才的修改记下了。','新配搭已经更新。','您说的要求已经改好。','没问题，这份已经调整。','好嘞，餐单改好了。','已经按您刚才说的修改。','这个改动已经记好了。'],remove:['好，已经取消了。','收到，指定餐点删好了。','已经移除这些餐点。','您说不要的已经取消。','好嘞，已经从草稿去掉。','指定的份数已经减掉。','已经按要求取消。','没问题，这几份去掉了。'],mixed:['好，刚才几步都处理好了。','收到，已经逐项记好了。','您说的修改已经一起处理。','这次的变动已经记下。','好嘞，刚才这些都跟上了。','已经按顺序完成这几步。','没问题，下面是处理结果。','刚才的要求都处理好了。'],undo:['好，已经撤销上一步。','刚才那一步已经还原。','收到，恢复到修改前。','上一项修改已经撤回。','好嘞，已经退回一步。','之前的餐单恢复好了。','已经还原刚才的操作。','没问题，上一步取消了。'],info:['好，已经处理好了。','收到，结果在下面。','这一步已经完成。','您要的信息准备好了。','好嘞，已经帮您查好。','没问题，已经准备好了。','刚才的要求已经收到。','这一步已经帮您处理。'],kept:['好，餐单保持原样。','收到，原来的配搭保留。','这一步没有改餐单。','原先选的餐点都留着。','没问题，餐单照旧。','已经保留原来的选择。','好嘞，还是原来的配搭。','您的餐单没有变动。']};
const tails=['','还想加什么可以继续说。','有其他要求可以接着说。','餐单已经保留好了。','需要调整可以告诉我。','您可以继续点餐。'];const next=g.KamCounterReply.next,success=new Map();
g.KamCounterReply.next=(kind,lang='tc')=>{if(lang!=='sc')return next(kind,lang);const list=starts[kind]||starts.info,i=success.get(kind)||0;success.set(kind,(i+1)%48);return list[i%8]+tails[Math.floor(i/8)];};
})(globalThis);

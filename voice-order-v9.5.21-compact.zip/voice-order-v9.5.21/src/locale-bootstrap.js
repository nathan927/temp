/* A page owns exactly one immutable locale and one storage namespace. A
 * language change navigates to a new document/realm, rather than hot-swapping K. */
(function(g){'use strict';const valid=value=>['tc','sc','en'].includes(value);let raw=null,sessionRaw=null;try{raw=g.localStorage;}catch{}try{sessionRaw=g.sessionStorage;}catch{}
let url;try{url=new URL(g.location?.href||('https://voice-order.invalid/'+(g.location?.search||'')));}catch{url=new URL('https://voice-order.invalid/');}
let id=url.searchParams.get('lang');if(!valid(id)&&valid(g.KAM_LANG))id=g.KAM_LANG;if(!valid(id)){try{id=raw?.getItem('voice-order.active-language.v1');}catch{}if(!valid(id))id='tc';}
const prefix='voice-order.v20.'+id+'.',legacyKey='voice-order.legacy-shared.v1',claimKey='voice-order.legacy-claims.v1';
const keys=['kamkee.v2','kamkee.evolution.v1','kamkee.voice-statistics.v1','kamkee.unlearned.v1','kamkee.debug.v9'];
try{if(raw&&!raw.getItem(legacyKey)){const entries={};for(const key of keys){const value=raw.getItem(key);if(value!==null)entries[key]=value;}if(Object.keys(entries).length)raw.setItem(legacyKey,JSON.stringify({schema:1,at:new Date().toISOString(),entries}));}}catch{}
const scoped=store=>Object.freeze({getItem(key){if(!String(key).startsWith('kamkee.'))throw Error('invalid-workspace-key');return store?.getItem(prefix+key)??null;},setItem(key,value){if(!String(key).startsWith('kamkee.'))throw Error('invalid-workspace-key');if(!store)throw Error('Storage unavailable');store.setItem(prefix+key,String(value));},removeItem(key){if(!String(key).startsWith('kamkee.'))throw Error('invalid-workspace-key');store?.removeItem?.(prefix+key);}});
const legacy=()=>{try{return JSON.parse(raw?.getItem(legacyKey)||'null');}catch{return null;}};
const claims=()=>{try{return JSON.parse(raw?.getItem(claimKey)||'{}');}catch{return {};}};
const assignLegacy=(rows,write)=>{if(!raw)throw Error('Storage unavailable');const before=raw.getItem(claimKey),all=claims();for(const row of rows){const key=row.kind+':'+row.index;if(all[key])throw Error('legacy-already-classified');all[key]=id;}raw.setItem(claimKey,JSON.stringify(all));try{write();}catch(error){try{if(before===null)raw.removeItem(claimKey);else raw.setItem(claimKey,before);}catch{}throw error;}};
const navigate=next=>{if(!valid(next))throw Error('invalid-language');if(next===id)return false;const target=new URL(g.location?.href||url.href);target.searchParams.set('lang',next);try{raw?.setItem('voice-order.active-language.v1',next);}catch{}if(g.location?.assign)g.location.assign(target.href);else throw Error('navigation-unavailable');return true;};
g.KamLocale=Object.freeze({id,prefix,storage:scoped(raw),sessionStorage:scoped(sessionRaw),databaseName:'smart-cafe-audit-v20-'+id,locale:{tc:'zh-HK',sc:'zh-CN',en:'en-HK'}[id],legacy,claims,assignLegacy,navigate});
})(globalThis);

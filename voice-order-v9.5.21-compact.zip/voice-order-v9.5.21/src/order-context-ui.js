function effectiveCart(){return K.effectiveItems(S.cart,S.orderNotes||[]);}
function currentBill(){return K.orderPricing(effectiveCart(),activePrices(),S.mode,1);}
function draftSnapshot(){return {cart:structuredClone(S.cart),portionOrder:S.portionOrder.slice(),mode:S.mode,table:S.table,orderNotes:[...(S.orderNotes||[])]};}
function saveDraft(cart,metadata={},remember=true){
 const next={cart:cart.map(K.normalize),mode:metadata.mode??S.mode,table:metadata.table??S.table,orderNotes:K.normalizeOrderNotes(metadata.orderNotes??S.orderNotes??[])};
 if(metadata.portionOrder)next.portionOrder=K.normalizePortionOrder(next.cart,metadata.portionOrder);
 if(!['dinein','takeaway'].includes(next.mode))throw new K.OrderError('invalidPlan');
 if(next.cart.length>50||next.cart.reduce((n,i)=>n+i.qty,0)>100)throw new K.OrderError('orderLimit');
 K.effectiveItems(next.cart,next.orderNotes);const previous=draftSnapshot();update(next);confirmToken=K.uid();
 KamDebug.log('order','draft.context',{mode:next.mode,orderNotes:next.orderNotes,charges:K.orderPricing(K.effectiveItems(next.cart,next.orderNotes),activePrices(),next.mode).charges});if(remember){undos.push(previous);if(undos.length>25)undos.shift();}render();
}
function packagingMarkup(bill){if(!bill.charges.total)return '';return `<section class="packaging-summary" aria-label="${t('packaging')}"><div><span>${t('subtotal')}</span><b>${money(bill.foodSubtotal)}</b></div><div><span>${t('boxFee',{n:bill.charges.boxes})}</span><b>${money(bill.charges.boxFee)}</b></div><div><span>${t('bagFee',{n:bill.charges.bags})}</span><b>${money(bill.charges.bagFee)}</b></div><small>${t('packagingPolicy')}</small></section>`;}
function orderNotesMarkup(){const notes=S.orderNotes||[];return `<section class="order-notes" aria-labelledby="order-notes-title"><header><h3 id="order-notes-title">${t('orderNotes')}</h3>${notes.length?`<button class="text-button" data-action="clear-order-notes">${t('clearOrderNotes')}</button>`:''}<details class="order-note-editor"><summary>${t('addOrderNote')}</summary><form id="order-note-form"><label class="sr-only" for="order-note-input">${t('orderNotes')}</label><input id="order-note-input" maxlength="240" placeholder="${t('orderNotePlaceholder')}" autocomplete="off"><button class="secondary" type="submit">${t('save')}</button></form></details></header>${notes.length?`<ul>${notes.map((n,index)=>`<li><span>${esc(n)}</span><button data-remove-order-note="${index}" aria-label="${t('removeOrderNote')}">×</button></li>`).join('')}</ul>`:''}</section>`;}
function refreshOrderContext(){const slot=$('#order-context-slot');if(slot)slot.innerHTML=orderNotesMarkup();const fees=$('#packaging-slot');if(fees)fees.innerHTML=packagingMarkup(currentBill());}
function changeService(mode,quiet=false){if(!['dinein','takeaway'].includes(mode))throw new K.OrderError('invalidPlan');if(mode!==S.mode)saveDraft(S.cart,{mode});else render();KamDebug.log('order','service.changed',{mode,charges:currentBill().charges,cartUids:S.cart.map(i=>i.uid)});if(!quiet)toast(t('serviceChanged',{name:t(mode)}));$('.servicebar')?.scrollIntoView?.({behavior:'smooth',block:'nearest'});}
function addOrderNote(value){const note=String(value||'').trim();if(!note)return;const notes=K.mergeOrderNotes(S.orderNotes||[],[note]);saveDraft(S.cart,{orderNotes:notes});const info=K.orderNoteInfo(note);if(!info.known){const inputId=K.uid();unlearned.capture({inputId,text:note,kind:'note-fallback',terms:info.unknown,source:'manual-note',phase:'order-note',context:S.cart,orderContext:{mode:S.mode,orderNotes:S.orderNotes},error:'customNoteFallback'});unlearned.settle(inputId,{status:'resolved',noteOnly:true});}KamDebug.log('order','note.added',{note,structured:info.known});}
function kitchenNotes(notes=[]){return notes.length?`<section class="ticket-order-notes"><strong>${t('orderNotes')}</strong><ul>${notes.map(n=>`<li>${esc(n)}</li>`).join('')}</ul></section>`:'';}
function pricedOrderFields(){return {...K.checkoutFields(S,activePrices()),language:KamLocale.id};}
function validateStoredOrder(o){
 if(!['dinein','takeaway'].includes(o.mode))throw new K.OrderError('invalidBackup');
 o.items=o.items.map(K.normalize);o.orderNotes=K.normalizeOrderNotes(o.orderNotes||[]);const version=o.pricingVersion??0,bill=K.orderPricing(o.items,o.prices,o.mode,version);
 if(bill.total!==o.total)throw new K.OrderError('invalidBackup');
 if(version===1){if(!o.charges||Object.keys(bill.charges).some(k=>o.charges[k]!==bill.charges[k])||o.foodSubtotal!==bill.foodSubtotal)throw new K.OrderError('invalidBackup');o.baseItems=(o.baseItems||o.items).map(K.normalize);if(JSON.stringify(K.effectiveItems(o.baseItems,o.orderNotes))!==JSON.stringify(o.items))throw new K.OrderError('invalidBackup');}
 return o;
}
async function requireOrderContextBackend(fields){if(!S.settings.apiBase||(!fields.charges.total&&!fields.orderNotes.length))return;const store=await storeAPI('/store');if(!(store.capabilities?.orderContext>=1))throw new K.OrderError('serverOrderContext');}
document.addEventListener('submit',e=>{if(e.target.id==='order-note-form'){e.preventDefault();try{addOrderNote($('#order-note-input').value);}catch(error){voiceError(error);}}});

function validateServerContext(order,fields){if(!fields.charges.total&&!fields.orderNotes.length)return;try{if(order.mode!==fields.mode||order.total!==fields.total||JSON.stringify(order.orderNotes)!==JSON.stringify(fields.orderNotes)||!order.charges||Object.keys(fields.charges).some(k=>order.charges[k]!==fields.charges[k]))throw Error('Server order context mismatch');validateStoredOrder(order);}catch(error){throw new K.OrderError('serverOrderMismatch',{reason:error.code||error.message});}}

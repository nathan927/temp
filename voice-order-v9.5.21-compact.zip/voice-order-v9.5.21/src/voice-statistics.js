/* Persistent per-message accounting; a cloud ASR + local parse still used an API. */
(function(g){
 'use strict';
 const appVersion='9.5.21';
 const fields=['received','apiEligible','apiEligibleUsed','apiMessages','localResolved','apiASRLocalResolved','modelResolved','resolved','clarification','failed','pending','cancelled','withDeviceText','initialLocal','initialFallback','initialClarify','noDeviceText','asrMessages','parseMessages','apiRequests','apiOK','apiFailed','apiPending','retries'];
 const outcomeFields=['outcomeMeasured','localFirstPass','localAfterClarification','localAfterRetry','noteFallback','notesOnly','unresolved'];
 fields.push(...outcomeFields);
 const empty=()=>({counts:Object.fromEntries(fields.map(k=>[k,0])),providers:{},reasons:{},intents:{}});
 function merge(a,b){for(const k of fields)a.counts[k]=(a.counts[k]||0)+(b.counts[k]||0);for(const group of ['providers','reasons','intents'])for(const [k,v]of Object.entries(b[group]||{})){if(typeof v==='number')a[group][k]=(a[group][k]||0)+v;else{a[group][k]??={};for(const [field,n]of Object.entries(v))a[group][k][field]=(a[group][k][field]||0)+n;}}return a;}
 const day=at=>new Date(at).toLocaleDateString('en-CA',{timeZone:'Asia/Hong_Kong'});
 function contribution(m){
  const s=empty(),c=s.counts;c.received=1;c.apiEligible=+!!m.cloudConfigured;c.withDeviceText=+!!m.deviceText;c.noDeviceText=+!m.deviceText;c.retries=m.retries||0;
  const hasAPI=Object.values(m.providers).some(p=>p.asr.attempts+p.parse.attempts>0);c.apiMessages=+hasAPI;c.apiEligibleUsed=+(hasAPI&&m.cloudConfigured);
  c.pending=+(m.status==='processing');c.resolved=+(m.status==='resolved');c.clarification=+(m.status==='clarification');c.failed=+(m.status==='failed');c.cancelled=+(m.status==='cancelled');
  c.localResolved=+(m.status==='resolved'&&!hasAPI);c.apiASRLocalResolved=+(m.status==='resolved'&&Object.values(m.providers).some(p=>p.asr.ok>0)&&m.finalSource==='dictionary');c.modelResolved=+(m.status==='resolved'&&m.finalSource==='model');
  if(m.outcomeTracked){
   c.outcomeMeasured=1;
   c.noteFallback=+(m.status==='resolved'&&!!m.noteFallback);
   c.notesOnly=+(m.status==='resolved'&&!!m.noteOnly);
   c.unresolved=+['failed','clarification','cancelled'].includes(m.status);
   if(c.localResolved&&!c.noteFallback){
    if(m.hadClarification)c.localAfterClarification=1;
    else if(m.retries)c.localAfterRetry=1;
    else c.localFirstPass=1;
   }
  }
  c.initialLocal=+(m.initial?.decision==='local');c.initialFallback=+(m.initial?.decision==='fallback');c.initialClarify=+(m.initial?.decision==='clarify');
  if(m.initial)s.reasons[m.initial.reason||m.initial.decision]=1;if(m.intent)s.intents[m.intent]=1;
  for(const [name,p]of Object.entries(m.providers)){
   const all={messages:1,asr:p.asr.attempts,parse:p.parse.attempts,requests:p.asr.attempts+p.parse.attempts,ok:p.asr.ok+p.parse.ok,failed:p.asr.failed+p.parse.failed,pending:p.asr.pending+p.parse.pending};
   s.providers[name]=all;c.apiRequests+=all.requests;c.apiOK+=all.ok;c.apiFailed+=all.failed;c.apiPending+=all.pending;
   if(p.asr.attempts)c.asrMessages=1;if(p.parse.attempts)c.parseMessages=1;
  }return s;
 }
 class Store{
  constructor({storage,storageKey='kamkee.voice-statistics.v1',now=()=>new Date().toISOString(),limit=500,maxChars=600000}={}){
   try{this.storage=storage===undefined?g.localStorage:storage;}catch(error){this.storage=null;g.KamDebug?.error('statistics','storage.unavailable',error);}this.storageKey=storageKey;this.now=now;this.limit=limit;this.maxChars=Math.max(12000,Number(maxChars)||600000);this.listeners=new Set();this.storageAvailable=!!this.storage?.setItem;this.serial=0;
   this.data={version:1,startedAt:this.now(),archive:empty(),archiveDays:{},messages:[]};
   try{const saved=JSON.parse(this.storage?.getItem(storageKey)||'null');if(saved?.version===1){const validSummary=x=>x&&fields.every(k=>Number.isFinite(x.counts?.[k])||outcomeFields.includes(k)&&x.counts?.[k]===undefined)&&x.providers&&x.reasons&&x.intents;if(!Array.isArray(saved.messages)||!validSummary(saved.archive)||!saved.archiveDays||!Object.values(saved.archiveDays).every(validSummary)||!saved.messages.every(m=>typeof m.id==='string'&&Number.isFinite(Date.parse(m.at))&&m.providers&&Array.isArray(m.openCalls)&&['processing','resolved','clarification','failed','cancelled'].includes(m.status)&&Object.values(m.providers).every(p=>['asr','parse'].every(op=>p[op]&&['attempts','ok','failed','pending'].every(k=>Number.isFinite(p[op][k]))))))throw new Error('Invalid saved voice statistics');this.data=saved;}}catch(error){g.KamDebug?.error('statistics','load.failed',error);}
   let interrupted=0;
   for(const m of this.data.messages){if(m.status==='processing'||m.openCalls?.length){for(const call of m.openCalls||[]){const op=m.providers[call.provider]?.[call.operation];if(op){op.pending=Math.max(0,op.pending-1);op.failed++;}}m.openCalls=[];if(m.status!=='cancelled'){m.status='failed';m.error='interrupted';}m.updatedAt=this.now();interrupted++;}}
   if(interrupted){g.KamDebug?.log('statistics','interrupted',{messages:interrupted},'warn');this.save();}
  }
  find(id){return this.data.messages.find(m=>m.id===id);}
  subscribe(fn){this.listeners.add(fn);return()=>this.listeners.delete(fn);}
  save(){
   for(const message of this.data.messages)g.KamAudit?.record('voice',message.id,message);
   // Archive only settled messages; totals and daily/provider counts survive pruning.
   let serialized=JSON.stringify(this.data);
   while(this.data.messages.length>this.limit||serialized.length>this.maxChars){const index=this.data.messages.findIndex(m=>m.status!=='processing'&&!m.openCalls.length);if(index<0)break;const [m]=this.data.messages.splice(index,1),c=contribution(m),d=day(m.at);merge(this.data.archive,c);this.data.archiveDays[d]??=empty();merge(this.data.archiveDays[d],c);serialized=JSON.stringify(this.data);}
   try{if(!this.storage?.setItem)throw new Error('Storage unavailable');this.storage.setItem(this.storageKey,serialized);this.storageAvailable=true;}catch(error){if(this.storageAvailable)g.KamDebug?.error('statistics','save.failed',error);this.storageAvailable=false;}
   for(const fn of this.listeners){try{fn();}catch{}}
  }
  begin({id,source='microphone',cloudConfigured=false,deviceText=false,text='',context,alternatives=[],capture}={}){
   id=id||'voice-'+Date.now().toString(36)+'-'+(++this.serial);if(this.find(id))return id;
   const at=this.now();this.data.messages.push({id,at,updatedAt:at,source,cloudConfigured,deviceText,appVersion,text:this.transcript(text),context:this.snapshot(context),alternatives:this.alternatives(alternatives),capture:this.capture(capture),status:'processing',outcomeTracked:true,initial:deviceText?null:{decision:'noTranscript',reason:'noDeviceTranscript'},finalSource:null,intent:null,providers:{},openCalls:[],retries:0});
   this.save();g.KamDebug?.log('statistics','message.received',{voiceId:id,source,cloudConfigured,deviceText});return id;
  }
  transcript(text){return String(g.KamDebug?.sanitize(String(text??''))??text??'').slice(0,2000);}
  alternatives(values){return Array.isArray(values)?[...new Set(values.filter(v=>typeof v==='string').map(v=>this.transcript(v)))].slice(0,5):[];}
  capture(value){if(!value||typeof value!=='object')return null;return {origin:this.safe(value.origin||''),language:this.safe(value.language||''),requestedDeviceSpeech:!!value.deviceSpeech,didListen:!!value.didListen,...(value.sessionId?{sessionId:this.safe(value.sessionId),turn:Number.isInteger(value.turn)?value.turn:undefined,receivedAt:Number.isFinite(value.receivedAt)?value.receivedAt:undefined}:{})};}
  snapshot(state){
   if(!state||typeof state!=='object')return null;
   const K=g.Kam,cart=[],raw=Array.isArray(state.cart)?state.cart:[];
   for(const item of raw.slice(0,100)){
    try{const normalized=K.normalize(item),row={uid:this.safe(normalized.uid),id:normalized.id,qty:normalized.qty};
     for(const key of [...Object.keys(K.options),'note','drinkStatus','drinkPrompted'])if(Object.hasOwn(normalized,key))row[key]=typeof normalized[key]==='string'?this.safe(normalized[key]):normalized[key];
     row.extras=normalized.extras.slice();cart.push(row);
    }catch{}
   }
   const ids=new Set(cart.map(item=>item.uid));
   return {mode:state.mode==='takeaway'?'takeaway':'dinein',cart,
    portionOrder:K.normalizePortionOrder(cart,Array.isArray(state.portionOrder)?state.portionOrder.filter(id=>ids.has(id)):[]).slice(0,100),
    orderNotes:Array.isArray(state.orderNotes)?state.orderNotes.slice(0,12).map(value=>this.safe(value)):[],
    availability:Object.fromEntries(K.menu.filter(item=>state.availability?.[item.id]===false).map(item=>[item.id,false])),
    recommendationActive:!!state.recommendationActive,submittedOrderCount:Number.isInteger(state.submittedOrderCount)?state.submittedOrderCount:Array.isArray(state.orders)?state.orders.length:0,
    truncated:raw.length>100||raw.reduce((n,item)=>n+(Number(item.qty)||0),0)>100};
  }
  safe(text){return String(g.KamDebug?.sanitize(String(text))??text).slice(0,240);}
  local(id,result,{phase='device',text}={}){
   const m=this.find(id);if(!m)return;
   if(text)m.text=this.transcript(text);
   if(phase==='device'&&!m.initial)m.initial={decision:result.decision,reason:result.error?.code||result.decision};
   m.lastLocal={phase,decision:result.decision,reason:result.error?.code||null};m.updatedAt=this.now();this.save();
  }
  retry(id){const m=this.find(id);if(!m)return;m.retries++;m.status='processing';m.updatedAt=this.now();this.save();}
  apiStart(id,{provider,operation}){
   const m=this.find(id);if(!m||!['asr','parse'].includes(operation))return null;
   m.providers[provider]??={asr:{attempts:0,ok:0,failed:0,pending:0},parse:{attempts:0,ok:0,failed:0,pending:0}};
   const p=m.providers[provider][operation];p.attempts++;p.pending++;
   const requestId=id+'-request-'+Date.now().toString(36)+'-'+(++this.serial);m.openCalls.push({id:requestId,provider,operation});m.updatedAt=this.now();this.save();return requestId;
  }
  apiFinish(id,requestId,{ok,error}={}){
   const m=this.find(id),index=m?.openCalls.findIndex(c=>c.id===requestId);if(!m||index<0||index===undefined)return;
   const [call]=m.openCalls.splice(index,1),p=m.providers[call.provider][call.operation];p.pending=Math.max(0,p.pending-1);p[ok?'ok':'failed']++;if(error)m.lastAPIError=this.safe(error.code||error.message||String(error));m.updatedAt=this.now();this.save();
  }
  finish(id,{status='resolved',source='dictionary',intent,error,noteFallback=false,noteOnly=false,after}={}){const m=this.find(id);if(!m)return;m.status=status;
   if(status==='clarification')m.hadClarification=true;
   if(after)m.after=this.snapshot(after);
   m.noteFallback=noteFallback;m.noteOnly=noteOnly;m.finalSource=source;m.intent=intent||m.intent;m.error=error?this.safe(error.code||error):null;m.updatedAt=this.now();this.save();g.KamDebug?.log('statistics','message.finished',{voiceId:id,status,source,intent,error:m.error});}
  report(range='all'){
   const today=day(this.now()),cutoff=range==='today'?today:range==='7d'?day(new Date(new Date(this.now()).getTime()-6*86400000).toISOString()):null;
   const result=empty(),days={};
   if(!cutoff)merge(result,this.data.archive);
   for(const [d,s]of Object.entries(this.data.archiveDays)){if(cutoff&&d<cutoff)continue;days[d]=structuredClone(s);if(cutoff)merge(result,s);}
   for(const m of this.data.messages){const d=day(m.at);if(cutoff&&d<cutoff)continue;const s=contribution(m);merge(result,s);days[d]??=empty();merge(days[d],s);}
   result.days=days;result.startedAt=this.data.startedAt;result.storageAvailable=this.storageAvailable;result.historyLimit=this.limit;result.historyMaxChars=this.maxChars;result.messages=this.data.messages.filter(m=>!cutoff||day(m.at)>=cutoff).slice().reverse();
   const c=result.counts,pct=(n,d)=>d?Math.round(n/d*10000)/100:0;
   result.percentages={api:pct(c.apiMessages,c.received),local:pct(c.localResolved,c.received),parserAPI:pct(c.parseMessages,c.received),asrAPI:pct(c.asrMessages,c.received),eligibleAPI:pct(c.apiEligibleUsed,c.apiEligible),resolved:pct(c.resolved,c.received)};
   result.outcomePercentages={
    firstPass:pct(c.localFirstPass,c.outcomeMeasured),
    afterClarification:pct(c.localAfterClarification,c.outcomeMeasured),
    localCompleted:pct(c.localFirstPass+c.localAfterClarification+c.localAfterRetry,c.outcomeMeasured),
   };
   return result;
  }
  export(){
   const data=structuredClone(this.data);
   for(const m of data.messages){
    m.text=this.transcript(m.text);m.alternatives=this.alternatives(m.alternatives);
    if(m.context)m.context=this.snapshot(m.context);if(m.after)m.after=this.snapshot(m.after);if(m.capture)m.capture=this.capture({...m.capture,deviceSpeech:m.capture.requestedDeviceSpeech});
    for(const key of ['error','lastAPIError'])if(typeof m[key]==='string')m[key]=this.safe(m[key]);
   }
   const summary=this.report();summary.messages=data.messages.slice().reverse();
   return JSON.stringify({language:g.KamLocale?.id,appVersion,exportedAt:this.now(),contextDefinition:'New recordings include bounded draft context captured at microphone start, final transcript and up to five ASR alternatives. No audio or API credentials. Historical messages without context remain unknown. Missing device text is not a parser failure.',definition:'One received order recording or upload; retries are the same message. Mic tests, capture permission failures, text and manual changes excluded. App ASR and parser API calls count; device speech networking is unknown. Outcome rates use only messages tracked under the new definition and exclude unresolved and kitchen-note fallbacks from successful local completion.',summary,data},null,2);
  }
  reset(){this.data={version:1,startedAt:this.now(),archive:empty(),archiveDays:{},messages:[]};this.save();g.KamDebug?.log('statistics','reset');}
 }
 g.KamVoiceStatistics={Store,contribution};
})(globalThis);

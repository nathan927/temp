/* Transport/metadata binding does not select or rewrite an ordering grammar. */
(function(g){'use strict';const K=g.Kam,locale=g.KamLocale.id;Object.defineProperty(K,'languageId',{value:locale,writable:false,configurable:false});
const spec=K.spec;K.spec=(operation,payload)=>{const bound={...payload,language:locale,speechLanguage:g.KamLocale.locale},result=spec(operation,bound);
if(operation==='parse'&&result.body?.messages?.length){const message=result.body.messages.at(-1),context=JSON.parse(message.content);context.language=locale;context.speechLanguage=g.KamLocale.locale;message.content=JSON.stringify(context);}
if(operation==='asr'){if(payload.provider==='minimax'){result.headers={...result.headers,language:{tc:'yue',sc:'zh',en:'en'}[locale]};if(payload.apiProfile==='global')result.url='https://api.minimax.io/v1/speech_to_text';}else if(result.body)result.body.asr_options={language:{tc:'auto',sc:'zh',en:'en'}[locale]};}return result;};
})(globalThis);

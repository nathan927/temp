function providerProfilesHTML(){
 return `<label class="form-field">${t('mimoProfile')}<select id="mimo-profile"><option value="standard">${t('standardKey')}</option><option value="token-cn">Token Plan · ${t('chinaRegion')}</option><option value="token-sgp">Token Plan · ${t('singaporeRegion')}</option></select></label><label class="form-field">${t('minimaxRegion')}<select id="minimax-profile"><option value="cn">${t('chinaRegion')}</option><option value="global">${t('globalRegion')}</option></select></label><label class="form-field">${t('minimaxModel')}<select id="minimax-model"><option value="MiniMax-M2.7">MiniMax-M2.7</option><option value="MiniMax-M3.1-Flash">MiniMax-M3.1-Flash</option><option value="MiniMax-M2.5">MiniMax-M2.5</option></select></label><label class="form-field">${t('mimoModel')}<select id="mimo-model"><option value="mimo-v2.6-flash">mimo-v2.6-flash</option><option value="mimo-v2.6-pro">mimo-v2.6-pro</option></select></label><div class="settings-tools"><button class="secondary" data-action="api-probe">${t('apiProbe')}</button><button class="secondary" data-action="all-logs">${t('allLogs')}</button></div><p class="micro-hint">${t('apiProbeHint')}</p><p id="api-probe-result" role="status"></p><p id="audit-storage-status" role="status"></p>`;
}
function automaticPairs(){
 const rows=[],seen=new Set();
 for(const [location,pack]of [['local',evolution.data.active],['remote',evolution.data.remote]])for(const rule of pack.rules){
  const key=KamEvolution.key(rule);if(seen.has(key))continue;seen.add(key);
  rows.push({source:rule.phrase,target:rule.rewrite||KamEvolution.canonical(rule.program||{}).at(-1)||JSON.stringify(rule.program),guard:rule.guard,key,location,version:pack.version});
 }
 return rows;
}
function automaticPairRows(query=''){
 const rows=automaticPairs(),needle=KamEvolution.clean(query),matches=rows.map((row,index)=>({...row,index})).filter(row=>!needle||KamEvolution.clean(row.source+' '+row.target).includes(needle));
 return `<p>${t('automaticPairCount',{n:matches.length,total:rows.length})}</p>`+matches.slice(-100).reverse().map(row=>`<li><span><strong>${esc(row.source)}</strong> → ${esc(label(row.target))}<small>${t(row.guard?'automaticPairGuarded':'automaticPairReusable')} · ${esc(row.location)} · ${esc(row.version)}</small></span>${row.location==='local'?`<button class="text-button" data-auto-pair-remove="${row.index}">${t('remove')}</button>`:''}</li>`).join('');
}
function automaticPairPanel(){return `<h3>${t('automaticPairs')}</h3><p class="micro-hint">${t('automaticPairHint')}</p><label class="form-field">${t('search')}<input id="automatic-pair-search" type="search" autocomplete="off"></label><ul class="manual-pair-list" id="automatic-pair-list">${automaticPairRows()}</ul>`;}
function removeAutomaticPair(index){
 if(!settingsAccess)return;const row=automaticPairs()[index];if(!row||row.location!=='local')return;
 evolutionWrite(()=>evolution.change(data=>{
  const old=data.active;data.previous.push(old);data.previous=data.previous.slice(-12);
  data.active={...old,version:K.uid(),parent:old.version,at:new Date().toISOString(),origin:'manual-removal',rules:old.rules.filter(rule=>KamEvolution.key(rule)!==row.key)};
  data.blocked=[...new Set([...data.blocked,row.key])];KamEvolutionCycle.event(data,'pair.removed',{phrase:row.source,version:data.active.version});
 }));manualPairsPage();
}
async function exportAllLogs(){
 if(!settingsAccess)return;
 const history=await KamAudit.read(),voice=JSON.parse(voiceMetrics.export()),allVoice=new Map();
 for(const [key,value]of Object.entries(history.latest))if(key.startsWith('voice:'))allVoice.set(value.id,value);
 for(const message of voice.data.messages)allVoice.set(message.id,message);
 const messages=[...allVoice.values()].filter(message=>message.at>=voice.data.startedAt).sort((a,b)=>a.at.localeCompare(b.at));
 const retained=new Set(voice.data.messages.map(message=>message.id));
 const subtract=(target,part)=>{for(const [key,value]of Object.entries(part)){if(typeof value==='number'){if(typeof target[key]!=='number'||target[key]<value)throw new K.OrderError('auditReadFailed');target[key]-=value;}else if(value&&typeof value==='object'){target[key]??={};subtract(target[key],value);}}};
 for(const message of messages)if(!retained.has(message.id)){const part=KamVoiceStatistics.contribution(message),day=new Date(message.at).toLocaleDateString('en-CA',{timeZone:'Asia/Hong_Kong'});subtract(voice.data.archive,part);if(voice.data.archiveDays[day])subtract(voice.data.archiveDays[day],part);}
 voice.data.messages=messages;voice.summary.messages=messages.slice().reverse();
 const complete={...voice,language:KamLocale.id,schema:'smart-cafe-complete-logs-v1',audit:history,
  coverage:{...history.coverage,currentPeriodVoiceDetails:messages.length,currentPeriodVoiceCount:voice.summary.counts.received,legacyVoiceDetailsMissing:Math.max(0,voice.summary.counts.received-messages.length)},
  debug:JSON.parse(KamDebug.export()),evolution:KamAudit.sanitize(evolution.data),unlearned:JSON.parse(unlearned.export())};
 download(JSON.stringify(complete,null,2),'SmartCafe-All-Logs-'+KamLocale.id+'-'+new Date().toISOString().replace(/[:.]/g,'-')+'.json','application/json');
 KamAudit.append('export','complete',{events:history.events.length,voiceMessages:messages.length,coverage:complete.coverage});
}
let apiProbeBusy=false;
async function testAPIConnection(){
 if(!settingsAccess||apiProbeBusy)return;
 const configured=cloudProviders();if(!parseProviders().length)throw new K.OrderError('missingKey');
 apiProbeBusy=true;setBusy(true);const el=$('#api-probe-result'),id='api-probe-'+K.uid();
 if(el)el.textContent=t('apiProbeRunning');
 const state=KamEvolution.snapshot({cart:[],mode:'dinein',orderNotes:[]}),text={tc:'連線驗證：一份菠蘿油',sc:'连线验证：一份菠萝包夹黄油',en:'Connection check: one pineapple bun with butter'}[KamLocale.id];
 let data;const sandbox=new KamEvolutionCycle.Journal({read:()=>null,write:value=>{data=value;}}),actual=[evolution.data.active,evolution.data.remote];
 try{
  const local=K.analyzeLocal(text,[]);sandbox.sample(id,text,local,state,'device');
  const result=await K.fallbackFlow.resolve({text,cart:[],context:state,settings:S.settings,configured,
   parse:(provider,text,cart)=>ai('parse',{provider,text,cart,mode:'dinein',orderNotes:[]},id)});
  const expected=K.analyzeLocal('一份菠蘿油',[]).plan;
  if(result.source!=='model'||KamEvolution.effect(result.plan,state)!==KamEvolution.effect(expected,state))throw new K.OrderError('apiProbeUnexpected');
  sandbox.resolved(id,text,result.plan,state,'model');KamEvolution.install(data.active);
  const replay=K.analyzeLocal(text,[],state);if(!replay.learned)throw new K.OrderError('apiProbeLearningFailed');
  KamAudit.append('api-probe','passed',{id,provider:result.provider,localLearning:true,secondCallLocal:true,orderChanged:false});
  if(el)el.textContent=t('apiProbePassed',{provider:result.provider});
 }catch(error){KamAudit.append('api-probe','failed',{id,error});if(el)el.textContent=err(error);throw error;}
 finally{KamEvolution.install(...actual);evolutionWrite(()=>evolution.finish(id,{status:'probe',source:'api-connectivity-test'}));apiProbeBusy=false;setBusy(false);}
}
document.addEventListener('input',event=>{
 if(event.target.id==='automatic-pair-search'&&settingsAccess)$('#automatic-pair-list').innerHTML=automaticPairRows(event.target.value);
});
Object.assign(L.dict,{
 cloudRecordRetry:['用後備收音再講一次','Try again with cloud recording'],
 automaticFallback:['本機優先，失敗自動用已設定 API','Local first, then configured APIs'],
 automaticPairs:['API 自動學習配對','API-learned pairs'],
 automaticPairHint:['API 成功處理後，通過本機重播驗證嘅叫法會同步喺呢度同字典顯示。有背景限制嘅配對只喺相同餐單情境使用；唔會覆蓋你手工配對。','Validated API recoveries appear here and in the dictionary. Context-bound pairs apply only to matching drafts. Your manual pairs stay separate.'],
 automaticPairCount:['找到 {n} 組（共 {total} 組），最多顯示最近符合嘅 100 組。','{n} matches out of {total}; showing up to 100.'],
 automaticPairGuarded:['需相同餐單背景','Matching draft context required'],automaticPairReusable:['可重用叫法','Reusable phrase'],
 apiProbe:['實測 API 接手及本機重播','Test API recovery and local replay'],
 apiProbeHint:['先儲存金鑰及服務類型，再測一次真實 API 請求、驗證及第二次本機重播。測試用獨立草稿，唔會改你張單；會使用 API 用量。','Save the key and API profile first. This sends a real request and verifies learning in an isolated draft without changing your order; API usage applies.'],
 apiProbeRunning:['正喺度試 API 接手同學習，等一等吖～','Testing API recovery and learning…'],
 apiProbePassed:['{provider} 已實際回覆，方案驗證同第二次本機重播都成功；你張單冇改。','{provider} responded. Plan validation and the second local replay passed. Your order was kept.'],
 apiProbeUnexpected:['API 有回覆，但測試餐點唔一致，今次唔算通過。請匯出完整紀錄核對。','The API responded, but the test order differed. Export the complete logs to investigate.'],
 apiProbeLearningFailed:['API 已接到，但本機重播未通過，今次未算學識。紀錄已保存。','The API responded, but local replay failed. The diagnostic record is saved.'],
 debugClear:['清除畫面快取','Clear display cache'],statsResetTitle:['重設本期語音統計？','Reset the current voice statistics period?'],statsResetHint:['會開始新一期統計，完整歷史紀錄仍保留喺全量下載。','Starts a new statistics period. Complete historical logs remain available in the full download.'],
 allLogs:['下載全部執行紀錄','Download complete execution logs'],
 auditMemoryOnly:['完整紀錄暫時只保留喺今次開頁記憶體，關頁前請下載；瀏覽器未能寫入持久記錄。','Complete logs are in this page’s memory only. Download before closing; persistent storage is unavailable.'],
});

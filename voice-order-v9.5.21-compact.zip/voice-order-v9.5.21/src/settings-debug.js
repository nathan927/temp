// Settings access lasts only while its modal flow remains open.
let settingsAccess=false,settingsDestination='settings',debugRenderTimer;
const declinedUpgrades=new Set();
function settingsEntry(destination='settings'){
 stopAudio();settingsDestination=destination;
 KamDebug.log('settings','password.requested',{destination});
 modal(t('settings'),t('settingsGate'),`<form id="settings-auth-form" class="settings-auth-form"><label class="form-field">${t('settingsPassword')}<input id="settings-password" type="password" autocomplete="off" autocapitalize="none" spellcheck="false" required></label><div id="settings-auth-error" class="notice error-notice" role="alert" hidden></div><button class="primary full" type="submit">${t('settingsUnlock')}</button></form>`,'','settings-auth');
 $('#settings-password').focus();
}
function requireSettings(destination){if(settingsAccess)return true;settingsEntry(destination);return false;}
function unlockSettings(){
 const ok=$('#settings-password')?.value==='nathanyuen.org';
 KamDebug.log('settings',ok?'password.accepted':'password.rejected',{},ok?'info':'warn');
 if(!ok){const el=$('#settings-auth-error');el.textContent=t('settingsWrong');el.hidden=false;$('#settings-password').select();return;}
 $('#settings-password').value='';settingsAccess=true;
 const destination=settingsDestination;settingsDestination='settings';
 if(destination==='manual-pairs')manualPairsPage();else if(destination==='evolution')evolutionPage();else if(destination==='unlearned')unlearnedPage();else if(destination==='debug')debugLog();else if(destination==='glossary')glossary();else if(destination==='mic-help')microphoneHelp();else settings();
}
function upgradeBanner(){
 const candidates=K.upgradeCandidates(S.cart).filter(i=>!declinedUpgrades.has(i.uid));
 if(!candidates.length)return '';
 return `<section class="upgrade-followup" aria-label="${t('upgradeTitle')}"><strong>${t('upgradeTitle')}</strong><small>${t('upgradeHint')}</small>${candidates.map(i=>{const m=mBy(i.id),combo=mBy(m.upgradeTo);return `<div class="upgrade-row"><span>${name(m)} × ${i.qty}<small>${t('upgradePrice',{price:money(activePrices()[combo.id]??combo.price)})}</small></span><button class="primary" data-upgrade="${i.uid}">${t('upgradeButton')}</button><button class="text-button" data-keep-standalone="${i.uid}">${t('keepStandalone')}</button></div>`;}).join('')}</section>`;
}
function upgradeClarification(error,text,origin,voiceId,source){
 pending={upgradeText:text,origin,voiceId,source};
 modal(t('clarify'),t('requestUnchanged'),`<p class="micro-hint">${t('clarifyDesc')}</p><div class="clarify-options">${error.data.choices.map(c=>{const i=S.cart[c.index];return `<button data-upgrade="${i.uid}"><b>${c.index+1}. ${name(mBy(i.id))} × ${i.qty}</b><small>${esc(details(i))}</small></button>`;}).join('')}</div>`,'','upgrade-clarify');
}
function debugLog(){
 if(!requireSettings('debug'))return;
 stopAudio();
 modal(t('debugLog'),t('appVersion'),`<p class="micro-hint">${t('debugHint')}</p><button class="secondary" data-action="unlearned">${t('learningTitle')}</button> <button class="secondary" data-action="evolution">${t('evolutionTitle')}</button><div class="debug-toolbar"><input id="debug-filter" type="search" placeholder="${t('debugFilter')}" aria-label="${t('debugFilter')}"><select id="debug-level" aria-label="Log level"><option value="">All levels</option><option value="error">Error</option><option value="warn">Warning</option><option value="info">Info</option></select></div><div class="settings-tools"><button class="secondary" data-action="debug-refresh">${t('debugRefresh')}</button><button class="secondary" data-action="debug-copy">${t('debugCopy')}</button><button class="secondary" data-action="debug-export">${t('debugExport')}</button><button class="text-button" data-action="debug-clear">${t('debugClear')}</button></div><p id="debug-count" class="debug-summary" role="status"></p><div id="debug-entries"></div>`,`<button class="primary full" data-action="settings">${t('backSettings')}</button>`,'debug');
 renderDebug();KamDebug.inspect('debug.open');
}
function renderDebug(){
 if(modalType!=='debug'||!settingsAccess)return;
 const query=($('#debug-filter')?.value||'').toLowerCase(),level=$('#debug-level')?.value;
 const rows=KamDebug.entries().filter(r=>(!level||r.level===level)&&(!query||JSON.stringify(r).toLowerCase().includes(query))),shown=rows.slice(-100);
 const open=new Set([...document.querySelectorAll('.debug-entry[open]')].map(el=>el.dataset.seq));
 $('#debug-count').textContent=t('debugCount',{n:rows.length,shown:shown.length});
 $('#debug-entries').innerHTML=shown.length?shown.reverse().map(r=>`<details class="debug-entry" data-level="${esc(r.level)}" data-seq="${r.seq}" ${open.has(String(r.seq))?'open':''}><summary>#${r.seq} · ${esc(r.at)} · ${esc(r.level.toUpperCase())} · ${esc(r.scope)} / ${esc(r.event)}</summary><pre>${esc(JSON.stringify(r.data,null,2))}</pre></details>`).join(''):`<p>${t('debugEmpty')}</p>`;
}
KamDebug.subscribe(()=>{if(modalType==='debug'){clearTimeout(debugRenderTimer);debugRenderTimer=setTimeout(renderDebug,150);}});
document.addEventListener('submit',e=>{if(e.target.id==='settings-auth-form'){e.preventDefault();unlockSettings();}});

(()=>{'use strict';
const localStorage=KamLocale.storage;const K=Kam,L=I18n,$=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])),icon=kamIcon;
const initial={version:2,lang:KamLocale.id,cart:[],portionOrder:[],orderNotes:[],manualPairs:[],orders:[],settings:{parser:'auto',asr:'browser',voiceLang:'yue',apiBase:'',speakBack:false,continuous:false,handsFree:true,storeName:'智能茶餐廳'},availability:{},prices:{},mode:'dinein',table:12,adminHash:''};
let S;try{const s=JSON.parse(localStorage.getItem('kamkee.v2'));if(s&&s.lang!==KamLocale.id)throw Error('workspace-language-mismatch');S=s?.version===2?{...initial,...s,settings:{...initial.settings,...s.settings}}:structuredClone(initial);S.cart=S.cart.map(K.normalize);S.portionOrder=K.normalizePortionOrder(S.cart,S.portionOrder);S.orderNotes=K.normalizeOrderNotes(S.orderNotes||[]);S.manualPairs=K.manualPairs.normalize(S.manualPairs);}catch(error){KamDebug.error('storage','read.failed',error);S=structuredClone(initial);}
S.settings.voiceLang=S.lang==='en'?'en':S.lang==='sc'?'zh':'yue';
if(['金記茶餐廳','Kam Kee Café','智能茶餐厅'].includes(S.settings.storeName))S.settings.storeName='智能茶餐廳';
let voiceWork=0;let recoVisible=false,micStarting=false,voiceStatusKey='startMic',voiceActive=false;const sessionOrdersKey='kamkee.session-orders.v1',sessionOrderIds=loadSessionOrders();const voiceMetrics=new KamVoiceStatistics.Store();const unlearned=new KamUnlearned.Store();unlearned.migrateVoice(voiceMetrics.data.messages);let activeVoiceId=null;
const evolution=createEvolution();
let keys={minimax:'',mimo:'',store:''},category='全部',search='',modalType='',lastFocus=null,draft=null,editOrder=null,beforeEdit=null,undos=[],events=[],pending=null,recoFilter={},recoIndex=0,recoList=[],busy=false,recording=null,recognition=null,recordTimer,autoTimer,toastTimer,voiceValue='',unlocked=false,confirmToken='',lastClip=null,lastVoiceCorrection=null;
const nativePending=new Map(),t=(k,a)=>L.text(k,S.lang,a),label=s=>L.label(s,S.lang),name=m=>L.name(m,S.lang),money=n=>'$'+Number(n).toFixed(Number.isInteger(+n)?0:2),mBy=id=>K.menu.find(m=>m.id===id),activePrices=()=>editOrder?.prices||S.prices,sum=items=>K.total(items,activePrices()),details=i=>K.details(i).map(label).join(' · '),locale=()=>S.lang==='en'?'en-HK':S.lang==='sc'?'zh-CN':'zh-HK';
function loadSessionOrders(){
 try{
  const navigation=performance.getEntriesByType?.('navigation')?.[0]?.type;
  if(navigation==='reload'||!navigation&&performance.navigation?.type===1){
   KamLocale.sessionStorage?.removeItem(sessionOrdersKey);
   return new Set();
  }
  const ids=JSON.parse(KamLocale.sessionStorage?.getItem(sessionOrdersKey)||'[]');
  return new Set(Array.isArray(ids)?ids.filter(id=>typeof id==='string'):[]);
 }catch{return new Set();}
}
function rememberSessionOrder(id){
 sessionOrderIds.add(id);
 try{KamLocale.sessionStorage?.setItem(sessionOrdersKey,JSON.stringify([...sessionOrderIds]));}catch{}
}
function sessionOrders(){return S.orders.filter(order=>sessionOrderIds.has(order.id));}
function commit(next){if(next.lang!==KamLocale.id)throw new K.OrderError('localeMismatch');next={...next,settings:{...next.settings,voiceLang:next.lang==='en'?'en':next.lang==='sc'?'zh':'yue'}};KamDebug.log('storage','state.commit',{cart:next.cart.map(i=>({id:i.id,uid:i.uid,qty:i.qty})),orderCount:next.orders.length});try{localStorage.setItem('kamkee.v2',JSON.stringify(beforeEdit?{...next,...beforeEdit}:next));S=next;}catch(error){KamDebug.error('storage','write.failed',error);throw new K.OrderError('storage');}}
function update(p){
 if(p.cart&&!Object.hasOwn(p,'portionOrder')){
  p={...p,portionOrder:K.reconcilePortionOrder(S.cart,S.portionOrder,p.cart)};
 }
 commit({...S,...p});
}
function unheardClause(clause){return ['unrecognizedTokens','notUnderstood'].includes(clause.code);}
function err(e){
 const data=e?.data||{};
 if(e?.code==='partialUnresolved'&&data.unresolved?.some(clause=>!unheardClause(clause))){
  return [t('partialNeedsAttention',data),...data.unresolved.map(clause=>unheardClause(clause)?
   t('partialNeedsRepeat',clause):t('partialClauseReason',{text:clause.text,reason:err({code:clause.code,data:clause.data})}))].join('\n');
 }
 let reason;
 if(['notApplicable','orderNoteConflict'].includes(e?.code)){
  const item=K.menu.find(m=>m.name===data.name)||S.cart.length===1&&mBy(S.cart[0].id);
  const subject=item?name(item):t('thisItem');
  const option=data.option==='temperature'?'drinkTemperature':data.option;
  reason=t(e.code==='orderNoteConflict'?'orderNoteConflict':'cantCustomize',{name:subject,option:t(Object.hasOwn(L.dict,option)?option:'thisOption')});
 }else if(e?.code==='missingTarget'&&data.row){
  reason=t(data.mismatch?'rowMismatch':'missingRow',data);
 }else{
  const code=e?.code;
  const key=code&&(Object.hasOwn(L.dict,code)||Object.hasOwn(L.errors,code))?code:
   e?.name==='TimeoutError'?'timeout':e?.name==='AbortError'?'interrupted':
   e?.message==='Failed to fetch'?'network':'unexpectedFailure';
  const friendlyData={...data};if(S.lang==='en'&&typeof data.name==='string'){const item=K.menu.find(m=>m.name===data.name||m.en===data.name);if(item)friendlyData.name=name(item);}reason=t(key,friendlyData);
  if(/\{\w+\}/.test(reason))reason=t('unexpectedFailure');
 }
 return data.editClause?t('editClauseFailed',{clause:data.editClause,reason}):reason;
}
function toast(s){$('#toast').textContent=s;$('#toast').hidden=false;clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('#toast').hidden=true,4500);}
function photos(root=document){root.querySelectorAll('[data-photo]').forEach(el=>{if(el.querySelector('.photo-media'))return;const n=+el.dataset.photo,asset=n===202?'watercress':n>=200?'drink':n>=100?'food':n===16?'egg':'base',cols=asset==='drink'||asset==='food'?6:['egg','watercress'].includes(asset)?1:4,rows=asset==='drink'?4:cols,index=asset==='watercress'?0:n>=200?n-200:n>=100?n-100:n===16?0:n;const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.setAttribute('class','photo-media');svg.setAttribute('viewBox',`${(index%cols)/cols} ${Math.floor(index/cols)/rows} ${1/cols} ${1/rows}`);svg.setAttribute('preserveAspectRatio',n>=200?'xMidYMid meet':'xMidYMid slice');svg.setAttribute('aria-hidden','true');const use=document.createElementNS('http://www.w3.org/2000/svg','use');use.setAttribute('href','#photo-asset-'+asset);const defs=document.createElementNS('http://www.w3.org/2000/svg','defs'),clip=document.createElementNS('http://www.w3.org/2000/svg','clipPath'),rect=document.createElementNS('http://www.w3.org/2000/svg','rect'),clipId='tile-'+K.uid();clip.setAttribute('id',clipId);clip.setAttribute('clipPathUnits','userSpaceOnUse');for(const [key,value]of Object.entries({x:(index%cols)/cols,y:Math.floor(index/cols)/rows,width:1/cols,height:1/rows,fill:'#fff',stroke:'none'}))rect.setAttribute(key,String(value));clip.appendChild(rect);defs.appendChild(clip);use.setAttribute('clip-path','url(#'+clipId+')');svg.append(defs,use);el.classList.toggle('photo-drink',n>=200);el.prepend(svg);});}
function service(){return S.mode==='dinein'?t('dinein')+' · '+t('table',{n:S.table}):t('takeaway');}
function render(){document.documentElement.lang=S.lang==='tc'?'zh-HK':S.lang==='sc'?'zh-CN':'en';document.title=t('brand');if(S.cart.length&&!confirmToken)confirmToken=K.uid();$('#app').innerHTML=`<div class="simple-app"><header class="simple-header"><button class="simple-brand" data-action="home"><span class="brand-mark">智</span><strong>${t('brand')}</strong></button><div class="simple-header-actions"><select id="ui-language" class="language-select" aria-label="${t('language')}"><option value="tc">${t('languageTC')}</option><option value="sc">${t('languageSC')}</option><option value="en">${t('languageEN')}</option></select><button class="icon-button" data-action="settings" aria-label="${t('settings')}">${icon('settings')}</button></div></header><main class="simple-main"><div class="servicebar"><div class="segmented">${['dinein','takeaway'].map(a=>`<button class="${S.mode===a?'selected':''}" data-mode="${a}">${icon(a==='dinein'?'store':'bag')}${t(a)}</button>`).join('')}</div><button class="table-button" data-action="table">${S.mode==='dinein'?t('table',{n:S.table}):t('pickup')}${icon('chevron')}</button></div>${editOrder?`<div class="amend-banner">${t('amendNotice',{id:editOrder.id})}<button data-action="discard-amend">${t('cancel')}</button></div>`:''}<div class="home-order-grid"><section class="voice-home" aria-labelledby="voice-home-title"><span class="home-eyebrow">${t('homeVoiceEyebrow')}</span><h1 id="voice-home-title">${t('homeVoiceHeading')}</h1><div class="home-mic-wrap"><button id="home-mic" class="home-mic mic-button" data-action="record" aria-label="${t('startMic')}" aria-pressed="false">${icon('mic')}</button></div><div class="sr-only" data-voice-state role="status" aria-live="polite">${t(voiceStatusKey)}</div><p class="home-mic-hint">${t('homeMicHint')}</p><p id="hands-free-state" class="micro-hint" role="status" aria-live="polite"></p><button class="recommend-shortcut" data-action="recommend">${t('sampleRec')}</button><div id="voice-error" class="notice error-notice" role="alert" hidden></div></section><section class="current-order" id="cart-panel" aria-labelledby="current-order-title"><header class="current-order-header"><div><h2 id="current-order-title">${t('bag')}</h2><p data-cart-hint>${t('currentDraftHint')}</p></div><span class="draft-status" data-cart-status>${t('draftStatus')}</span></header><div class="cart-items" id="cart-items" aria-live="polite" aria-atomic="false"></div><div id="drink-followup-slot"></div><div id="order-context-slot"></div><div class="current-order-footer" ${!S.cart.length?'hidden':''}><div class="current-order-tools"><button class="secondary" data-action="record">${icon('mic')}${t('reviewVoice')}</button><button class="text-button" data-action="undo">${t('undo')}</button><button class="text-button" data-action="clear">${t('clear')}</button></div><div id="packaging-slot"></div><div class="current-order-total"><span>${t('total')} <small>${t('currency')}</small></span><strong>${money(currentBill().total)}</strong></div><p class="current-no-service">${t('serviceFee')} $0</p><label class="allergy-ack" ${!/敏感|過敏|allerg|花生|peanut/i.test(effectiveCart().map(i=>i.note).concat(S.orderNotes).join('；'))?'hidden':''}><input id="allergy-ack" type="checkbox">${t('allergyAck')}</label><button class="primary full home-confirm" data-action="confirm" ${!S.cart.length?'disabled':''}>${t(editOrder?'confirmEdit':'confirm')} · ${money(currentBill().total)}${icon('check')}</button><p class="current-confirm-hint">${t('beforeConfirm')}</p></div><div id="session-orders-slot"></div></section></div><section id="recommendation-slot" ${!recoVisible?'hidden':''}></section><section class="home-catalog" id="home-catalog"><div class="menu-heading"><div><span class="eyebrow">${t('menuEyebrow')}</span><h2>${t('menuTitle')}</h2></div></div><nav class="categories">${[['全部','all'],['早餐套餐','catBreakfast'],['包點多士','catBakery'],['單點小食','catSnack'],['飯麵主食','catMains'],['港式飲品','catDrinks']].map(([c,k])=>`<button data-cat="${c}" class="${(Array.isArray(category)?category:[category]).includes(c)?'active':''}">${t(k)}</button>`).join('')}</nav><div class="menu-note">${t('menuNote')}</div><p id="navigation-status" class="navigation-status" role="status" aria-live="polite" hidden></p><section class="menu-grid" id="menu-grid"></section></section><footer class="simple-footer"><span>${t('brand')}</span><div>${(S.orders.length||S.settings.apiBase)?`<button data-action="orders">${t('confirmedOrders')}</button>`:''}<button data-action="desk">${t('operations')}</button></div></footer></main></div>`;$('#ui-language').value=S.lang;renderMenu();renderCart();if(recoVisible)renderRecommend();photos();voiceState(voiceStatusKey,!!recording);}

function drinkTariff(m){const vals=K.optionValues(m,'drink',K.defaults(m));return `<div class="drink-tariff"><span>${t('standalone')} ${vals.map(v=>label(v)+' '+money(K.unit({...K.defaults(m),drink:v},S.prices))).join(' · ')}</span><b>${t('withSet')} ${vals.map(v=>label(v)+' +'+money(K.drinkSupplement(v))).join(' · ')}</b></div>`;}
function renderMenu(){const list=K.searchMenu(search).filter(m=>category==='全部'||(Array.isArray(category)?category:[category]).includes(m.cat));$('#menu-grid').innerHTML=list.length?list.map(m=>`<article class="food-card ${S.availability[m.id]===false?'is-soldout':''}"><button data-add="${m.id}" ${S.availability[m.id]===false?'disabled':''} aria-label="${t('choose',{name:name(m)})}"><div class="card-image food-photo" data-photo="${m.photo}">${S.availability[m.id]===false?`<span class="card-badge">${t('soldout')}</span>`:m.recommended?`<span class="card-badge">${t('recommended')}</span>`:''}</div><div class="card-body"><div class="card-kicker">${m.combo?t('breakfastSet',{code:L.setCode(m.id,S.lang)}):t('classics')}</div><h3>${m.combo?L.setCode(m.id,S.lang)+'. ':''}${name(m)}</h3><p class="card-desc">${L.description(m,S.lang)}</p>${m.drink?drinkTariff(m):''}<div class="card-bottom"><span class="card-price">${money(K.unit(K.defaults(m),S.prices))}<small>${m.combo?t('withDrink'):''}</small></span><span class="add-btn">+</span></div></div></button></article>`).join(''):`<p class="empty-search">${t('noResults')}</p>`;photos($('#menu-grid'));}
function line(i,n,mini=false){const m=mBy(i.id);return`<article class="${mini?'voice-line':'cart-item'}"><div class="cart-thumb food-photo" data-photo="${m.photo}"></div><div><button class="cart-edit" data-edit="${i.uid}">${t('edit')}</button><h3><span class="line-number">${n+1}</span> ${m.combo?'['+L.setCode(m.id,S.lang)+'] ':''}${name(m)}</h3><p>${esc(details(i))}</p><div class="cart-item-bottom"><b>${money(K.unit(i,activePrices())*i.qty)}</b><div class="stepper"><button data-qty="${i.uid}" data-delta="-1" aria-label="− ${name(m)}">−</button><span>${i.qty}</span><button data-qty="${i.uid}" data-delta="1" aria-label="+ ${name(m)}">+</button></div></div></div></article>`;}
function previewLine(i,n){const m=mBy(i.id),b=K.breakdown(i,activePrices());return`<article class="review-card current-preview-item"><div class="review-photo food-photo" data-photo="${m.photo}"></div><div class="review-main"><div class="review-top"><h3>${m.combo?`<span class="review-set">${t('breakfastSet',{code:L.setCode(m.id,S.lang)})}</span>`:m.upgradeTo?`<span class="review-set">${t('standalone')}</span>`:''}${name(m)}</h3><span class="review-qty">× ${i.qty}</span></div><p class="review-options">${esc(details(i))}</p><div class="review-pricing"><span>${t('basePrice')} ${money(b.base)}</span>${b.adjustments.map(a=>`<span>${esc(label(a.label))} ${a.amount>=0?'+':'−'}${money(Math.abs(a.amount))}</span>`).join('')}${i.qty>1?`<span>${t('unitPrice')} ${money(b.unitPrice)} × ${i.qty}</span>`:''}</div><div class="preview-controls"><button data-edit="${i.uid}">${t('edit')}</button><div class="stepper"><button data-qty="${i.uid}" data-delta="-1" aria-label="${t('reduceQty')}">−</button><span>${i.qty}</span><button data-qty="${i.uid}" data-delta="1" aria-label="${t('increaseQty')}">+</button></div><strong>${money(b.lineTotal)}</strong></div></div></article>`;}
function renderSessionOrders(orders=sessionOrders()){
 const slot=$('#session-orders-slot');if(!slot)return;
 const submittedOnly=!S.cart.length&&orders.length>0;
 $('[data-cart-hint]').textContent=t(submittedOnly?'sessionOnlyHint':'currentDraftHint');
 $('[data-cart-status]').textContent=t(submittedOnly?'sessionSent':'draftStatus');
 slot.innerHTML=orders.length?`<section class="submitted-orders" aria-labelledby="submitted-orders-title">
  <h3 id="submitted-orders-title">${t('sessionSent')}</h3>
  ${orders.map(o=>`<article class="history-card" data-submitted-order="${esc(o.id)}">
   <header><strong>${esc(o.id)}</strong><span class="status-badge">${t(o.status)}</span></header>
   <ul>${o.items.map(i=>`<li>${i.qty} × ${esc(name(mBy(i.id)))}<small>${esc(details(i))}</small></li>`).join('')}</ul>
   ${kitchenNotes(o.orderNotes||[])}
   <header><b>${money(o.total)}</b><button class="secondary" data-receipt="${esc(o.id)}">${t('receipt')}</button>
   ${o.status!=='cancelled'&&K.pendingDrinks(o.items).length?`<button class="primary" data-amend="${esc(o.id)}">${t('drinkFollowup')}</button>`:''}</header>
  </article>`).join('')}
 </section>`:'';
}
function renderCart(){
 const el=$('#cart-items');if(!el)return;
 const orders=sessionOrders();
 el.innerHTML=S.cart.length?effectiveCart().map(previewLine).join(''):orders.length?'':`<div class="current-empty"><span>${icon('bag')}</span><h3>${t('currentEmptyTitle')}</h3><p>${t('currentEmptyHint')}</p></div>`;
 const slot=$('#drink-followup-slot');if(slot)slot.innerHTML=upgradeBanner()+drinkBanner();
 refreshOrderContext();renderSessionOrders(orders);photos(el);
}


function modal(title,sub,body,footer='',type=''){KamDebug.log('ui','modal.open',{type});lastFocus=lastFocus||document.activeElement;modalType=type;$('#modal').className='modal '+(['voice','unlearned','evolution'].includes(type)?'modal-wide':type==='desk'?'modal-desk':'');$('#modal').innerHTML=`<header class="modal-top"><h2 id="modal-title">${title}<small>${sub}</small></h2><button class="icon-button" data-action="close" aria-label="${t('close')}">${icon('close')}</button></header><div class="modal-content">${body}</div>${footer?`<div class="modal-footer">${footer}</div>`:''}`;$('#modal-layer').hidden=false;photos($('#modal'));$('#modal').focus();}
/*v9-hands-free-ui*/
// Microphone UI integration. Menu parsing and price validation stay in Kam.
let micTestUrl='',micTestStarted=0;
const microphone=new KamMicrophone.Microphone({
 onState(state,s){
  micStarting=state==='starting';recording=state==='idle'?null:s;
  if(s.options.test){
   const el=$('#mic-test-status');if(el)el.textContent=t(state==='starting'?'startingMic':state==='listening'?'micTestListening':state==='stopping'?'micFinishing':'micTestReady');
   const stop=$('[data-action="finish-mic-test"]');if(stop)stop.disabled=state!=='listening';
   for(const start of document.querySelectorAll('[data-action="test-mic"]'))start.disabled=state!=='idle';
  }
  voiceState(state==='starting'?'startingMic':state==='listening'?'listening':state==='stopping'?'micFinishing':S.cart.length?'draftReady':'startMic',state==='listening');
  const mic=$('#home-mic');if(mic)mic.disabled=busy||state==='starting'||state==='stopping'||!!s.options.test&&state!=='idle';
  if(state==='listening'&&s.options.continuous)handsFree.ready();refreshHandsFreeUI();
 },
 onLevel(level,s){
  const meter=$('#mic-level');if(meter)meter.value=Math.min(1,level*8);
  const elapsed=$('#mic-test-elapsed');if(elapsed&&s.options.test)elapsed.textContent=Math.min(4,Math.floor((performance.now()-micTestStarted)/1000))+' / 4 '+t('micSeconds');
 },
 onActivity(s,kind){if(s.options.continuous)handsFree.activity(kind);},
 onUtterance(result,s){if(s.options.continuous)queueHandsFreeResult(result,s);},
 onResult(result,s){
  if(s.options.test){showMicTest(result);return;}
  if(s.options.continuous){queueHandsFreeResult(result,s);rearmHandsFree();return;}
  lastClip=null;lastVoiceCorrection=null;
  const voiceId=voiceMetrics.begin({id:s.id,cloudConfigured:!!(keys.minimax||keys.mimo||S.settings.apiBase),deviceText:!!result.text,text:result.text||'',context:s.options.draftContext||voiceContext(),alternatives:result.alternatives,capture:{...s.options,didListen:s.didListen}});activeVoiceId=voiceId;
  if(result.blob){
   if(result.peak<.0001&&!result.text){voiceMetrics.finish(voiceId,{status:'failed',error:'micSilent'});activeVoiceId=null;voiceError(new K.OrderError('micSilent'));return;}
   recoverClip(result.blob,result.text||'',s.options.origin,result.alternatives||[],voiceId).catch(voiceError);
  }else if(result.text){
   handleDeviceVoice(result,s.options.origin,voiceId).catch(voiceError);
  }else{voiceMetrics.finish(voiceId,{status:'failed',error:'micNoMatch'});activeVoiceId=null;voiceError(new K.OrderError('micNoMatch'));}
 },
 onError(error,s){
  if(s.options.continuous)stopHandsFree('capture-error');
  if(s.options.test){const el=$('#mic-test-status');if(el)el.textContent=err(error);}
  if(s.speechOnly&&s.didListen&&!['micSpeechDenied','micSpeechInterrupted','micSpeechUnavailable'].includes(error.code)){
   const id=voiceMetrics.begin({id:s.id,cloudConfigured:!!(keys.minimax||keys.mimo||S.settings.apiBase),context:s.options.draftContext||voiceContext(),capture:{...s.options,didListen:s.didListen}});
   voiceMetrics.finish(id,{status:'failed',error});
  }
  voiceError(error);
 },
 onCancel(s){if(s?.options.continuous)stopHandsFree('capture-cancelled');voiceState(S.cart.length?'draftReady':'startMic');}
});
globalThis.kamMicEvent=(id,type,data)=>microphone.nativeEvent(id,type,data);
function releaseMicrophone(){microphone.release();}
function stopAudio(discard=true){if(handsFree.processing)return null;if(handsFree.active)stopHandsFree('navigation');clearTimeout(autoTimer);if(discard){microphone.cancel();micStarting=false;recording=null;}else microphone.finish();return null;}
function finishRecording(){microphone.finish();}
async function record(keepReply=false,forceAudio=false){
 if(handsFree.active){stopHandsFree('tap');return;}
 if(busy||handsFree.processing||handsFree.pending||micStarting)return;
 if(microphone.active){microphone.finish();return;}
 if(modalType&&!['voice','review','recommend'].includes(modalType))return;
 lastClip=null;lastVoiceCorrection=null;
 globalThis.speechSynthesis?.cancel();
 const error=$('#voice-error');if(error&&!keepReply)error.hidden=true;
 if(S.settings.handsFree!==false){handsFreeStopReason='';if(handsFree.start({id:'hf-'+K.uid(),origin:modalType||'home',forceAudio})){await openHandsFreeCapture();}return;}
 await microphone.start({origin:modalType||'home',language:locale(),test:false,
  deviceSpeech:S.settings.asr==='browser'&&!forceAudio,draftContext:voiceMetrics.snapshot(voiceContext())});
}
function micTestPanel(){return`<div class="mic-test-panel"><p>${t('micTestHint')}</p><p id="mic-test-status" role="status" aria-live="polite">${t('micTestReady')}</p><meter id="mic-level" min="0" max="1" value="0" aria-label="${t('micLevel')}"></meter><span id="mic-test-elapsed"></span><div id="mic-test-playback"></div><div class="mic-test-actions"><button class="primary" data-action="test-mic">${t('micTestStart')}</button><button class="secondary" data-action="finish-mic-test" disabled>${t('stopMic')}</button></div><p class="micro-hint">${t('micTestPrivate')}</p></div>`;}
async function testMicrophone(){
 if(modalType!=='mic-public-help'&&!requireSettings('settings'))return;
 if(busy||microphone.active)return;
 if(!$('#mic-test-status'))modal(t('micTestTitle'),t('appVersion'),micTestPanel(),'','mic-test');
 const playback=$('#mic-test-playback');if(playback)playback.replaceChildren();
 if(micTestUrl){URL.revokeObjectURL(micTestUrl);micTestUrl='';}
 micTestStarted=performance.now();globalThis.speechSynthesis?.cancel();
 await microphone.start({test:true,language:locale(),origin:modalType});
}
function showMicTest(result){
 const status=$('#mic-test-status'),playback=$('#mic-test-playback');if(!status||!playback)return;
 status.textContent=t(result.peak<.0001?'micTestSilent':'micTestSuccess');
 if(!result.blob){status.textContent=t('micFailed');return;}
 micTestUrl=URL.createObjectURL(result.blob);const audio=document.createElement('audio');
 audio.controls=true;audio.src=micTestUrl;audio.setAttribute('aria-label',t('micPlayback'));playback.append(audio);
 const button=document.createElement('button');button.className='secondary';button.textContent=t('micPlayback');button.dataset.action='play-mic-test';playback.append(button);
 const stats=document.createElement('p');stats.className='micro-hint';stats.textContent=t('micTestStats',{seconds:(result.durationMs/1000).toFixed(1),level:(result.peak*100).toFixed(1)});playback.append(stats);
 audio.play().catch(()=>{});
}
function micErrorActions(element,error){
 const inTest=modalType==='settings'||modalType.startsWith('mic-');
 const actions=inTest?[['test-mic','micRetry']]:[['record','micRetry'],['voice-mic-help','micHelpTitle']];
 actions.push(['mic-report','micReportExport']);
 if(modalType!=='mic-public-help')actions.push(['debug','debugLog']);
 if(globalThis.KamNative?.openMicrophoneSettings&&['micDenied','micDeniedPermanent'].includes(error.code))actions.unshift(['mic-settings','micSettings']);
 const row=document.createElement('div');row.className='mic-test-actions';
 for(const [action,key]of actions){const b=document.createElement('button');b.dataset.action=action;b.className='secondary';b.textContent=t(key);row.append(b);}
 element.append(row);
}
function microphoneHelp(publicHelp=false){
 if(!publicHelp&&!requireSettings('mic-help'))return;
 modal(t('micHelpTitle'),t('appVersion'),`<div class="help-copy"><p>${t(microphone.native?'micHelpAndroid':'micHelpBrowser')}</p><p>${t('micHelpGlobal')}</p><p>${t('micHelpSpeech')}</p></div>${micTestPanel()}`,'<button class="secondary full" data-action="mic-report">'+t('micReportExport')+'</button>',publicHelp?'mic-public-help':'mic-help');
}

function close(){if(busy)return;KamDebug.log('ui','modal.close',{type:modalType});stopAudio();globalThis.speechSynthesis?.cancel();globalThis.KamNative?.cancelRecognition?.();$('#modal-layer').hidden=true;settingsAccess=false;modalType='';draft=null;pending=null;if(micTestUrl){URL.revokeObjectURL(micTestUrl);micTestUrl='';}if(lastFocus?.isConnected)lastFocus.focus();lastFocus=null;}
function replaceCart(items,metadata={}){
 const order=metadata.portionOrder??K.reconcilePortionOrder(S.cart,S.portionOrder,items);
 const grouped=editOrder?{cart:items,portionOrder:order}:K.groupDraft(items,order);
 saveDraft(grouped.cart,{...metadata,portionOrder:grouped.portionOrder});
}
function optionPrice(k,x){const i=draft.item,m=mBy(i.id);if(k==='drink'){if(m.combo)return K.drinkSupplement(x);if(m.drink&&m.temperatures?.length!==1)return (x.startsWith('凍')?3:0)-(m.drink.startsWith('凍')?3:0);}if(k==='noodle'&&x==='出前一丁'&&m.noodle!=='出前一丁')return 3;if(k==='portion'&&x==='加底'||k==='size'&&x==='大杯'||k==='milk'&&x==='轉燕麥奶')return 5;if(k==='milk'&&x==='轉鮮奶')return 3;return 0;}
function chips(k,vals,v){return`<div class="chips">${vals.map(x=>{const price=optionPrice(k,x);return`<button data-option="${k}" data-value="${x}" class="chip ${x===v?'selected':''}">${label(x)}${price||k==='drink'&&mBy(draft.item.id).combo?`<small> ${price<0?'−':'+'}${money(Math.abs(price))}</small>`:''}</button>`;}).join('')}</div>`;}
function openItem(id,uid=''){stopAudio();const i=S.cart.find(i=>i.uid===uid);const base=i?structuredClone(i):K.defaults(mBy(id)),effective=K.effectiveItems([base],S.orderNotes||[])[0];draft={item:structuredClone(effective),originalBase:base,originalEffective:effective,existing:!!i,back:modalType};drawItem();}
function drawItem(){const i=draft.item,m=mBy(i.id);modal(name(m),m.combo?t('breakfastSet',{code:L.setCode(m.id,S.lang)}):t('classics'),`<div class="modal-image food-photo" data-photo="${m.photo}"></div><p class="micro-hint">${L.description(m,S.lang)}</p>${S.orderNotes.length?`<div class="notice">${t('orderNotes')}: ${S.orderNotes.map(esc).join('；')}</div>`:''}${Object.keys(K.options).filter(k=>K.applicable(m,k,i)).map(k=>`<div class="option-group"><div class="option-label">${t(k)}</div>${chips(k,K.optionValues(m,k,i),i[k])}${k==='drink'&&m.combo?`<p class="micro-hint">${t('drinkPriceHint')}</p>`:''}</div>`).join('')}${K.allowedExtras(m,i).length?`<div class="option-group"><div class="option-label">${t('extras')}</div><div class="chips">${K.allowedExtras(m,i).map(x=>`<button class="chip ${(i.extras||[]).includes(x.id)?'selected':''}" data-extra="${x.id}">${S.lang==='en'?x.en:label(x.name)} <small>+${money(x.price)}</small></button>`).join('')}</div><p class="micro-hint">${t('extrasHint')}</p></div>`:''}<p class="micro-hint">${i.note?esc(label(i.note)):t('voiceCustomHint')}</p><div class="notice">${t('allergen',{items:m.allergens.map(label).join(', ')})}</div>${draft.existing?`<button class="delete-item" data-action="delete-item">${t('remove')}</button>`:''}`,`<div class="option-qty"><div class="stepper"><button data-draftqty="-1">−</button><span>${i.qty}</span><button data-draftqty="1">+</button></div></div><button class="primary" data-action="save-item">${t(draft.existing?'saveChanges':'add')} · ${money(K.unit(i,activePrices())*i.qty)}</button>`,'item');}
function saveItem(){draft.item.note=($('#item-note')?.value??draft.item.note);const base={...draft.item};for(const key of Object.keys(draft.originalEffective||{}))if(JSON.stringify(base[key])===JSON.stringify(draft.originalEffective[key]))base[key]=draft.originalBase[key];const i=K.normalize(base),back=draft.back;if(S.availability[i.id]===false)throw new K.OrderError('soldOut',{name:name(mBy(i.id))});if(!draft.existing&&mBy(i.id)?.combo&&i.drink==='待選飲品'){
 let p;try{p=K.pairMenuItem(i,S.cart);}catch(e){if(e.code==='ambiguousTarget'&&e.data?.plan){draft=null;pairClarification(e,'揀飲品配套餐','voice');return;}throw e;}
 replaceCart(K.applyPlan(S.cart,p,S.availability).items);
 }else replaceCart(draft.existing?S.cart.map(x=>x.uid===i.uid?i:x):[...S.cart,i]);draft=null;voiceModal();}
function drinkBanner(){const waiting=K.pendingDrinks(S.cart);if(!waiting.length)return '';const fresh=waiting.some(i=>!i.drinkPrompted);if(fresh)update({cart:S.cart.map(i=>waiting.some(w=>w.uid===i.uid)?{...i,drinkPrompted:true}:i)});return`<section class="drink-followup"><strong>${fresh?t('drinkQuestion'):t(waiting.some(i=>i.drinkStatus==='missing')?'drinkPending':'drinkDeferred')}</strong><p>${waiting.map(i=>`${t('breakfastSet',{code:L.setCode(i.id,S.lang)})} × ${i.qty}`).join(' · ')}</p><small>${t('drinkPriceHint')}</small><div><button class="secondary" data-action="defer-drink">${t('deferDrink')}</button><button class="primary" data-action="choose-drink">${t('chooseDrink')}</button></div></section>`;}
function deferDrinks(){
 const ops=K.pendingDrinks(S.cart).filter(i=>i.drinkStatus==='missing')
  .map(i=>({type:'update',target:{uid:i.uid},patch:{drinkStatus:'deferred',drinkPrompted:true}}));
 if(!ops.length)return;
 return processCommand(t('deferDrink'),{plan:{intent:'edit',ops},origin:modalType});
}
function voiceModal(){stopAudio();if(!$('#modal-layer').hidden)close();voiceState(S.cart.length?'draftReady':'startMic');}

function voiceError(e,{clarifying=false}={}){e=e||new K.OrderError('unexpectedFailure');if(clarifying)KamDebug.log('voice','clarification',{code:e.code,data:e.data,modal:modalType});else if(e.code==='partialUnresolved')KamDebug.log('voice','partial',{unresolved:e.data?.unresolved,count:e.data?.count});else KamDebug.error('voice','failed',e,{modal:modalType});
 const menuReply=['partialUnresolved','unavailable','soldOut','notApplicable','fixedSugar','unrecognizedTokens','notUnderstood','needChange','missingTarget','needClarification','conflictingOptions','invalidQty','ambiguousTarget','noUpgradeable','alreadyCombo','missingDrink','micNoMatch','deviceTranscriptMissing'].includes(e.code);
 voiceState('',false);
 const el=(!$('#modal-layer').hidden&&($('#mic-test-status')||$('#settings-error')))||$('#voice-error');
 if(el){
  el.classList.toggle('voice-counter-reply',el.id==='voice-error'||menuReply);
  el.dataset.reply=e.code==='partialUnresolved'?'partial':clarifying?'clarification':'error';
  el.setAttribute('role',menuReply||clarifying?'status':'alert');
  el.textContent='';
  const playful=['micNoMatch','micSilent','micRecognitionTimeout','deviceTranscriptMissing','recordShort','notUnderstood','unrecognizedTokens'].includes(e.code);
  const message=document.createElement('strong');
  message.textContent=L.exceptionLead(e.code,S.lang);
  el.append(message);
  const explanation=document.createElement('p');
  explanation.className='voice-help-detail';
  explanation.textContent=err(e);
  el.append(explanation);el.hidden=false;
  if(String(e.code||'').startsWith('mic'))micErrorActions(el,e);
  if(['micNoMatch','deviceTranscriptMissing','micRecognitionTimeout'].includes(e.code)&&cloudProviders().length){const retry=document.createElement('button');retry.className='secondary';retry.dataset.action='cloud-record';retry.textContent=t('cloudRecordRetry');el.append(retry);}
 if(lastVoiceCorrection){const b=document.createElement('button');b.dataset.action='correct-transcript';b.className='secondary';b.textContent=t('editTranscript');el.append(' ',b);}
 if(lastClip&&cloudProviders().length){const b=document.createElement('button');b.dataset.action='retry-clip';b.className='secondary';b.textContent=t('retryVoiceCloud');el.append(' ',b);}}
 else toast(err(e));
 return el;
}

function voiceState(k,on=false){on=on||handsFree.active;voiceStatusKey=k;voiceActive=on;for(const el of document.querySelectorAll('[data-voice-state]'))el.textContent=t(k);for(const b of document.querySelectorAll('.mic-button')){b.classList.toggle('recording',on);b.setAttribute('aria-pressed',String(on));b.setAttribute('aria-label',t(on?'stopMic':'startMic'));}for(const c of document.querySelectorAll('[data-action="confirm"]'))c.disabled=busy||on||micStarting||!!recording||!S.cart.length;$('#ui-language')?.toggleAttribute('disabled',busy||on||micStarting);const b=$('#home-mic');if(b)b.disabled=busy||micStarting;refreshHandsFreeUI();}

function setBusy(on){busy=on;$('#modal').classList.toggle('busy',on);$('.simple-app')?.classList.toggle('processing',on);for(const b of document.querySelectorAll('[data-action="confirm"]'))b.disabled=on||!S.cart.length;const mic=$('#home-mic');if(mic)mic.disabled=on||micStarting;refreshHandsFreeUI();}

function nativeFetch(spec){return new Promise((resolve,reject)=>{const id=K.uid();let target='unknown';try{const u=new URL(spec.url);target=u.origin+u.pathname;}catch{}KamDebug.log('android','network.request',{id,url:target});const timer=setTimeout(()=>{nativePending.delete(id);const error=new K.OrderError('timeout');KamDebug.error('android','network.timeout',error,{id});reject(error);},45000);nativePending.set(id,{resolve,reject,timer});try{KamNative.request(id,JSON.stringify(spec));}catch(error){clearTimeout(timer);nativePending.delete(id);KamDebug.error('android','network.request.failed',error,{id});reject(error);}});}
globalThis.kamNativeResponse=(id,status,text)=>{const p=nativePending.get(id);KamDebug.log('android','network.response',{id,status,accepted:!!p});if(!p)return;clearTimeout(p.timer);nativePending.delete(id);p.resolve({ok:status>=200&&status<300,status,text:async()=>text});};
async function ai(op,p,voiceId){
 KamDebug.log('provider','request',{operation:op,provider:p.provider,voiceId});
 const payload={...p,apiProfile:S.settings[p.provider+'Profile'],model:S.settings[p.provider+'Model'],...(op==='parse'?{mode:p.mode??S.mode,orderNotes:p.orderNotes??S.orderNotes}:{}),key:keys[p.provider],language:S.lang,speechLanguage:locale()};let send,endpoint,model;const proxy=S.settings.apiBase;
 if(proxy){endpoint=proxy+'/api/'+op;model='proxy-selected';send=()=>fetch(endpoint,{method:'POST',headers:{'Content-Type':'application/json','X-Store-Token':keys.store},body:JSON.stringify(payload),signal:AbortSignal.timeout(45000)});}
 else{
  const spec=K.spec(op,payload);endpoint=spec.url;model=spec.body?.model||spec.multipart?.model;
  if(globalThis.KamNative?.request)send=()=>nativeFetch(spec);
  else{let body;if(spec.multipart){body=new FormData();body.append('model',spec.multipart.model);body.append('response_format','json');body.append('file',new Blob([Uint8Array.from(atob(spec.multipart.audio),c=>c.charCodeAt(0))],{type:'audio/wav'}),'order.wav');}else body=JSON.stringify(spec.body);send=()=>fetch(spec.url,{method:'POST',headers:spec.headers,body,signal:AbortSignal.timeout(40000)});}
 }
 const requestId=voiceMetrics.apiStart(voiceId,{provider:p.provider,operation:op});
 const started=Date.now();
 evolutionWrite(()=>evolution.call(voiceId,requestId,{phase:'request',operation:op,provider:p.provider,endpoint,model,language:payload.language,...(op==='parse'?{text:p.text,state:KamEvolution.snapshot(payload)}:{audioBase64Length:p.audio?.length})}));
 KamAudit.append('api','request',{voiceId,requestId,operation:op,provider:p.provider,endpoint,model,...(op==='parse'?{text:p.text,state:KamEvolution.snapshot({...S,cart:p.cart}),body:proxy?{provider:p.provider,text:p.text,cart:p.cart}:K.spec(op,payload).body}:{audioBytes:p.audio?.length})});
 try{const r=await send(),raw=await r.text();let d;
  KamAudit.append('api','response',{voiceId,requestId,operation:op,provider:p.provider,status:r.status,durationMs:Date.now()-started,body:raw});
  evolutionWrite(()=>evolution.call(voiceId,requestId,{phase:'response',status:r.status,durationMs:Date.now()-started,response:KamEvolutionCycle.payload(raw,24000)}));
  if(!r.ok)throw K.fallbackFlow.failure(null,r.status);
  try{d=JSON.parse(raw);}catch(error){KamDebug.error('provider','invalidJSON',error,{operation:op,provider:p.provider,status:r.status});throw new K.OrderError('invalidJSON');}
  if(!r.ok){KamDebug.log('provider','response.rejected',{operation:op,provider:p.provider,status:r.status,error:d.error||d.message||d.code||d.base_resp},'error');throw K.fallbackFlow.failure(null,r.status);}
  if(d.status==='incomplete'||d.status==='failed'||d.choices?.some(c=>['length','content_filter'].includes(c.finish_reason)))throw new K.OrderError('apiIncomplete');
  const result=proxy?d:K.readAI(op,d);voiceMetrics.apiFinish(voiceId,requestId,{ok:true});evolutionWrite(()=>evolution.call(voiceId,requestId,{phase:'accepted',result}));return result;
 }catch(caught){const error=K.fallbackFlow.failure(caught);KamAudit.append('api','failed',{voiceId,requestId,provider:p.provider,operation:op,error});voiceMetrics.apiFinish(voiceId,requestId,{ok:false,error});evolutionWrite(()=>evolution.call(voiceId,requestId,{phase:'failed',error,durationMs:Date.now()-started}));throw error;}
}
async function storeAPI(path,method='GET',body){try{const request=async(p,m,b)=>{const r=await fetch(S.settings.apiBase+(p==='/store'?'/api/store':'/api/orders'+p),{method:m,headers:{'Content-Type':'application/json','X-Store-Token':keys.store,'X-Voice-Language':KamLocale.id},body:b?JSON.stringify({...b,language:KamLocale.id}):undefined,signal:AbortSignal.timeout(20000)});const d=await r.json();if(!r.ok)throw new K.OrderError(d.code||'network');if(d.language!==KamLocale.id||Array.isArray(d.orders)&&d.orders.some(o=>o.language!==KamLocale.id))throw new K.OrderError('serverLanguageIsolation');return d;};if(method!=='GET'){const config=await request('/store','GET');if(!(config.capabilities?.languageIsolation>=1))throw new K.OrderError('serverLanguageIsolation');}return await request(path,method,body);}catch(e){throw e.code?e:new K.OrderError('network');}}
function listenAgain(){refreshHandsFreeUI();}

const voiceContext=()=>({...S,recommendationActive:recoVisible});
const parseProviders=()=>K.fallbackFlow.providers(S.settings,cloudProviders());
const cloudProviders=()=>['minimax','mimo'].filter(p=>keys[p]||S.settings.apiBase);
const observeVoice=(voiceId,{provider,text,result})=>{
 const phase=provider==='device'?'device':'cloud-asr';
 voiceMetrics.local(voiceId,result,{phase,text});
 collectUnlearned(text,result,{voiceId,phase:provider==='device'?phase:phase+'-'+provider});
};
function transcriptClarification(text,candidates,origin,voiceId){
 voiceError(new K.OrderError('confirmTranscript'),{clarifying:true});
 stopAudio();lastVoiceCorrection=null;
 voiceMetrics.finish(voiceId,{status:'clarification',error:'confirmTranscript'});
 settleUnlearned(voiceId,{status:'clarification',error:'confirmTranscript'});
 pending={transcript:true,candidates,origin,voiceId,state:S};
 const buttons=candidates.map((value,index)=>`<button data-voice-candidate="${index}">${esc(value)}</button>`).join('');
 modal(t('confirmTranscript'),t('requestUnchanged'),`<div class="clarify-options">${buttons}</div><form id="voice-correction-form" class="form-field"><label for="voice-correction">${t('editTranscript')}</label><input id="voice-correction" maxlength="2000" value="${esc(text)}" required autocomplete="off"><button class="primary" type="submit">${t('saveChanges')}</button></form>`,`<button class="secondary full" data-action="record-again">${t('startMic')}</button>`,'voice-clarify');
}
async function handleDeviceVoice(result,origin,voiceId){
 const text=String(result.text||'').trim();
 let resolved;
 try{
  resolved=K.resolveDeviceVoice({localText:text,localAlternatives:result.alternatives,cart:S.cart,context:voiceContext(),observe:observation=>observeVoice(voiceId,observation)});
 }catch(error){
  return handleVoiceClarification(error,origin,voiceId);
 }
 return processCommand(resolved.text??text,{origin,voiceId,plan:resolved.plan,learned:resolved.learned,corrections:resolved.corrections,observed:true,primaryText:text});
}
function handleVoiceClarification(error,origin,voiceId){
 if(error.code==='confirmTranscript'){
  transcriptClarification(error.transcript,error.data.candidates,origin,voiceId);
  if(activeVoiceId===voiceId)activeVoiceId=null;
  return;
 }
 return processCommand(error.transcript,{origin,voiceId,localError:K.fallbackFlow.eligible({decision:'fallback',error})?undefined:error,observed:true});
}
function targetClarification(choices,text,origin,voiceId,source){
 voiceError(new K.OrderError('ambiguousTarget'),{clarifying:true});
 pending={targetChoices:choices,text,origin,voiceId,source,state:S};
 modal(t('clarify'),t('requestUnchanged'),`<p class="micro-hint">${esc(L.failureLead('ambiguousTarget',S.lang))} ${t('clarifyDesc')}</p><div class="clarify-options">${choices.map(c=>{
  const i=S.cart.find(row=>row.uid===c.uid);
  return `<button data-target="${i.uid}"><b>${c.index+1}. ${name(mBy(i.id))} × ${i.qty}</b><small>${esc(details(i))}</small></button>`;
 }).join('')}</div>`,'','clarify');
}
function correctVoiceTranscript(value){
 const x=pending;if(!x?.transcript||x.state!==S)return;
 const text=String(value||'').trim();if(!text)return;
 pending=null;lastClip=null;
 return processCommand(text,{origin:x.origin,voiceId:x.voiceId,localOnly:true});
}
function termClarification(error,text,origin=modalType,voiceId,source){voiceError(error,{clarifying:true});stopAudio();const data=error.data||{};pending={term:data,text,origin,voiceId,source};const reason=t(data.reason||'optionContext');modal(t('termTitle'),t('requestUnchanged'),`<div class="notice">${esc(t('termPrompt',{term:data.term,reason}))}</div><p class="micro-hint">${t('chooseDish')}</p><div class="clarify-options">${(data.ids||[]).map(id=>{const m=mBy(id);return `<button data-term-item="${id}"><b>${name(m)}</b><small>${L.description(m,S.lang)}</small></button>`;}).join('')}</div>`,`<button class="secondary full" data-action="home">${t('backEdit')}</button>`,'term-clarify');}
function pairClarification(error,text,origin,voiceId,source){
 voiceError(error,{clarifying:true});
 const data=error.data;pending={p:data.plan,text,origin,voiceId,source};
 modal(t('clarify'),t('requestUnchanged'),`<p class="micro-hint">${t('pairChoicePrompt')}</p><div class="clarify-options">${data.choices.map(c=>{const i=S.cart[c.index];return `<button data-pair-drink="${i.uid}"><b>${c.index+1}. ${name(mBy(i.id))} × ${i.qty}</b><small>${esc(details(i))}</small></button>`;}).join('')}</div>`,'','pair-clarify');
}
function prepareDrinkFollowup(id,plan,text){
 const order=S.orders.find(o=>o.id===id);
 if(!order||order.status==='cancelled')throw new K.OrderError('orderLocked');
 const updated=K.followupPlan(plan,text,(order.baseItems||order.items).map(K.normalize));
 amend(id);
 return updated;
}
function attachExistingDrink(text,opts){if(editOrder||S.cart.length||K.extraDrink.test(text))return false;const plan=opts.plan||K.analyzeLocal(text,[],{...S,recommendationActive:recoVisible}).plan;if(!plan||plan.intent!=='add'||!plan.ops?.length||!plan.ops.every(o=>mBy(o.item?.id)?.drink))return false;const candidates=S.orders.filter(o=>sessionOrderIds.has(o.id)&&o.status!=='cancelled'&&K.pendingDrinks(o.items).length);if(!candidates.length)return false;if(candidates.length===1){opts.plan=prepareDrinkFollowup(candidates[0].id,plan,text);return false;}pending={drinkText:text,drinkPlan:plan,voiceId:opts.voiceId,source:opts.source};modal(t('continueDrinkOrder'),t('whichDrinkOrder'),`<div class="clarify-options">${candidates.map(o=>`<button data-followup-order="${o.id}"><b>${esc(o.id)} · ${o.mode==='dinein'?t('table',{n:o.table}):t('takeaway')}</b><small>${time(o.at)} · ${K.pendingDrinks(o.items).map(i=>t('breakfastSet',{code:i.id})+' × '+i.qty).join(' · ')}</small></button>`).join('')}</div>`,'','drink-order');return true;}
async function processCommand(value,opts={}){
 lastVoiceCorrection=null;
 const {voiceId}=opts,work=voiceId?++voiceWork:null,origin=opts.origin||modalType,text=String(value??'').trim(),inputId=voiceId||opts.inputId||K.uid();let finalSource=opts.source||'dictionary';
 KamDebug.log('order','command.received',{text,origin,voiceId});voiceValue=text;
 if(!text){voiceMetrics.finish(voiceId,{status:'failed',error:'emptyInput'});if(activeVoiceId===voiceId)activeVoiceId=null;voiceError(new K.OrderError('emptyInput'));return;}
 try{
  if(text&&attachExistingDrink(text,opts)){settleUnlearned(inputId,{status:'clarification',source:finalSource});voiceMetrics.finish(voiceId,{status:'clarification',source:finalSource});if(activeVoiceId===voiceId)activeVoiceId=null;return;}
  stopAudio();setBusy(true);voiceState('processing');
  let local=opts.localError?{decision:'clarify',error:opts.localError}:opts.plan?{decision:'provided',plan:opts.plan,corrections:opts.corrections}:K.analyzeLocal(text,S.cart,voiceContext());
  if(!opts.plan&&!opts.observed){voiceMetrics.local(voiceId,local,{text});collectUnlearned(text,local,{voiceId,inputId,phase:voiceId?'device':'text'});}
  if(local.learned||opts.learned)KamDebug.log('evolution','rule.used',{voiceId,text,...(local.learned||opts.learned)});
  KamDebug.log('parser','decision',{voiceId,decision:local.decision,normalized:local.normalized,plan:local.plan,error:local.error,elapsedMs:local.elapsedMs});let plan;
  if(local.plan?.partialUnresolved?.length&&!opts.localOnly&&parseProviders().length)local={...local,decision:'fallback'};
  if(local.decision==='local'||local.decision==='provided'){
   plan=local.plan;if(local.corrections?.length)for(const c of local.corrections)events.push({text:c.from,result:t('heardAs',c)});
  }else if(local.decision==='clarify'&&!(K.fallbackFlow.eligible(local)&&!opts.localOnly&&parseProviders().length)){
   setBusy(false);voiceMetrics.finish(voiceId,{status:'clarification',source:finalSource,error:local.error});settleUnlearned(inputId,{status:'clarification',source:finalSource,error:local.error});
   if(local.error.code==='ambiguousTerm'){termClarification(local.error,text,origin,voiceId,finalSource);return;}
   if(local.error.code==='ambiguousTarget'&&local.error.data?.upgrade){upgradeClarification(local.error,text,origin,voiceId,finalSource);return;}
   if(local.error.code==='ambiguousTarget'&&local.error.data?.plan){pairClarification(local.error,text,origin,voiceId,finalSource);return;}
   if(local.error.code==='ambiguousTarget'&&local.error.data?.choices?.every(c=>c.plan)){
    targetClarification(local.error.data.choices,text,origin,voiceId,finalSource);return;
   }
   if(voiceId)lastVoiceCorrection={text,origin,voiceId,state:S};
   voiceError(local.error);return;
  }else{
   if(opts.localOnly)throw local.error;
   const stateToken=S;
   const resolved=await K.fallbackFlow.resolve({text,cart:S.cart,context:voiceContext(),settings:S.settings,configured:cloudProviders(),
    parse:(provider,text,cart)=>ai('parse',{provider,text,cart},voiceId||inputId),current:()=>stateToken===S&&(!voiceId||work===voiceWork),
    observe:detail=>KamAudit.append('routing',detail.phase,{voiceId,text,...detail})});
   plan=resolved.plan;finalSource=resolved.source;
  }
  if(voiceId&&work!==voiceWork)return;
  const state=KamEvolution.snapshot(S);
  setBusy(false);const outcome=await actPlan(plan,text,origin,{voiceId,source:finalSource});
  if(outcome?.status!=='clarification'&&(!opts.primaryText||opts.primaryText===text||opts.cloudTranscript))evolutionWrite(()=>evolution.resolved(voiceId||inputId,text,plan,state,finalSource));
  const status=outcome?.status||'resolved',noteFallback=status==='resolved'&&!!plan.orderNotesAdd?.some(n=>!K.orderNoteInfo(n).known);
  const noteOnly=noteFallback&&!plan.ops?.length&&!plan.mode&&!plan.orderNotesClear&&!plan.orderNotesRemove?.length&&plan.orderNotesAdd.every(n=>!K.orderNoteInfo(n).known);
  voiceMetrics.finish(voiceId,{status,source:finalSource,intent:plan.intent,noteFallback,noteOnly,after:voiceContext()});
  settleUnlearned(inputId,{status,source:finalSource,noteOnly});
 }catch(error){if(voiceId&&work!==voiceWork)return;setBusy(false);voiceMetrics.finish(voiceId,{status:'failed',source:finalSource,error});settleUnlearned(inputId,{status:'failed',source:finalSource,error});if(voiceId)lastVoiceCorrection={text,origin,voiceId,state:S};voiceError(error);}
 finally{if(activeVoiceId===voiceId&&work===voiceWork)activeVoiceId=null;}
}

function appendCounterLines(box,lines){
 if(!box||!lines.length)return;
 if(lines.length===1){
  const detail=document.createElement('p');
  detail.className='voice-help-detail';detail.textContent=lines[0];box.append(detail);return;
 }
 const list=document.createElement('ul');
 list.className='counter-receipt-lines';
 for(const line of lines){
  const item=document.createElement('li');
  item.textContent=line;list.append(item);
 }
 box.append(list);
}
function showCounterReceipt(reply,text,again=true){
 voiceState('',false);
 const box=$('#voice-error'),opening=KamCounterReply.next(reply.kind,S.lang);
 if(box){
  box.classList.add('voice-counter-reply');box.dataset.reply='success';box.setAttribute('role','status');
  const heading=document.createElement('strong');
  heading.textContent=opening;box.replaceChildren(heading);appendCounterLines(box,reply.lines);
  box.hidden=false;
 }
 const result=[opening,...reply.lines].join(' ');
 events.push({text,result});
 if(S.settings.speakBack&&!handsFree.active&&globalThis.speechSynthesis)speak(result,again);
 else if(again)listenAgain();
}
function showPartialOrder(plan,reply){
 const unresolved=plan.partialUnresolved;
 const tokens=unresolved.map(clause=>clause.text).join('、');
 const count=plan.ops.filter(op=>op.type==='add').reduce((n,op)=>n+op.item.qty,0);
 const error=new K.OrderError('partialUnresolved',{n:count,count,tokens,unresolved});
 events.push({text:tokens,result:[err(error),...reply.lines].join(' ')});
 appendCounterLines(voiceError(error),reply.lines);
 return {status:'clarification'};
}
function restoredDraftLines(previous){
 const old=new Map(previous.cart.map(item=>[item.uid,item]));
 const restored=new Map(S.cart.map(item=>[item.uid,item]));
 const changes=S.cart.map(item=>old.has(item.uid)?
  {type:'update',before:old.get(item.uid),after:item}:{type:'add',after:item});
 for(const item of previous.cart)if(!restored.has(item.uid))changes.push({type:'remove',before:item});
 const reply=KamCounterReply.describe(changes,previous.orderNotes,S.orderNotes,S.lang);
 if(previous.mode!==S.mode)reply.lines.push(t('counterService',{name:service()}));
 return [t('counterUndo',{n:S.cart.reduce((n,item)=>n+item.qty,0)}),...reply.lines];
}

async function actPlan(p,text,origin=modalType,context={}){
 KamDebug.log('order','plan.apply',{text,plan:p,voiceId:context.voiceId});
 if(p.intent==='navigate'){
  navigateMenu(p);
  const categories=p.categories.map(id=>t(K.navigationCategories.find(c=>c.id===id).label)).join('、');
  showCounterReceipt({kind:'info',lines:[t('browseCategory',{name:categories})]},text,false);return;
 }
 if(p.preserveDraft||p.declineUpgrade){
  if(p.declineUpgrade){K.upgradeCandidates(S.cart).forEach(i=>declinedUpgrades.add(i.uid));renderCart();}
  voiceModal();
  showCounterReceipt({kind:'kept',lines:p.declineUpgrade?[t('keepStandalone')]:[]},text);return;
 }
 if(p.intent==='recommend'){
  recoFilter={...recoFilter,...p.filter};recoIndex=p.next?recoIndex+1:0;recommend();
  showCounterReceipt({kind:'info',lines:[t(recoList.length?'counterRecommended':recoFilter.vegetarian||recoFilter.noPeanut?'recommendAllergy':'recommendNone')]},text,false);return;
 }
 if(p.intent==='undo'){
  const previous=S;undo(true);voiceModal();
  showCounterReceipt({kind:'undo',lines:restoredDraftLines(previous)},text);return;
 }
 if(p.intent==='preview'){
  review();showCounterReceipt({kind:'info',lines:[t('counterPreview',{n:S.cart.reduce((n,item)=>n+item.qty,0)})]},text,false);return;
 }
 if(p.intent==='service'){
  changeService(p.mode,true);voiceValue='';voiceModal();
  showCounterReceipt({kind:'info',lines:[t('counterService',{name:service()})]},text);return;
 }
 try{
  const result=K.transitionDraft(S,p,S.availability);
  const reply=KamCounterReply.describe(result.changes,S.orderNotes,result.orderNotes,S.lang);
  if(p.intent==='clear'){
   recoVisible=false;
   if(!reply.lines.length)reply.lines.push(t('counterCleared'));
  }
  if(result.mode!==S.mode){
   reply.lines.push(t('counterService',{name:t(result.mode)}));
   reply.kind=reply.kind==='kept'?'info':'mixed';
  }
  replaceCart(result.cart,{mode:result.mode,orderNotes:result.orderNotes,portionOrder:result.portionOrder});
  voiceValue='';
  const preview=(origin==='review'||p.previewAfter)&&S.cart.length;
  voiceModal();
  if(preview)$('#cart-panel')?.scrollIntoView?.({behavior:'smooth',block:'nearest'});
  if(p.partialUnresolved?.length)return showPartialOrder(p,reply);
  showCounterReceipt(reply,text,!preview);
 }catch(e){
  if(e.code!=='ambiguousTarget')throw e;
  if(p.ops?.length!==1)throw new K.OrderError('needClarification');
  const op=p.ops[0],choices=e.data.choices.map(c=>({...c,plan:{...p,ops:[{...op,target:{...op.target,uid:c.uid,all:false}}]}}));
  targetClarification(choices,text,origin,context.voiceId,context.source);
  return {status:'clarification'};
 }
}
function undo(quiet=false){
 if(!undos.length)throw new K.OrderError('noUndo');
 const snapshot=undos.pop();
 saveDraft(Array.isArray(snapshot)?snapshot:snapshot.cart,Array.isArray(snapshot)?{}:snapshot,false);
 if(!quiet)toast(t('undone'));
}
function recommend(){stopAudio();if(!$('#modal-layer').hidden)close();recoList=K.recommendations(S.orders,S.availability,recoFilter,S.prices);recoVisible=true;renderRecommend();$('#recommendation-slot')?.scrollIntoView?.({behavior:'smooth',block:'nearest'});}
function renderRecommend(){const slot=$('#recommendation-slot');if(!slot)return;slot.hidden=!recoVisible;if(!recoVisible)return;if(!recoList.length){slot.innerHTML=`<div class="notice">${t(recoFilter.vegetarian||recoFilter.noPeanut?'recommendAllergy':'recommendNone')}</div><button class="secondary" data-action="next-recommend">${t('recommendOther')}</button><button class="text-button" data-action="reset-recommend">${t('recommendReset')}</button>`;return;}const r=recoList[recoIndex%recoList.length],reason=r.reason==='bestseller'?'bestseller':'reason'+r.reason[0].toUpperCase()+r.reason.slice(1);slot.innerHTML=`<header class="inline-recommend-header"><h2>${t('recommendTitle')}</h2><button class="icon-button" data-action="hide-recommend" aria-label="${t('close')}">${icon('close')}</button></header><div class="recommend-grid">${r.items.map(i=>{const m=mBy(i.id);return`<article><div class="recommend-photo food-photo" data-photo="${m.photo}"></div><h3>${name(m)}</h3><p>${esc(details(i))}</p><strong>${money(K.unit(i,activePrices()))}</strong></article>`;}).join('')}</div><div class="recommend-description"><strong>${t(reason)}</strong><p>${r.sales?t('salesBasis',{n:r.sales}):t('curatedBasis')}</p></div><div class="inline-recommend-actions"><span>${t('total')} ${money(sum(r.items))}</span><button class="secondary" data-action="next-recommend">${t('recommendOther')}</button><button class="primary" data-action="use-recommend">${t('recommendUse')}</button></div>`;photos(slot);}

function speak(text,again=false){if(!globalThis.speechSynthesis){toast(t('noSpeech'));return;}stopAudio();speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(text);u.lang=locale();u.rate=.95;u.onend=()=>{if(again)listenAgain();};speechSynthesis.speak(u);}
function readback(){speak(effectiveCart().map((i,n)=>`${n+1}. ${i.qty} ${name(mBy(i.id))}, ${details(i)}`).join('. ')+'. '+(S.orderNotes.length?t('orderNotes')+S.orderNotes.join('；')+'. ':'')+t('total')+' '+t('currency')+' '+currentBill().total);}
async function audioBase64(blob){if(blob.size>4000000)throw new K.OrderError('invalidAudio');return new Promise((res,rej)=>{const r=new FileReader();r.onload=()=>res(r.result.split(',')[1]);r.onerror=rej;r.readAsDataURL(blob);});}
async function recoverClip(blob,localText='',origin=modalType,alternatives=[],voiceId,retry=false){
 voiceId=voiceId||voiceMetrics.begin({source:'upload',cloudConfigured:!!(keys.minimax||keys.mimo||S.settings.apiBase),deviceText:!!localText,text:localText,context:voiceContext(),alternatives});
 if(retry){if(!voiceMetrics.find(voiceId))voiceMetrics.begin({id:voiceId,source:'upload',cloudConfigured:!!(keys.minimax||keys.mimo||S.settings.apiBase),deviceText:!!localText,text:localText,context:voiceContext(),alternatives});else voiceMetrics.retry(voiceId);}
 if(!blob||blob.size>4000000){voiceMetrics.finish(voiceId,{status:'failed',error:'invalidAudio'});throw new K.OrderError('invalidAudio');}
 lastClip={blob,localText,origin,alternatives,voiceId};activeVoiceId=voiceId;const work=++voiceWork;setBusy(true);voiceState('recognizing');
 try{
  let encoded;
  const continuousTurn=handsFreeTurn;
  const result=await K.resolveVoice({audio:blob,localText,localAlternatives:alternatives,cart:S.cart,context:voiceContext(),
   transformASR:continuousTurn?(text)=>{const parsed=KamHandsFree.split(text);if(parsed.closing&&continuousTurn.sessionId===handsFree.id)handsFree.stop('closing',parsed.phrase,{discardAfter:continuousTurn.sequence});if(parsed.clarify)throw new K.OrderError('voiceClosingAmbiguous');if(parsed.closing&&!parsed.text||parsed.keepListening)return {control:'voice-stop'};return {text:parsed.text};}:undefined,
   available:p=>work===voiceWork&&(retry||['browser','auto'].includes(S.settings.asr)||S.settings.asr===p)&&cloudProviders().includes(p),
   canParse:()=>work===voiceWork&&parseProviders().length>0,
   asr:async(provider,sameAudio)=>{
    const audio=await (encoded??=audioBase64(sameAudio));
    if(work!==voiceWork)throw new K.OrderError('interrupted');
    return ai('asr',{provider,audio},voiceId);
   },parse:(_provider,text,cart)=>ai('parse',{provider:parseProviders()[0],text,cart},voiceId),
   observe:observation=>{if(work===voiceWork)observeVoice(voiceId,observation);},
   progress:(provider,stage)=>{if(work===voiceWork)voiceState(provider==='minimax'?'retryMinimax':'retryMimo');}});
  if(work!==voiceWork)return;if(result.control){lastClip=null;setBusy(false);voiceMetrics.finish(voiceId,{status:'resolved',source:'control',intent:'voice-stop'});settleUnlearned(voiceId,{status:'resolved',source:'control'});return;}voiceValue=result.text;lastClip=null;setBusy(false);
  await processCommand(result.text,{origin,plan:result.plan,voiceId,source:result.source,learned:result.learned,corrections:result.corrections,primaryText:localText,cloudTranscript:result.provider!=='device'});
 }catch(error){if(work!==voiceWork)return;setBusy(false);
  if(error.voiceClarification){await handleVoiceClarification(error,origin,voiceId);return;}
  if(localText&&!retry&&S.settings.asr==='browser'){
   await processCommand(localText,{origin,voiceId,observed:true});return;
  }
  if(error.code==='missingKey'&&!localText&&!retry&&S.settings.asr==='browser')error=new K.OrderError('deviceTranscriptMissing');
  voiceMetrics.finish(voiceId,{status:'failed',error});settleUnlearned(voiceId,{status:'failed',error});voiceError(error);
 }finally{if(activeVoiceId===voiceId&&work===voiceWork)activeVoiceId=null;}
}
async function transcribe(blob){return recoverClip(blob,'',modalType);}

function review(){stopAudio();if(!S.cart.length)throw new K.OrderError('emptyCart');for(const i of S.cart)K.ensureAvailable(i,S.availability,!!editOrder&&['ready','completed'].includes(editOrder.status));if(!$('#modal-layer').hidden)close();voiceStatusKey='draftReady';render();$('#cart-panel')?.scrollIntoView?.({behavior:'smooth',block:'nearest'});}


async function confirm(){
 KamDebug.log('order','confirm.requested',{cart:S.cart.map(i=>({id:i.id,qty:i.qty})),mode:S.mode,orderNotes:S.orderNotes,charges:currentBill().charges,amending:!!editOrder});
 if(busy||handsFree.active||handsFree.processing||handsFree.pending||recording||micStarting||!S.cart.length)return;
 const fields=pricedOrderFields();K.verifyCheckout(fields,S.availability,!!editOrder&&['ready','completed'].includes(editOrder.status));
 confirmToken=confirmToken||K.uid();
 if($('#allergy-ack')&&!$('#allergy-ack').closest('[hidden]')&&!$('#allergy-ack').checked)throw new K.OrderError('allergyConfirm');
 setBusy(true);
 try{
  await requireOrderContextBackend(fields);let o;const now=new Date().toISOString();
  if(editOrder){
   const old=S.orders.find(o=>o.id===editOrder.id);if(!old||old.status==='cancelled')throw new K.OrderError('orderLocked');
   const cookingFinished=['ready','completed'].includes(old.status),drinksOnly=cookingFinished||old.fulfillment==='drinks';
   const filled=drinksOnly?K.completedDrinkUids(old.items,fields.items):[];
   if(drinksOnly&&(!filled.length||old.mode!==fields.mode||old.table!==fields.table||JSON.stringify(old.orderNotes||[])!==JSON.stringify(fields.orderNotes)))throw new K.OrderError('orderLocked');
   if(old.revision!==editOrder.revision)throw new K.OrderError('staleOrder');
   o={...old,...fields,prices:{...old.prices},updatedAt:now,revision:old.revision+1,revisions:[...(old.revisions||[]),{at:now,items:old.items,baseItems:old.baseItems,mode:old.mode,orderNotes:old.orderNotes||[],charges:old.charges,pricingVersion:old.pricingVersion??0,total:old.total,revision:old.revision}]};
   if(drinksOnly){
    if(cookingFinished)o.status='received';
    o.fulfillment='drinks';o.drinkUids=[...new Set([...(cookingFinished?[]:old.drinkUids||[]),...filled])];
   }
   o.paidAmount=old.paidAmount??(old.paid?old.total:0);o.paid=o.paidAmount>=o.total;
   if(S.settings.apiBase){o=await storeAPI('/'+encodeURIComponent(old.id),'PATCH',{expectedRevision:old.revision,...fields});validateServerContext(o,fields);}
   update({orders:S.orders.map(x=>x.id===o.id?o:x),...(beforeEdit||{cart:[],orderNotes:[]})});editOrder=null;beforeEdit=null;
  }else{
   const send=S.settings.apiBase?async order=>{const received=await storeAPI('','POST',order);validateServerContext(received,fields);return received;}:undefined;
   o=await K.placeOrder(()=>S,fields,{token:confirmToken,now,send,save:update});
   if(!o){setBusy(false);return;}
  }
  rememberSessionOrder(o.id);undos=[];events=[];voiceValue='';lastClip=null;confirmToken='';recoVisible=false;voiceStatusKey='startMic';render();setBusy(false);receipt(o);
 }catch(error){setBusy(false);throw error;}
}

const time=at=>new Date(at).toLocaleString(S.lang==='en'?'en-HK':S.lang==='sc'?'zh-CN':'zh-HK',{timeZone:'Asia/Hong_Kong',hour12:false});
function ticket(o){return`<div class="ticket"><div class="ticket-head"><strong>${esc(S.settings.storeName==='智能茶餐廳'?t('brand'):S.settings.storeName)}</strong><span>${esc(o.id)} · ${t('revision',{n:o.revision})}</span><span>${time(o.at)} · ${o.mode==='dinein'?t('table',{n:o.table}):t('takeaway')}</span></div>${o.items.map(i=>`<div class="ticket-row"><span>${i.qty} × ${name(mBy(i.id))}<small>${esc(details(i))}</small></span><b>${money(K.unit(i,o.prices)*i.qty)}</b></div>`).join('')}${kitchenNotes(o.orderNotes||[])}${o.pricingVersion===1?packagingMarkup({foodSubtotal:o.foodSubtotal,charges:o.charges}):''}<div class="ticket-row ticket-total"><span>${t('total')} ${t('currency')}</span><strong>${money(o.total)}</strong></div><div class="ticket-row"><span>${t(o.paid?'paid':'unpaid')}</span><span>${t(o.status)}</span></div>${(o.paidAmount||0)>(o.status==='cancelled'?0:o.total)?`<div class="ticket-row"><span>${t('refundDue')}</span><b>${money(o.paidAmount-(o.status==='cancelled'?0:o.total))}</b></div>`:(o.paidAmount||0)>0&&!o.paid?`<div class="ticket-row"><span>${t('balanceDue')}</span><b>${money(o.total-o.paidAmount)}</b></div>`:''}</div>`;}
function receipt(o){modal(t('success'),t('orderNumber',{id:o.id}),`<div class="receipt"><div class="success-icon">${icon('check')}</div><h3>${t(o.status)}</h3><p>${t(S.settings.apiBase?'connectedMode':'recordedLocally')}</p>${K.pendingDrinks(o.items).length&&o.status!=='cancelled'?`<button class="primary full" data-amend="${o.id}">${t('drinkFollowup')}</button>`:''}${ticket(o)}<div class="receipt-actions"><button class="secondary" data-print="${o.id}">${icon('receipt')}${t('print')}</button>${(['received','preparing'].includes(o.status)||o.status!=='cancelled'&&K.pendingDrinks(o.items).length)?`<button class="secondary" data-amend="${o.id}">${t('amend')}</button>`:''}${o.status==='received'?`<button class="text-button" data-cancel-order="${o.id}">${t('cancelOrder')}</button>`:''}</div></div>`,`<button class="secondary" data-action="orders">${t('orders')}</button><button class="primary" data-action="close">${t('continue')}</button>`,'receipt');}
async function sync(){if(S.settings.apiBase){const [r,c]=await Promise.all([storeAPI(''),storeAPI('/store')]);update({orders:r.orders,prices:c.prices,availability:c.availability,settings:{...S.settings,storeName:c.storeName}});renderSessionOrders();}}
async function orders(){stopAudio();try{await sync();}catch(e){toast(err(e));}modal(t('orders'),t(S.settings.apiBase?'connectedMode':'localMode'),S.orders.length?S.orders.map(o=>`<article class="history-card"><header><h3>${esc(o.id)}</h3><span class="status-badge status-${o.status}">${t(o.status)}</span></header><p>${o.items.map(i=>`${i.qty} × ${name(mBy(i.id))}`).join(' · ')}</p><header><small>${time(o.at)} · ${money(o.total)} · ${t(o.paid?'paid':'unpaid')}</small><button data-receipt="${o.id}">${t('receipt')}</button></header><button data-reorder="${o.id}">${t('reorder')}</button></article>`).join(''):`<div class="empty-cart"><div class="empty-illustration">${icon('receipt')}</div><h3>${t('historyEmpty')}</h3><p>${t('historyHelp')}</p></div>`,`<button class="primary full" data-action="close">${t('continue')}</button>`,'orders');}
function amend(id){
 if(editOrder){if(editOrder.id===id){close();return;}throw new K.OrderError('finishAmendFirst');}
 const o=S.orders.find(o=>o.id===id);
 if(!o||o.status==='cancelled'||!['received','preparing'].includes(o.status)&&!K.pendingDrinks(o.items).length)throw new K.OrderError('orderLocked');
 beforeEdit=draftSnapshot();editOrder=structuredClone(o);
 try{update({cart:(o.baseItems||o.items).map(K.normalize),orderNotes:K.normalizeOrderNotes(o.orderNotes||[]),mode:o.mode,table:o.table});}
 catch(error){beforeEdit=null;editOrder=null;throw error;}
 undos=[];render();voiceModal();
}
function discardAmend(){
 if(!editOrder)return;
 update(beforeEdit);beforeEdit=null;editOrder=null;undos=[];confirmToken='';render();close();
}
async function changeOrder(id,p){const old=S.orders.find(o=>o.id===id);if(!old)return;let o={...old,...p,...(p.paid?{paidAmount:old.total}:{}),revision:old.revision+1,updatedAt:new Date().toISOString()};if(S.settings.apiBase)o=await storeAPI('/'+encodeURIComponent(id),'PATCH',{expectedRevision:old.revision,...p});update({orders:S.orders.map(x=>x.id===id?o:x)});renderSessionOrders();return o;}
async function hashPin(s){if(!crypto.subtle)throw new K.OrderError('secureMic');return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s)))).map(b=>b.toString(16).padStart(2,'0')).join('');}
function deskEntry(){if(unlocked){desk().catch(voiceError);return;}modal(t('operations'),t('enterPin'),`<label class="form-field">${t('password')}<input id="desk-pin" type="password" inputmode="numeric" maxlength="12" autocomplete="off"></label><p class="micro-hint">${t('pinHint')}</p><div id="pin-error" class="notice error-notice" hidden></div>`,`<button class="primary full" data-action="unlock">${t('unlock')}</button>`,'pin');}
async function desk(){if(!unlocked){deskEntry();return;}await sync();const active=S.orders.filter(o=>!['completed','cancelled'].includes(o.status));modal(t('operations'),t(S.settings.apiBase?'connectedMode':'localMode'),`<div class="desk-stats">${[[active.length,'openCount'],[S.orders.filter(o=>o.status==='completed').length,'completedCount'],[money(S.orders.filter(o=>o.paid&&o.status!=='cancelled').reduce((n,o)=>n+o.total,0)),'revenue']].map(([v,k])=>`<div><strong>${v}</strong><span>${t(k)}</span></div>`).join('')}</div><div class="desk-heading"><h3>${t('kitchen')}</h3><button class="secondary" data-action="desk-refresh">${t('refresh')}</button></div><div class="kitchen-grid">${active.length?active.map(o=>`<article class="kitchen-card"><header><strong>${esc(o.id)}</strong><span class="status-badge">${t(o.status)}</span></header><small>${time(o.at)} · ${o.mode==='dinein'?t('table',{n:o.table}):t('takeaway')} · ${t('revision',{n:o.revision})}</small>${o.fulfillment==='drinks'?`<div class="notice">${t('drinkOnly')}</div>`:''}${kitchenNotes(o.orderNotes||[])}${o.items.filter(i=>o.fulfillment!=='drinks'||o.drinkUids?.includes(i.uid)).map(i=>`<p><b>${i.qty} × ${o.fulfillment==='drinks'?label(i.drink):name(mBy(i.id))}</b><small>${esc(details(i))}</small></p>`).join('')}<div class="kitchen-actions"><button class="primary" data-status-id="${o.id}" data-status="${o.status==='received'?'preparing':o.status==='preparing'?'ready':'completed'}">${t(o.status==='received'?'markPreparing':o.status==='preparing'?'markReady':'markCompleted')}</button>${!o.paid?`<button class="secondary" data-pay="${o.id}">${t('markPaid')}</button>`:`<span>${t('paid')}</span>`}<button class="text-button" data-cancel-order="${o.id}">${t('cancelOrder')}</button></div></article>`).join(''):`<div class="empty-search">${t('queueEmpty')}</div>`}</div><details class="desk-details"><summary>${t('adminMenu')}</summary><div class="admin-menu">${K.menu.map(m=>`<div><b>${name(m)}</b><label>${t('price')}<input data-price="${m.id}" type="number" min="1" max="999" value="${S.prices[m.id]??m.price}"></label><button data-availability="${m.id}" class="chip ${S.availability[m.id]===false?'':'selected'}">${t(S.availability[m.id]===false?'soldout':'available')}</button></div>`).join('')}</div><button class="primary" data-action="save-prices">${t('save')}</button></details><details class="desk-details"><summary>${t('backup')} / ${t('restore')}</summary><p class="micro-hint">${t('backupHint')}</p><button class="secondary" data-action="backup">${t('backup')}</button><button class="secondary" data-action="restore">${t('restore')}</button></details><p class="micro-hint">${t('storageHint')}</p>`,`<button class="secondary" data-action="lock">${t('lock')}</button><button class="secondary" data-action="settings">${t('settings')}</button><button class="primary" data-action="close">${t('close')}</button>`,'desk');}
/*v9-settings-debug*/
/*v9-statistics-ui*/
/*v9-order-context-ui*/
/*v9-unlearned-ui*/
/*v9-evolution-ui*/
function settings(){if(!requireSettings('settings'))return;stopAudio();modal(t('settings'),t('appVersion'),`<div class="settings-tools">${KamLocale.legacy()?`<button class="secondary" data-action="legacy-review">${t('legacyReview')}</button>`:''}<button class="secondary" data-action="manual-pairs">${t('manualPairs')}</button><button class="secondary" data-action="test-mic">${t('micTestTitle')}</button><button class="secondary" data-action="glossary">${t('glossary')}</button><button class="primary" data-action="debug">${t('debugLog')}</button><button class="secondary" data-action="unlearned">${t('learningTitle')}</button><button class="secondary" data-action="evolution">${t('evolutionTitle')}</button></div><p class="micro-hint">${t('settingsNote')}</p><label class="form-field">${t('voiceLang')}<select id="voice-language" disabled aria-describedby="voice-language-hint"><option value="yue" ${S.settings.voiceLang==='yue'?'selected':''}>${t('cantonese')}</option><option value="zh" ${S.settings.voiceLang==='zh'?'selected':''}>${t('mandarin')}</option><option value="en" ${S.settings.voiceLang==='en'?'selected':''}>${t('english')}</option></select><small id="voice-language-hint">${t('voiceLanguageLocked')}</small></label><label class="voice-setting-toggle"><input id="hands-free-mode" type="checkbox" ${S.settings.handsFree!==false?'checked':''}>${t('handsFreeMode')}</label><p class="micro-hint">${t('handsFreeSettingHint')}</p><label class="voice-setting-toggle"><input id="speakback" type="checkbox" ${S.settings.speakBack?'checked':''}>${t('speakBack')}</label><p class="micro-hint">${t('routingPolicy')}</p><div id="voice-statistics-panel">${statisticsPanel()}</div><label class="form-field">${t('parser')}<select id="parser"><option value="auto">${t('automaticFallback')}</option><option value="off">${t('localParser')}</option><option value="minimax">${t('fallbackMinimax')}</option><option value="mimo">${t('fallbackMimo')}</option></select></label><label class="form-field">${t('asr')}<select id="asr"><option value="browser">${t('deviceSpeech')}</option><option value="minimax">MiniMax · asr-1.0</option><option value="mimo">MiMo · mimo-v2.5-asr</option></select></label><p class="micro-hint">${t('asrHint')}</p><p class="micro-hint">${t('micPermissionHint')}</p>${micTestPanel()}<button class="secondary" data-action="release-mic">${t('releaseMic')}</button>${['minimax','mimo'].map(p=>`<label class="form-field">${p==='mimo'?'MiMo':'MiniMax'} ${t('serviceKey')}<input type="password" id="key-${p}" value="${esc(keys[p])}" autocomplete="off"><small>${t('keyHint')}</small></label>`).join('')}<details class="desk-details"><summary>${t('apiBase')}</summary><label class="form-field">${t('serverUrl')}<input id="api-base" type="url" value="${esc(S.settings.apiBase)}" placeholder="https://orders.your-restaurant.hk"></label><label class="form-field">${t('serverToken')}<input id="store-token" type="password" value="${esc(keys.store)}" autocomplete="off"></label><p class="micro-hint">${t('serverHint')}</p><p class="micro-hint">${t('proxyHint')}</p></details><details class="desk-details"><summary>${t('operations')}</summary>${providerProfilesHTML()}<label class="form-field">${t('storeName')}<input id="store-name" maxlength="60" value="${esc(S.settings.storeName==='智能茶餐廳'?t('brand'):S.settings.storeName)}"></label><label class="form-field">${t('newPin')}<input id="new-pin" type="password" inputmode="numeric" maxlength="12" autocomplete="off"></label><p class="micro-hint">${t('pinHint')}</p></details><div class="notice error-notice" id="settings-error" hidden></div>`,`<button class="secondary" data-action="desk">${t('operations')}</button><button class="secondary" data-action="help">${t('help')}</button><button class="primary" data-action="save-settings">${t('saveSettings')}</button>`,'settings');$('#parser').value=['local','auto'].includes(S.settings.parser)?'auto':S.settings.parser;$('#asr').value=S.settings.asr;$('#minimax-profile').value=S.settings.minimaxProfile||'cn';$('#mimo-profile').value=S.settings.mimoProfile||'standard';$('#minimax-model').value=S.settings.minimaxModel||'MiniMax-M2.7';$('#mimo-model').value=S.settings.mimoModel||'mimo-v2.6-flash';const audit=$('#audit-storage-status');if(audit)audit.textContent=KamAudit.status==='persistent'?'':t('auditMemoryOnly');loadStatisticsHistory();}
async function saveSettings(){if(!settingsAccess){settingsEntry();return;}const base=$('#api-base').value.trim().replace(/\/$/,'');if(base){try{const u=new URL(base);if((u.protocol!=='https:'&&!(u.protocol==='http:'&&['localhost','127.0.0.1','[::1]'].includes(u.hostname)))||u.pathname!=='/'||u.search||u.hash||u.username)throw Error();}catch{throw new K.OrderError('invalidUrl');}}const pin=$('#new-pin').value;if(pin&&!/^\d{4,12}$/.test(pin))throw new K.OrderError('invalidPin');if(pin&&!unlocked)throw new K.OrderError('wrongPin');const adminHash=pin?await hashPin(pin):S.adminHash;update({adminHash,settings:{...S.settings,parser:$('#parser').value,asr:$('#asr').value,apiBase:base,minimaxProfile:$('#minimax-profile')?.value||'cn',mimoProfile:$('#mimo-profile')?.value||'standard',minimaxModel:$('#minimax-model')?.value||'MiniMax-M2.7',mimoModel:$('#mimo-model')?.value||'mimo-v2.6-flash',storeName:$('#store-name').value.trim()||t('brand')}});keys={minimax:$('#key-minimax').value.trim(),mimo:$('#key-mimo').value.trim(),store:$('#store-token').value.trim()};Object.values(keys).forEach(value=>KamDebug.addSecret(value));KamDebug.log('settings','saved',{parser:S.settings.parser,asr:S.settings.asr,voiceLang:S.settings.voiceLang,cloudConfigured:!!(keys.minimax||keys.mimo)});render();close();toast(t('settingsSaved'));}
function glossaryRows(q){const query=K.tc(q).trim().toLowerCase();const cultures=K.glossary.filter(row=>K.tc(row.join(' ')).toLowerCase().includes(query)).map(row=>`<article class="glossary-row"><strong>${label(row[0])}</strong><p>${S.lang==='en'?row[2]:label(row[1])}</p></article>`).join('');const dishes=K.menu.filter(m=>!query||K.lexicon.byItem[m.id].some(row=>row.term.includes(query))||K.tc(m.name+m.en).toLowerCase().includes(query)).map(m=>`<article class="dish-aliases"><h3>${name(m)}</h3><p>${[...new Set(K.lexicon.byItem[m.id].filter(row=>S.lang==='en'||/\p{Script=Han}/u.test(row.baseTerm||row.term)||q&&/[a-z]/i.test(q)).map(row=>label(row.term)))].map(esc).join('、')}</p></article>`).join('');const learned=automaticPairs().filter(row=>!query||K.tc(row.source+' '+row.target).toLowerCase().includes(query));const learnedHTML=learned.length?'<h3>'+t('automaticPairs')+'</h3>'+learned.slice(-100).reverse().map(row=>`<article class="glossary-row automatic-dictionary-row"><strong>${esc(row.source)}</strong><p>${esc(label(row.target))}</p><small>${t(row.guard?'automaticPairGuarded':'automaticPairReusable')}</small></article>`).join(''):'';return learnedHTML+cultures+(dishes?`<h3 class="alias-section-title">${t('aliasHeading')}</h3>`+dishes:'');}
function glossary(){if(!requireSettings('glossary'))return;const s=K.lexicon.stats;modal(t('glossary'),t('glossarySubtitle'),`<div class="source-line">${t('lexiconStats',{total:s.entries,items:s.itemAliases,phonetic:s.phonetic,options:s.modifiers})}</div><label class="form-field">${t('search')}<input id="glossary-search" type="search" autocomplete="off"></label><div id="glossary-list">${glossaryRows('')}</div>`,`<button class="secondary full" data-action="settings">${t('backSettings')}</button>`,'glossary');}
function tableModal(){modal(t('chooseTable'),t('dinein'),`<div class="table-options">${Array.from({length:24},(_,n)=>`<button class="${S.table===n+1?'selected':''}" data-table="${n+1}">${n+1}</button>`).join('')}</div>`,'','table');}
function clearModal(){modal(t('clearConfirm'),t('requestUnchanged'),`<p class="micro-hint">${t('clearDesc')}</p>`,`<button class="secondary" data-action="close">${t('cancel')}</button><button class="primary" data-action="clear-confirm">${t('clear')}</button>`,'clear');}
function download(data,filename,type){if(globalThis.KamNative?.saveFile){KamNative.saveFile(filename,type,btoa(unescape(encodeURIComponent(data))));return;}const url=URL.createObjectURL(new Blob([data],{type})),a=document.createElement('a');a.href=url;a.download=filename;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
function backup(){download(JSON.stringify({...S,exportedAt:new Date().toISOString()},null,2),'SmartCafe-Backup-'+KamLocale.id+'-'+new Date().toISOString().slice(0,10)+'.json','application/json');toast(t('exported'));}
async function restore(file){if(file.size>5000000)throw new K.OrderError('invalidBackup');let b;try{b=JSON.parse(await file.text());if(b.version!==2||!Array.isArray(b.orders)||!Array.isArray(b.cart)||!['tc','sc','en'].includes(b.lang))throw Error();if(b.lang!==KamLocale.id)throw new K.OrderError('localeMismatch');b.cart=b.cart.map(K.normalize);b.portionOrder=K.normalizePortionOrder(b.cart,b.portionOrder);b.orderNotes=K.normalizeOrderNotes(b.orderNotes||[]);b.manualPairs=K.manualPairs.normalize(b.manualPairs);if(!['dinein','takeaway'].includes(b.mode))throw Error();const ids=new Set();for(const o of b.orders){if(!o.id||ids.has(o.id)||!['received','preparing','ready','completed','cancelled'].includes(o.status))throw Error();ids.add(o.id);validateStoredOrder(o);}if(Object.values(b.prices||{}).some(x=>!Number.isFinite(+x)||+x<1||+x>999))throw Error();}catch(error){if(error.code==='localeMismatch')throw error;throw new K.OrderError('invalidBackup');}if(editOrder)throw new K.OrderError('finishAmendFirst');commit({...initial,...b,settings:{...initial.settings,...b.settings}});unlocked=false;render();close();toast(t('restored'));}
function printReceipt(id){const o=S.orders.find(o=>o.id===id);if(!o)return;const html=`<html><meta charset="utf-8"><style>body{font:14px sans-serif;max-width:75mm;margin:10mm auto}h1{font-size:20px}.ticket-row{display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px dashed #aaa}small{display:block;color:#555}</style><h1>${esc(S.settings.storeName==='智能茶餐廳'?t('brand'):S.settings.storeName)}</h1>${ticket(o)}</html>`;if(globalThis.KamNative?.printReceipt){KamNative.printReceipt(html);return;}const w=window.open('','_blank');if(!w)return;w.document.write(html);w.document.close();w.focus();w.print();}
/*v9-manual-pairs-ui*/
/*v9-locale-isolation-ui*/
/*v9-api-learning-ui*/
async function click(b){const d=b.dataset;
 if(d.manualPairChoice!==undefined){choosePairTarget(Number(d.manualPairChoice));return;}
 if(d.autoPairRemove!==undefined){removeAutomaticPair(Number(d.autoPairRemove));return;}
 if(d.manualPairEdit!==undefined){manualPairsPage(Number(d.manualPairEdit));return;}
 if(d.manualPairRemove!==undefined){removeManualPair(Number(d.manualPairRemove));return;}
 if(d.learningTerm){if(settingsAccess)unlearned.mark(d.learningTerm,d.learningStatus);return;}if(d.removeOrderNote!==undefined){const notes=S.orderNotes.filter((_,i)=>i!==Number(d.removeOrderNote));saveDraft(S.cart,{orderNotes:notes});return;}if(d.keepStandalone){declinedUpgrades.add(d.keepStandalone);renderCart();return;}if(d.upgrade){const i=S.cart.find(i=>i.uid===d.upgrade);if(!i||!mBy(i.id).upgradeTo)return;const text=pending?.upgradeText||'跟餐';const origin=pending?.origin||'home',voiceId=pending?.voiceId,source=pending?.source;pending=null;await processCommand('第'+(S.cart.indexOf(i)+1)+'份 '+text,{origin,voiceId,source});return;}if(d.followupOrder){const x=pending;if(!x?.drinkPlan)return;pending=null;const plan=prepareDrinkFollowup(d.followupOrder,x.drinkPlan,x.drinkText);await processCommand(x.drinkText,{plan,origin:'voice',voiceId:x.voiceId,source:x.source});return;}if(d.pairDrink){const x=pending;if(!x?.p)return;pending=null;await processCommand(x.text,{plan:K.pairWithDrink(x.p,S.cart,d.pairDrink),origin:x.origin,voiceId:x.voiceId,source:x.source});return;}if(d.termItem){const x=pending;if(!x?.term)return;const term=x.term;const replacement=mBy(d.termItem).name;const revised=term.original.slice(0,term.start)+replacement+term.original.slice(term.end);pending=null;await processCommand(revised,{origin:x.origin,voiceId:x.voiceId,source:x.source});return;}if(d.add){openItem(d.add);return;}if(d.edit){const i=S.cart.find(i=>i.uid===d.edit);openItem(i.id,i.uid);return;}if(d.extra){draft.item.note=($('#item-note')?.value??draft.item.note);const x=draft.item.extras||[];draft.item.extras=x.includes(d.extra)?x.filter(id=>id!==d.extra):[...x,d.extra];drawItem();return;}if(d.option){draft.item.note=($('#item-note')?.value??draft.item.note);draft.item[d.option]=d.value;if(d.option==='drink'){if(!K.drinkMilkAllowed(d.value))draft.item.milk='正常奶';draft.item.sugar='正常甜';draft.item.ice='正常冰';draft.item.extras=(draft.item.extras||[]).filter(id=>K.allowedExtras(mBy(draft.item.id),draft.item).some(x=>x.id===id));}drawItem();return;}if(d.draftqty){draft.item.note=($('#item-note')?.value??draft.item.note);draft.item.qty=Math.max(1,Math.min(20,draft.item.qty+ +d.draftqty));drawItem();return;}if(d.qty){const back=!modalType||modalType==='voice';replaceCart(S.cart.map(i=>i.uid===d.qty?{...i,qty:Math.min(20,i.qty+ +d.delta)}:i).filter(i=>i.qty>0));if(back)voiceModal();return;}if(d.cat){category=d.cat;render();return;}if(d.mode){changeService(d.mode);return;}if(d.table){update({table:+d.table});render();close();return;}if(d.target){
 const x=pending,choice=x?.state===S&&x.targetChoices?.find(c=>c.uid===d.target);
 if(!choice)return;
 pending=null;await processCommand(x.text,{plan:choice.plan,origin:x.origin,voiceId:x.voiceId,source:x.source});return;
}if(d.voiceCandidate!==undefined){return correctVoiceTranscript(pending?.candidates?.[Number(d.voiceCandidate)]);}if(d.receipt){receipt(S.orders.find(o=>o.id===d.receipt));return;}if(d.amend){amend(d.amend);return;}if(d.reorder){const o=S.orders.find(o=>o.id===d.reorder);const items=(o.baseItems||o.items).map(i=>({...i,uid:K.uid()}));for(const i of items)if(S.availability[i.id]===false)throw new K.OrderError('soldOut',{name:name(mBy(i.id))});replaceCart([...S.cart,...items],{orderNotes:K.mergeOrderNotes(S.orderNotes,o.orderNotes||[])});close();return;}if(d.print){printReceipt(d.print);return;}if(d.cancelOrder){const o=S.orders.find(o=>o.id===d.cancelOrder);if(!unlocked&&o.status!=='received')throw new K.OrderError('orderLocked');modal(t('cancelConfirm'),esc(o.id),'',`<button class="secondary" data-action="close">${t('cancel')}</button><button class="primary" data-confirm-cancel="${o.id}">${t('cancelOrder')}</button>`,'cancel');return;}if(d.confirmCancel){await changeOrder(d.confirmCancel,{status:'cancelled'});await orders();return;}if(d.statusId){if(!unlocked)return;await changeOrder(d.statusId,{status:d.status});await desk();return;}if(d.pay){if(!unlocked)return;modal(t('markPaid'),d.pay,`<div class="chips">${['cash','card'].map(m=>`<button data-record-payment="${d.pay}" data-method="${m}" class="chip">${t(m)}</button>`).join('')}</div>`,'','pay');return;}if(d.recordPayment){if(!unlocked)return;await changeOrder(d.recordPayment,{paid:true,paymentMethod:d.method});await desk();return;}if(d.availability){if(!unlocked)return;const availability={...S.availability,[d.availability]:S.availability[d.availability]===false};if(S.settings.apiBase)await storeAPI('/store','PATCH',{availability});update({availability});render();await desk();return;}
const actions={...evolutionActions,'legacy-review':legacyReview,'legacy-assign':legacyAssign,'legacy-export':legacyExport,'all-logs':exportAllLogs,'api-probe':testAPIConnection,'cloud-record':()=>record(false,true),'manual-pairs':()=>manualPairsPage(),
'correct-transcript':()=>{const x=lastVoiceCorrection;if(x?.state===S)transcriptClarification(x.text,[],x.origin,x.voiceId);},
'record-again':()=>{close();return record();},'clear-order-notes':()=>saveDraft(S.cart,{orderNotes:[]}),'unlearned':unlearnedPage,'unlearned-export-json':()=>exportUnlearned('json'),'unlearned-export-jsonl':()=>exportUnlearned('jsonl'),'unlearned-export-csv':()=>exportUnlearned('csv'),'unlearned-recheck':()=>{if(!settingsAccess)return;const result=unlearned.recheck();toast(t('learningRechecked',result));renderUnlearned();},'unlearned-reset':unlearnedReset,'unlearned-reset-confirm':()=>{if(settingsAccess){unlearned.reset();unlearnedPage();}},'statistics-export':exportAllLogs,'statistics-reset':statisticsReset,'statistics-reset-confirm':()=>{if(!settingsAccess)return;voiceMetrics.reset();settings();},debug:debugLog,'debug-refresh':()=>KamDebug.inspect('manual'),'debug-export':exportAllLogs,'debug-clear':()=>{if(settingsAccess)KamDebug.clear();},'test-mic':testMicrophone,'finish-mic-test':()=>microphone.finish(),'play-mic-test':()=>$('#mic-test-playback audio')?.play().catch(()=>{}),'mic-help':()=>microphoneHelp(),'voice-mic-help':()=>microphoneHelp(true),'mic-report':()=>download(KamDebug.microphoneReport(),'SmartCafe-Mic-Diagnostics-'+new Date().toISOString().replace(/[:.]/g,'-')+'.json','application/json'),'mic-settings':()=>globalThis.KamNative?.openMicrophoneSettings(),home:()=>{close();window.scrollTo({top:0,behavior:'smooth'});},voice:record,recommend:()=>{recoFilter={};recoIndex=0;recommend();},orders,desk:deskEntry,settings,glossary,close,cart:()=>$('#cart-panel').classList.add('open'),'close-cart':()=>$('#cart-panel').classList.remove('open'),table:tableModal,'save-item':saveItem,'delete-item':()=>{const back=draft.back;replaceCart(S.cart.filter(i=>i.uid!==draft.item.uid));draft=null;if(back==='review')review();else if(back==='voice')voiceModal();else close();},review,confirm,clear:clearModal,'clear-confirm':()=>{replaceCart([],{orderNotes:[]});close();voiceState('startMic');},undo:()=>{undo();if(modalType==='voice')voiceModal();},record,readback,'next-recommend':()=>{recoIndex++;recommend();},'reset-recommend':()=>{recoFilter={};recoIndex=0;recommend();},'hide-recommend':()=>{recoVisible=false;renderRecommend();},'use-recommend':()=>{const r=recoList[recoIndex%recoList.length];if(!K.recommendationAllowed(r,S.availability,recoFilter,S.prices)){recoIndex=0;recommend();toast(t('recommendUpdated'));return;}const next=K.transitionDraft(S,{intent:'add',ops:r.items.map(i=>({type:'add',item:i}))},S.availability);replaceCart(next.cart,{mode:next.mode,orderNotes:next.orderNotes});recoVisible=false;voiceValue='';voiceModal();},'save-settings':saveSettings,help:()=>modal(t('help'),t('helpSubtitle'),`<p class="help-copy">${t('helpText')}</p><button class="secondary full" data-action="glossary">${t('glossary')}</button>`,'','help'),unlock:async()=>{const expected=S.adminHash||await hashPin('2468');if(await hashPin($('#desk-pin').value)!==expected)throw new K.OrderError('wrongPin');unlocked=true;await desk();},'desk-refresh':desk,lock:()=>{unlocked=false;close();},'save-prices':async()=>{if(!unlocked)return;const prices={};for(const e of document.querySelectorAll('[data-price]')){const n=+e.value;if(!Number.isInteger(n)||n<1||n>999)throw new K.OrderError('invalidOption');prices[e.dataset.price]=n;}if(S.settings.apiBase)await storeAPI('/store','PATCH',{prices});update({prices});render();await desk();toast(t('priceSaved'));},backup,restore:()=>modal(t('restore'),t('operations'),`<div class="notice">${t('confirmRestore')}</div>`,`<button class="secondary" data-action="backup">${t('backup')}</button><button class="primary" data-action="choose-restore">${t('restore')}</button>`,'restore'),'choose-restore':()=>$('#restore-file').click(),'release-mic':()=>{stopAudio();releaseMicrophone();toast(t('micReleased'));},'retry-clip':()=>{if(lastClip)return recoverClip(lastClip.blob,lastClip.localText,lastClip.origin,lastClip.alternatives||[],lastClip.voiceId,true);},'defer-drink':deferDrinks,'choose-drink':()=>{const i=K.pendingDrinks(S.cart)[0];if(i)openItem(i.id,i.uid);},'discard-amend':discardAmend};return actions[d.action]?.();}
document.addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;KamDebug.log('ui','click',{action:b.dataset,disabled:b.disabled,busy});if(b.disabled||((busy||handsFree.processing||handsFree.pending)&&!(handsFree.active&&b.dataset.action==='record')))return;click(b).catch(e=>{KamDebug.error('ui','action.failed',e,{action:b.dataset});const el=!$('#modal-layer').hidden&&($('#settings-error')||$('#pin-error'));if(el){el.textContent=err(e);el.hidden=false;}else voiceError(e);});});
document.addEventListener('input',e=>{if(e.target.id==='manual-pair-target')renderPairMatches();if(e.target.id==='manual-pair-source')renderPairPreview();if(e.target.id==='learning-search'){learningFilters.q=e.target.value;renderUnlearnedRows();}if(e.target.id==='debug-filter')renderDebug();if(e.target.id==='search'){search=e.target.value;renderMenu();}if(e.target.id==='glossary-search')$('#glossary-list').innerHTML=glossaryRows(e.target.value);});
document.addEventListener('change',e=>{KamDebug.log('ui','change',{id:e.target.id,type:e.target.type,value:e.target.type==='password'?'[REDACTED]':['ui-language','parser','asr','voice-language','debug-level'].includes(e.target.id)?e.target.value:e.target.type==='checkbox'?e.target.checked:'[omitted]'});if(e.target.id==='debug-level')renderDebug();if(e.target.dataset.learningFilter){learningFilters[e.target.dataset.learningFilter]=e.target.value;renderUnlearnedRows();}if(e.target.id==='statistics-range'){statisticsRange=e.target.value;renderStatistics();}try{if(e.target.id==='ui-language'){const lang=e.target.value;if(lang!==KamLocale.id){stopHandsFree('language-navigation',true);voiceWork++;setBusy(false);stopAudio();releaseMicrophone();stopEvolution();KamLocale.navigate(lang);}return;}if(['continuous','hands-free-mode','speakback','voice-language'].includes(e.target.id)){const settings={...S.settings};if(e.target.id==='hands-free-mode'){settings.handsFree=e.target.checked;if(!settings.handsFree)stopHandsFree('setting-off');}if(e.target.id==='continuous')settings.continuous=e.target.checked;if(e.target.id==='speakback')settings.speakBack=e.target.checked;if(e.target.id==='voice-language')settings.voiceLang=S.lang==='en'?'en':S.lang==='sc'?'zh':'yue';update({settings});}if(e.target.id==='audio-upload'&&e.target.files[0])transcribe(e.target.files[0]).catch(voiceError);if(e.target.id==='restore-file'&&e.target.files[0])restore(e.target.files[0]).catch(voiceError);}catch(e){toast(err(e));}});
document.addEventListener('submit',e=>{
 if(e.target.id==='manual-pair-form'){e.preventDefault();if(!busy)saveManualPair();return;}
 if(e.target.id!=='voice-correction-form')return;
 e.preventDefault();if(!busy)Promise.resolve(correctVoiceTranscript($('#voice-correction')?.value)).catch(voiceError);
});
document.addEventListener('keydown',e=>{if($('#modal-layer').hidden)return;if(e.key==='Escape')close();if(e.key==='Tab'){const f=[...$('#modal').querySelectorAll('button,input,select,textarea,a')].filter(x=>!x.disabled&&x.offsetParent!==null);if(!f.length)return;if(e.shiftKey&&(document.activeElement===f[0]||document.activeElement===$('#modal'))){e.preventDefault();f[f.length-1].focus();}else if(!e.shiftKey&&document.activeElement===f[f.length-1]){e.preventDefault();f[0].focus();}}});
$('#modal-layer').addEventListener('click',e=>{if(e.target===$('#modal-layer'))close();});globalThis.kamStop=()=>{stopHandsFree('app-stopped',true);if(activeVoiceId){voiceMetrics.finish(activeVoiceId,{status:'cancelled',error:'app-stopped'});settleUnlearned(activeVoiceId,{status:'cancelled',error:'app-stopped'});activeVoiceId=null;}voiceWork++;setBusy(false);stopAudio();releaseMicrophone();};globalThis.kamBack=()=>{if(handsFree.active){stopHandsFree('back');return true;}if(!$('#modal-layer').hidden){close();return true;}if($('#cart-panel').classList.contains('open')){$('#cart-panel').classList.remove('open');return true;}return false;};document.addEventListener('visibilitychange',()=>{if(document.hidden){if(microphone.starting){KamDebug.log('hands-free','permission-sheet-hidden');microphone.background();return;}stopHandsFree('background',true);if(activeVoiceId){voiceMetrics.finish(activeVoiceId,{status:'cancelled',error:'app-background'});settleUnlearned(activeVoiceId,{status:'cancelled',error:'app-background'});activeVoiceId=null;}voiceWork++;setBusy(false);microphone.background();}});window.addEventListener('pagehide',()=>{stopHandsFree('page-hidden',true);if(activeVoiceId){voiceMetrics.finish(activeVoiceId,{status:'cancelled',error:'page-hidden'});settleUnlearned(activeVoiceId,{status:'cancelled',error:'page-hidden'});activeVoiceId=null;}settingsAccess=false;voiceWork++;setBusy(false);stopAudio();releaseMicrophone();lastClip=null;keys={minimax:'',mimo:'',store:''};stopEvolution();});render();
// Import retained legacy detail. IndexedDB keeps all later revisions, including
// records which have since left the small UI/localStorage caches.
for(const message of voiceMetrics.data.messages)KamAudit.record('voice',message.id,message);
for(const record of unlearned.data.cases)KamAudit.record('unlearned',record.id,record);
if(globalThis.indexedDB){
 const mic=$('#home-mic');if(mic)mic.disabled=true;
 KamAudit.ready.then(()=>{
  const saved=KamAudit.recoveredEvolution;
  if(saved&&Date.parse(saved.active?.at||0)>Date.parse(evolution.data.active?.at||0)){
   KamEvolution.validatePack(saved.active);KamEvolution.validatePack(saved.remote);
   evolution.data=saved;KamEvolution.install(saved.active,saved.remote);
   KamAudit.append('learning','restored-from-full-history',{version:saved.active.version,rules:saved.active.rules.length});
  }
 }).catch(error=>KamDebug.error('audit','restore.failed',error)).finally(()=>{const mic=$('#home-mic');if(mic)mic.disabled=busy||micStarting;});
}
document.addEventListener('keydown',event=>{if(event.key==='Escape'&&handsFree.active){event.preventDefault();stopHandsFree('escape');}});
})();

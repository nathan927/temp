let pairEditing=-1,pairMatches=[];
function manualPairsPage(editIndex=-1){
 if(!requireSettings('manual-pairs'))return;
 stopAudio();
 const row=S.manualPairs[editIndex];
 pairEditing=row?editIndex:-1;pairMatches=[];
 const existing=S.manualPairs.map(({source,target},index)=>`<li>
  <span><strong>${esc(source)}</strong><span aria-hidden="true"> → </span>${esc(label(target))}</span>
  <div><button type="button" class="text-button" data-manual-pair-edit="${index}">${t('edit')}</button>
  <button type="button" class="text-button" data-manual-pair-remove="${index}">${t('remove')}</button></div>
 </li>`).join('');
 modal(t('manualPairs'),t('appVersion'),`
  <p class="micro-hint">${t('manualPairIntro')}</p>
  <form id="manual-pair-form">
   <label class="form-field">${t('manualPairSource')}<input id="manual-pair-source" value="${esc(row?.source||'')}"
    maxlength="${K.manualPairs.sourceLimit}" placeholder="${t('manualPairSourceExample')}" aria-describedby="manual-pair-source-help" autocomplete="off" required>
    <small id="manual-pair-source-help">${t('manualPairSourceHelp')}</small>
   </label>
   <label class="form-field">${t('manualPairTarget')}<input id="manual-pair-target" value="${esc(row?.target||'')}"
    maxlength="2000" placeholder="${t('manualPairTargetExample')}" aria-describedby="manual-pair-match-count" aria-controls="manual-pair-results" autocomplete="off" required></label>
   <p class="micro-hint" id="manual-pair-match-count" role="status">${t('manualPairType')}</p>
   <div id="manual-pair-results" class="manual-pair-results" hidden></div>
   <p class="manual-pair-preview" id="manual-pair-preview" hidden></p>
   <p id="manual-pair-message" class="notice" role="status" hidden></p>
   <button class="primary" type="submit">${t(pairEditing>=0?'saveChanges':'manualPairSave')}</button>
   ${pairEditing>=0?`<button class="secondary" type="button" data-action="manual-pairs">${t('cancel')}</button>`:''}
  </form>
  <h3>${t('manualPairSavedList',{n:S.manualPairs.length})}</h3>
  ${automaticPairPanel()}
  ${existing?`<ul class="manual-pair-list">${existing}</ul>`:`<p class="micro-hint">${t('manualPairEmpty')}</p>`}
 `,`<button class="secondary full" data-action="settings">${t('backSettings')}</button>`,'manual-pairs');
 renderPairPreview();
}
function renderPairPreview(){
 const el=$('#manual-pair-preview'),source=$('#manual-pair-source')?.value.trim(),target=$('#manual-pair-target')?.value.trim();
 if(!el)return;
 el.hidden=!(source&&target);
 el.textContent=source&&target?t('manualPairPreview',{source,target})+' '+t(K.manualPairs.isToken(target)?'manualPairInSentence':'manualPairWholeSentence'):'';
}
function renderPairMatches(){
 if(!settingsAccess||modalType!=='manual-pairs')return;
 const query=$('#manual-pair-target').value;
 const extras=[evolution.data.active,evolution.data.remote].flatMap(pack=>(pack?.rules||[]).map(rule=>rule.phrase));
 pairMatches=K.manualPairs.search(query,extras);
 $('#manual-pair-match-count').textContent=query.trim()?t(pairMatches.length?'manualPairMatches':'manualPairNoMatches',{n:pairMatches.length}):t('manualPairType');
 const list=$('#manual-pair-results');
 list.hidden=!pairMatches.length;
 list.innerHTML=pairMatches.map((row,index)=>`<button type="button" data-manual-pair-choice="${index}">
  <strong>${esc(label(row.text))}</strong><small>${t({item:'manualPairKindItem',modifier:'manualPairKindModifier',command:'manualPairKindCommand'}[row.kind])}${row.hint?' · '+esc(row.hint):''}</small>
 </button>`).join('');
 renderPairPreview();
}
function choosePairTarget(index){
 if(!settingsAccess||modalType!=='manual-pairs'||!pairMatches[index])return;
 const input=$('#manual-pair-target');
 input.value=S.lang==='sc'?L.toSC(pairMatches[index].text):pairMatches[index].text;
 $('#manual-pair-results').hidden=true;
 $('#manual-pair-match-count').textContent=t('manualPairPicked');
 renderPairPreview();input.focus();
}
function pairMessage(message,isError=false){
 const el=$('#manual-pair-message');
 el.textContent=message;el.hidden=false;
 el.classList.toggle('error-notice',isError);
 el.setAttribute('role',isError?'alert':'status');
}
function saveManualPair(){
 if(!settingsAccess||modalType!=='manual-pairs')return;
 try{
  const manualPairs=K.manualPairs.save(S.manualPairs,$('#manual-pair-source').value,$('#manual-pair-target').value,S.cart,voiceContext(),pairEditing);
  update({manualPairs});
  manualPairsPage();pairMessage(t('manualPairSaved'));
 }catch(error){pairMessage(err(error),true);}
}
function removeManualPair(index){
 if(!settingsAccess||modalType!=='manual-pairs'||!S.manualPairs[index])return;
 try{
  update({manualPairs:S.manualPairs.filter((_,i)=>i!==index)});
  manualPairsPage();pairMessage(t('manualPairRemoved'));
 }catch(error){pairMessage(err(error),true);}
}

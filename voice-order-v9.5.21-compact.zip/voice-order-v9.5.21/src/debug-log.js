/* Local, bounded diagnostic journal. Never record credentials or audio payloads. */
(function (g) {
  'use strict';
  const LIMIT=2500, STORAGE='kamkee.debug.v9', listeners=new Set();
  const sensitive=/password|pin$|token|authorization|api.?key|key-(?:mini|mimo)|store-token|desk-pin|settings-password|new-pin|^key$|base64|deviceId|groupId/i;
  let secrets=new Set(['nathanyuen.org']), rows=[], seq=0, persistTimer, permissionStatus, storageWarning=false;
  function scrubString(value,max=6000) {
    let s=String(value).slice(0,max);
    for(const secret of secrets) if(secret) s=s.split(secret).join('[REDACTED]');
    return s.replace(/Bearer\s+[^\s"',}]+/gi,'Bearer [REDACTED]').replace(/\bsk-[\w-]{8,}\b/g,'[REDACTED]').replace(/data:audio\/[^;]+;base64,[A-Za-z0-9+/=]+/g,'[AUDIO REDACTED]');
  }
  function sanitize(value,key='',depth=0,seen=new WeakSet()) {
    if(sensitive.test(key)||/^audio(?:data)?$/i.test(key)&&(typeof value==='string'||Array.isArray(value)||ArrayBuffer.isView(value)))return '[REDACTED]';
    if(depth>7)return '[depth limit]';
    if(typeof value==='string')return scrubString(value);
    if(value==null||typeof value==='number'||typeof value==='boolean')return value;
    if(typeof value==='function')return '[function]';
    if(typeof value!=='object')return String(value);
    if(seen.has(value))return '[circular]';seen.add(value);
    if(value instanceof Error || /\[object (?:Error|DOMException)\]/.test(Object.prototype.toString.call(value))) {
      return sanitize({name:value.name,message:value.message,code:value.code,diagnostic:value.diagnostic,constraint:value.constraint,stack:value.stack,cause:value.cause,data:value.data},'',depth+1,seen);
    }
    if(g.Blob&&value instanceof g.Blob)return {type:value.type,bytes:value.size};
    if(Array.isArray(value))return value.slice(0,80).map(v=>sanitize(v,'',depth+1,seen));
    const out={};for(const k of Object.keys(value).slice(0,80)){try{out[k]=sanitize(value[k],k,depth+1,seen);}catch{out[k]='[unreadable]';}}return out;
  }
  try{const saved=JSON.parse(g.localStorage?.getItem(STORAGE)||'[]');if(Array.isArray(saved))rows=saved.slice(-LIMIT).map(r=>sanitize(r));seq=rows.reduce((n,r)=>Math.max(n,+r.seq||0),0);}catch{}
  for(const row of rows)g.KamAudit?.append('debug','legacy-import',row);
  function persist(){try{g.localStorage?.setItem(STORAGE,JSON.stringify(rows.slice(-800)));storageWarning=false;}catch(error){if(!storageWarning){storageWarning=true;log('debug','persistence.failed',{error,handling:'記錄仍在本次記憶體；請先匯出 JSON。儲存空間不足或瀏覽器拒絕儲存時，重新開啟可能遺失記錄。'},'warn');}}}
  function log(scope,event,data={},level='info'){
    const row={seq:++seq,at:new Date().toISOString(),level,scope,event,data:sanitize(data)};
    g.KamAudit?.append('debug',event,row);
    rows.push(row);if(rows.length>LIMIT)rows.splice(0,rows.length-LIMIT);
    clearTimeout(persistTimer);persistTimer=setTimeout(persist,500);
    for(const listener of listeners){try{listener(row);}catch{}}return row;
  }
  function environment(){
    let framed=false,policy='unknown';try{framed=g.top!==g.self;}catch{framed=true;}
    try{const p=g.document?.permissionsPolicy||g.document?.featurePolicy;policy=p?p.allowsFeature('microphone'):'API unavailable';}catch(e){policy=e.name;}
    const nav=g.navigator||{},bridge=g.KamNative;
    return {userAgent:nav.userAgent,platform:nav.platform,language:nav.language,online:nav.onLine,
      protocol:g.location?.protocol,origin:g.location?.origin,secureContext:g.isSecureContext,framed,
      visibility:g.document?.visibilityState,microphonePolicy:policy,
      mediaDevices:!!nav.mediaDevices,getUserMedia:!!nav.mediaDevices?.getUserMedia,
      permissionQuery:!!nav.permissions?.query,audioContext:!!(g.AudioContext||g.webkitAudioContext),speechRecognition:!!(g.SpeechRecognition||g.webkitSpeechRecognition),
      nativeBridge:!!bridge,nativeMethods:Object.fromEntries(['startMic','finishMic','cancelMic','openMicrophoneSettings','request','saveFile'].map(k=>[k,typeof bridge?.[k]==='function'])),
      nativePermissionDetail:bridge?'Only native callbacks can report Android runtime grants / permanent denial. No native source is present in this repository.':'Browser permissions apply'};
  }
  async function inspect(reason='manual',sessionId){
    const trace=(details,event='permission.query')=>{if(sessionId)log('mic-trace',event,{sessionId,...details});};
    log('environment','snapshot',{reason,...environment()});
    if(!g.navigator?.permissions?.query){trace({state:'unsupported'});log('permission','query.unavailable',{reason:'Permissions API unavailable; this does not imply denial. Native Android permission is separate.'},'warn');return;}
    try{
      const status=await g.navigator.permissions.query({name:'microphone'});
      trace({state:status.state,layer:'browser'});
      log('permission','microphone.state',{state:status.state,reason,layer:'browser',nativeState:'not exposed by browser permission query'});
      if(permissionStatus&&permissionStatus!==status)permissionStatus.onchange=null;
      permissionStatus=status;
      status.onchange=()=>{
        trace({state:status.state,layer:'browser'},'permission.change');
        log('permission','microphone.changed',{state:status.state,layer:'browser'});
      };
    }catch(error){trace({state:'unknown',errorName:error.name});log('permission','query.failed',{error,handling:'Continue to the actual microphone request. Some browsers do not support querying microphone permission.'},'warn');}
  }
  const recovery={
    micDenied:'檢查網站或 App 麥克風權限後重試；NotAllowedError 本身不能分辨用戶拒絕與系統政策。',
    micDeniedPermanent:'Android 已回報永久拒絕；請開啟 App 權限設定，允許麥克風後重試。',
    micInsecure:'請使用 HTTPS 或 localhost；此來源不符合瀏覽器收音要求。',
    micPolicy:'檢查 Permissions-Policy、iframe allow="microphone" 及宿主 WebView 設定。',
    micMissing:'檢查裝置是否有可用麥克風及是否連接成功。',micBusy:'關閉其他通話／錄音程式，檢查裝置後重試。',
    micPreview:'請在完整瀏覽器的安全來源開啟，或使用支援原生收音的 App。',
    micPromptTimeout:'60 秒內未收到授權或開始回報；檢查系統提示。Android 詳細原因仍需原生層回報。',
    micRecognitionTimeout:'錄音停止後未收到辨識結果；檢查語音服務及網絡，再重試。',
    micSilent:'檢查 Android 麥克風存取總開關、輸入裝置、耳機及其他收音程式。',
    micAudioUnsupported:'檢查 AudioContext 支援及使用者點擊啟動限制。',micConstraints:'已嘗試放寬為 audio:true；仍失敗請檢查輸入裝置。'
  };
  const api={log,inspect,environment,sanitize,
    error(scope,event,error,extra={}){return log(scope,event,{error,handling:recovery[error?.code]||'保留錯誤原名及上下文；核對相關權限、裝置或服務設定後重試。',...extra},'error');},
    addSecret(value){if(value){secrets.add(String(value));g.KamAudit?.addSecret(value);}},
    sanitizeForResearch(value,max=6000){let s=String(value);for(const secret of secrets)for(const variant of [secret,secret.toLowerCase(),secret.normalize('NFKC').toLowerCase().replace(/[\p{P}\p{S}\s]+/gu,' ').trim()])if(variant)s=s.split(variant).join('[REDACTED]');return scrubString(s,max);},
    entries(){return rows.map(r=>sanitize(r));},
    export(){return JSON.stringify({language:g.KamLocale?.id,version:9,appVersion:'9.5.21',exportedAt:new Date().toISOString(),environment:environment(),entries:api.entries()},null,2);},
    microphoneReport(){
      const trace=rows.filter(r=>r.scope==='mic-trace'),ids=[...new Set(trace.map(r=>r.data.sessionId))].slice(-10);
      const env=environment();
      return JSON.stringify({language:g.KamLocale?.id,version:1,appVersion:'9.5.21',exportedAt:new Date().toISOString(),environment:{
        userAgent:env.userAgent,protocol:env.protocol,secureContext:env.secureContext,framed:env.framed,
        microphonePolicy:env.microphonePolicy,getUserMedia:env.getUserMedia,permissionQuery:env.permissionQuery,
        audioContext:env.audioContext,speechRecognition:env.speechRecognition,nativeBridge:env.nativeBridge,online:env.online
      },attempts:ids.map(id=>({id,events:trace.filter(r=>r.data.sessionId===id).map(({at,event,data})=>{
        const {sessionId,...detail}=data;return {at,event,...detail};
      })}))},null,2);
    },
    clear(){rows=[];persist();log('debug','cleared');},
    subscribe(fn){listeners.add(fn);return()=>listeners.delete(fn);},flush:persist};
  g.KamDebug=api;
  // Future Android builds can send structured permission/recorder details here.
  g.kamNativeDebug=(event,payload={})=>log('android',String(event),payload,payload.level||'info');
  if(g.addEventListener){
    g.addEventListener('error',e=>api.error('window','error',e.error||new Error(e.message),{file:e.filename,line:e.lineno,column:e.colno}));
    g.addEventListener('unhandledrejection',e=>api.error('window','unhandledrejection',e.reason));
    for(const event of ['online','offline','focus','blur','pageshow'])g.addEventListener(event,()=>log('lifecycle',event,{visible:g.document?.visibilityState}));
    g.addEventListener('pagehide',()=>{log('lifecycle','pagehide');persist();});
  }
  g.document?.addEventListener('visibilitychange',()=>log('lifecycle','visibilitychange',{state:g.document.visibilityState}));
  if(typeof g.fetch==='function'){
    const fetch=g.fetch.bind(g);
    g.fetch=async function(input,init){
      const started=Date.now(),id='net-'+(++seq);let target='unknown';
      try{const u=new URL(typeof input==='string'?input:input.url,g.location?.href);target=u.origin+u.pathname;}catch{}
      log('network','request',{id,url:target,method:init?.method||input?.method||'GET'});
      try{const response=await fetch(input,init);log('network','response',{id,status:response.status,ok:response.ok,type:response.type,elapsedMs:Date.now()-started},response.ok?'info':'error');return response;}
      catch(error){api.error('network','failed',error,{id,elapsedMs:Date.now()-started,handling:'核對網絡、服務網址與 CORS；瀏覽器未必提供底層拒絕原因。'});throw error;}
    };
  }
  log('app','boot',{version:9,revision:'9.5',retainedEntries:rows.length});
  inspect('boot');
})(globalThis);

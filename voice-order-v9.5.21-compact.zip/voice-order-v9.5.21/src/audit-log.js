/* Complete append-only diagnostic history. UI caches may be bounded; this
 * IndexedDB journal is never automatically trimmed. Credentials/audio omitted. */
(function(g){
 'use strict';
 const secretKey=/password|authorization|api.?key|^key$|token|base64|^audio(?:data)?$/i;
 class Store{
  constructor({adapter,indexedDB=g.indexedDB}={}){
   this.pending=new Map();this.pendingStates=new Map();this.latest=new Map();this.fingerprints=new Map();this.secrets=new Set();this.serial=0;
   this.session=(g.crypto?.randomUUID?.()||Date.now().toString(36)+'-'+Math.random().toString(36).slice(2));
   this.status='opening';this.error=null;this.queue=Promise.resolve();
   this.ready=(async()=>{
    try{
     if(adapter)this.adapter=adapter;
     else{
      if(!indexedDB)throw Error('IndexedDB unavailable');
      const db=await new Promise((resolve,reject)=>{
       const request=indexedDB.open(g.KamLocale?.databaseName||'smart-cafe-audit-v1',2);
       request.onupgradeneeded=()=>{const d=request.result;if(!d.objectStoreNames.contains('events'))d.createObjectStore('events',{keyPath:'id'});if(!d.objectStoreNames.contains('latest'))d.createObjectStore('latest',{keyPath:'key'});const latest=request.transaction.objectStore('latest');if(!latest.indexNames.contains('sourceAt'))latest.createIndex('sourceAt',['source','at']);};
       request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error);request.onblocked=()=>reject(Error('Audit database upgrade blocked'));
      });
      this.adapter={
       checkpoints:true,
       write:(batch,states=[])=>new Promise((resolve,reject)=>{
        const tx=db.transaction(['events','latest'],'readwrite');
        for(const row of batch){tx.objectStore('events').put(row);if(row.key)tx.objectStore('latest').put({key:row.key,source:row.source,at:row.data.at||row.at,value:row.data});}for(const state of states)tx.objectStore('latest').put(state);
        tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error||Error('Audit transaction aborted'));
       }),
       recent:(source,limit)=>new Promise((resolve,reject)=>{const tx=db.transaction('latest','readonly'),rows=[],range=g.IDBKeyRange.bound([source,''],[source,'\uffff']),request=tx.objectStore('latest').index('sourceAt').openCursor(range,'prev');request.onsuccess=()=>{const cursor=request.result;if(cursor&&rows.length<limit){rows.push(cursor.value.value);cursor.continue();}};tx.oncomplete=()=>resolve(rows);tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error||Error('Audit history read aborted'));}),
       get:key=>new Promise((resolve,reject)=>{const tx=db.transaction('latest','readonly'),request=tx.objectStore('latest').get(key);request.onsuccess=()=>resolve(request.result?.value);request.onerror=()=>reject(request.error);}),
       read:()=>new Promise((resolve,reject)=>{
        const tx=db.transaction(['events','latest'],'readonly'),events=tx.objectStore('events').getAll(),latest=tx.objectStore('latest').getAll();
        tx.oncomplete=()=>resolve({events:events.result,latest:latest.result});tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error||Error('Audit read aborted'));
       }),
      };
     }
     if(this.adapter.get)this.recoveredEvolution=await this.adapter.get('state:evolution');
     this.status='persistent';
    }catch(error){this.status='memory-only';this.error=String(error?.message||error);}
   })();
  }
  addSecret(value){if(value)this.secrets.add(String(value));}
  sanitize(value,key='',seen=new WeakSet()){
   if(secretKey.test(key))return '[REDACTED]';
   if(typeof value==='string'){
    let text=value;for(const secret of this.secrets)if(secret)text=text.split(secret).join('[REDACTED]');
    text=text.replace(/Bearer\s+[^\s"',}]+/gi,'Bearer [REDACTED]').replace(/\bsk-[\w-]{8,}\b/g,'[REDACTED]').replace(/data:audio\/[^;]+;base64,[A-Za-z0-9+/=]+/g,'[AUDIO REDACTED]');
    return text;
   }
   if(value==null||typeof value==='number'||typeof value==='boolean')return value;
   if(typeof value!=='object')return String(value);
   if(g.Blob&&value instanceof g.Blob)return {type:value.type,bytes:value.size};
   if(seen.has(value))return '[circular]';seen.add(value);
   let result;
   if(value instanceof Error||/\[object (?:Error|DOMException)\]/.test(Object.prototype.toString.call(value)))result=this.sanitize({name:value.name,message:value.message,code:value.code,data:value.data,stack:value.stack},'',seen);
   else result=Array.isArray(value)?value.map(item=>this.sanitize(item,'',seen)):Object.fromEntries(Object.keys(value).map(name=>[name,this.sanitize(value[name],name,seen)]));
   seen.delete(value);return result;
  }
  append(source,event,value,key){
   const data=this.sanitize(value),fingerprint=key&&JSON.stringify(data);
   if(key&&this.fingerprints.get(key)===fingerprint)return;
   if(key){this.fingerprints.set(key,fingerprint);this.latest.set(key,data);}
   const row={id:this.session+'-'+String(++this.serial).padStart(10,'0'),session:this.session,sequence:this.serial,at:new Date().toISOString(),source,event,...(key?{key}:{}),data};
   this.pending.set(row.id,row);
   this.queue=this.queue.then(async()=>{
    await this.ready;if(!this.adapter)return;
    const batch=[...this.pending.values()],states=[...this.pendingStates.values()];if(!batch.length&&!states.length)return;
    try{if(this.adapter.checkpoints)await this.adapter.write(batch,states);else await this.adapter.write([...batch,...states.map(state=>({id:this.session+'-checkpoint-'+state.key,session:this.session,sequence:this.serial,at:state.at,source:'state',event:'checkpoint',key:state.key,data:state.value}))]);for(const item of batch)this.pending.delete(item.id);for(const state of states)if(this.pendingStates.get(state.key)===state)this.pendingStates.delete(state.key);this.status='persistent';this.error=null;}
    catch(error){this.status='memory-only';this.error=String(error?.message||error);}
   });
   return row.id;
  }
  record(source,id,value){return this.append(source,'record',value,source+':'+id);}
  state(name,value){const snapshot=this.sanitize(value),key='state:'+name,at=new Date().toISOString();this.latest.set(key,snapshot);this.pendingStates.set(key,{key,source:'state',at,value:snapshot});return this.append('state',name,{checkpoint:key,language:snapshot.language,activeVersion:snapshot.active?.version,remoteVersion:snapshot.remote?.version,cases:snapshot.cases?.length,events:snapshot.events?.length,last:snapshot.last?{id:snapshot.last.id,status:snapshot.last.status}:undefined});}
  async recent(source,limit=100){
   await this.ready;await this.queue;let rows=[];
   if(this.adapter?.recent)rows=await this.adapter.recent(source,limit);else if(this.adapter){const saved=await this.adapter.read();rows=saved.latest.filter(row=>row.key.startsWith(source+':')).map(row=>row.value);}
   const found=new Map(rows.map(row=>[row.id,row]));for(const [key,value]of this.latest)if(key.startsWith(source+':'))found.set(value.id,value);
   return [...found.values()].sort((a,b)=>String(b.at||b.updated||'').localeCompare(String(a.at||a.updated||''))).slice(0,limit);
  }
  async read(){
   await this.ready;await this.queue;
   let saved={events:[],latest:[]};
   if(this.adapter){try{saved=await this.adapter.read();}catch(error){throw Object.assign(Error('Unable to read complete audit history'),{code:'auditReadFailed',cause:error});}}
   const rows=new Map(saved.events.map(row=>[row.id,row]));for(const row of this.pending.values())rows.set(row.id,row);
   const latest=new Map(saved.latest.map(row=>[row.key,row.value]));for(const [key,value]of this.latest)latest.set(key,value);
   return {schema:'smart-cafe-full-audit-v1',appVersion:'9.5.21',exportedAt:new Date().toISOString(),
    coverage:{persistent:this.status==='persistent',status:this.status,error:this.error,pending:this.pending.size,pendingCheckpoints:this.pendingStates.size,automaticDeletion:false,checkpointPolicy:'Latest full state is retained separately; every voice/API/learning event and state-change summary remains append-only.',
     historyNote:'Full history recorded from v9.5.21 onward plus imported retained legacy records. Details deleted by earlier versions cannot be reconstructed. Audio and credentials are excluded.'},
    events:[...rows.values()].sort((a,b)=>a.at.localeCompare(b.at)||a.session.localeCompare(b.session)||a.sequence-b.sequence),latest:Object.fromEntries(latest)};
  }
 }
 const store=new Store();
 g.KamAudit=store;g.KamAudit.Store=Store;
})(globalThis);

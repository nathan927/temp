# 智能茶餐廳 v9.5.21 精簡包

將 `智能茶餐廳-v9.5.21.html` 更新至現有 HTTPS 網站入口；可改名為 `index.html`。只含今版程式、源碼、可重跑測試及本輪結果。

| 頁面 | 下單語言 | 裝置語言 | 私有規則 |
|---|---|---|---|
| `?lang=tc` 繁體 | 廣東話 | zh-HK | `src/locales/tc/` |
| `?lang=sc` 简体 | 普通话 | zh-CN | `src/locales/sc/` |
| `?lang=en` English | English | en-HK | `src/locales/en/` |

三種語言各有自己的解析器、詞庫、手工配對、學習、設定、餐單及紀錄。切頁會載入獨立引擎；API key 仍只在當頁記憶體。儲存命名空間維持 v20 schema，方便承接 v9.5.20 的同語言資料，不會把三種語言合併。

本輪新增三語各一萬個介面情境，涵蓋點餐、近音、多人長單、修改中間餐點、照跟、取消、部分聽清、澄清、API 學習／失敗、手工配對、收尾及導航覆單。預期澄清／拒絕會獨立列明，不當作成功落單。每頁有 4,018 條不同的一般指令，其餘短指令於不同餐單上下文測試。

Node.js 24：

```sh
npm ci --ignore-scripts
npm run build
npm run test:three-languages
npm run test:three-languages:verify
node scripts/verify-release.mjs
```

可設 `VOICE_TEST_CONCURRENCY=1`、`2` 或 `3`；預設兩種語言同時測。整套會跑大量實際 DOM 流程，需時較長。每完成 500 個便更新 `verification/<lang>-final-checkpoint.json`。測試使用模擬收音與假供應商回應，不消耗真實 API 額度。

完整案例及期望位於 `acceptance/three-languages/`；`verification/three-languages-final.json` 索引每語言總數及全部主紀錄。詳細修正、結果及限制見本版報告。

部分學習／除錯快照儲存已改善：保留每次語音、API、學習及狀態變動事件；完整當前狀態以最新 checkpoint 保留。這避免在缺少 IndexedDB 時，對每次變動重複保存整份狀態而耗盡記憶體。下載仍讀取完整操作歷史，列表最多顯示 100 條。

未知飲食或過敏要求不能被默默丟棄；未確定時先問清楚，不以一般加餐方案蓋過要求。這不代表店舖能保證食物沒有過敏原。

連續收音預設開啟，可在設定關閉。收尾詞或七秒無語音會停止收音，保留餐單，確認按鈕才送單。真實手機權限及辨識效果仍需按 `docs/` 真機清單驗證。

舊共用資料可在設定逐項分類或匯出；不同語言備份及學習包不能直接套用。若接駁訂單後端，須支援 `X-Voice-Language`、相符 `language` 及 `capabilities.languageIsolation`。詳見 `docs/language-isolation.md`。
